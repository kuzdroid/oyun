# iPhone sürümünü Mac olmadan derlemek (Codemagic)

Codemagic, projeyi kendi bulut Mac'lerinde derleyip App Store Connect'e yükler. Sen her şeyi Windows'tan, tarayıcıyla yaparsın.

## Gerekenler

- **Apple Developer hesabı** (yıllık 99 dolar): https://developer.apple.com/programs/
  App Store'a koymak için her durumda gerekir; bunun başka yolu yok.
- **GitHub hesabı** (ücretsiz): https://github.com
- **Codemagic hesabı**: https://codemagic.io
  GitHub hesabınla giriş yapılır. Bireysel kullanım için ücretsiz bir aylık derleme süresi var; güncel kota sitede yazar.

## 1. Apple tarafı

1. **Uygulama kimliğini kaydet:** https://developer.apple.com/account adresinde Certificates, IDs & Profiles bölümüne gir. Identifiers'ta **+** düğmesine bas, App IDs'i seç.
   - Bundle ID olarak `com.yesilvadi.ormaninkalbi` yaz (Explicit).
2. **Uygulamayı oluştur:** https://appstoreconnect.apple.com adresinde Uygulamalar bölümünde **+** düğmesine bas, Yeni Uygulama'yı seç.
   - Platform: iOS
   - Ad: `Ormanın Kalbi`
   - Dil: Türkçe
   - Bundle ID: az önce kaydettiğin kimlik
   - SKU: `ormaninkalbi`
3. **API anahtarı oluştur:** App Store Connect'te Kullanıcılar ve Erişim, ardından Entegrasyonlar sekmesine gir. App Store Connect API bölümünde **+** düğmesine bas.
   - Ad: `Codemagic`
   - Erişim: **App Manager**
   - Şunları bir yere not et: **Issuer ID** ve **Key ID**. Bir de `.p8` dosyasını indir; bu dosya yalnızca bir kez indirilebilir.

## 2. Projeyi GitHub'a koy

1. GitHub'da **New repository** düğmesine bas.
   - Ad: `ormanin-kalbi`
   - Görünürlük: **Private**
2. Yeni depoda **uploading an existing file** bağlantısına tıkla.
3. Zip'ten çıkan `OrmaninKalbi` klasörünün **içindeki her şeyi** sürükleyip bırak. `codemagic.yaml` en üst düzeyde durmalı.
4. **Commit changes** düğmesine bas.

## 3. Codemagic tarafı

1. https://codemagic.io adresinde GitHub ile giriş yap. **Add application** düğmesine bas ve `ormanin-kalbi` deposunu seç.
   - Proje türü sorulursa "codemagic.yaml" ile yapılandırmayı seç.
2. **API anahtarını ekle:** Team settings, ardından Team integrations bölümünde Developer Portal'ı bul ve **Manage keys** düğmesine bas, sonra **Add key**.
   - Name: `OrmaninKalbi` (codemagic.yaml dosyasındaki adla aynı olmalı)
   - 1. adımda not ettiğin Issuer ID ve Key ID'yi gir, `.p8` dosyasını yükle.
3. **İmza dosyalarını oluştur:** Team settings, ardından codemagic.yaml settings, ardından Code signing identities bölümüne gir.
   - **iOS certificates** sekmesinde "Generate certificate" ile Apple Distribution türünde bir sertifika oluştur.
   - **iOS provisioning profiles** sekmesinde "Fetch profiles" ile `com.yesilvadi.ormaninkalbi` için App Store profilini getir. Profil yoksa önce Apple Developer sitesinde Profiles bölümünde **+** düğmesine basıp App Store Connect türünde bir profil oluştur, sonra tekrar getir.
4. Uygulama sayfasında **Start new build** düğmesine bas ve "Ormanın Kalbi iPhone (App Store)" iş akışını seç.

Derleme yaklaşık 10–20 dakika sürer. Bitince:
- `.ipa` dosyası Codemagic'te indirilebilir olur,
- otomatik olarak **TestFlight**'a yüklenir.

## 4. Telefonda dene ve yayınla

1. iPhone'a App Store'dan **TestFlight** uygulamasını kur. App Store Connect'te TestFlight sekmesinden kendini test kullanıcısı olarak ekle; oyunu iPhone'una TestFlight'tan kurarsın.
2. Her şey yolundaysa App Store Connect'te uygulama sayfasını doldur:
   - ekran görüntüleri,
   - açıklama,
   - yaş derecelendirmesi,
   - fiyat: Ücretsiz.
3. Derlemeyi seç ve **İncelemeye Gönder** düğmesine bas.

## Güncelleme

`www` klasörünü yeni oyun dosyalarıyla değiştirip GitHub'a yükle ve Codemagic'te yeni derleme başlat. Derleme numarası her seferinde kendiliğinden artar.

## Sorun çıkarsa

Codemagic'teki kırmızı adımın günlüğünü kopyalayıp bana gönder, birlikte düzeltelim. Bu ayar dosyasını gerçek bir Codemagic hesabında deneyemedim; ilk derlemede küçük bir düzeltme gerekebilir.
