# Ormanın Kalbi: mağazaya yükleme rehberi

Paket adı (iki platformda da): `com.yesilvadi.ormaninkalbi`

## Hangi dosya nereye?

| Platform | Dosya uzantısı | Ne işe yarar | Nerede |
|---|---|---|---|
| Android | `.apk` | Telefona doğrudan kurulur (deneme, arkadaşlara gönderme) | `CIKTI/OrmaninKalbi.apk` |
| Android | `.aab` | **Google Play'e yüklenen dosya** | `CIKTI/OrmaninKalbi-PlayStore.aab` |
| iPhone | `.ipa` | **App Store'a yüklenen dosya**. Yalnızca Mac'te Xcode ile üretilir | `ios/` klasöründeki Xcode projesinden |

## Önce bunu yedekle (çok önemli)

- `imza/ormaninkalbi-yukleme.jks` (Android yükleme anahtarı)
- `android/keystore.properties` (anahtarın şifresi bu dosyada)

Bu ikisini bir USB belleğe ya da güvenli bir buluta kopyala ve kimseyle paylaşma.

## Google Play (Android)

1. **Geliştirici hesabı aç:** https://play.google.com/console adresinden açılır. Tek seferlik 25 dolar ücreti var.
2. **Uygulamayı oluştur:** "Uygulama oluştur" deyip adına `Ormanın Kalbi` yaz, oyun ve ücretsiz seçeneklerini işaretle.
3. **Mağaza sayfasını doldur:**
   - Simge olarak `magaza-simge-512.png` dosyasını kullan.
   - Kısa ve uzun açıklamayı yaz.
   - En az 2 ekran görüntüsü ekle (oyundan yatay görüntü al).
   - 1024×500 bir öne çıkan görsel ekle.
4. **Uygulama içeriği bölümü:** yaş derecelendirmesi anketini doldur. Oyun veri toplamadığı için Veri güvenliği bölümünde "veri toplanmıyor" de. Bir gizlilik politikası bağlantısı istenebilir; basit bir sayfa yeterli.
5. **Sürüm yükle:** Test, sonra Kapalı test bölümüne gelip `OrmaninKalbi-PlayStore.aab` dosyasını yükle. "Play Uygulama İmzalama"yı kabul et.
6. **Kapalı test kuralı:** Yeni kişisel hesaplarda Google, yayına almadan önce en az 12 test kullanıcısının 14 gün boyunca kapalı testte olmasını istiyor. Bu süre dolunca "Üretim" sürümüne geçebilirsin.

### Orijinal kopya kontrolünü sıkılaştırmak (isteğe bağlı)

Oyun şu durumlarda "BU KOPYA ORİJİNAL DEĞİL" uyarısı gösterir:
- uygulama içinde değil de tarayıcıda açılırsa,
- paket adı `com.yesilvadi.ormaninkalbi` değilse.

İmza sertifikası kontrolü de var, ama şu an kapalı. Sebebi şu: Google Play oyunu kendi anahtarıyla yeniden imzalıyor. Bu yüzden onun özetini bilmeden açılırsa Play'den indirenlere de uyarı çıkar.

Açmak için:
1. Play Console'da "Uygulama bütünlüğü" altındaki "Uygulama imzalama" bölümüne gir. "Uygulama imzalama anahtarı sertifikası" altındaki **SHA-256** değerini kopyala.
2. `orijinal.json` dosyasındaki listeye o değeri ve kendi yükleme anahtarının değerini ekle:
   ```json
   "androidImzaSha256": [
     "PLAY_KONSOLDAN_KOPYALANAN_SHA256",
     "FA:D5:22:42:1C:51:E6:6B:CB:3A:6D:61:C9:08:FA:6E:B3:F6:C5:47:63:5A:A5:03:F9:4F:B5:8A:7A:59:79:F9"
   ]
   ```
3. Yeniden derle (aşağıdaki "Güncelleme çıkarmak" bölümüne bak).

Böylece paket adı aynı bırakılıp başka anahtarla imzalanan kopyalar da yakalanır.

## App Store (iPhone)

Apple, `.ipa` dosyasının yalnızca **Mac'te Xcode** ile üretilmesine izin veriyor. Bu Windows bilgisayarda yapılamaz. Proje hazır; sadece bir Mac lazım (arkadaşının Mac'i ya da kiralık bir bulut Mac de olur).

1. **Geliştirici hesabı aç:** https://developer.apple.com/programs/ adresinden. Yıllık 99 dolar.
2. **Hazırlık:** Mac'e Xcode (App Store'dan ücretsiz) ve Node.js kur. Bu `uygulama` klasörünü Mac'e kopyala.
3. **Projeyi aç:** Terminalde şunları çalıştır:
   ```
   cd uygulama
   npm install
   npx cap sync ios
   npx cap open ios
   ```
4. **İmzalamayı ayarla:** Xcode'da "App" hedefini seç. "Signing & Capabilities" bölümünde Team olarak kendi hesabını seç.
5. **Arşivle ve yükle:** Üstteki cihaz seçicide "Any iOS Device" seç. Ardından Product, Archive, Distribute App, App Store Connect yolunu izle. Bu adım `.ipa`'yı üretip Apple'a yükler.
6. **App Store Connect'te yayınla:** https://appstoreconnect.apple.com adresinde ekran görüntülerini, açıklamayı ve yaş derecelendirmesini doldur, ücretsiz seç ve incelemeye gönder.

iPhone'da da oyun mağaza dışı bir kopyada (tarayıcıda açılan sürümde) aynı uyarıyı gösterir.

## Güncelleme çıkarmak (2. Bölüm geldiğinde)

1. `mobil/src` içindeki oyunu değiştir.
2. `android/app/build.gradle` içinde `versionCode` değerini 1 artır (2, 3, ...) ve `versionName` değerini güncelle ("1.1" gibi).
3. Ana klasörde şunları çalıştır:
   ```
   node mobil/build.js
   cd uygulama
   npx cap sync
   cd android
   gradlew.bat bundleRelease assembleRelease
   ```
4. Yeni `.aab` dosyası `android/app/build/outputs/bundle/release/` klasöründe çıkar.
5. iPhone için Mac'te `npx cap sync ios` çalıştır, Xcode'da sürüm numarasını artır ve yeniden Archive al.
