﻿// online katmanı olmayan derlemeler için
#include "net.h"
NetTransport* makeTransport() { return nullptr; }

