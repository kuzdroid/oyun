// ORMANIN KALBİ - kodla üretilen müzik ve ses efektleri
#pragma once
#include <mutex>
#include <vector>
#include <unordered_map>

enum {
  SFX_CHIME = 0, SFX_FIRE = 1, SFX_HURT = 2, SFX_BLIP = 3, SFX_MAGIC = 4, SFX_RUMBLE = 5, SFX_SHATTER = 6, SFX_SELECT = 7, SFX_GROAN = 8,
  SFX_STEP = 9, SFX_SHUTTER = 10, SFX_ERR = 11, SFX_BIRD = 12, SFX_CLICK = 13, SFX_GROWL = 14, SFX_SNORT = 15, SFX_SWING = 16, SFX_HIT = 17, SFX_EAT = 18, SFX_HOWL = 19,
  SFX_LAUGH = 20, SFX_SPLASH = 21,
};
struct Mood { double root; int scale[7]; int prog[4]; double chordDur, beat, arpProb, padAmp, arpAmp, bassAmp, arpOct, mel, melAmp; int drum; };

class Synth {
 public:
  bool ok = false, muted = false;
  double SR = 22050;
  // ses iş parçacığı doldurur; oyun play/setMood çağırır
  void fill(float* out, int n);
  void play(int type, double amp = 1);
  void setMood(int m);
 private:
  struct Voice { int type; double t, amp, lp; };
  struct PadC { int k = -1, mood = -1; double f[3] = { 0, 0, 0 }, fb = 0; };
  struct ArpC { long bb = -1; int mood = -1; bool play = false; double f = 0; };
  struct MelC { long bb = -1; int mood = -1, sec = -1; bool play = false; double f = 0, len = 0; };
  std::mutex mu;
  int mood = 7, nextMood = 7; double mgain = 0, master = 1, t = 0; uint32_t ns = 12345;
  std::vector<Voice> voices;
  std::unordered_map<int, double> nf;
  PadC padC[2]; ArpC arpC[8]; MelC melC[4];
  double noise();
  double noteF(const Mood& m, int deg);
  PadC& padFreqs(const Mood& m, int k);
  double chordPad(const Mood& m, int k, double tt, double env);
  ArpC& arpEv(const Mood& m, long bb);
  double music(double tt);
  MelC& melEv(const Mood& m, long bb, int sec, double step);
  double melody(const Mood& m, double tt, int k);
  double drums(const Mood& m, double tt);
  double sfx(Voice& v);
};
