// ORMANIN KALBİ - Bölüm 1-5: Oyun Adası
// 1-4'ün sonunda "SON" yazısını Sis Kralı'nın eli yakalayıp parçalar: hikâye bitmedi. Kral, Kalbin ışığını on altı Yıldız Kıvılcımı'na böldü.
// İlk kıvılcım Oyun Adası'ndaki Oyun Ustası'nda: adanın beş ustasını (dama, satranç, tavla, papaz kimde, 101 okey) yenmek gerekir.
// mainStep: 28 = 1-4 bitti, 29 Nine, 30 Kaptan Deniz, 31 Oyun Ustası, 32 beş usta, 33 ustaya dön, 34 bölüm bitti
#include "game.h"
#include "oyunlar.h"

enum { N_MASTER = 60, N_GDAMA, N_GSATRANC, N_GTAVLA, N_GPAPAZ, N_GOKEY };
static const int GW = 44, GH = 30;
static const int TABLES[5][2] = { { 11, 10 }, { 22, 7 }, { 33, 10 }, { 14, 19 }, { 30, 19 } };   // dama satranç tavla papaz okey
static const int G5_BIT[5] = { G5_DAMA, G5_SATRANC, G5_TAVLA, G5_PAPAZ, G5_OKEY };
static const char* MASTER_NAME[5] = { "Dama Dedesi Şükrü", "Satranççı Vezir Hanım", "Tavlacı Zar Ali", "Kartçı Papatya", "Okeyci Nimet Teyze" };

// ---------------- harita ----------------
void buildGameIsle(WorldMap& m) {
  m.init(GW, GH, MAP_GAMEISLE, T_WATER);
  for (int y = 0; y < GH; y++) for (int x = 0; x < GW; x++) {
    double dx = (x - 22) / 19.5, dy = (y - 14.5) / 12.5, d = dx * dx + dy * dy, wob = 0.06 * std::sin(x * 0.8 + y * 0.6);
    if (d < 0.72 + wob) m.set(x, y, T_GRASS); else if (d < 1 + wob) m.set(x, y, T_SAND); else if (d < 1.25 + wob) m.set(x, y, T_SHALLOW);
  }
  // ortada küçük meydan, masalara ve kayığa giden yollar
  for (int y = 10; y <= 17; y++) for (int x = 17; x <= 27; x++) { double dx = (x - 22) / 5.5, dy = (y - 13.5) / 3.8; if (dx * dx + dy * dy < 1) m.set(x, y, T_PATH); }
  auto line = [&](int x0, int y0, int x1, int y1) { int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0)); for (int i = 0; i <= n; i++) { int x = x0 + (x1 - x0) * i / std::max(1, n), y = y0 + (y1 - y0) * i / std::max(1, n); m.set(x, y, T_PATH); m.set(x, y + 1, T_PATH); } };
  for (auto& t : TABLES) line(22, 13, t[0], t[1] + 1);
  line(22, 16, 22, 26);
  for (int i = 0; i < 5; i++) { Obj& o = m.add(O_GAMETABLE, TABLES[i][0], TABLES[i][1], 2, 1); o.var = i; }
  for (auto p : { std::pair{ 6, 9 }, { 37, 9 }, { 8, 21 }, { 36, 21 }, { 15, 4 }, { 29, 4 } }) m.add(O_PALM, p.first, p.second).var = p.first & 1;
  for (auto p : { std::pair{ 18, 13 }, { 26, 13 } }) m.add(O_BARREL, p.first, p.second);
  m.add(O_SIGN, 24, 24, 1, 1).text = "OYUN ADASI\nBeş usta, beş oyun. Hepsini yenen,\nOyun Ustası'nın sırrını öğrenir.";
  // dönüş kayığı: güney kıyısında
  for (int y = GH - 1; y > 15; y--) if (m.get(22, y) == T_SAND && m.get(23, y) == T_SAND && (m.get(22, y + 1) != T_SAND)) { m.add(O_BOAT, 22, y, 2, 1).text = "isle"; break; }
}
void Game::enterGameIsle() {
  buildGameIsle(map);
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1; pvx = pvy = 0;
  px = 22 * 16 + 8; py = 21 * 16 + 8; pdir = 1;
  for (auto& o : map.objs) if (o->type == O_BOAT) { px = (o->tx + 1) * 16; py = (o->ty - 1) * 16 + 8; }
  placeNPCs(); setMood(5);
  if (mainStep == 30) { mainStep = 31; saveGame(); say({ L("", "Kaptan Deniz'in teknesi ağır ağır kıyıya yanaştı. Adanın ortasında masalar, masaların başında oyuncular..."), L("Arda", "Burası bir oyun adası! Oyun Ustası ortadaki meydanda olmalı.") }); }
  toast("OYUN ADASI");
}
// ---------------- "SON" yazısını parçalayan el ----------------
bool Game::twistDue() { return mainStep == 28 && !(f5 & G5_TWIST) && netRole != "guest"; }
void Game::twistStart() { if (twistT < 0) { twistT = 0; setMood(21); } }
void Game::twistEnd() {
  f5 |= G5_TWIST; mainStep = 29; twistT = -1;
  fadeTo([this] {
    state = S_PLAY; dayT = 0.9; enterOverworld(43 * 16 + 8, 57 * 16 + 4); pdir = 3; setMood(12); saveGame();
    say({ L("", "Gökyüzü yarıldı. Sisten yapılmış dev bir el, Yeşilvadi'nin üstünde yumruğunu sıktı."),
      L("Sis Kralı", "Bitti mi sandın, küçük bekçi? Sis Efendisi yalnızca benim gölgemdi."),
      L("Sis Kralı", "Kalbin ışığını on altı Yıldız Kıvılcımı'na böldüm ve dünyanın dört bir yanına saçtım. Hikâye... henüz bitmedi."),
      L("Arda", "On altı kıvılcım mı?! ...Nine! Nine'ye gitmeliyim!") },
      [this] { toast("BÖLÜM 1-5: OYUN ADASI"); });
  });
}
void Game::twistDraw() {
  double t = twistT, cx = VW / 2.0, cy = 72;
  g->rect(0, 0, W, H, rgba(4, 2, 10, 0.9));
  // SON yazısı: önce durur, sonra titrer, sonra harfleri dağılır
  const char* L3[3] = { "S", "O", "N" };
  for (int i = 0; i < 3; i++) {
    double x = cx + (i - 1) * 34, y = cy, a = 1;
    if (t > 2.6 && t < 3.6) { x += std::sin(t * 60 + i) * 2; y += std::cos(t * 50 + i) * 2; }
    if (t >= 3.6) { double k = t - 3.6; x += (i - 1) * k * 90 + (i == 1 ? 0 : 0); y += -40 * k + 140 * k * k; a = std::max(0.0, 1 - k * 0.7); }
    if (a > 0) text(L3[i], x, y - 20, 1.6, rgba(154, 240, 160, a), 1, true);
  }
  // sis eli: aşağıdan yükselir, yakalar, sıkar
  double rise = clampf(t / 2.4, 0, 1), hy = VH + 20 - rise * (VH + 20 - (cy + 4));
  double sc = 3.2 + (t > 3.4 ? std::min(0.6, (t - 3.4) * 2) : 0);
  if (t > 3.6) hy += (t - 3.6) * 10;
  const Spr* hs = A.mistHand;
  g->sprite(hs, vx(cx - hs->w * sc / 2), (hy - hs->h * sc * 0.4) * s, hs->w * sc * s, hs->h * sc * s, false, std::min(1.0, t));
  for (int k = 0; k < 6; k++) { double a = time * 2 + k; g->glow(vx(cx + std::cos(a) * 30), (hy + 10 + std::sin(a) * 8) * s, 18 * s, 0.12); }
  if (t > 4.2) {
    string msg = "Henüz bitmedi...";
    int n = (int)((t - 4.2) * 14);
    text("SİS KRALI", cx, 122, 0.3, rgba(200, 120, 255, std::min(1.0, t - 4.2)), 1, true);
    text(msg, cx, 134, 0.6, rgba(255, 90, 120, 1), 1, true, n);
  }
  if (t > 3.6 && t < 3.8) g->rect(0, 0, W, H, rgba(255, 255, 255, (3.8 - t) * 3));
}
// ---------------- bölüm akışı ----------------
string Game::objective5() {
  switch (mainStep) {
    case 28: return "Ormanın Kalbi bütün! Dilediğin gibi gez. Bütün gizli bossları buldun mu?";
    case 29: return "Bilge Nine ile konuş: Sis Kralı ve on altı kıvılcım.";
    case 30: return "Mercanköy'e git; Kaptan Deniz seni Oyun Adası'na götürsün.";
    case 31: return "Oyun Adası'nın ortasındaki Oyun Ustası ile konuş.";
    case 32: { int n = 0; for (int b : G5_BIT) if (f5 & b) n++; return fmt("Adanın beş ustasını kendi oyunlarında yen (%d/5).", n); }
    case 33: return "Oyun Ustası'na dön.";
  }
  return "Bölüm 1-6 yakında! Oyun Adası'nda istediğin kadar oyna.";
}
std::vector<string> Game::credits5() {
  return { "BÖLÜM 1-5 SONU", "", "Oyun Adası'nın beş ustası yenildi.", "İlk Yıldız Kıvılcımı Arda'nın avucunda parlıyor.",
    "On beş kıvılcım daha dünyanın dört bir yanında...", "", "Dama Dedesi Şükrü rövanş istiyor.", "Okeyci teyzeler hâlâ okeyi kimin attığını tartışıyor.", "", "",
    "BÖLÜM 1-6 YAKINDA", "", "Oynadığın için teşekkürler!" };
}
static int masterIdx(int id) { return id >= N_GDAMA && id <= N_GOKEY ? id - N_GDAMA : -1; }
void Game::playMaster(int i) {
  int kinds[5] = { MG_DAMA, MG_SATRANC, MG_TAVLA, MG_PAPAZ, MG_OKEY };
  auto start = [this, i, kinds](bool withFriend) {
    std::vector<string> rv = { MASTER_NAME[i] };
    if (kinds[i] == MG_OKEY) rv = { "Okeyci Nimet Teyze", "Saadet Teyze", "Hayriye Teyze" };
    mgStart(kinds[i], withFriend, rv, [this, i, withFriend](int w) {
      if (withFriend) { say({ L(MASTER_NAME[i], w == 99 ? "Berabere! İkiniz de iyi oynadınız." : w == 0 ? "Arda kazandı! Arkadaşın rövanş ister mi?" : "Arkadaşın kazandı! Arda, bir dahaki sefere.") }); return; }
      bool first = !(f5 & G5_BIT[i]);
      if (w == 0) {
        f5 |= G5_BIT[i]; coins += first ? 30 : 10;
        int n = 0; for (int b : G5_BIT) if (f5 & b) n++;
        say({ L(MASTER_NAME[i], first ? "Yendin beni! Al, bu oyun pulu senin. Oyun Ustası'na göster." : "Yine mi yendin? Hah! Al bakalım, cep harçlığı.") },
          [this, n, first] { if (first) toast(fmt("Oyun pulu! (%d/5)  +30 altın", n)); if (n >= 5 && mainStep == 32) { mainStep = 33; toast("Beş usta da yenildi! Oyun Ustası'na dön."); } saveGame(); });
      } else say({ L(MASTER_NAME[i], w == 99 ? "Berabere... Bir el daha?" : "Bu sefer ben kazandım. Ama pes etme; ustalık kaybederek öğrenilir.") });
    });
  };
  if (p2) ask({ L(MASTER_NAME[i], fmt("%s oynayalım mı? Kiminle oynamak istersin?", mgName(kinds[i]))) }, { "Ustayla", "Arkadaşımla", "Vazgeç" }, [start](int c) { if (c < 2) start(c == 1); });
  else ask({ L(MASTER_NAME[i], fmt("Bir el %s oynayalım mı?", mgName(kinds[i]))) }, { "Oyna", "Vazgeç" }, [start](int c) { if (c == 0) start(false); });
}
void Game::initBolum5() {
  EXT.area[MAP_GAMEISLE] = [this] { setMood(night() ? 12 : 5); };   // (EXT.mood zemini başka çizdirir; burada kullanılmaz)
  EXT.enter[MAP_GAMEISLE] = [this] { enterGameIsle(); };
  EXT.obj[O_GAMETABLE] = [this](Obj& o, double x, double y) {
    spr(A.shadow, x - 12, y - 4, false, 0.8, 2, 1);
    fillLo(x - 13, y - 14, 26, 4, hexc(0x6a3e20)); fillLo(x - 12, y - 10, 3, 8, hexc(0x5a3418)); fillLo(x + 9, y - 10, 3, 8, hexc(0x5a3418));
    fillLo(x - 13, y - 18, 26, 5, hexc(0x9a6438));
    switch (o.var) {
      case 0: case 1: for (int i = 0; i < 8; i++) fillLo(x - 8 + i * 2, y - 18 + (i & 1), 2, 2, (i & 1) ? hexc(0xe8cc90) : hexc(0x302018)); break;
      case 2: fillLo(x - 9, y - 18, 18, 4, hexc(0xd8b880)); fillLo(x - 1, y - 18, 2, 4, hexc(0x5a3a1e)); break;
      case 3: fillLo(x - 7, y - 19, 5, 6, hexc(0xfaf8f0)); fillLo(x - 1, y - 19, 5, 6, hexc(0x2a4a9a)); break;
      default: for (int i = 0; i < 4; i++) fillLo(x - 9 + i * 5, y - 19, 4, 5, hexc(0xf6f0dc)); break;
    }
  };
  EXT.interact[O_GAMETABLE] = [this](Obj& o) { say({ L("", fmt("%s masası. Ustasıyla konuş.", mgName(o.var == 0 ? MG_DAMA : o.var == 1 ? MG_SATRANC : o.var == 2 ? MG_TAVLA : o.var == 3 ? MG_PAPAZ : MG_OKEY))) }); };
  // kayıklar: ada ile Mercanköy arası
  auto oldBoat = EXT.interact[O_BOAT];
  EXT.interact[O_BOAT] = [this, oldBoat](Obj& o) {
    if (fadeState) return;
    if (o.text == "isle") { ask({ L("", "Tekneyle Mercanköy'e dönmek ister misin?") }, { "Dön", "Kal" }, [this](int c) { if (!c) fadeTo([this] { enterSea(12 * 16 + 8, 36 * 16 + 4); pdir = 0; }); }); return; }
    if (o.text == "ferry") { ask({ L("", "Kaptan Deniz'in teknesi. Oyun Adası'na gitmek ister misin?") }, { "Git", "Kal" }, [this](int c) { if (!c) fadeTo([this] { enterGameIsle(); }); }); return; }
    if (oldBoat) oldBoat(o);
  };
  EXT.npcs.push_back([this] {
    if (map.kind == MAP_GAMEISLE) {
      addNPC(N_MASTER, 22, 12, A.cloudGuard, "Oyun Ustası Bilmece");
      static const int SPR[5] = { 3, 13, 7, 5, 1 };
      for (int i = 0; i < 5; i++) addNPC(N_GDAMA + i, TABLES[i][0] + (i == 1 ? 0 : 0), TABLES[i][1] - 1, A.villager[SPR[i]], MASTER_NAME[i], i >= 3);
    }
  });
  // Mercanköy'e ada teknesi (bölüm 1-5)
  EXT.tick.push_back([this](double) {
    if (map.kind == MAP_SEA && mainStep >= 30) {
      bool has = false; for (auto& o : map.objs) if (o->alive && o->type == O_BOAT && o->text == "ferry") has = true;
      if (!has) for (int y = 38; y <= 46 && !has; y++) for (int x = 8; x <= 22 && !has; x++)
        if (map.get(x, y) == T_SAND && map.get(x + 1, y) == T_SAND && !map.blk[y * map.W + x] && !map.blk[y * map.W + x + 1] && (map.get(x, y + 1) == T_WATER || map.get(x, y + 1) == T_SHALLOW)) { map.add(O_BOAT, x, y, 2, 1).text = "ferry"; has = true; }
    }
    // kayıtlı oyun 1-4'ün sonundaysa el sahnesi bir kez oynar
    if (twistDue() && state == S_PLAY && !dlg && !fadeState && !mg) { twistWait += 1 / 60.0; if (twistWait > 2.5) { state = S_CREDITS; creditsT = 30; twistStart(); } }
  });
  auto pre = [this](int id, std::function<bool()> f) {
    auto old = EXT.talkPre.count(id) ? EXT.talkPre[id] : nullptr;
    EXT.talkPre[id] = [f, old](Npc* n) { if (n && f()) return true; return old ? old(n) : false; };
  };
  pre(N_ELDER, [this] {
    if (mainStep == 29) {
      say({ L("Bilge Nine", "Arda! O el... Gökyüzünü yırtan o el... Sis Kralı. Annem anlatırdı ama masal sanırdım."),
        L("Bilge Nine", "Kalbin ışığını on altı kıvılcıma bölmüş. Her biri dünyanın başka bir köşesinde, başka bir bekçinin elinde."),
        L("Baba", "Kıvılcımların izini bilen biri var: Oyun Adası'nın ustası. Gençken ona bir el tavla kaybetmiştim... ve bir de kılıcımı."),
        L("Bilge Nine", "Ada denizin ortasında. Mercanköy'e git; Kaptan Deniz yolu bilir."),
        L("Arda", "Yine mi deniz? Peki... Kılıcım hazır. Ama tavlada pek iyi değilim.") },
        [this] { mainStep = 30; toast("Mercanköy'e git: Kaptan Deniz seni Oyun Adası'na götürecek."); saveGame(); });
      return true;
    }
    return false;
  });
  pre(N_CAPTAIN, [this] {
    if (mainStep != 30) return false;
    ask({ L("Kaptan Deniz", "Oyun Adası mı? Hah! Oranın ustası bana yirmi yıldır bir dama borcu var. Teknem iskelenin güneyinde. Hemen gidelim mi?") }, { "Gidelim", "Sonra" },
      [this](int c) { if (!c) fadeTo([this] { enterGameIsle(); }); });
    return true;
  });
  EXT.talk[N_MASTER] = [this](Npc&) {
    if (mainStep <= 31) {
      say({ L("Oyun Ustası Bilmece", "Hoş geldin, bekçi. Sis Kralı'nın elini gördüm; gökyüzü bile titredi."),
        L("Oyun Ustası Bilmece", "Evet, ilk Yıldız Kıvılcımı bende. Onu bir oyun pulunun içine sakladım; Sis Kralı oyun oynamayı bilmez, bulamaz."),
        L("Oyun Ustası Bilmece", "Ama kıvılcımı yalnızca adanın beş ustasını kendi oyunlarında yenene veririm. Kural kuraldır."),
        L("Oyun Ustası Bilmece", "Dama, satranç, tavla, papaz kimde ve 101 okey. Arkadaşınla gelirsen ustalar onunla da oynar; ama pulu ancak ustayı yenince alırsın."),
        L("Arda", "Kılıçla değil, akılla... Ayna Şövalyesi de böyle demişti. Peki, başlayalım!") },
        [this] { mainStep = std::max(mainStep, 32); toast("Adanın beş ustasını yen!"); saveGame(); });
      return;
    }
    if (mainStep == 32) { int n = 0; for (int b : G5_BIT) if (f5 & b) n++; say({ L("Oyun Ustası Bilmece", fmt("%d ustayı yendin. Beşi de lazım. Acele etme; iyi oyuncu sabırlıdır.", n)) }); return; }
    if (mainStep == 33) {
      say({ L("Oyun Ustası Bilmece", "Beş usta, beş oyun... Hepsini yendin. Kural kuraldır."),
        L("", "Usta cebinden ışıldayan bir oyun pulu çıkardı. Pul ikiye ayrıldı; içinden yıldız gibi parlayan bir kıvılcım süzüldü."),
        L("Oyun Ustası Bilmece", "İlk Yıldız Kıvılcımı. Kalan on beşi dünyanın dört bir yanında. Her birinin başında bir bekçi, bir bilmece, bir oyun var."),
        L("Oyun Ustası Bilmece", "Bir de... Babana söyle: tavla borcunu unutmadım. Kılıcını hâlâ saklıyorum."),
        L("Arda", "Babamın kılıcı mı? ...Onu da bir gün kazanacağım!") },
        [this] { mainStep = 34; f5 |= G5_MASTER; maxHp += 2; hp = maxHp; showItem(A.spark, "İLK YILDIZ KIVILCIMI! +1 kalp kabı"); saveGame();
          fadeTo([this] { state = S_CREDITS; creditsT = 0; setMood(5); }); });
      return;
    }
    say({ L("Oyun Ustası Bilmece", "Kıvılcım sende. Ama masalar boş durmasın; istediğin zaman bir el oyna!") });
  };
  for (int i = 0; i < 5; i++) EXT.talk[N_GDAMA + i] = [this, i](Npc&) {
    if (mainStep < 32) { say({ L(MASTER_NAME[i], "Önce Oyun Ustası ile konuş, delikanlı. Ada'nın kuralları var.") }); return; }
    playMaster(i);
  };
}
