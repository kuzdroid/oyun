// ORMANIN KALBİ - 2. Bölüm: Karlı Dağlar
// Ayazköy, Yeti, Ateş Taşı, Alev Feneri, buz duvarları, Buz Tapınağı ve Buz Devi; yan görevler: keçiler, donmuş gezgin, kurt sürüsü
#include "game.h"

static const double GP_X0 = 53 * 16, GP_X1 = 57 * 16, GP_Y0 = 40 * 16, GP_Y1 = 44 * 16;   // keçi ağılının içi (piksel)
static const double YETI_HOME[2] = { 14 * 16 + 8, 12 * 16 + 8 };

string Game::objective2() {
  switch (mainStep) {
    case 6: return "Bilge Nine ile konuş: yeni bir yolculuk başlıyor.";
    case 7: return "Tapınağın doğusundaki Kuzey Geçidi'nden Karlı Dağlar'a çık, Ayazköy'ü bul.";
    case 8: return "Kuzeybatıdaki mağaranın önünde Yeti'yi yen, Ateş Taşı'nı geri al.";
    case 9: return "Ateş Taşı'nı Ayazköy'deki Demirci Bora'ya götür.";
    case 10: return "Alev Feneri ile buz duvarını erit, Buz Tapınağı'na gir.";
    case 11: return "Buz Tapınağı'nda Kalbin ikinci parçasını bul.";
    case 12: return "Kalbin ikinci parçasını Yeşilvadi'deki Bilge Nine'ye götür.";
  }
  return objective3();
}

// ---------------- haritalar ----------------
void Game::enterSnow(double x, double y) {
  WorldMap& m = map;
  buildSnow(m); populateSnow(m, iceMask);
  interior = -1;
  ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1;
  pvx = pvy = 0;
  EACH(o, m.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  if (flags & F2_TRAVELER) EACH(o, m.objs) if (o.type == O_FROZEN && o.alive) m.removeObj(o);
  px = x; py = y;
  placeNPCs();
  for (int i = 0; i < 3; i++) {
    bool done = qs[Q_GOAT] == 2;
    Ent& gt = done ? spawn(E_GOAT, GP_X0 + 12 + i * 18, GP_Y0 + 20 + (i % 2) * 14) : spawn(E_GOAT, (58 + i * 3) * 16, (20 + i * 4) * 16);
    gt.state = done ? 3 : 0;
  }
  if (mainStep < 13) {
    scatterEnemies(E_ICESLIME, 5, 48, 10, 68, 36); scatterEnemies(E_ICESLIME, 4, 4, 42, 24, 54);
    scatterEnemies(E_SNOWWOLF, 2, 50, 12, 68, 30); scatterEnemies(E_ICEBAT, 3, 28, 8, 44, 18);
    scatterEnemies(E_ICESLIME, 3, 8, 12, 24, 22);
    if (mainStep >= 8 && !(flags & F2_YETI)) { Ent& yt = spawn(E_YETI, YETI_HOME[0], YETI_HOME[1]); yt.hx = YETI_HOME[0]; yt.hy = YETI_HOME[1]; }
    if (night()) spawnNight2();
  }
  camX = clampf(px - VW / 2.0, 0, m.W * 16 - VW); camY = clampf(py - VH / 2.0, 0, m.H * 16 - VH);
  setMood(night() ? 12 : 8);
  if (mainStep == 6 || mainStep == 7) mainStep = 7;
  if (!(flags & F2_SNOWINTRO)) {
    flags |= F2_SNOWINTRO;
    say({ L("", "2. BÖLÜM: KARLI DAĞLAR"),
      L("", "Geçidin ardında her şey bembeyazdı. Rüzgâr ıslık çalıyor, çamların dalları karın ağırlığıyla eğiliyordu."),
      L("Arda", "Brr... Nine haklıymış, burası bambaşka bir dünya. Aşağıda bir köy var, dumanı tütüyor. Ayazköy olmalı.") });
  }
  saveGame();
}
void Game::enterIceTemple() {
  WorldMap& m = map;
  buildIceTemple(m, rooms);
  interior = -1;
  ents.clear(); picks.clear(); pts.clear(); npcs.clear();
  pvx = pvy = 0;
  EACH(o, m.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  for (int i = 0; i < m.W * m.H; i++) { int lid = m.lockId[i]; if (lid && ((doorMask >> lid) & 1)) m.t[i] = T_DOOR_OPEN; }
  if (flags & F2_BLOCK) { EACH(o, m.objs) if (o.type == O_BLOCK) moveBlockTo(o, RW * 2 + 15, RH + 5); addRoomChest(5, 21, 10, 3); }
  if (flags & F2_TORCH) { EACH(o, m.objs) if (o.type == O_TORCH && o.tx >= RW * 2 && o.ty >= RH * 2) o.var = 0; addRoomChest(8, 19); }
  px = RW * 16 + RW * 8; py = (RH * 2 + RH - 3) * 16; pdir = 1;
  curRoom = -1;
  enterRoom(roomOf(px, py), true);
  camX = (curRoom % 3) * RW * 16 - (VW - RW * 16) / 2.0; camY = (curRoom / 3) * RH * 16 - (VH - RH * 16) / 2.0;
  if (mainStep < 11) mainStep = 11;
  saveGame();
}
void Game::enterRoom2(int r, bool instant) {
  curRoom = r;
  roomT = instant ? 0 : 0.5;
  ents.clear();
  bool boss = r == 1 && !golemDead;
  if ((clear2 >> r) & 1) { setMood(boss ? 11 : 10); return; }
  double ox = (r % 3) * RW * 16, oy = (r / 3) * RH * 16;
  auto at = [&](int type, double tx, double ty) { spawn(type, ox + tx * 16 + 8, oy + ty * 16 + 12).room = r; };
  switch (r) {
    case 7: at(E_ICESLIME, 5, 5); at(E_ICESLIME, 14, 5); break;
    case 6: at(E_ICEBAT, 8, 4); at(E_ICEBAT, 13, 6); break;
    case 8: at(E_SNOWWOLF, 9, 5); at(E_SNOWWOLF, 11, 7); at(E_ICESLIME, 10, 4); break;
    case 4: at(E_ICESLIME, 5, 4); at(E_ICESLIME, 14, 4); at(E_ICESLIME, 10, 7); at(E_ICEBAT, 6, 7); at(E_ICEBAT, 13, 7); at(E_SKEL, 10, 5); break;
    case 3: at(E_SKEL, 12, 4); at(E_SKEL, 14, 7); at(E_ICEBAT, 11, 6); break;
    case 5: at(E_SNOWWOLF, 6, 4); at(E_SNOWWOLF, 13, 8); break;
    case 0: at(E_ICEBAT, 6, 5); at(E_ICEBAT, 12, 4); at(E_ICEBAT, 9, 8); at(E_SKEL, 7, 6); at(E_SKEL, 13, 6); break;
    case 2: at(E_ICESLIME, 5, 6); at(E_ICESLIME, 14, 6); at(E_ICESLIME, 10, 8); break;
    case 1: if (!golemDead) { at(E_GOLEM, 9.5, 4); toast("BUZ DEVİ uyandı!"); sfx(SFX_RUMBLE); shake = 0.5; } break;
  }
  if (ents.empty()) clear2 |= 1u << r;
  setMood(boss ? 11 : 10);
  if (r == 0) toast("Zifiri karanlık... Alev Feneri yolunu aydınlatıyor.");
}
void Game::roomCleared2(int r) {
  clear2 |= 1u << r; sfx(SFX_MAGIC);
  if (r == 4) { openLock(11); toast("Buz kapılar çatırdayarak açıldı!"); shake = 0.3; sfx(SFX_RUMBLE); }
  saveGame();
}
void Game::spawnNight2() {
  if (mainStep >= 13) return;
  scatterEnemies(E_SNOWWOLF, 4, 48, 10, 68, 34); scatterEnemies(E_SNOWWOLF, 3, 4, 40, 24, 54);
  scatterEnemies(E_SNOWWOLF, 2, 6, 10, 24, 22); scatterEnemies(E_ICEBAT, 2, 30, 24, 60, 34);
}
void Game::placeNPCs2() {
  bool n = night(); WorldMap& m = map;
  if (m.kind == MAP_SNOW) {
    if (!n) {
      addNPC(N_MUHTAR, 43, 40, A.muhtar, "Muhtar Ayaz");
      addNPC(N_SMITH, 46, 45, A.smith, "Demirci Bora", true);
      addNPC(N_SHEPHERD, 49, 43, A.shepherd, "Çoban Lale");
      if (flags & F2_TRAVELER) addNPC(N_TRAVELER, 33, 47, A.traveler, "Gezgin Rüzgâr");
    }
    addNPC(N_HUNTER, 29, 48, A.hunter, "Avcı Tolga");
  } else if (m.kind == MAP_INTERIOR && interior == 3) {
    addNPC(N_INNKEEP, 10, 3, A.innkeep, innName());
    if ((flags & F2_TRAVELER) && n) addNPC(N_TRAVELER, 6, 7, A.traveler, "Gezgin Rüzgâr", true);
  }
  for (auto& f : EXT.npcs) f();
}

// ---------------- alan, geçişler ----------------
void Game::updateArea2() {
  int tx = (int)std::trunc(px / 16), ty = (int)std::trunc(py / 16);
  if (mainStep >= 13) setMood(5);
  else if (night()) setMood(12);
  else if (tx > 25 && tx < 48 && ty > 33 && ty < 53) setMood(9);
  else setMood(8);
  if (qs[Q_GOAT] == 1) {
    int n = 0;
    EACH(e, ents) if (e.alive && e.type == E_GOAT) {
      bool inside = e.x > GP_X0 && e.x < GP_X1 && e.y > GP_Y0 + 4 && e.y < GP_Y1 + 4;
      if (inside && e.state != 3) { e.state = 3; sfx(SFX_CHIME, 0.5); burst(1, e.x, e.y - 8, 4, 0xffffff); }
      if (e.state == 3) n++;
    }
    if (n != qc[Q_GOAT]) { qc[Q_GOAT] = n; toast(fmt("Ağıldaki keçiler: %d/3", n)); }
  }
}
void Game::checkTransitions2(int tx, int ty, bool up, bool down) {
  WorldMap& m = map;
  if (m.get(tx, ty) == T_PASS && down && py > (SH - 2) * 16 && fadeState == 0) {
    sfx(SFX_CLICK); fadeTo([this] { enterOverworld(PASS_X * 16 + 16, 12 * 16 + 8); pdir = 0; });
    return;
  }
  EACH(o, m.objs) if (o.alive && o.type == O_CABIN && up && tx == o.tx + 1 && std::fabs(py - o.y) < 14 + PHH) {
    if (o.text == "3") { if (fadeState == 0) { int rx = o.tx + 1, ry = o.ty + 3; sfx(SFX_CLICK); fadeTo([this, rx, ry] { enterInterior(3, rx, ry); }); } }
    else if (toastT <= 0) toast(o.text == "M" ? "Muhtar'ın evi. Kapı kilitli; Muhtar dışarıda olmalı." : "Avcı Tolga'nın kulübesi. İçeriden kurt postu kokusu geliyor.");
    return;
  }
  if (tx >= 34 && tx <= 36 && ty <= 7 && up && py < 7 * 16 + 14) {
    if (!hasFireLantern) { if (toastT <= 0) toast("Tapınağın kapısı kalın bir buzla kaplı. Sönmeyen bir alev lazım."); }
    else if (mainStep >= 13) { if (toastT <= 0) toast("Buz Tapınağı artık sessiz."); }
    else if (fadeState == 0) fadeTo([this] { enterIceTemple(); toast("BUZ TAPINAĞI"); });
  }
  if (tx >= 13 && tx <= 14 && ty <= 7 && up && py < 7 * 16 + 14) {
    if (!(flags & F2_YETI)) { if (toastT <= 0) toast("Mağaranın içi kemik ve buz dolu. Yeti dışarıda dolaşıyor olmalı."); }
    else if (fadeState == 0) { sfx(SFX_CLICK); fadeTo([this] { enterCave(1); }); }
  }
}

// ---------------- buz eritme ----------------
void Game::melt(Obj& o) {
  if (!hasFireLantern) {
    if (o.type == O_FROZEN && qs[Q_FROZEN] == 0) { qs[Q_FROZEN] = 1; toast("Yeni görev: Donmuş Gezgin"); }
    if (toastT <= 0) { toast(o.type == O_FROZEN ? "Buzun içinde biri var! Eritmek için ateş lazım." : "Buz kaya gibi sert. Kılıç işlemiyor; sönmeyen bir alev lazım."); sfx(SFX_CLICK); }
    return;
  }
  WorldMap& m = map;
  if (o.type == O_FROZEN) {
    m.removeObj(o); flags |= F2_TRAVELER; sfx(SFX_FIRE); burst(1, o.x, o.y - 12, 12, 0xd4f0ff); poof(o.x, o.y - 10);
    say({ L("", "Alev Feneri'nin sıcaklığıyla buz çatırdayarak eridi. İçinden titreyen bir adam çıktı."),
      L("Gezgin Rüzgâr", "Hhh... Hhhaa... Kaç gündür buradayım? Buz Devi'nin nefesi beni yakalamıştı..."),
      L("Gezgin Rüzgâr", "Hayatımı kurtardın. Al şunu: dağlarda bulduğum bir kalp parçası. Bir de bu keseyi."),
      L("Gezgin Rüzgâr", "Bir sır daha: Buz Devi'nin kalbi göğsünde parlar. Taş ve buz parçalarını kılıcınla geri çevirebilirsin. Ayazköy'ün hanında görüşürüz!") },
      [this] { qs[Q_FROZEN] = 2; coins += 40; givePiece(); placeNPCs(); saveGame(); });
    return;
  }
  // buz duvarı: değdiği yerin çevresindeki bütün buz parçaları erir
  int n = 0, otx = o.tx, oty = o.ty;
  EACH(w, m.objs) if (w.alive && w.type == O_ICEWALL && std::abs(w.tx - otx) <= 2 && std::abs(w.ty - oty) <= 2) {
    m.removeObj(w); n++;
    if (m.kind == MAP_SNOW && w.var < 30) iceMask |= 1u << w.var;
    burst(5, w.x, w.y - 10, 6); burst(1, w.x, w.y - 10, 2, 0xd4f0ff);
  }
  if (n) { sfx(SFX_FIRE); shake = 0.12; if (m.kind == MAP_SNOW) { if (toastT <= 0) toast("Buz eridi!"); saveGame(); } }
}

// ---------------- düşmanlar ----------------
void Game::hitBig2(Ent& e, double hp0) {
  if (e.type == E_GOLEM) {
    for (double th : { e.maxHp * 2 / 3, e.maxHp / 3 }) if (hp0 > th && e.hp <= th) {
      double ex = e.x, ey = e.y; int room = e.room;
      for (int sg = -1; sg <= 1; sg += 2) spawn(E_ICESLIME, ex + sg * 30, ey + 8).room = room;
      toast("Buz Devi'nden parçalar koptu!"); sfx(SFX_SHATTER, 0.6);
    }
  }
  if (e.type == E_YETI && hp0 > e.maxHp / 2 && e.hp <= e.maxHp / 2) { toast("Yeti öfkeyle kükredi!"); sfx(SFX_GROWL); shake = 0.4; }
  if (EXT.hit.count(e.type)) EXT.hit[e.type](e, hp0);
}
bool Game::kill2(Ent& e) {
  if (e.type == E_SNOWWOLF && qs[Q_WOLVES] == 1 && night()) { qc[Q_WOLVES]++; toast(fmt("Kurt sürüsü: %d/6", std::min(6, qc[Q_WOLVES]))); }
  if (e.type == E_YETI) {
    flags |= F2_YETI; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 6; i++) poof(ex + (rnd() - 0.5) * 44, ey - 10 - rnd() * 28);
    addPick(P_FIRESTONE, ex, ey, 100);
    for (int i = 0; i < 8; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 34, ey + (rnd() - 0.5) * 22, 80 + rnd() * 40);
    toast("Yeti yenildi!"); setMood(5); saveGame();
    return true;
  }
  if (e.type == E_GOLEM) {
    golemDead = true; shake = 1.0; haptic("big");
    double ex = e.x, ey = e.y; int room = e.room;
    for (int i = 0; i < 8; i++) poof(ex + (rnd() - 0.5) * 56, ey - 10 - rnd() * 36);
    addPick(P_GEM2, ex, ey, 90); addPick(P_HEARTC, ex + 30, ey, 90);
    EACH(o, ents) if (o.alive && o.room == room && o.type != E_GOLEM) { o.alive = false; poof(o.x, o.y - 6); }
    setMood(5); saveGame();
    return true;
  }
  if (EXT.kill.count(e.type)) return EXT.kill[e.type](e);
  return false;
}
// halka dalga (yere çarpma)
void Game::slamRing(Ent& e) { double ex = e.x, ey = e.y; int room = e.room; Ent& w = shoot(E_ROCKP, ex, ey, 0, 0, room); w.state = 9; w.hx = 0; w.hy = 0; }
// Yeti, Buz Devi, keçi
void Game::updateEnemy2(Ent& e, double dt, double dx, double dy, double d) {
  switch (e.type) {
    case E_YETI: {
      if (d > 190 && e.state == 0) { double a = e.t * 0.4; moveE(e, std::cos(a) * 14 * dt, std::sin(a) * 10 * dt, 10, 8); break; }
      if (e.state == 1) {   // hücum
        bool hit = moveE(e, e.vx * dt, e.vy * dt, 10, 8);
        if (hit || e.t > 0.9) { e.state = 2; e.t = 0; if (hit) { shake = 0.25; sfx(SFX_HIT, 0.7); burst(5, e.x, e.y - 4, 10); } }
      } else if (e.state == 2) { if (e.t > (e.hp <= e.maxHp / 2 ? 0.6 : 1.0)) { e.state = 0; e.t = 0; } }
      else if (e.state == 3) {   // havaya sıçrayıp yere çarpma (öfkeliyken)
        e.vz -= 380 * dt; e.z += e.vz * dt; moveE(e, e.vx * dt, e.vy * dt, 10, 8);
        if (e.z <= 0) {
          e.z = 0; e.vz = 0; e.state = 2; e.t = 0; shake = 0.5; sfx(SFX_RUMBLE);
          slamRing(e);
          burst(5, e.x, e.y, 16);
        }
      } else {
        double ax = e.hx - e.x, ay = e.hy - e.y, back = std::sqrt(ax * ax + ay * ay);
        if (back > 120) moveE(e, ax / back * 40 * dt, ay / back * 40 * dt, 10, 8);
        else moveE(e, dx / d * 22 * dt, dy / d * 22 * dt, 10, 8);
        if (e.t > (e.hp <= e.maxHp / 2 ? 1.1 : 1.6)) {
          e.t = 0; e.cd += 1;
          int act = I(e.cd) % 3;
          if (act == 0 || d > 120) {   // üç kartopu
            sfx(SFX_SWING, 0.8);
            double ex = e.x, ey = e.y; int room = e.room;
            for (int k = -1; k <= 1; k++) {
              double a = std::atan2(dy, dx) + k * 0.28, sp = 95;
              Ent& b = shoot(E_SNOWBALL, ex, ey - 6, std::cos(a) * sp, std::sin(a) * sp, room); b.z = 14; b.vz = 70; b.hx = 0; b.hy = 0;
            }
          } else if (act == 1) { e.state = 1; e.t = 0; e.vx = dx / d * 150; e.vy = dy / d * 150; sfx(SFX_GROWL, 0.7); }
          else if (e.hp <= e.maxHp / 2) { e.state = 3; e.t = 0; e.vz = 200; e.vx = dx / 1.4; e.vy = dy / 1.4; toast("Yeti havaya sıçradı!"); }
          else { e.state = 1; e.t = 0; e.vx = dx / d * 130; e.vy = dy / d * 130; }
        }
      }
      e.dir = dx < 0 ? 2 : 3;
      break;
    }
    case E_GOLEM: {
      bool fast = e.hp <= e.maxHp / 2;
      if (e.state == 3) {   // sıçrama
        e.vz -= 300 * dt; e.z += e.vz * dt; moveE(e, e.vx * dt, 0, 16, 10); moveE(e, 0, e.vy * dt, 16, 10);
        if (e.z <= 0) {
          e.z = 0; e.vz = 0; e.state = 0; e.t = 0; shake = 0.6; sfx(SFX_RUMBLE); haptic("big");
          slamRing(e);
          burst(5, e.x, e.y, 20);
        }
        break;
      }
      if (e.state == 1) { moveE(e, dx / d * (fast ? 40 : 28) * dt, 0, 16, 10); moveE(e, 0, dy / d * (fast ? 40 : 28) * dt, 16, 10); if (e.t > 1.2) { e.state = 0; e.t = 0; } break; }
      if (e.t > (fast ? 0.8 : 1.15)) {
        e.t = 0; e.cd += 1;
        int act = I(e.cd) % 4;
        double ex = e.x, ey = e.y, ecd = e.cd; int room = e.room;
        auto shard = [&](double a, double sp) { Ent& s0 = shoot(E_SHARD, ex + std::cos(a) * 18, ey - 8 + std::sin(a) * 10, std::cos(a) * sp, std::sin(a) * sp, room); s0.hx = 0; s0.hy = 0; };
        if (act == 0) { int nn = fast ? 12 : 8; for (int k = 0; k < nn; k++) shard(k * PI * 2 / nn + ecd * 0.2, 80); sfx(SFX_SHATTER, 0.5); }
        else if (act == 1) { e.state = 1; e.t = 0; }
        else if (act == 2) { double a0 = std::atan2(dy, dx); for (int k = -2; k <= 2; k++) shard(a0 + k * 0.22, 105); sfx(SFX_CLICK, 0.8); }
        else { e.state = 3; e.vz = 220; e.vx = dx / 1.6; e.vy = dy / 1.6; toast("Buz Devi sıçradı!"); }
      }
      break;
    }
    case E_GOAT: {
      if (e.state == 3) {   // ağılda
        if (e.t > 2.5) { e.t = 0; e.vx = (rnd() - 0.5) * 14; e.vy = (rnd() - 0.5) * 10; e.dir = e.vx < 0 ? 2 : 3; }
        double nx = e.x + e.vx * dt, ny = e.y + e.vy * dt;
        if (nx > GP_X0 + 6 && nx < GP_X1 - 6 && ny > GP_Y0 + 8 && ny < GP_Y1) { e.x = nx; e.y = ny; }
        break;
      }
      if (qs[Q_GOAT] == 1 && d < 54) {   // inatçı: yaklaşınca kaçar, ara sıra ters yöne sıçrar
        double sp = e.cd > 0 ? 40 : 66;
        moveE(e, -dx / d * sp * dt, 0, 5, 4); moveE(e, 0, -dy / d * sp * dt, 5, 4);
        e.dir = dx > 0 ? 2 : 3; e.state = 1;
        if (rnd() < 0.004) { e.cd = 0.6; sfx(SFX_SNORT, 0.4); }
        break;
      }
      if (e.state == 2) { moveE(e, -dx / d * 70 * dt, -dy / d * 70 * dt, 5, 4); if (e.t > 1.0) e.state = 0; break; }
      if (e.t > 2.4) { e.t = 0; e.state = rnd() < 0.5 ? 1 : 0; e.dir = rnd() < 0.5 ? 2 : 3; e.vy = (rnd() - 0.5) * 12; }
      if (e.state == 1) moveE(e, (e.dir == 2 ? -12 : 12) * dt, e.vy * dt, 5, 4);
      break;
    }
    default: if (EXT.enemy.count(e.type)) EXT.enemy[e.type](e, dt, dx, dy, d);
  }
}
void Game::pick2(Pick& k) {
  if (k.type == P_FIRESTONE) {
    hasFireStone = true; if (mainStep < 9) mainStep = 9;
    showItem(A.fireStone, "ATEŞ TAŞI! İçinde sönmeyen bir alev var.");
    say({ L("Arda", "Avucumu ısıtıyor... Bu taş buzu eritebilir. Ayazköy'deki demirciye götürmeliyim.") });
    saveGame();
  }
  if (k.type == P_GEM2) {
    hasGem2 = true; mainStep = 12; showItem(A.gem2, "KALBİN İKİNCİ PARÇASI!");
    say({ L("", "Mavi bir ışık odayı doldurdu. Taşın kırık kenarı, cebindeki ilk parçaya doğru titreşiyor."),
      L("Arda", "İki parça birbirini çağırıyor... Bunu hemen Nine'ye götürmeliyim.") });
    saveGame();
  }
  if (EXT.pick.count(k.type)) EXT.pick[k.type](k);
}
void Game::chest2(int v) {
  switch (v) {
    case 18: case 19: keys++; showItem(A.key, "Küçük anahtar buldun."); break;
    case 20: giveHeartC(); break;
    case 21: coins += 50; showItem(A.coin[0], "50 altın! Taş bulmacası çözüldü."); break;
    case 22: bossKey2 = true; showItem(A.bossKey, "BÜYÜK BUZ ANAHTARI! Buz Devi'nin kapısını açar."); break;
    case 23: potions += 2; coins += 30; showItem(A.potion, "2 can iksiri ve 30 altın!"); break;
    case 25: coins += 30; showItem(A.coin[0], "30 altın buldun!"); break;
    case 26: givePiece(); break;
    default: if (EXT.chest.count(v)) EXT.chest[v](v);
  }
}

// ---------------- etkileşim ----------------
void Game::interact2(Obj& o) {
  switch (o.type) {
    case O_ANVIL: say({ L("", "Demirci Bora'nın örsü. Hâlâ sıcak; üstünde yarım kalmış bir nal duruyor.") }); return;
    case O_SNOWMAN: {
      static const char* t[3] = { "Kardan adamın havuç burnu biraz eğri. Yine de çok yakışıklı.", "Kardan adam sana bakıyor gibi. Belki de sadece kömür gözleri öyle.", "Birisi kardan adamın başına bir şapka koymuş. Ayazköy'ün çocukları çok yaratıcı." };
      say({ L("", t[(o.tx + o.ty) % 3]) }); return;
    }
    case O_FROZEN: melt(o); return;
    case O_ICEWALL: melt(o); return;
    case O_CRYSTAL: say({ L("", "Kristalin içinde mavi bir ışık titriyor. Dokununca parmakların karıncalandı.") }); return;
    case O_CAMPFIRE:
      if (hp < maxHp && !(flags & F2_FIREWARM)) {
        flags |= F2_FIREWARM; hp = std::min(maxHp, hp + 4); freezeT = 0; sfx(SFX_FIRE);
        say({ L("", "Ateşin başında ellerini ısıttın. İçin ısındı. (+2 kalp, günde bir kez)") });
      } else say({ L("", "Kamp ateşi çıtır çıtır yanıyor. Kıvılcımlar karanlığa doğru uçuşuyor.") });
      return;
    case O_COUNTER:
      if (interior == 3 || interior == 4) { innShop(); return; }
      say({ L("", "Tezgâhta sıcak ekmekler ve tarçınlı çörekler diziliyor.") }); return;
    default: if (EXT.interact.count(o.type)) EXT.interact[o.type](o);
  }
}
string Game::innName() { return interior == 4 ? "Hancı Dalga" : "Hancı Kardelen"; }
void Game::innShop() {
  ask({ L(innName(), "Hoş geldin yolcu! Soğukta donmuşsundur. Ne istersin?") },
    { "Sıcak çorba — 8 altın", "Can iksiri — 15 altın", "Hiçbir şey" }, [this](int c) {
      if (c == 0) {
        if (coins >= 8) { coins -= 8; breads++; showItem(A.soup, "Sıcak çorba! İksir düğmesiyle iç. (+2 kalp)"); saveGame(); }
        else say({ L(innName(), "8 altın canım. Dağda her şey pahalı, odun bile.") });
      } else if (c == 1) {
        if (coins >= 15) { coins -= 15; potions++; showItem(A.potion, "Can iksiri!"); saveGame(); }
        else say({ L(innName(), "İksir için 15 altın lazım. Kemal Usta'dan ucuza alamazsın, o kesin.") });
      }
    });
}
void Game::innSleep() {
  ask({ L(innName(), "Bir gece 5 altın. Sıcak yatak, kalın yorgan. Sabaha kadar uyumak ister misin? (Oyun kaydedilir.)") }, { "Uyu (5 altın)", "Vazgeç" }, [this](int c) {
    if (c != 0) return;
    if (coins < 5) { say({ L(innName(), "5 altının yok mu? Ah yolcu... Bu gece ocağın başında uyu bari, ama yatak parayla.") }); return; }
    coins -= 5;
    fadeTo([this] {
      if (dayT > 0.25) dayN++;
      dayT = 0.27; hp = maxHp; freezeT = 0; flags &= ~F2_FIREWARM; placeNPCs();
      saveGame();
      say({ L("", "Arda kalın yorganın altında mışıl mışıl uyudu. Pencerenin buzlu camından sabah ışığı süzülüyor.") });
      toast(fmt("Gün %d • Can doldu • Kaydedildi", dayN));
    });
  });
}
void Game::talkElder2() {
  int s0 = mainStep;
  if (s0 >= 13) { talkElder3(); return; }
  if (s0 == 6) {
    say({ L("Bilge Nine", "Arda, gel otur. Baban'ın mektubunu düşünüp durdum. Kalbin ikinci parçası kuzeydeki karlı dağlarda, Buz Tapınağı'nda."),
      L("Bilge Nine", "Sis çekilince Kuzey Geçidi açıldı. Tapınağın doğusunda, uçuruma oyulmuş basamaklar var. Oradan yukarı çık."),
      L("Bilge Nine", "Dağların ardında Ayazköy diye bir köy var. Muhtarları Ayaz eski bir dostumdur. Ona benden selam söyle."),
      L("Arda", "Karlı dağlar mı? İyi ki babamın eski kürkünü saklamışım."),
      L("Bilge Nine", "Dikkatli ol evladım. Orada kurtlar daha aç, rüzgâr daha sert. Ve dağların bir bekçisi var derler... Buz Devi.") },
      [this] { mainStep = 7; toast("2. BÖLÜM: KARLI DAĞLAR"); saveGame(); });
    return;
  }
  if (s0 == 12) {
    mainStep = 13; saveGame();
    say({ L("Bilge Nine", "Arda! Bu mavi ışık... Kalbin ikinci parçası!"),
      L("", "Nine iki parçayı yan yana koydu. Kırık kenarlar birbirine kenetlendi; yeşil ve mavi ışık iç içe geçti."),
      L("", "Dağların üstündeki bulutlar dağıldı. Kuzeyden ılık bir rüzgâr esti; buzlar çözülmeye başladı."),
      L("Bilge Nine", "Yarısı tamam. Ama bak, ışık hâlâ bir şeyleri arıyor gibi titriyor."),
      L("Arda", "Doğudaki batık şehir ve göklerdeki kule... Diğer iki parça orada, değil mi?"),
      L("Bilge Nine", "Evet. Ama bu gece değil. Bu gece Yeşilvadi senin için şenlik yapacak. Kemal Usta bile indirim yapacakmış!"),
      L("Arda", "Kemal Usta mı? İndirim mi? Bu... Buz Devi'ni yenmekten daha zor bir mucize!") },
      [this] { fadeTo([this] { state = S_CREDITS; creditsT = 0; setMood(5); }); });
    return;
  }
  string hint = s0 == 7 ? "Kuzey Geçidi tapınağın doğusunda. Ayazköy'de Muhtar Ayaz'ı bul." :
    s0 <= 11 ? "Dağların sesi buraya kadar geliyor. Dikkatli ol, Arda. Yorulursan Ayazköy'ün hanında dinlen." :
      "Dinlen biraz, Arda. Yakında yeniden yola çıkacaksın.";
  say({ L("Bilge Nine", hint) });
}
void Game::talk2(Npc& n) {
  int s0 = mainStep;
  switch (n.id) {
    case N_MUHTAR:
      if (s0 <= 7) {
        say({ L("Muhtar Ayaz", "Yeşilvadi'den bir yolcu mu? Bu karda? ...Nine mi gönderdi seni? Hah! O inatçı kadın hâlâ yaşıyor demek."),
          L("Muhtar Ayaz", "Dinle evlat. Bir ay önce gökten mavi bir yıldız düştü, Buz Tapınağı'na. O günden beri Buz Devi uyandı."),
          L("Muhtar Ayaz", "Tapınağın yolunu sonsuz bir buz duvarı kapattı. Onu ancak sönmeyen bir alev eritir: köyümüzün Ateş Taşı."),
          L("Muhtar Ayaz", "Ama taşı Yeti çaldı! Kuzeybatıdaki mağarasının önünde, parlayan şeylerin üstüne yatıyor."),
          L("Muhtar Ayaz", "Taşı geri getirirsen Demirci Bora ondan bir fener döver. Hanımız da senin. Kardelen'e benden selam söyle.") },
          [this] { mainStep = 8; toast("Yeti'yi yen, Ateş Taşı'nı geri al."); enterYeti2(); saveGame(); });
      } else if (s0 == 8) say({ L("Muhtar Ayaz", "Yeti kuzeybatıda. Göl kıyısından kuzeye çıkan patikayı izle. Kartopu atar, hücum eder; yana kaç!") });
      else if (s0 == 9) say({ L("Muhtar Ayaz", "Ateş Taşı! Köyün ocakları yine yanacak. Hemen Bora'ya götür, örsünün başındadır.") });
      else if (s0 <= 11) say({ L("Muhtar Ayaz", "Buz Tapınağı kuzeyde. İçeride kaygan zeminler var derler; dikkatli yürü.") });
      else say({ L("Muhtar Ayaz", "Dağlara bahar geldi! Sana minnettarız, Yeşilvadi'nin Bekçisi.") });
      break;
    case N_SMITH:
      if (s0 == 9 || (hasFireStone && !hasFireLantern)) {
        say({ L("Demirci Bora", "Bu... Ateş Taşı! Yeti'yi sen mi yendin? Vay be, Yeşilvadi'nin çocukları sağlam çıkıyor!"),
          L("", "Bora taşı örsün üstüne koydu. Çekiç her inişinde kıvılcımlar kar gibi yağdı. Fener'in camı kızıl bir ışıkla doldu."),
          L("Demirci Bora", "Alev Feneri. İçindeki ateş hiç sönmez. Buz duvarına kılıcınla vur; alev kılıcına geçer, buzu eritir."),
          L("Demirci Bora", "Karanlıkta da daha uzağı gösterir. Hadi, Buz Tapınağı seni bekliyor.") },
          [this] { hasFireLantern = true; hasLantern = true; mainStep = std::max(mainStep, 10); showItem(A.fireLantern, "ALEV FENERİ! Buz duvarlarını kılıçla eritir."); saveGame(); });
        return;
      }
      if (hasFireLantern && swordLv < 3) {
        ask({ L("Demirci Bora", "Kılıcın güzel ama dağların soğuğunda körelir. 60 altına onu Ayaz çeliğiyle güçlendireyim mi? Üç kat vurur!") },
          { "Güçlendir (60 altın)", "Sonra" }, [this](int c) {
            if (c != 0) return;
            if (coins >= 60) { coins -= 60; swordLv = 3; showItem(A.sword, "AYAZ KILICI! Artık üç kat vuruyor."); saveGame(); }
            else say({ L("Demirci Bora", "60 altın lazım. Çalıları kes, kasaları kır; dağda altın boldur.") });
          });
        return;
      }
      say({ L("Demirci Bora", s0 < 9 ? "Ocağım soğudu evlat. Ateş Taşı olmadan ne nal döverim ne kılıç. Lanet olası Yeti!" : "Fenerin işini görüyor mu? Kılıcın da keskin; Buz Devi'ne benden selam söyle!") });
      break;
    case N_SHEPHERD:
      if (qs[Q_GOAT] == 0) {
        say({ L("Çoban Lale", "Ah, bir yabancı! Yardım eder misin? Fırtınada keçilerim kaçtı, doğudaki yaylaya çıktılar."),
          L("Çoban Lale", "Üç tane! İnatçıdırlar; yaklaşınca kaçarlar. Arkalarından dolanıp ağıla doğru sür. Kapı batı tarafta.") },
          [this] { qs[Q_GOAT] = 1; qc[Q_GOAT] = 0; toast("Yeni görev: Kaçak Keçiler"); saveGame(); });
      } else if (qs[Q_GOAT] == 1 && qc[Q_GOAT] >= 3) {
        say({ L("Çoban Lale", "Üçü de içeride! Sen bir keçi fısıldayıcısısın! Al, bunu yaylada bulmuştum, parlıyordu.") },
          [this] { qs[Q_GOAT] = 2; coins += 20; givePiece(); saveGame(); });
      } else say({ L("Çoban Lale", qs[Q_GOAT] == 1 ? fmt("Ağılda %d keçi var. Üçü lazım! Keçiler kendi istedikleri yere gider; sen sadece onları ikna et.", qc[Q_GOAT]) : string("Keçilerim mutlu, ben mutluyum. Sütleri de çok güzel bu yıl!")) });
      break;
    case N_HUNTER:
      if (qs[Q_WOLVES] == 0) {
        say({ L("Avcı Tolga", "Hey, sen! Kılıç taşıyorsun, iyi. Geceleri kar kurtları köyün çevresinde dolaşıyor."),
          L("Avcı Tolga", "Sürüyü dağıtmak için yardım lazım. Gece çıkıp altı kar kurdu yen. Ödülün benden.") },
          [this] { qs[Q_WOLVES] = 1; qc[Q_WOLVES] = 0; toast("Yeni görev: Kurt Sürüsü"); saveGame(); });
      } else if (qs[Q_WOLVES] == 1 && qc[Q_WOLVES] >= 6) {
        say({ L("Avcı Tolga", "Altı kurt! Sürü dağıldı, köy rahat uyuyacak. Al, avcıların uğuru: bir kalp parçası.") },
          [this] { qs[Q_WOLVES] = 2; coins += 25; givePiece(); saveGame(); });
      } else say({ L("Avcı Tolga", qs[Q_WOLVES] == 1 ? fmt("Şimdiye kadar %d kurt. Kurtlar yalnızca geceleri çıkar. Atıldıklarında yana kaç!", qc[Q_WOLVES]) : string("Sürü dağıldı. Artık geceleri yalnızca rüzgâr uluyor.")) });
      break;
    case N_TRAVELER: {
      static const char* t[3] = { "Doğuda, denizin dibinde batık bir şehir varmış. Kalbin bir parçası orada olabilir.",
        "Buz Devi'nin sıçrayışından sonra yerden halka halka dalga yayılır. Zamanla zıpla... şey, yana kaç!",
        "Bu handa çorba enfes. Kardelen'e söyleme ama tarifi Yeşilvadi'den." };
      say({ L("Gezgin Rüzgâr", t[(dayN + qc[Q_WOLVES]) % 3]) });
      break;
    }
    case N_INNKEEP: innShop(); break;
    default: if (EXT.talk.count(n.id)) EXT.talk[n.id](n);
  }
}
// Muhtar konuştuktan sonra Yeti'yi hemen ortaya çıkar (harita yeniden kurulmadan)
void Game::enterYeti2() {
  if (map.kind != MAP_SNOW || (flags & F2_YETI)) return;
  for (auto& e : ents) if (e->alive && e->type == E_YETI) return;
  Ent& yt = spawn(E_YETI, YETI_HOME[0], YETI_HOME[1]); yt.hx = YETI_HOME[0]; yt.hy = YETI_HOME[1];
}

// ---------------- çizim ----------------
void Game::drawTile2(int t, int x, int y, double sx, double sy) {
  double tm = time; bool d2 = map.kind == MAP_DUNGEON2;
  switch (t) {
    case T_SNOW: spr(A.snow[I(hash2(x, y) * 4) & 3], sx, sy); break;
    case T_SNOWPATH: spr(A.snowPath, sx, sy); break;
    case T_ICE: spr(A.ice[(x + y) & 1], sx, sy); if (hash2(x, y + I(tm * 0.7)) > 0.93) spr(A.spark, sx + 5, sy + 4, false, 0.6, 0.6, 0.6); break;
    case T_SNOWCLIFF: spr(A.snowCliff, sx, sy); break;
    case T_SNOWTOP: spr(A.snowTop, sx, sy); break;
    case T_PASS: spr(A.pass, sx, sy); break;
    case T_ICEWATER: spr(A.iceWater[I(tm * 2) & 1], sx, sy); break;
    case T_DFLOOR: case T_DOOR_OPEN: spr(d2 ? A.dfloor2[(x + y) & 1] : A.dfloor[(x + y) & 1], sx, sy); break;
    case T_CARPET: spr(d2 ? A.carpet2 : A.carpet, sx, sy); break;
    case T_STAIRS: spr(d2 ? A.stairs2 : A.stairs, sx, sy); break;
    case T_DWALL: spr(d2 ? A.dwall2 : A.dwall, sx, sy); break;
    case T_DTOP: spr(d2 ? A.dwallTop2 : A.dwallTop, sx, sy); break;
    case T_DOOR_SHUT: spr(d2 ? A.doorShut2 : A.doorShut, sx, sy); break;
    case T_DOOR_LOCK: spr(d2 ? A.doorLock2 : A.doorLock, sx, sy); break;
    case T_DOOR_BOSS: spr(d2 ? A.doorBoss2 : A.doorBoss, sx, sy); break;
    case T_PLATE: spr((d2 ? A.plate2 : A.plate)[(flags & (d2 ? F2_BLOCK : F_BLOCK)) ? 1 : 0], sx, sy); break;
    default: if (EXT.tile.count(t)) EXT.tile[t](t, x, y, sx, sy);
  }
}
void Game::drawObj2(Obj& o, double x, double y) {
  double tm = time;
  switch (o.type) {
    case O_PINE: spr(A.shadow, x - 13, y - 4, false, 1, 1.7, 1.3); spr(A.pine[o.var & 1], x - 14, y - 41); break;
    case O_SNOWBUSH: spr(A.shadow, x - 8, y - 4); spr(A.snowBush, x - 9, y - 15); break;
    case O_SNOWROCK: spr(A.shadow, x - 8, y - 4); spr(A.snowRock, x - 9, y - 15); break;
    case O_SNOWMAN: spr(A.shadow, x - 7, y - 4, false, 1, 0.9); spr(A.snowman, x - 8, y - 21); break;
    case O_ICEWALL: spr(A.iceWall, x - 9, y - 19); if (hash2(o.tx, I(tm * 1.5)) > 0.8) spr(A.spark, x - 4 + (o.tx % 3), y - 16, false, 0.7, 0.6, 0.6); break;
    case O_FROZEN: spr(A.shadow, x - 9, y - 4); spr(A.frozen, x - 10, y - 25); if (std::sin(tm * 3) > 0.6) spr(A.spark, x + 2, y - 22, false, 0.8, 0.7, 0.7); break;
    case O_ANVIL: spr(A.anvil, x - 9, y - 13); spr(A.logs, x + 6, y - 9); spr(A.flame[I(tm * 10) % 3], x + 9, y - 17); break;
    case O_CABIN: spr(A.cabin[o.var % 3], x - 26, y - 53); break;
    case O_ICETEMPLE: spr(A.iceTemple, x - 25, y - 43); break;
    case O_YETICAVE: spr(A.yetiCave, x - 17, y - 25); break;
    case O_SNOWPILE: spr(A.snowPile, x - 18, y - 21); break;
    case O_CRYSTAL: spr(A.crystal, x - 5, y - 17); spr(A.spark, x - 6, y - 18, false, 0.3 + 0.25 * std::sin(tm * 2 + o.tx), 1.6, 1.6); break;
    case O_CAMPFIRE: spr(A.logs, x - 8, y - 9); spr(A.flame[I(tm * 10) % 3], x - 5, y - 18, false, 1, 1.2, 1.2); break;
    default: if (EXT.obj.count(o.type)) EXT.obj[o.type](o, x, y);
  }
}
void Game::drawEnt2(Ent& e, double x, double y, bool fl) {
  switch (e.type) {
    case E_SNOWWOLF: spr(A.shadow, x - 8, y - 4); spr(A.snowWolf[I(e.t * (e.state == 1 ? 14 : 7)) & 1], x - 9, y - 13, e.dir == 2, 1, 1, 1, fl); break;
    case E_ICESLIME: {
      double sq = e.z > 0 ? 0.9 : 1 + 0.08 * std::sin(e.t * 8), st = e.z > 0 ? 1.15 : 1 / sq; const Spr* s0 = A.iceSlime[e.z > 0 ? 1 : 0];
      spr(A.shadow, x - 7, y - 4, false, 1, 0.9);
      spr(s0, x - s0->w * sq / 2, y - s0->h * st - e.z + 1, false, 1, sq, st, fl);
      break;
    }
    case E_ICEBAT: { spr(A.shadow, x - 5, y - 4, false, 0.6, 0.7); const Spr* s0 = A.iceBat[I(e.t * 10) & 1]; spr(s0, x - s0->w / 2, y - s0->h - e.z, false, 1, 1, 1, fl); break; }
    case E_YETI: {
      const Spr* s0 = A.yeti[e.state == 1 || e.state == 3 ? 1 : I(e.t * 3) & 1]; double sq = e.state == 2 ? 1.06 : 1;
      spr(A.shadow, x - 18, y - 6, false, 1, 2.2, 1.8);
      spr(s0, x - s0->w * sq / 2, y - s0->h / sq - e.z + 2, e.dir == 2, 1, sq, 1 / sq, fl);
      break;
    }
    case E_GOLEM: {
      const Spr* s0 = A.golem[e.state == 3 || (I(e.t * 2) & 1) ? 1 : 0];
      spr(A.shadow, x - 24, y - 7, false, 1, 3, 2.2);
      spr(s0, x - s0->w / 2, y - s0->h - e.z + 3, false, 1, 1, 1, fl);
      break;
    }
    case E_GOAT: {
      spr(A.shadow, x - 7, y - 3, false, 1, 0.9);
      const Spr* s0 = A.goat[(e.state ? I(e.t * 8) : 0) & 1];
      spr(s0, x - 8, y - 13 - (e.state == 2 ? std::fabs(std::sin(e.t * 20)) * 3 : 0), e.dir == 2, 1, 1, 1, fl);
      break;
    }
    case E_SNOWBALL: spr(A.shadow, x - 4, y - 2, false, 0.7, 0.5); spr(A.snowball, x - 4, y - 8 - e.z); break;
    case E_SHARD: rot(A.shard, x, y - 6, 5, 3, std::atan2(e.vy, e.vx)); break;
    default: if (EXT.draw.count(e.type)) EXT.draw[e.type](e, x, y, fl);
  }
}
// kar yağışı; gece kar fırtınası
void Game::drawWeather2(double ox, double oy) {
  double na = nightAmt(); bool storm = na > 0.5;
  if (flakes.empty()) { Rng r(99); for (int i = 0; i < 170; i++) flakes.push_back({ r.f() * 500, r.f() * VH, 0.5 + r.f(), r.f() * 6 }); }
  int n = storm ? 170 : 80; double wind = storm ? 34 : 8 + std::sin(time * 0.3) * 6, dt = std::min(0.05, time - (lastWx > 0 ? lastWx : time)); lastWx = time;
  Col c = storm ? rgba(235, 242, 255, 0.85) : rgba(255, 255, 255, 0.8);
  for (int i = 0; i < n; i++) {
    Flake& f = flakes[i];
    f.y += (12 + f.s * 16) * dt; f.x += (wind * f.s + std::sin(time * 1.3 + f.p) * 6) * dt;
    double sx = std::fmod(std::fmod(f.x - ox * 0.15 * f.s, VW + 20) + VW + 20, VW + 20) - 10, sy = std::fmod(std::fmod(f.y - oy * 0.15 * f.s, VH + 10) + VH + 10, VH + 10) - 5;
    double sz = f.s > 1.2 ? 2 : 1;
    fillLo(std::round(sx), std::round(sy), sz, sz, c);
  }
  if (storm) fillLo(0, 0, VW, VH, rgba(200, 215, 240, 0.08 + 0.04 * std::sin(time * 0.8)));
}
