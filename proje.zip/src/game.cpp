// ORMANIN KALBİ - Bölüm 1-1: Kara Sis (Bölüm 1-2: game2.cpp)
// kahraman, kılıç, düşmanlar, ara boss, boss, gece-gündüz, uyku, ev içleri, bulmacalar, görevler, kayıt
#include "game.h"

const char* QNAME[Q_COUNT] = { "Kayıp Kedi", "Kaçak Tavuklar", "Sıcak Ekmek", "Göl Temizliği", "Gece Hortlakları", "Kaçak Keçiler", "Donmuş Gezgin", "Kurt Sürüsü", "Kayıp İnciler", "Yengeç Avı", "Deniz Feneri",
  "Altın Tüyler", "Yavru Kuşlar", "Fırtına Ruhları" };
const int MUSH_POS[3][2] = { {22, 24}, {15, 44}, {9, 36} };
static const char* SAVE_KEY3 = "orman_kayit_v3";
bool isProjT(int t) { return t == E_ROCKP || t == E_SEED || t == E_SNOWBALL || t == E_SHARD || t == E_HAMMER || t == E_COINP || t == E_BUBBLE || t == E_BLADE
  || t == E_FEATHERP || t == E_SPARK || t == E_ORB || t == E_DARKORB; }
bool isBigT(int t) { return t == E_BOSS || t == E_STUMP || t == E_YETI || t == E_GOLEM || t == E_KEMAL || t == E_SYETI || t == E_CRABKING || t == E_KRAKEN || t == E_GCAPTAIN
  || t == E_EAGLE || t == E_LORD || t == E_KNIGHT; }
bool isTameT(int t) { return t == E_CHICK || t == E_CAT || t == E_GOAT || t == E_BIRDLING; }

Game::Game(Gfx* gfx, Synth* synth) : au(synth), g(gfx) {
  initArt(A); loadLang();
  SOLID_X[T_CWALL] = SOLID_X[T_CTOP] = true;
  SOLID_X[T_REEF] = SOLID_X[T_RUINWALL] = SOLID_X[T_TIDE] = true;
  resetProgress();
  initGizli(); initBolum3(); initBolum4(); initAyna(); initGenis(); initHikaye(); initBolum5();
  buildOverworld(map); populateOverworld(map);
  setMood(7);
}
void Game::resetProgress() {
  hp = 6; maxHp = 6; coins = 0; keys = 0; potions = 0; breads = 0; swordLv = 0; hpPieces = 0;
  hasLantern = false; bossKey = false; hasGem = false; cured = false; bossDead = false;
  chestMask = 0; doorMask = 0; clearMask = 0; flags = 0; mainStep = 0; mushMask = 0;
  for (int i = 0; i < Q_COUNT; i++) qs[i] = qc[i] = 0;
  dayT = 0.3; dayN = 1;
  iceMask = 0; clear2 = 0; hasFireStone = false; hasFireLantern = false; hasGem2 = false; bossKey2 = false; golemDead = false;
  pvx = 0; pvy = 0; freezeT = 0;
  sec = 0; c3 = 0; clear3 = 0; hasCharm = false; hasGem3 = false; bossKey3 = false; krakenDead = false; tide = 0;
  f4 = 0; feathers = 0; c4 = 0; clear4 = 0; hasHorn = false; hasGem4 = false; bossKey4 = false;
  for (int i = 0; i < 64; i++) hs[i] = hc[i] = 0;
  hGen = hNight = -1; qScroll = 0;
  f5 = 0; twistT = -1; twistWait = 0; mg.reset(); mgDone = nullptr;
}
void Game::resize(int w, int h) {
  W = w; H = h;
  VW = (int)std::lround(clampf((double)VH * w / h, 300, 430));
  s = (double)h / VH; ox0 = std::round((w - VW * s) / 2);
  textCache.clear();
}

// ---------------- yardımcılar ----------------
void Game::sfx0(int t, double a) { if (au) au->play(t, a); }
void Game::haptic(const char* k) { if (onHaptic) onHaptic(k); }
void Game::setMood(int m) { if (m != mood) { if (au) au->setMood(m); mood = m; } }
void Game::toast(const string& str) { toastS = tr(str); toastT = 3; }
void Game::say(const std::vector<Line>& lines, std::function<void()> done /*= nullptr*/) { dl = lines; for (auto& l : dl) { l.who = tr(l.who); l.text = tr(l.text); } di = 0; dchars = 0; dDone = done; dChoices.clear(); dChoice = nullptr; dlg = true; sfx(SFX_BLIP); }
void Game::ask(const std::vector<Line>& lines, const std::vector<string>& ch, std::function<void(int)> cb) { dl = lines; for (auto& l : dl) { l.who = tr(l.who); l.text = tr(l.text); } di = 0; dchars = 0; dDone = nullptr; dChoices = ch; for (auto& c : dChoices) c = tr(c); dChoice = cb; dSel = 0; dlg = true; }
void Game::fadeTo(std::function<void()> cb) { if (fadeState == 1) return; fadeState = 1; fadeCb = cb; }
double Game::rnd() { rs = rs * 1664525u + 1013904223u; return ((rs >> 8) & 0xFFFF) / 65536.0; }
void Game::dirVec(int d, double& x, double& y) { x = d == 2 ? -1 : d == 3 ? 1 : 0; y = d == 0 ? 1 : d == 1 ? -1 : 0; }
double Game::faceAng(int d) { return d == 1 ? 0 : d == 3 ? PI / 2 : d == 0 ? PI : -PI / 2; }
int Game::roomOf(double x, double y) { int rx = (int)std::trunc(x / (RW * 16)), ry = (int)std::trunc(y / (RH * 16)); return ry * 3 + rx; }
bool Game::night() { return dayT > 0.8 || dayT < 0.2; }
double Game::nightAmt() {
  double d = dayT;
  if (d > 0.28 && d < 0.7) return 0;
  if (d >= 0.7 && d < 0.82) return (d - 0.7) / 0.12;
  if (d >= 0.18 && d <= 0.28) return 1 - (d - 0.18) / 0.1;
  return 1;
}
int Game::mushCount() { int n = 0; for (int i = 0; i < 3; i++) n += (mushMask >> i) & 1; return n; }
string Game::objective() {
  string h = hikayeHedef(); if (h.size()) return h;
  switch (mainStep) {
    case 0: return "Bilge Nine ile konuş.";
    case 1: return "Batıdaki ormanda, uçurumun dibindeki mağarada yaşlı bekçiyi bul.";
    case 2: return fmt("Ormanda 3 şifalı mantar bul (%d/3), sonra bekçiye dön.", mushCount());
    case 3: return hasLantern ? "Çelik kılıçla dikenli çalıları kes ve kuzeydeki Eski Tapınak'a git." : "Pazardan 40 altına fener al, sonra kuzeydeki tapınağa git.";
    case 4: return "Eski Tapınak'ta Ormanın Kalbi'ni bul.";
    case 5: return "Ormanın Kalbi'ni köye, Bilge Nine'ye götür.";
  }
  return objective2();
}
int Game::dmg() { return swordLv >= 4 ? 4 : swordLv >= 3 ? 3 : swordLv >= 2 ? 2 : 1; }

// ---------------- kayıt ----------------
bool Game::hasSave() { return !storeGet(SAVE_KEY3).empty(); }
// kaydedilen alanlar: ad -> değişken
void Game::saveFields(std::function<void(const char*, double*, int*, bool*, uint32_t*)> f) {
  f("swordLv", nullptr, &swordLv, nullptr, nullptr); f("hasLantern", nullptr, nullptr, &hasLantern, nullptr); f("coins", nullptr, &coins, nullptr, nullptr);
  f("keys", nullptr, &keys, nullptr, nullptr); f("bossKey", nullptr, nullptr, &bossKey, nullptr); f("potions", nullptr, &potions, nullptr, nullptr);
  f("maxHp", nullptr, &maxHp, nullptr, nullptr); f("hasGem", nullptr, nullptr, &hasGem, nullptr); f("cured", nullptr, nullptr, &cured, nullptr);
  f("bossDead", nullptr, nullptr, &bossDead, nullptr); f("chestMask", nullptr, nullptr, nullptr, &chestMask); f("doorMask", nullptr, nullptr, nullptr, &doorMask);
  f("clearMask", nullptr, nullptr, nullptr, &clearMask); f("flags", nullptr, &flags, nullptr, nullptr); f("mainStep", nullptr, &mainStep, nullptr, nullptr);
  f("mushMask", nullptr, &mushMask, nullptr, nullptr); f("hpPieces", nullptr, &hpPieces, nullptr, nullptr); f("breads", nullptr, &breads, nullptr, nullptr);
  f("dayT", &dayT, nullptr, nullptr, nullptr); f("dayN", nullptr, &dayN, nullptr, nullptr);
  for (int i = 0; i < Q_COUNT; i++) { static char a[Q_COUNT][8], b[Q_COUNT][8]; snprintf(a[i], 8, "qs%d", i); snprintf(b[i], 8, "qc%d", i); f(a[i], nullptr, &qs[i], nullptr, nullptr); f(b[i], nullptr, &qc[i], nullptr, nullptr); }
  f("iceMask", nullptr, nullptr, nullptr, &iceMask); f("clear2", nullptr, nullptr, nullptr, &clear2); f("hasFireStone", nullptr, nullptr, &hasFireStone, nullptr);
  f("hasFireLantern", nullptr, nullptr, &hasFireLantern, nullptr); f("hasGem2", nullptr, nullptr, &hasGem2, nullptr); f("bossKey2", nullptr, nullptr, &bossKey2, nullptr);
  f("golemDead", nullptr, nullptr, &golemDead, nullptr); f("sec", nullptr, &sec, nullptr, nullptr); f("c3", nullptr, nullptr, nullptr, &c3);
  f("clear3", nullptr, nullptr, nullptr, &clear3); f("hasCharm", nullptr, nullptr, &hasCharm, nullptr); f("hasGem3", nullptr, nullptr, &hasGem3, nullptr);
  f("bossKey3", nullptr, nullptr, &bossKey3, nullptr); f("krakenDead", nullptr, nullptr, &krakenDead, nullptr); f("tide", nullptr, &tide, nullptr, nullptr);
  f("f4", nullptr, &f4, nullptr, nullptr); f("feathers", nullptr, &feathers, nullptr, nullptr); f("c4", nullptr, nullptr, nullptr, &c4);
  f("clear4", nullptr, nullptr, nullptr, &clear4); f("hasHorn", nullptr, nullptr, &hasHorn, nullptr); f("hasGem4", nullptr, nullptr, &hasGem4, nullptr);
  f("bossKey4", nullptr, nullptr, &bossKey4, nullptr); f("f5", nullptr, &f5, nullptr, nullptr);
  for (int i = 0; i < 64; i++) { static char a[64][8], b[64][8]; snprintf(a[i], 8, "hs%d", i); snprintf(b[i], 8, "hc%d", i); f(a[i], nullptr, &hs[i], nullptr, nullptr); f(b[i], nullptr, &hc[i], nullptr, nullptr); }
}
int Game::saveWhere() {
  int k = map.kind;
  if (EXT.saveAs.count(k)) return EXT.saveAs[k]();
  if (k == MAP_INTERIOR) return EXT.interiorMap.count(interior) ? EXT.interiorMap[interior] : interior == 3 ? MAP_SNOW : MAP_OVER;
  return k;
}
void Game::saveGame() {
  if (netRole == "guest") return;   // misafir kaydetmez
  string d = fmt("yer %d\n", saveWhere());
  saveFields([&](const char* n, double* dv, int* iv, bool* bv, uint32_t* uv) {
    if (dv) d += fmt("%s %.17g\n", n, *dv); else if (iv) d += fmt("%s %d\n", n, *iv); else if (bv) d += fmt("%s %d\n", n, *bv ? 1 : 0); else d += fmt("%s %u\n", n, *uv);
  });
  storeSet(SAVE_KEY3, d);
}
void Game::enterSaved(int yer) {
  if (yer == MAP_DUNGEON) enterDungeon();
  else if (yer == MAP_DUNGEON2) enterIceTemple();
  else if (yer == MAP_SNOW) enterSnow(30 * 16 + 8, 39 * 16 + 12);
  else if (EXT.enter.count(yer)) EXT.enter[yer]();
  else enterOverworld(38 * 16 + 8, 64 * 16 + 12);
}
bool Game::loadGame() {
  string j = storeGet(SAVE_KEY3);
  if (j.empty()) return false;
  std::map<string, string> kv;
  for (auto& ln : splitStr(j, '\n')) { size_t sp = ln.find(' '); if (sp != string::npos) kv[ln.substr(0, sp)] = ln.substr(sp + 1); }
  resetProgress();
  saveFields([&](const char* n, double* dv, int* iv, bool* bv, uint32_t* uv) {
    auto it = kv.find(n); if (it == kv.end()) return;
    const char* v = it->second.c_str();
    if (dv) *dv = atof(v); else if (iv) *iv = atoi(v); else if (bv) *bv = atoi(v) != 0; else *uv = (uint32_t)strtoul(v, nullptr, 10);
  });
  hp = maxHp;
  enterSaved(atoi(kv["yer"].c_str()));
  return true;
}

// ---------------- harita kurulumu ----------------
void Game::addNPC(int id, int tx, int ty, const Spr* spr, const string& name, bool flip /*= false*/) {
  WorldMap& m = map; int i = ty * m.W + tx; bool inMap = tx >= 0 && ty >= 0 && tx < m.W && ty < m.H;
  auto n = std::make_unique<Npc>();
  n->id = id; n->x = tx * 16 + 8; n->y = ty * 16 + 14; n->spr = spr; n->name = name; n->flip = flip; n->blkI = inMap && !m.blk[i] ? i : -1; n->gen = m.gen;
  npcs.push_back(std::move(n));
  if (inMap) m.blk[i] = 1;
}
// can: zorluk için normal düşmanlar 1,5 kat, bosslar 1,25 kat; iki kişi oynanırken bir kat daha artar
int Game::hpOf(int type) {
  static const int B[] = { 1, 2, 2, 1, 4, 24, 1, 1, 3, 4, 3, 2, 14, 1, 1, 5, 4, 2, 22, 34, 1, 1, 1 };
  int base = EXT.hp.count(type) ? EXT.hp[type] : (type >= 0 && type < 23 ? B[type] : 1);
  if (!base) base = 1;
  if (isProjT(type) || isTameT(type)) return 1;
  double cp = 1 + 0.4 * partnerCount();   // her ek kahraman için düşmanlar biraz daha dayanıklı
  return (int)std::ceil(base * (isBigT(type) ? 1.25 : 1.5) * cp);
}
Ent& Game::spawn(int type, double x, double y) {
  auto e = std::make_unique<Ent>();
  int h = hpOf(type);
  e->type = type; e->x = x; e->y = y; e->hp = h; e->maxHp = h; e->dir = I(rnd() * 4); e->hx = x; e->hy = y;
  e->t = rnd() * 2;
  ents.push_back(std::move(e)); return *ents.back();
}
bool Game::freeTile(int x, int y) { return !map.solid(x, y) && map.get(x, y) != T_WATER; }
void Game::scatterEnemies(int type, int n, int x0, int y0, int x1, int y1) {
  int made = 0, tries = 0;
  while (made < n && tries < 600) {
    tries++;
    int x = x0 + I(rnd() * (x1 - x0)), y = y0 + I(rnd() * (y1 - y0));
    if (!freeTile(x, y) || map.get(x, y) == T_BRIDGEH) continue;
    if (std::fabs(x * 16 - px) < 90 && std::fabs(y * 16 - py) < 70) continue;
    spawn(type, x * 16 + 8, y * 16 + 12); made++;
  }
}
void Game::spawnNight() {
  if (map.kind == MAP_SNOW) { spawnNight2(); return; }
  if (EXT.night.count(map.kind)) { EXT.night[map.kind](); return; }
  if (map.kind != MAP_OVER || cured) return;
  scatterEnemies(E_GHOST, 5, 34, 13, 62, 30); scatterEnemies(E_GHOST, 3, 8, 30, 30, 60); scatterEnemies(E_GHOST, 2, 30, 40, 66, 66);
  scatterEnemies(E_WOLF, 4, 6, 18, 29, 56); scatterEnemies(E_WOLF, 2, 34, 14, 62, 30); extEnemies(true);
}
void Game::addMush(int i, double x, double y) { auto k = std::make_unique<Pick>(); k->type = P_MUSH; k->val = i; k->x = x; k->y = y; picks.push_back(std::move(k)); }
void Game::enterOverworld(double x, double y) {
  WorldMap& m = map;
  buildOverworld(m); populateOverworld(m);
  addNorthPass(m, mainStep >= 6);
  for (auto& f : EXT.overBuild) f(m);
  extendOverworldObjs(m, flags);
  interior = -1;
  ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1;
  EACH(o, m.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  if (swordLv >= 2 && ((doorMask >> 20) & 1)) EACH(o, m.objs) if (o.type == O_THORN && o.alive) m.removeObj(o);
  px = x; py = y;
  placeNPCs();
  for (int i = 0; i < 4; i++) {
    Ent& c = qs[Q_CHICK] == 2 ? spawn(E_CHICK, (59.5 + (i % 3)) * 16, (64.5 + (i / 3)) * 16) : spawn(E_CHICK, (42 + i * 3) * 16, (57 + (i % 2) * 3) * 16);
    c.state = qs[Q_CHICK] == 2 ? 3 : 0;
  }
  if (qs[Q_CAT] == 0 || qs[Q_CAT] == 1) {
    Ent& c = spawn(E_CAT, 86 * 16, 51 * 16); c.state = qs[Q_CAT] == 1 && ((flags >> 10) & 1) ? 1 : 0;
    if (c.state) { c.x = px + 12; c.y = py; }
  }
  if (!cured) {
    scatterEnemies(E_SLIME, 6, 34, 13, 62, 30); scatterEnemies(E_SLIMER, 3, 34, 13, 62, 30); scatterEnemies(E_BAT, 3, 34, 12, 62, 18);
    scatterEnemies(E_BOAR, 2, 34, 14, 62, 30); scatterEnemies(E_SLIME, 5, 5, 18, 29, 50); scatterEnemies(E_SLIMER, 2, 5, 18, 29, 50);
    scatterEnemies(E_THORN, 5, 5, 16, 29, 56); scatterEnemies(E_OCTO, 6, 60, 26, 92, 52); scatterEnemies(E_BOAR, 3, 66, 50, 90, 64);
    spawn(E_OCTO, 80 * 16, 39 * 16);
    if (!(flags & F_STUMP)) spawn(E_STUMP, 9 * 16 + 8, 36 * 16 + 8).state = 0;
    extEnemies(false);
    if (night()) spawnNight();
  }
  if (mainStep == 2) for (int i = 0; i < 2; i++) if (!((mushMask >> i) & 1)) addMush(i, MUSH_POS[i][0] * 16 + 8, MUSH_POS[i][1] * 16 + 12);
  if (mainStep == 2 && (flags & F_STUMP) && !((mushMask >> 2) & 1)) addMush(2, 9 * 16 + 8, 36 * 16 + 12);
  camX = clampf(px - VW / 2.0, 0, m.W * 16 - VW); camY = clampf(py - VH / 2.0, 0, m.H * 16 - VH);
  saveGame();
}
void Game::placeNPCs() {
  // önceki köylülerin kapladığı kareleri boşalt (yoksa gece-gündüz geçişinde görünmez duvar kalıyordu)
  for (auto& n : npcs) if (n->blkI >= 0 && n->gen == map.gen) map.blk[n->blkI] = 0;
  npcs.clear();
  bool n = night();
  if (map.kind == MAP_OVER) {
    if (!n) {
      addNPC(N_ELDER, 41, 55, A.elder, "Bilge Nine"); addNPC(N_SHOP, 52, 58, A.shopkeep, "Kemal Usta");
      addNPC(N_KID, 56, 65, A.kid, "Küçük Efe"); addNPC(N_FISHER, 58, 41, A.kid, "Balıkçı Çocuk", true);
    }
    addNPC(N_HERMIT, 11, 12, A.hermit, "Yaşlı Bekçi");
  } else if (map.kind == MAP_INTERIOR) {
    if (interior == 0 && n) addNPC(N_ELDER, 8, 4, A.elder, "Bilge Nine");
    if (interior == 1) addNPC(N_BAKER, 6, 3, A.baker, "Fırıncı Hatice");
  }
  placeNPCs2();
}
void Game::enterInterior(int id, int retX, int retY) {
  buildInterior(map, id);
  interior = id; interiorRet[0] = retX; interiorRet[1] = retY;
  ents.clear(); picks.clear(); pts.clear();
  EACH(o, map.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  placeNPCs();
  px = 7 * 16; py = 8 * 16 + 12; pdir = 1;
  camX = (IW * 16 - VW) / 2.0; camY = (IH * 16 - VH) / 2.0;
  setMood(id == 1 ? 0 : id == 3 ? 9 : 6);
}
void Game::enterDungeon() {
  WorldMap& m = map;
  buildDungeon(m, rooms);
  interior = -1;
  ents.clear(); picks.clear(); pts.clear(); npcs.clear();
  EACH(o, m.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  for (int i = 0; i < m.W * m.H; i++) { int lid = m.lockId[i]; if (lid && ((doorMask >> lid) & 1)) m.t[i] = T_DOOR_OPEN; }
  if ((clearMask >> 5) & 1) addRoomChest(5, 14);
  if ((clearMask >> 3) & 1) addRoomChest(3, 15);
  if (flags & F_BLOCK) { EACH(o, m.objs) if (o.type == O_BLOCK) moveBlockTo(o, 4, RH * 2 + 5); addRoomChest(6, 16); }
  if (flags & F_TORCH) { EACH(o, m.objs) if (o.type == O_TORCH) o.var = 0; addRoomChest(8, 17); }
  px = RW * 16 + RW * 8; py = (RH * 2 + RH - 3) * 16; pdir = 1;
  curRoom = -1;
  enterRoom(roomOf(px, py), true);
  camX = (curRoom % 3) * RW * 16 - (VW - RW * 16) / 2.0; camY = (curRoom / 3) * RH * 16 - (VH - RH * 16) / 2.0;
  if (mainStep < 4) mainStep = 4;
  saveGame();
}
void Game::moveBlockTo(Obj& o, int tx, int ty) {
  WorldMap& m = map;
  m.blk[o.ty * m.W + o.tx] = 0;
  o.tx = tx; o.ty = ty; o.x = tx * 16 + 8; o.y = (ty + 1) * 16;
  m.blk[ty * m.W + tx] = 1;
}
void Game::addRoomChest(int room, int v, int tx /*= 10*/, int ty /*= -1*/) {
  if (ty < 0) ty = room == 6 ? 7 : 5;
  int rx = room % 3, ry = room / 3;
  EACH(o, map.objs) if (o.type == O_CHEST && (o.var & 0xFF) == v) return;
  Obj& c = map.add(O_CHEST, rx * RW + tx, ry * RH + ty); c.var = v;
  if (chestOpen(v)) c.var |= 0x100;
}
void Game::openLock(int lid) { WorldMap& m = map; for (int i = 0; i < m.W * m.H; i++) if (m.lockId[i] == lid) m.t[i] = T_DOOR_OPEN; doorMask |= 1u << lid; }
bool Game::roomClear(int r) {
  if (EXT.room.count(map.kind)) return EXT.room[map.kind].isClear(r);
  return map.kind == MAP_DUNGEON2 ? ((clear2 >> r) & 1) : ((clearMask >> r) & 1);
}
void Game::enterRoom(int r, bool instant) {
  if (r == curRoom) return;
  if (map.kind == MAP_DUNGEON2) { enterRoom2(r, instant); return; }
  if (EXT.room.count(map.kind)) { EXT.room[map.kind].enter(r, instant); return; }
  curRoom = r;
  roomT = instant ? 0 : 0.5;
  ents.clear();
  if ((clearMask >> r) & 1) { setMood(r == 1 && !bossDead ? 4 : 3); return; }
  double ox = (r % 3) * RW * 16, oy = (r / 3) * RH * 16;
  auto at = [&](int type, double tx, double ty) { spawn(type, ox + tx * 16 + 8, oy + ty * 16 + 12).room = r; };
  switch (r) {
    case 4: at(E_SLIME, 5, 4); at(E_SLIME, 14, 4); at(E_SLIMER, 10, 6); at(E_SLIME, 7, 8); at(E_THORN, 15, 8); break;
    case 5: at(E_BAT, 5, 4); at(E_BAT, 14, 5); at(E_BAT, 10, 7); at(E_SLIMER, 6, 7); at(E_SLIME, 13, 8); break;
    case 3: at(E_SKEL, 6, 5); at(E_SKEL, 13, 6); at(E_SLIMER, 10, 8); break;
    case 0: at(E_BAT, 6, 5); at(E_BAT, 12, 4); at(E_BAT, 9, 8); at(E_SKEL, 10, 6); break;
    case 2: at(E_SKEL, 6, 6); at(E_SKEL, 13, 6); at(E_BAT, 10, 8); at(E_THORN, 4, 3); break;
    case 6: at(E_SLIME, 14, 3); at(E_SLIME, 15, 8); at(E_SKEL, 6, 8); break;
    case 8: at(E_BAT, 8, 4); at(E_BAT, 12, 6); at(E_BAT, 10, 8); at(E_THORN, 10, 3); break;
    case 1: if (!bossDead) { at(E_BOSS, 9.5, 4); toast("KARA BALÇIK KRAL"); } break;
    default: clearMask |= 1u << r; break;
  }
  if (ents.empty()) clearMask |= 1u << r;
  setMood(r == 1 && !bossDead ? 4 : 3);
  if (r == 0 && !hasLantern) toast("Zifiri karanlık...");
}
void Game::roomCleared(int r) {
  if (map.kind == MAP_DUNGEON2) { roomCleared2(r); return; }
  if (EXT.room.count(map.kind)) { EXT.room[map.kind].cleared(r); return; }
  clearMask |= 1u << r; sfx(SFX_MAGIC);
  if (r == 4) { openLock(10); toast("Kapılar açıldı!"); shake = 0.3; sfx(SFX_RUMBLE); }
  if (r == 5) { addRoomChest(5, 14); toast("Bir sandık belirdi!"); }
  if (r == 3) { addRoomChest(3, 15); toast("Bir sandık belirdi!"); }
  saveGame();
}
void Game::newGame() {
  resetProgress();
  enterOverworld(38 * 16 + 8, 64 * 16 + 12); pdir = 3;
  state = S_PLAY;
  std::vector<Line> v;
  if (pirate) v.push_back(L("Uyarı", "Bu kopya orijinal değil. Ormanın Kalbi zaten bedava! App Store'dan ve Google Play'den ücretsiz indirebilirsin."));
  v.push_back(L("", "Yeşilvadi köyü. Bir zamanlar Ormanın Kalbi'nin ışığıyla parlayan bu topraklara, bir gecede kara bir sis çöktü."));
  v.push_back(L("", "BÖLÜM 1-1: KARA SİS"));
  v.push_back(L("Arda", "Ahh... Sabah oldu mu? Nine dün akşam benimle konuşmak istediğini söylemişti. Meydanda olmalı."));
  say(v);
}

// ---------------- çarpışma ----------------
bool Game::boxHit(double x, double y, double hw, double hh) {
  int x0 = (int)std::floor((x - hw) / 16), x1 = (int)std::floor((x + hw - 0.01) / 16), y0 = (int)std::floor((y - hh) / 16), y1 = (int)std::floor((y - 0.01) / 16);
  for (int ty = y0; ty <= y1; ty++) for (int tx = x0; tx <= x1; tx++) if (map.solid(tx, ty)) return true;
  return false;
}
// nesnenin x,y alanlarını kaydırır; çarpınca true döner
bool Game::moveBox(double& ox, double& oy, double dx, double dy, double hw, double hh) {
  bool hit = false;
  if (dx != 0) { if (!boxHit(ox + dx, oy, hw, hh)) ox += dx; else { hit = true; double sg = dx > 0 ? 1 : -1; for (int i = 0; i < 8 && !boxHit(ox + sg * 0.5, oy, hw, hh); i++) ox += sg * 0.5; } }
  if (dy != 0) { if (!boxHit(ox, oy + dy, hw, hh)) oy += dy; else { hit = true; double sg = dy > 0 ? 1 : -1; for (int i = 0; i < 8 && !boxHit(ox, oy + sg * 0.5, hw, hh); i++) oy += sg * 0.5; } }
  return hit;
}
bool Game::moveE(Ent& e, double dx, double dy, double hw, double hh) { return moveBox(e.x, e.y, dx, dy, hw, hh); }
void Game::movePlayer(double dx, double dy) { moveBox(px, py, dx, dy, PHW, PHH); }

// ---------------- parçacıklar ve ganimet ----------------
void Game::burst0(int kind, double x, double y, int n, uint32_t col) {
  for (int i = 0; i < n; i++) {
    double a = rnd() * 6.28, sp = 20 + rnd() * 60;
    Part p; p.kind = kind; p.x = x; p.y = y; p.vx = std::cos(a) * sp; p.vy = std::sin(a) * sp - (kind == 0 ? 30 : 0); p.life = 0.4 + rnd() * 0.5; p.rot = rnd() * 6; p.col = col;
    pts.push_back(p);
  }
}
void Game::poof0(double x, double y) { Part p; p.kind = 2; p.x = x; p.y = y; p.life = 0.4; pts.push_back(p); }
void Game::addPick(int type, double x, double y, double vz, int val /*= 1*/) { auto k = std::make_unique<Pick>(); k->type = type; k->x = x; k->y = y; k->vz = vz; k->val = val; picks.push_back(std::move(k)); }
void Game::drop(double x, double y, double chanceCoin, double chanceHeart) {
  double r = rnd();
  if (r < chanceHeart) addPick(P_HEART, x, y, 60);
  else if (r < chanceHeart + chanceCoin) addPick(P_COIN, x, y, 70, rnd() < 0.15 ? 5 : 1);
}
void Game::givePiece() {
  hpPieces++;
  if (hpPieces >= 4) { hpPieces = 0; maxHp += 2; hp = maxHp; showItem(A.heartBig, "4 kalp parçası birleşti: YENİ KALP!"); }
  else showItem(A.heartPiece, fmt("Kalp parçası! (%d/4)", hpPieces));
}

// ---------------- güncelleme ----------------
void Game::update(double dt) {
  if (netRole == "guest" && netLive && gKey.size()) { guestUpdate(dt); inp.pressed.clear(); return; }
  update0(dt);
  if (netRole == "host" && netLive) netTick(dt);
}
void Game::update0(double dt) {
  Press& I = inp.pressed;
  time += dt;
  if (laughCd > 0) laughCd -= dt;
  if (fadeState == 1) { fade += dt / 0.45; if (fade >= 1) { fade = 1; fadeState = 2; auto cb = fadeCb; fadeCb = nullptr; if (cb) cb(); if (fadeState == 2) fadeState = 3; } }
  else if (fadeState == 3) { fade -= dt / 0.5; if (fade <= 0) { fade = 0; fadeState = 0; } }
  if (toastT > 0) toastT -= dt;
  if (itemShowT > 0) itemShowT -= dt;
  switch (state) {
    case S_TITLE: updateTitle(dt); break;
    case S_PLAY:
      if (I.pause && !dlg) { if (questLog) questLog = false; else pause(); break; }
      if (mg) { if (dlg) updatePlay(dt); else mgUpdate(dt); break; }
      if (I.log && !dlg) { questLog = !questLog; sfx(SFX_SELECT); }
      if (questLog) {
        if (I.act || I.attack) questLog = false;
        if (I.up) qScroll -= 3;
        if (I.down) qScroll += 3;
        break;
      }
      updatePlay(dt); break;
    case S_PAUSE:
      if (I.pause) { state = S_PLAY; break; }
      if (menuNav(3)) pauseChoose(menuSel);
      break;
    case S_OVER:
      deathT += dt;
      if (deathT > 1.5 && (I.act || I.attack || I.confirm)) continueAfterDeath();
      break;
    case S_CREDITS:
      creditsT += dt; titleCam += dt * 14;
      if (twistDue()) {   // 1-4 sonu: "SON" yazısını Sis Kralı parçalar
        if (creditsT > 20 || (creditsT > 2 && (I.pause || I.confirm || I.act || I.attack))) twistStart();
        if (twistT >= 0) { twistT += dt; if (twistT > 8.5 && !fadeState) twistEnd(); }
        break;
      }
      if (creditsT > 50 || (creditsT > 2 && (I.pause || I.confirm))) toTitle();
      break;
  }
  inp.pressed.clear();
}
void Game::pause() { if (state == S_PLAY && !dlg) { state = S_PAUSE; menuSel = 0; sfx(SFX_SELECT); } }
void Game::pauseChoose(int i) {
  if (i == 0) state = S_PLAY;
  else if (i == 1) {
    if (au) au->muted = !au->muted; sfx(SFX_SELECT);
    storeSet("orman_ses", au && au->muted ? "0" : "1");
  } else { saveGame(); fadeTo([this] { state = S_TITLE; setMood(7); buildOverworld(map); populateOverworld(map); ents.clear(); npcs.clear(); interior = -1; }); }
}
void Game::continueAfterDeath() {
  if (fadeState) return;
  fadeTo([this] { hp = maxHp; state = S_PLAY; freezeT = 0; enterSaved(saveWhere()); });
}
void Game::toTitle() { menuMode = netRole == "host" ? "online" : "main"; fadeTo([this] { state = S_TITLE; setMood(7); }); }
bool Game::menuNav(int n) {
  Press& I = inp.pressed;
  if (I.up) { menuSel = (menuSel + n - 1) % n; sfx(SFX_SELECT); }
  if (I.down) { menuSel = (menuSel + 1) % n; sfx(SFX_SELECT); }
  return I.confirm || I.act || I.attack;
}
void Game::updateTitle(double dt) {
  titleCam += dt * 14;
  auto it = titleItems();
  if (menuSel >= (int)it.size()) menuSel = 0;
  if (fadeState == 0 && menuNav((int)it.size())) titleChoose(menuSel);
}
void Game::dlgAdvance() {
  if (netRole == "guest") { netPress("act"); return; }
  const Line& ln = dl[di]; double total = (double)u8len(ln.text);
  bool typed = dchars >= total, last = di == (int)dl.size() - 1;
  if (last && dChoices.size() && typed) { dlgChoose(dSel); return; }
  if (!typed) dchars = total;
  else { sfx(SFX_BLIP); di++; dchars = 0; if (di >= (int)dl.size()) { dlg = false; dlgClosed = true; auto cb = dDone; dDone = nullptr; if (cb) cb(); } }
}
void Game::dlgChoose(int i) {
  if (netRole == "guest") { netSendChoice(i); return; }
  dlg = false; dlgClosed = true; sfx(SFX_CHIME);
  auto cb = dChoice; dChoice = nullptr; dChoices.clear(); if (cb) cb(i);
}
void Game::updateDialogue(double dt) {
  Press& I = inp.pressed; const Line& ln = dl[di];
  dchars += dt * 60;
  bool typed = dchars >= u8len(ln.text), last = di == (int)dl.size() - 1;
  if (last && dChoices.size() && typed) {
    int n = (int)dChoices.size();
    if (I.up) { dSel = (dSel + n - 1) % n; sfx(SFX_SELECT); }
    if (I.down) { dSel = (dSel + 1) % n; sfx(SFX_SELECT); }
  }
  if (I.act || I.attack || I.confirm) dlgAdvance();
}

void Game::hurtPlayer(int d, double fx, double fy) {
  if (invT > 0 || state != S_PLAY) return;
  if (sec & 16) d = std::max(1, d - 1);   // Bekçi Kalkanı (Kemal Usta'yı yenince)
  hp -= d; invT = 1.1; shake = 0.25; sfx(SFX_HURT); haptic("hurt");
  double dx = px - fx, dy = py - fy, l = std::sqrt(dx * dx + dy * dy) + 0.01;
  kx = dx / l * 170; ky = dy / l * 170; kT = 0.18;
  if (hp <= 0) { hp = 0; state = S_OVER; deathT = 0; sfx(SFX_SHATTER); setMood(6); haptic("death"); }
}
void Game::hitEnemy(Ent& e, double fx, double fy) {
  if (e.lastHit == attackId || isProjT(e.type) || e.type == E_CAT) return;
  e.lastHit = attackId;
  if (EXT.hitPre.count(e.type) && EXT.hitPre[e.type](e)) return;
  if (e.inv) { sfx(SFX_CLICK); burst(1, e.x, e.y - 10, 3, 0xd0d4e0); if (toastT <= 0 && e.invMsg.size()) toast(e.invMsg); return; }
  if (e.type == E_CHICK || e.type == E_GOAT) { e.flash = 0.2; e.state = e.state == 3 ? 3 : 2; e.t = 0; sfx(SFX_SNORT, 0.6); burst(1, e.x, e.y - 6, 4, 0xffffff); return; }
  double hp0 = e.hp;
  e.hp -= dmg(); e.flash = 0.18; sfx(SFX_HIT); haptic("hit");
  double dx = e.x - fx, dy = e.y - fy, l = std::sqrt(dx * dx + dy * dy) + 0.01;
  double k = (isBigT(e.type) || e.type == E_THORN) ? (e.type == E_THORN ? 0 : 50) : 190;
  e.kx = dx / l * k; e.ky = dy / l * k; e.kt = k > 0 ? 0.15 : 0;
  if (e.type == E_BOAR) e.state = 0;
  burst(1, e.x, e.y - 8, 5, e.type >= E_SNOWWOLF ? 0xd4f0ff : 0xfff4b0);
  shake = std::max(shake, isBigT(e.type) ? 0.15 : 0.06);
  if (e.hp <= 0) killEnemy(e);
  else if (e.type == E_BOSS && ((hp0 > e.maxHp * 2 / 3 && e.hp <= e.maxHp * 2 / 3) || (hp0 > e.maxHp / 3 && e.hp <= e.maxHp / 3))) {
    double ex = e.x, ey = e.y; int room = e.room;
    for (int sg = -1; sg <= 1; sg += 2) spawn(E_SLIMER, ex + sg * 26, ey + 6).room = room;
    toast("Kral bölündü!");
  } else hitBig2(e, hp0);
}
void Game::killEnemy(Ent& e) {
  e.alive = false;
  poof(e.x, e.y - 8); sfx(isBigT(e.type) ? SFX_SHATTER : SFX_SWING, 0.8);
  hikayeOldu(e);
  if (kill2(e)) return;
  if (e.type == E_OCTO && qs[Q_OCTO] == 1) { qc[Q_OCTO]++; toast(fmt("Göl temizliği: %d/6", std::min(6, qc[Q_OCTO]))); }
  if (e.type == E_GHOST && qs[Q_GHOST] == 1) { qc[Q_GHOST]++; toast(fmt("Hortlak kovuldu: %d/5", std::min(5, qc[Q_GHOST]))); }
  if (e.type == E_STUMP) {
    flags |= F_STUMP; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 5; i++) poof(ex + (rnd() - 0.5) * 40, ey - 10 - rnd() * 24);
    addPick(P_MUSH, ex, ey, 90, 2);
    for (int i = 0; i < 6; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 30, ey + (rnd() - 0.5) * 20, 80 + rnd() * 40);
    toast("Yaşlı Kütük devrildi!"); saveGame();
    return;
  }
  if (e.type == E_BOSS) {
    bossDead = true; shake = 1.0; haptic("big");
    double ex = e.x, ey = e.y; int room = e.room;
    for (int i = 0; i < 6; i++) poof(ex + (rnd() - 0.5) * 50, ey - 10 - rnd() * 30);
    addPick(P_GEM, ex, ey, 90); addPick(P_HEARTC, ex + 28, ey, 90);
    EACH(o, ents) if (o.alive && o.room == room && o.type != E_BOSS) { o.alive = false; poof(o.x, o.y - 6); }
    setMood(5);
  } else drop(e.x, e.y, 0.45, 0.22);
}
void Game::tryOpenChest(Obj& o) {
  if (o.var & 0x100) { say({ L("", "Sandık boş.") }); return; }
  int v = o.var & 0xFF;
  o.var |= 0x100; setChest(v); sfx(SFX_MAGIC);
  switch (v) {
    case 1: case 2: case 12: giveHeartC(); break;
    case 3: coins += 20; showItem(A.coin[0], "20 altın buldun!"); break;
    case 4: coins += 10; showItem(A.coin[0], "10 altın ve eski bir mektup!");
      say({ L("Babanın mektubu", "'Arda, oğlum. Bu mektubu okuyorsan ben çoktan yola çıkmışımdır. Ormanın Kalbi tek bir taş değil; dört parçaya bölünmüş bir yıldız.'"),
        L("Babanın mektubu", "'Bir gün kara sis gelirse, parçaları bulman gerekecek. İlki Eski Tapınak'ta. Gerisini... zamanı gelince öğreneceksin. Seni seviyorum.'"),
        L("Arda", "Babam... Dört parça mı? Nine bunu biliyor mu acaba?") });
      break;
    case 11: bossKey = true; showItem(A.bossKey, "BÜYÜK ANAHTAR! Kralın kapısını açar."); break;
    case 13: coins += 30; showItem(A.coin[0], "30 altın buldun!"); break;
    case 14: case 15: keys++; showItem(A.key, "Küçük anahtar buldun."); break;
    case 16: coins += 50; showItem(A.coin[0], "50 altın! Blok bulmacası çözüldü."); break;
    case 17: potions += 2; showItem(A.potion, "2 can iksiri! Meşale bulmacası çözüldü."); break;
    default: chest2(v); break;
  }
  saveGame();
}
// sandık açıldı mı: 0-31 chestMask'te, 32-63 (3. bölüm) c3'te, 64 ve sonrası (4. bölüm) c4'te
bool Game::chestOpen(int v) { return v < 32 ? ((chestMask >> v) & 1) == 1 : v < 64 ? ((c3 >> (v - 32)) & 1) == 1 : ((c4 >> (v - 64)) & 1) == 1; }
void Game::setChest(int v) { if (v < 32) chestMask |= 1u << v; else if (v < 64) c3 |= 1u << (v - 32); else c4 |= 1u << (v - 64); }
void Game::markChests() { EACH(o, map.objs) if (o.type == O_CHEST && chestOpen(o.var & 0xFF)) o.var |= 0x100; }
bool Game::hasBossKey() { int k = map.kind; if (EXT.bossKey.count(k)) return this->*EXT.bossKey[k]; return k == MAP_DUNGEON2 ? bossKey2 : bossKey; }
void Game::giveHeartC() { maxHp += 2; hp = maxHp; showItem(A.heartBig, "KALP KABI! Can sınırın arttı."); }
void Game::showItem(const Spr* sp, const string& t) { itemShow = sp; itemShowT = 2.2; toast(t); sfx(SFX_CHIME); haptic("item"); }
void Game::usePotion() {
  if (hp >= maxHp) { if (potions + breads > 0 && toastT <= 0) toast("Canın zaten dolu."); return; }
  if (potions > 0) { potions--; hp = maxHp; sfx(SFX_MAGIC); toast("İksir içtin. Can doldu!"); burst(1, px, py - 10, 10, 0xf8a0b0); }
  else if (breads > 0) { breads--; hp = std::min(maxHp, hp + 4); sfx(SFX_EAT); toast(mainStep >= 6 ? "Sıcak yiyecek yedin. +2 kalp" : "Sıcak ekmek yedin. +2 kalp"); }
  else if (toastT <= 0) toast("İksirin ya da ekmeğin yok.");
}

void Game::updatePlay(double dt) {
  updatePlay0(dt);
  if (netRole == "host" && netLive && state == S_PLAY) { if (!pp[0]) makePartner(0, true); for (int e = 0; e < 2; e++) if (extraOn[e] && !pp[e + 1]) makePartner(e + 1, true); }
  updatePartners(dt);
}
void Game::updatePlay0(double dt) {
  Press& I = inp.pressed; WorldMap& m = map;
  dlgClosed = false;
  if (dlg) { updateDialogue(dt); updateCamera(dt); updateParticles(dt); return; }
  if (roomT > 0) { roomT -= dt; updateCamera(dt); return; }
  if (invT > 0) invT -= dt;
  if (shake > 0) shake -= dt;
  if (!isDg(m.kind)) {
    bool wasNight = night();
    dayT += dt / 600;
    if (dayT >= 1) { dayT -= 1; dayN++; }
    if (!wasNight && night()) {
      spawnNight(); if (isOut(m.kind)) placeNPCs();
      toast(m.kind == MAP_SNOW ? "Gece çöktü. Kar fırtınası ve kar kurtları..." : "Gece çöktü. Hortlaklar ve kurtlar ortaya çıkıyor...");
    }
    if (wasNight && !night()) {
      EACH(e, ents) if (e.alive && e.type == E_GHOST) { e.alive = false; poof(e.x, e.y - 8); }
      if (isOut(m.kind)) placeNPCs();
      toast(fmt("Gün %d doğdu.", dayN));
    }
  }
  heroStep(dt, I);
  for (auto& f : EXT.tick) f(dt);
  updateEnemies(dt);
  updatePicks(dt);
  updateParticles(dt);
  for (auto& n : npcs) n->t += dt;
  interact();
  checkTransitions();
  updateCamera(dt);
  updateArea();
}
// kahraman: hareket (buzda kayma, donma), saldırı, iksir. İkinci oyuncu da aynı kodu kullanır.
void Game::heroStep(double dt, Press& I) {
  WorldMap& m = map;
  if (freezeT > 0) freezeT -= dt;
  double mx = inp.ax, my = inp.ay, ml = std::sqrt(mx * mx + my * my);
  if (ml < 0.18) { mx = my = 0; ml = 0; }
  bool onIce = m.get((int)std::trunc(px / 16), (int)std::trunc((py - 3) / 16)) == T_ICE;
  double tvx = 0, tvy = 0, dmx = 0, dmy = 0;
  bool wantMove = ml > 0 && attackT <= 0;
  if (wantMove) {
    dmx = std::fabs(mx) > 0.38 * ml ? sgn(mx) : 0; dmy = std::fabs(my) > 0.38 * ml ? sgn(my) : 0;
    int pd = pdir;
    if (dmy != 0 && dmx == 0) pdir = dmy > 0 ? 0 : 1;
    else if (dmx != 0 && dmy == 0) pdir = dmx < 0 ? 2 : 3;
    else if ((pd == 0 && dmy < 0) || (pd == 1 && dmy > 0) || (pd == 2 && dmx > 0) || (pd == 3 && dmx < 0)) pdir = dmx < 0 ? 2 : 3;
    double sp = 78 * clampf((ml - 0.18) / 0.45 + 0.35, 0.35, 1) * (freezeT > 0 ? 0.5 : 1);
    tvx = mx / ml * sp; tvy = my / ml * sp;
  }
  if (onIce) { double k = std::min(1.0, dt * (wantMove ? 1.7 : 0.6)); pvx += (tvx - pvx) * k; pvy += (tvy - pvy) * k; }
  else { pvx = tvx; pvy = tvy; }
  double spd = std::sqrt(pvx * pvx + pvy * pvy);
  moving = spd > 4 && attackT <= 0;
  if (spd > 0.5) {
    double ox = px, oy = py;
    movePlayer(pvx * dt, 0); if (std::fabs(px - ox) < std::fabs(pvx * dt) * 0.3) pvx = onIce ? -pvx * 0.2 : pvx;
    double oy2 = py;
    movePlayer(0, pvy * dt); if (std::fabs(py - oy2) < std::fabs(pvy * dt) * 0.3) pvy = onIce ? -pvy * 0.2 : pvy;
    if (wantMove || onIce) animT += dt * std::min(1.0, spd / 78);
    dustT -= dt; if (dustT <= 0) { dustT = onIce ? 0.12 : 0.28; Part p; p.kind = onIce ? 5 : 3; p.x = px; p.y = py; p.vx = -pvx * 0.1; p.vy = -4; p.life = 0.35; pts.push_back(p); }
    bool stuck = std::fabs(px - ox) + std::fabs(py - oy) < 0.2;
    if (wantMove && stuck && (dmx == 0 || dmy == 0)) { pushT += dt; if (pushT > 0.35) { tryPush(); pushT = 0; } } else pushT = 0;
  } else pushT = 0;
  if (kT > 0) { kT -= dt; movePlayer(kx * dt, 0); movePlayer(0, ky * dt); }
  if (pushObj >= 0) { pushAnim -= dt; if (pushAnim <= 0) pushObj = -1; }

  // saldırı
  bool atk = I.attack;
  if (atk && swordLv > 0 && attackT <= 0) { attackT = 0.24; attackId++; sfx(SFX_SWING); }
  if (atk && swordLv == 0 && !dlgClosed && toastT <= 0) toast("Kılıcın yok. Önce yaşlı bekçiyi bul.");
  if (attackT > 0) {
    attackT -= dt;
    double p = 1 - attackT / 0.24;
    if (p > 0.15 && p < 0.95) {
      double dx, dy; dirVec(pdir, dx, dy);
      double reach = swordLv >= 2 ? 15 : 13;
      double hx = px + dx * reach, hy = py - 7 + dy * (reach - 1);
      EACH(e, ents) if (e.alive && !isProjT(e.type) && e.type != E_CAT) {
        double r = isBigT(e.type) ? 30 : 13, ex = e.x - hx, ey = (e.y - 7 - e.z) - hy;
        if (ex * ex + ey * ey < r * r) hitEnemy(e, px, py);
      }
      EACH(o, m.objs) if (o.alive && (o.type == O_BUSH || o.type == O_POT || o.type == O_THORN || o.type == O_SNOWBUSH || o.type == O_ICEWALL || o.type == O_FROZEN || EXT.cut.count(o.type))) {
        double ex = o.x - hx, ey = (o.y - 8) - hy;
        if (ex * ex + ey * ey >= 13 * 13) continue;
        if (EXT.cut.count(o.type)) { EXT.cut[o.type](o); continue; }
        if (o.type == O_ICEWALL || o.type == O_FROZEN) { melt(o); continue; }
        if (o.type == O_THORN && swordLv < 2) { if (toastT <= 0) { toast("Tahta kılıç bu dikenleri kesemiyor!"); sfx(SFX_CLICK); } continue; }
        m.removeObj(o);
        if (o.type == O_THORN) doorMask |= 1u << 20;
        if (o.type == O_SNOWBUSH) { burst(5, o.x, o.y - 8, 10); burst(0, o.x, o.y - 8, 4); sfx(SFX_SWING, 0.5); drop(o.x, o.y - 4, 0.3, 0.12); }
        else if (o.type == O_BUSH || o.type == O_THORN) { burst(0, o.x, o.y - 8, 9); sfx(SFX_SWING, 0.5); drop(o.x, o.y - 4, 0.28, 0.1); }
        else { burst(4, o.x, o.y - 6, 8, 0xb85a1c); sfx(SFX_HIT, 0.6); drop(o.x, o.y - 4, 0.9, 0.1); }
      }
      EACH(e, ents) if (e.alive && isProjT(e.type) && e.state != 9) {
        double ex = e.x - hx, ey = e.y - 6 - hy;
        if (ex * ex + ey * ey >= 14 * 14) continue;
        if (EXT.parry.count(e.type)) { EXT.parry[e.type](e); continue; }
        e.alive = false; burst(1, e.x, e.y - 6, 4, 0xd0d4e0); sfx(SFX_CLICK);
      }
    }
  }
  if (I.item) usePotion();
}
void Game::tryPush() {
  WorldMap& m = map;
  bool d2 = m.kind == MAP_DUNGEON2; Ext::PushX* xp = EXT.push.count(m.kind) ? &EXT.push[m.kind] : nullptr; int bflag = xp ? xp->flag : d2 ? F2_BLOCK : F_BLOCK;
  if (!isDg(m.kind) || (flags & bflag)) return;
  double dx, dy; dirVec(pdir, dx, dy);
  int fx = (int)std::trunc((px + dx * 10) / 16), fy = (int)std::trunc((py - 5 + dy * 10) / 16);
  for (size_t i = 0; i < m.objs.size(); i++) {
    Obj& o = *m.objs[i];
    if (o.type != O_BLOCK || o.tx != fx || o.ty != fy) continue;
    int nx = fx + (int)dx, ny = fy + (int)dy, nt = m.get(nx, ny);
    if (m.solid(nx, ny) || (nt != T_DFLOOR && nt != T_PLATE && nt != T_CARPET)) { sfx(SFX_CLICK, 0.4); return; }
    pushFX = o.x; pushFY = o.y;
    moveBlockTo(o, nx, ny);
    pushObj = (int)i; pushAnim = 0.25;
    sfx(SFX_RUMBLE, 0.5); haptic("hit");
    if (m.get(nx, ny) == T_PLATE) {
      flags |= bflag; if (xp) xp->done(); else if (d2) addRoomChest(5, 21, 10, 3); else addRoomChest(6, 16); sfx(SFX_MAGIC); shake = 0.3;
      toast("Taş plakaya oturdu. Bir sandık belirdi!"); saveGame();
    }
    return;
  }
}
void Game::updateArea() {
  WorldMap& m = map;
  if (isDg(m.kind)) {
    int r = roomOf(px, py);
    if (r != curRoom) { enterRoom(r, false); double dx, dy; dirVec(pdir, dx, dy); px += dx * 10; py += dy * 16; pvx = pvy = 0; }
    if (curRoom >= 0 && !roomClear(curRoom)) {
      bool any = false; EACH(e, ents) if (e.alive && !isProjT(e.type) && e.room == curRoom) any = true;
      if (!any) roomCleared(curRoom);
    }
    return;
  }
  if (m.kind == MAP_INTERIOR) return;
  if (m.kind == MAP_SNOW) { updateArea2(); return; }
  if (EXT.area.count(m.kind)) { EXT.area[m.kind](); return; }
  for (auto& f : EXT.areaOver) f();
  int tx = (int)std::trunc(px / 16), ty = (int)std::trunc(py / 16);
  if (cured) setMood(5);
  else if (night()) setMood(6);
  else if (std::abs(tx - 47) < 16 && ty > 46) setMood(0);
  else if (tx < 31) setMood(2);
  else setMood(1);
  if (qs[Q_CHICK] == 1) {
    int n = 0;
    EACH(e, ents) if (e.alive && e.type == E_CHICK) {
      bool inside = e.x > 59 * 16 && e.x < 62 * 16 && e.y > 64 * 16 && e.y < 67 * 16 + 4;
      if (inside && e.state != 3) { e.state = 3; sfx(SFX_CHIME, 0.5); burst(1, e.x, e.y - 8, 4, 0xffffff); }
      if (e.state == 3) n++;
    }
    if (n != qc[Q_CHICK]) { qc[Q_CHICK] = n; toast(fmt("Ağıldaki tavuklar: %d/4", n)); }
  }
}
void Game::checkTransitions() {
  WorldMap& m = map; int tx = (int)std::trunc(px / 16), ty = (int)std::trunc((py - 1) / 16);
  bool up = inp.ay < -0.4, down = inp.ay > 0.4;
  if (m.kind == MAP_OVER) {
    for (auto& f : EXT.transOver) if (f(tx, ty, up, down)) return;
    EACH(o, m.objs) if (o.alive && o.type == O_HOUSE && up && tx == o.tx + 1 && std::fabs(py - o.y) < 14 + PHH) {
      if (o.text == "L") { if (toastT <= 0) toast("Kapı kilitli. İçeriden horultu geliyor..."); }
      else if (fadeState == 0) { int id = atoi(o.text.c_str()), rx = o.tx + 1, ry = o.ty + 3; sfx(SFX_CLICK); fadeTo([this, id, rx, ry] { enterInterior(id, rx, ry); }); }
      return;
    }
    if (tx >= 46 && tx <= 48 && ty <= 12 && up && py < 12 * 16 + 14) {
      if (!hasLantern) { if (toastT <= 0) toast("İçerisi zifiri karanlık. Bir fener olmadan giremem."); }
      else if (!cured && fadeState == 0) fadeTo([this] { enterDungeon(); toast("ESKİ TAPINAK"); });
      else if (cured && toastT <= 0) toast("Tapınak artık sessiz. Kalbin ilk parçası burada değil.");
    }
    // Kuzey Geçidi: basamaklardan yukarı çık
    if (m.get(tx, ty) == T_PASS && up && py < 10 * 16 && fadeState == 0) {
      sfx(SFX_CLICK); fadeTo([this] { enterSnow(35 * 16 + 16, (SH - 3) * 16 + 4); pdir = 1; });
    }
  } else if (m.kind == MAP_SNOW) {
    checkTransitions2(tx, ty, up, down);
  } else if (EXT.trans.count(m.kind)) {
    EXT.trans[m.kind](tx, ty, up, down);
  } else if (m.kind == MAP_INTERIOR) {
    if (py > (IH - 1) * 16 + 2 && down && fadeState == 0) {
      int rx = interiorRet[0], ry = interiorRet[1]; bool snow = interior == 3; int out = EXT.interiorMap.count(interior) ? EXT.interiorMap[interior] : -1;
      fadeTo([this, rx, ry, snow, out] {
        if (out >= 0 && EXT.enterAt.count(out)) EXT.enterAt[out](rx, ry); else if (snow) enterSnow(rx * 16 + 8, ry * 16 + 12); else enterOverworld(rx * 16 + 8, ry * 16 + 12);
        pdir = 0;
      });
    }
  } else {
    if (m.get(tx, ty) == T_STAIRS && down && fadeState == 0) {
      int k = m.kind;
      if (EXT.exitDg.count(k)) fadeTo([this, k] { EXT.exitDg[k](); pdir = 0; });
      else if (k == MAP_DUNGEON2) fadeTo([this] { enterSnow(35 * 16 + 8, 8 * 16 + 4); pdir = 0; });
      else fadeTo([this] { enterOverworld(47 * 16 + 8, 13 * 16 + 12); pdir = 0; });
    }
    double dx, dy; dirVec(pdir, dx, dy);
    int fx = (int)std::trunc((px + dx * 9) / 16), fy = (int)std::trunc((py - 4 + dy * 9) / 16), ft = m.get(fx, fy);
    if (moving && (ft == T_DOOR_LOCK || ft == T_DOOR_BOSS)) {
      int lid = m.lockId[fy * m.W + fx];
      if (ft == T_DOOR_LOCK && keys > 0) { keys--; openLock(lid); sfx(SFX_RUMBLE); toast("Kilit açıldı."); saveGame(); }
      else if (ft == T_DOOR_BOSS && hasBossKey()) { openLock(lid); sfx(SFX_RUMBLE); toast("Büyük kapı gıcırdayarak açıldı..."); saveGame(); }
      else if (toastT <= 0) toast(ft == T_DOOR_BOSS ? "Bu kapı için BÜYÜK ANAHTAR lazım." : "Kilitli. Küçük bir anahtar lazım.");
    }
  }
}
// kahramanın önünde etkileşilebilir bir şey var mı
Game::Found Game::findInteract() {
  double dx, dy; dirVec(pdir, dx, dy); double qx = px + dx * 14, qy = py - 6 + dy * 14;
  for (auto& n : npcs) { double ex = n->x - qx, ey = n->y - 6 - qy; if (ex * ex + ey * ey < 15 * 15) return { n.get(), nullptr, nullptr }; }
  EACH(e, ents) if (e.alive && e.type == E_CAT) { double ex = e.x - qx, ey = e.y - 5 - qy; if (ex * ex + ey * ey < 14 * 14) return { nullptr, &e, nullptr }; }
  EACH(o, map.objs) {
    if (!o.alive) continue;
    int t = o.type;
    if (t != O_SIGN && t != O_CHEST && t != O_STALL && t != O_WELL && t != O_BED && t != O_SHELF && t != O_FIRE && t != O_OVEN && !(t == O_TORCH && o.var == 1)
      && t != O_ANVIL && t != O_SNOWMAN && t != O_FROZEN && t != O_CAMPFIRE && t != O_COUNTER && t != O_CRYSTAL && t != O_ICEWALL && !EXT.interact.count(t)) continue;
    double cx = o.x, cy = o.y - 8, r = 13;
    if (t == O_STALL || t == O_COUNTER) { cy = o.y - 6; r = 20; }
    if (t == O_BED) { cy = o.y - 16; r = 18; }
    if (t == O_SHELF || t == O_FIRE || t == O_OVEN || t == O_COUNTER) r = 18;
    if (EXT.interact.count(t)) r = interactR(o, cy);
    if ((cx - qx) * (cx - qx) + (cy - qy) * (cy - qy) > r * r) continue;
    return { nullptr, nullptr, &o };
  }
  return { nullptr, nullptr, nullptr };
}
void Game::interact() {
  if (!inp.pressed.act || dlgClosed) return;
  Found f = findInteract();
  if (f.npc) { talk(*f.npc); return; }
  if (f.cat) { catTouch(*f.cat); return; }
  if (!f.obj) return;
  Obj& o = *f.obj;
  switch (o.type) {
    case O_SIGN: say({ L("Tabela", o.text) }); return;
    case O_CHEST: tryOpenChest(o); return;
    case O_STALL: shop(); return;
    case O_WELL: if (!useWell()) say({ L("", "Kuyunun dibinde yıldızlar parlıyor. Bir dilek tuttun.") }); return;
    case O_BED: sleep(); return;
    case O_SHELF: say({ L("", interior == 0 ? "'Yeşilvadi'nin Kısa Tarihi'. İlk sayfada: 'Ormanın Kalbi gökten düşen bir yıldızdır.'" :
      interior == 2 ? "Babanın kitapları. Birinin arasından kurumuş bir yaprak düştü: kuzeydeki dağların haritası." :
        "Un çuvalları ve tarif defterleri. 'Hatice'nin gizli tarçınlı çöreği' sayfası yırtılmış.") }); return;
    case O_FIRE: say({ L("", "Ateşin sıcaklığı içini ısıttı.") }); return;
    case O_OVEN: say({ L("", "Fırından mis gibi ekmek kokusu geliyor.") }); return;
    case O_TORCH:
      if (o.var == 1) {
        if (!hasLantern) { say({ L("", "Sönük bir meşale. Yakmak için ateş lazım.") }); return; }
        o.var = 0; sfx(SFX_FIRE); burst(1, o.x, o.y - 22, 6, 0xf8b030);
        int lit = 0; EACH(t, map.objs) if (t.type == O_TORCH && t.var == 0 && t.ty >= RH * 2 && t.tx >= RW * 2) lit++;
        toast(fmt("Meşale yandı (%d/4)", lit));
        bool d2 = map.kind == MAP_DUNGEON2; int tflag = d2 ? F2_TORCH : F_TORCH;
        if (lit >= 4 && !(flags & tflag)) {
          flags |= tflag; if (d2) addRoomChest(8, 19); else addRoomChest(8, 17);
          sfx(SFX_MAGIC); toast("Dört alev yandı. Bir sandık belirdi!"); saveGame();
        }
      }
      return;
    default: interact2(o); return;
  }
}
void Game::sleep() {
  if (interior < 2 || interior > 5) { say({ L("", "Başkasının yatağında uyumak olmaz.") }); return; }
  if (interior >= 3) { innSleep(); return; }
  ask({ L("", "Yatağın yumuşak görünüyor. Sabaha kadar uyumak ister misin? (Oyun kaydedilir.)") }, { "Uyu", "Vazgeç" }, [this](int c) {
    if (c != 0) return;
    fadeTo([this] {
      if (dayT > 0.25) dayN++;
      dayT = 0.27; hp = maxHp; placeNPCs();
      saveGame();
      say({ L("", "Arda deliksiz bir uyku çekti. Pencereden sabah güneşi süzülüyor.") });
      toast(fmt("Gün %d • Can doldu • Kaydedildi", dayN));
    });
  });
}
void Game::catTouch(Ent& e) {
  if (qs[Q_CAT] == 0) {
    say({ L("Tekir", "Miyav!"), L("Arda", "Ne tatlı bir kedi. Tasmasında 'Kemal' yazıyor.") }, [this] {
      EACH(c, ents) if (c.alive && c.type == E_CAT) c.state = 1;
      qs[Q_CAT] = 1; flags |= 1 << 10; toast("Tekir peşine takıldı. Kemal Usta'ya götür.");
    });
  } else if (e.state == 0) { e.state = 1; flags |= 1 << 10; say({ L("Tekir", "Mırr... (peşine takıldı)") }); }
  else say({ L("Tekir", "Miyav? (Kemal Usta'nın yanına götür)") });
}
void Game::shop() {
  if (night()) { say({ L("", "Tezgâh kapalı. Bir not var: 'Sabah gel. - Kemal'") }); return; }
  if (EXT.talkPre.count(N_SHOP) && EXT.talkPre[N_SHOP](nullptr)) return;
  ask({ L("Kemal Usta", "Hoş geldin, delikanlı! Kemal Usta'nın tezgâhında ne ararsan var. Neye bakmıştın?") },
    { hasLantern ? "Fener (satıldı)" : "Fener — 40 altın", "Can iksiri — 15 altın", "Sadece bakıyorum" }, [this](int c) {
      if (c == 0) {
        if (hasLantern) say({ L("Kemal Usta", "Fenerini zaten aldın. Tek fenerim oydu, kıymetini bil!") });
        else if (coins >= 40) { coins -= 40; hasLantern = true; showItem(A.lantern, "FENER! Karanlıkta ışık saçar."); saveGame();
          say({ L("Kemal Usta", "Hay hayır gör! Bu fener dedemin dedesinden kalma. Geceleri de yolunu aydınlatır.") }); }
        else say({ L("Kemal Usta", "40 altın, evlat. Ne bir eksik ne bir fazla. Çalıları kes, saksıları kır; altın bulursun.") });
      } else if (c == 1) {
        if (coins >= 15) { coins -= 15; potions++; showItem(A.potion, "Can iksiri! İksir düğmesiyle iç."); saveGame(); }
        else say({ L("Kemal Usta", "15 altın lazım. Bedava iksir yok, bu bir dükkân, hayır kurumu değil!") });
      } else say({ L("Kemal Usta", "Bakmak bedava. Ama dokunmak... o da bedava. Neyse.") });
    });
}
void Game::talk(Npc& n) {
  sfx(SFX_BLIP);
  if (EXT.talkPre.count(n.id) && EXT.talkPre[n.id](&n)) return;
  switch (n.id) {
    case N_ELDER:
      if (mainStep >= 6) { talkElder2(); return; }
      if (mainStep == 5) {
        mainStep = 6; cured = true; saveGame();
        say({ L("Bilge Nine", "Arda... Bu ışık... Ormanın Kalbi! Getirdin!"),
          L("", "Nine taşı iki eliyle havaya kaldırdı. Yeşil bir ışık köyün üstünden ormana, gölden tapınağa kadar yayıldı."),
          L("", "Kara sis dağıldı. Balçıklar eriyip toprağa karıştı. Yarasalar yeniden kuşa döndü."),
          L("Bilge Nine", "Ama... bekle. Taşın bir kenarı kırık. Bu Kalbin tamamı değil."),
          L("Arda", "Babamın mektubunda yazıyordu: Kalp dört parçaya bölünmüş bir yıldızmış."),
          L("Bilge Nine", "Demek baban biliyordu... Sis şimdilik çekildi ama geri dönecek. Diğer üç parçayı bulmalısın."),
          L("Bilge Nine", "Kuzeydeki karlı dağlar, doğudaki batık şehir ve göklerdeki kule... Ama bunlar başka bir günün hikâyesi."),
          L("Bilge Nine", "Bugün dinlen. Yeşilvadi'nin Bekçisi sensin artık.") },
          [this] { fadeTo([this] { state = S_CREDITS; creditsT = 0; setMood(5); }); });
        return;
      }
      if (night() && map.kind == MAP_INTERIOR) {
        if (qs[Q_GHOST] == 0) {
          say({ L("Bilge Nine", "Bu saatte ne arıyorsun, evladım? Dışarıda hortlaklar dolaşıyor."),
            L("Bilge Nine", "Kara sisle birlikte geldiler. Köye yaklaştıkça çocuklar uyuyamıyor."),
            L("Bilge Nine", "Cesaretin varsa 5 hortlak kov. Sana ödül olarak bir kalp parçası veririm.") },
            [this] { qs[Q_GHOST] = 1; qc[Q_GHOST] = 0; toast("Yeni görev: Gece Hortlakları"); saveGame(); });
          return;
        }
        if (qs[Q_GHOST] == 1 && qc[Q_GHOST] >= 5) {
          say({ L("Bilge Nine", "Beş hortlak mı? Köydeki herkes bu gece rahat uyuyacak. Al bakalım.") }, [this] { qs[Q_GHOST] = 2; givePiece(); saveGame(); });
          return;
        }
        say({ L("Bilge Nine", qs[Q_GHOST] == 1 ? "Hortlaklar yalnızca geceleri dolaşır. Kılıcını sağlam tut." : "Hortlakları kovduğun için sağ ol. Şimdi git uyu, yarın uzun bir gün.") });
        return;
      }
      if (mainStep == 0) {
        mainStep = 1;
        say({ L("Bilge Nine", "Arda! Gel yanıma, evladım. Dün gece kuzeydeki Eski Tapınak'tan kara bir sis yükseldi. Ormanın Kalbi kayboldu."),
          L("Bilge Nine", "Kalp olmadan orman hastalanıyor. Hayvanlar balçığa, kuşlar yarasaya dönüşüyor. Geceleri hortlaklar dolaşıyor."),
          L("Arda", "Ne yapmam gerek, Nine?"),
          L("Bilge Nine", "Tapınağa giden yolu dikenli çalılar kapattı. Onları kesmek için iyi bir kılıç lazım."),
          L("Bilge Nine", "Batıdaki Fısıltılı Orman'da, uçurumun dibindeki mağarada yaşlı bir bekçi yaşar. Bir zamanlar kılıç ustasıydı. Onu bul."),
          L("Bilge Nine", "Tapınağın içi karanlıktır; Kemal Usta'nın tezgâhından bir fener alman gerekecek. 40 altına satıyor."),
          L("Bilge Nine", "Köydekilere de yardım et. Herkesin bir derdi var bu aralar. Yorulursan evine gidip uyu.") },
          [this] { saveGame(); });
      } else say({ L("Bilge Nine", mainStep < 3 ? "Yaşlı bekçi batıdaki ormanın kuzeyinde, uçurumun dibindeki mağarada yaşar." :
        "O kılıç sana yakıştı. Fenerini al ve kuzeydeki tapınağa git. Geceleri köyden uzaklaşırken dikkatli ol.") });
      break;
    case N_HERMIT:
      if (mainStep <= 1) {
        say({ L("Yaşlı Bekçi", "Hımm... Bu yaşlı gözler uzun zamandır ziyaretçi görmedi."),
          L("Yaşlı Bekçi", "Ormanın Kalbi'ni geri getirmeye mi gidiyorsun? O dikenli çalılar sıradan bir kılıçla kesilmez."),
          L("Yaşlı Bekçi", "Sana gerçek bir kılıç dövebilirim. Ama ocağım şifalı mantarlar olmadan yanmaz."),
          L("Yaşlı Bekçi", "Ormanda üç şifalı mantar bul. Biri kuzeydoğudaki açıklıkta, biri ormanın gizli köşesinde..."),
          L("Yaşlı Bekçi", "Üçüncüsünü ise Yaşlı Kütük yuttu. Ormanın batısındaki korusunda bekler. Dikkat et, tohum tükürür."),
          L("Yaşlı Bekçi", "Al, şimdilik bu tahta kılıçla idare et.") },
          [this] {
            swordLv = 1; mainStep = 2; showItem(A.woodSword, "TAHTA KILIÇ! Kılıç düğmesiyle saldır.");
            for (int i = 0; i < 2; i++) if (!((mushMask >> i) & 1)) addMush(i, MUSH_POS[i][0] * 16 + 8, MUSH_POS[i][1] * 16 + 12);
            if ((flags & F_STUMP) && !((mushMask >> 2) & 1)) addMush(2, 9 * 16 + 8, 36 * 16 + 12);
            saveGame();
          });
      } else if (mainStep == 2) {
        if (mushMask == 7) {
          say({ L("Yaşlı Bekçi", "Üçü de burada! Ocağım yıllardır böyle harlanmamıştı. Bekle..."),
            L("", "Mağaradan çekiç sesleri yükseldi. Kıvılcımlar uçuştu. Bir süre sonra yaşlı bekçi elinde parıldayan bir kılıçla çıktı."),
            L("Yaşlı Bekçi", "Bekçi Kılıcı. Dikenleri de, kara sisin yarattıklarını da keser. İki kat güçlüdür.") },
            [this] {
              swordLv = 2; mainStep = 3; showItem(A.sword, "BEKÇİ KILICI! Dikenli çalıları keser, iki kat vurur.");
              say({ L("Yaşlı Bekçi", "Tapınağın efendisi, Kara Balçık Kral... Bölündükçe çoğalır. Sabırlı ol, evlat."),
                L("Yaşlı Bekçi", "Taş tükürenlerin taşlarını ve diken çiçeklerinin tohumlarını kılıcınla geri çevirebilirsin.") }, [this] { saveGame(); });
            });
        } else say({ L("Yaşlı Bekçi", fmt("Şimdiye kadar %d mantar buldun. Üçü de lazım. Yaşlı Kütük'ü unutma.", mushCount())) });
      } else say({ L("Yaşlı Bekçi", "Kılıcın keskin, yüreğin cesur. Gerisi sabır işi.") });
      break;
    case N_SHOP:
      if (qs[Q_CAT] == 0) {
        say({ L("Kemal Usta", "Ah delikanlı, dertliyim. Kedim Tekir iki gündür kayıp! Balıkçılar onu gölün güneydoğusunda görmüş."),
          L("Kemal Usta", "Bulursan sana güzel bir şey veririm. Ama önce... alışveriş yapacak mısın?") },
          [this] { qs[Q_CAT] = 1; toast("Yeni görev: Kayıp Kedi"); saveGame(); shop(); });
        return;
      }
      if (qs[Q_CAT] == 1) {
        EACH(e, ents) if (e.alive && e.type == E_CAT && e.state == 1 && std::fabs(e.x - px) < 60 && std::fabs(e.y - py) < 60) {
          e.alive = false; poof(e.x, e.y - 6);
          say({ L("Kemal Usta", "TEKİR! Gel buraya seni yaramaz! ...Teşekkür ederim delikanlı, gerçekten."),
            L("Kemal Usta", "Al şunu: dedemden kalma bir kalp parçası. Ve 15 altın. Bunu kimseye söyleme, cimri diye bilinirim.") },
            [this] { qs[Q_CAT] = 2; flags &= ~(1 << 10); coins += 15; givePiece(); saveGame(); });
          return;
        }
      }
      shop();
      break;
    case N_KID:
      if (qs[Q_CHICK] == 0) {
        say({ L("Küçük Efe", "Ağabey! Tavuklar ağıldan kaçtı, annem beni öldürecek!"),
          L("Küçük Efe", "Dördünü de ağıla sokabilir misin? Kapı sol üst köşede. Tavuklar senden kaçar; onları kapıya doğru sür!") },
          [this] { qs[Q_CHICK] = 1; qc[Q_CHICK] = 0; toast("Yeni görev: Kaçak Tavuklar"); saveGame(); });
      } else if (qs[Q_CHICK] == 1 && qc[Q_CHICK] >= 4) {
        say({ L("Küçük Efe", "Hepsi içeride! Sen bir kahramansın! Al, bunu derenin dibinde bulmuştum.") }, [this] { qs[Q_CHICK] = 2; givePiece(); saveGame(); });
      } else say({ L("Küçük Efe", qs[Q_CHICK] == 1 ? fmt("Ağılda %d tavuk var. Dördü lazım! Arkalarından yaklaş, kaçsınlar.", qc[Q_CHICK]) : string("Tavuklar mutlu, annem mutlu, ben mutluyum!")) });
      break;
    case N_FISHER:
      if (flags & F_BASKET) {
        say({ L("Balıkçı Çocuk", "Hatice Teyze'nin ekmeği mi? Sabahtan beri açım! Sağ ol!") },
          [this] { flags &= ~F_BASKET; flags |= F_BREADSHOP; qs[Q_BREAD] = 2; coins += 20; showItem(A.coin[0], "20 altın! Fırıncı artık sana ekmek satıyor."); saveGame(); });
        return;
      }
      if (qs[Q_OCTO] == 0) {
        say({ L("Balıkçı Çocuk", "Taş tükürenler yüzünden balık tutamıyorum! Altısını temizlersen sana bir sır veririm."),
          L("Balıkçı Çocuk", "İpucu: taşlarını kılıcınla geri çevirebilirsin. Göldeki adada bir sandık da var!") },
          [this] { qs[Q_OCTO] = 1; qc[Q_OCTO] = 0; toast("Yeni görev: Göl Temizliği"); saveGame(); });
      } else if (qs[Q_OCTO] == 1 && qc[Q_OCTO] >= 6) {
        say({ L("Balıkçı Çocuk", "Göl tertemiz! Söz verdiğim sır: oltama takılan bu parlak şey. Kalp parçası galiba!") }, [this] { qs[Q_OCTO] = 2; givePiece(); saveGame(); });
      } else say({ L("Balıkçı Çocuk", qs[Q_OCTO] == 1 ? fmt("Kaç tane temizledin? %d/6. Devam!", qc[Q_OCTO]) : string("Bugün balıklar bol!")) });
      break;
    case N_BAKER:
      if (qs[Q_BREAD] == 0) {
        say({ L("Fırıncı Hatice", "Arda, yavrum! Balıkçı çocuk sabahtan beri gölde, bir lokma yemedi."),
          L("Fırıncı Hatice", "Şu sepeti ona götürür müsün? Gölün batı kıyısında, köprünün yakınında olur. Ama gündüz git, gece evine döner.") },
          [this] { qs[Q_BREAD] = 1; flags |= F_BASKET; toast("Yeni görev: Sıcak Ekmek (sepet alındı)"); saveGame(); });
        return;
      }
      if (flags & F_BREADSHOP) {
        ask({ L("Fırıncı Hatice", "Sıcak ekmek ister misin? Karnını doyurur, canını tazeler. Tanesi 10 altın.") }, { "Ekmek al (10 altın)", "Sağ ol, Hatice Teyze" }, [this](int c) {
          if (c == 0) {
            if (coins >= 10) { coins -= 10; breads++; showItem(A.bread, "Ekmek! İksirin yoksa İksir düğmesiyle ye. (+2 kalp)"); saveGame(); }
            else say({ L("Fırıncı Hatice", "Altının yetmiyor yavrum. Bir dahaki sefere.") });
          }
        });
        return;
      }
      say({ L("Fırıncı Hatice", "Sepeti balıkçı çocuğa götürdün mü? Ekmek soğumadan!") });
      break;
    default: talk2(n); break;
  }
}
