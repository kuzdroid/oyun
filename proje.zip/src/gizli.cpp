// ORMANIN KALBİ - gizli içerik
// 1. bölüm: Yaşlı Bekçi'nin mağarasının derinlikleri -> Dostluk Madalyonu -> Kemal Usta kaçar -> geri dönünce gizli boss "Demir Çekiç Kemal"
// 2. bölüm: Yeti Mağarası'nın derinlikleri -> gizli boss "Gölge Yeti"
// Bilgisayarda Kemal'in yanında "hammer of justice" yazılırsa kahkaha atar.
#include "game.h"

static const double STALL_POS[2] = { 52 * 16 + 8, 59 * 16 + 4 };

// ---------------- mağara haritası ----------------
void buildCave(WorldMap& m, int id) {
  m.init(46, 16, MAP_CAVE, T_CTOP);
  auto rect = [&](int x, int y, int w, int h) { for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) m.set(xx, yy, T_CFLOOR); };
  rect(2, 8, 9, 6); rect(13, 3, 9, 6); rect(24, 8, 9, 6); rect(34, 2, 10, 11);   // dört oda
  rect(10, 10, 8, 2); rect(16, 6, 2, 6);
  rect(21, 5, 8, 2); rect(27, 5, 2, 5);
  rect(32, 10, 3, 2);
  m.set(3, 14, T_STAIRS); m.set(4, 14, T_STAIRS);
  for (int y = 1; y < 16; y++) for (int x = 0; x < 46; x++) if (m.get(x, y) == T_CTOP && m.get(x, y + 1) == T_CFLOOR) m.set(x, y, T_CWALL);
  for (auto p : { std::pair{3, 9}, {9, 9}, {14, 4}, {20, 4}, {25, 9}, {31, 9}, {35, 3}, {42, 3} }) m.add(O_TORCH, p.first, p.second);
  for (auto p : { std::pair{6, 11}, {18, 7}, {29, 12}, {37, 9}, {41, 9} }) m.add(O_ROCK, p.first, p.second).var = 1;
  for (auto p : { std::pair{9, 12}, {14, 7}, {31, 12} }) m.add(O_POT, p.first, p.second);
  if (id == 0) {
    m.add(O_CHEST, 40, 4).var = 27;   // Dostluk Madalyonu
    m.add(O_CHEST, 20, 4).var = 28;   // 50 altın
    m.add(O_SIGN, 38, 11, 1, 1).text = "Duvara kazınmış: 'K + Y — Yeşilvadi'nin iki bekçisi. Sonsuza dek.'";
  } else {
    for (auto p : { std::pair{15, 5}, {26, 11}, {36, 4}, {42, 11} }) m.add(O_CRYSTAL, p.first, p.second);
    m.add(O_SIGN, 34, 12, 1, 1).text = "Buzun içine kazınmış pençe izleri. Daha büyük bir şey burada yaşıyor.";
  }
}

void Game::enterCave(int id) {
  WorldMap& m = map;
  buildCave(m, id);
  caveId = id; interior = -1;
  ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1; pvx = pvy = 0;
  EACH(o, m.objs) if (o.type == O_CHEST && ((chestMask >> o.var) & 1)) o.var |= 0x100;
  auto at = [&](int t, int x, int y) { spawn(t, x * 16 + 8, y * 16 + 12); };
  if (id == 0) { at(E_BAT, 15, 5); at(E_BAT, 19, 6); at(E_SKEL, 27, 10); at(E_SKEL, 30, 11); at(E_SLIMER, 6, 10); at(E_BAT, 38, 6); at(E_SKEL, 41, 7); at(E_SLIMER, 25, 12); }
  else { at(E_ICEBAT, 15, 5); at(E_ICEBAT, 19, 6); at(E_SNOWWOLF, 27, 10); at(E_ICESLIME, 30, 11); at(E_ICESLIME, 6, 10); at(E_SNOWWOLF, 9, 11); at(E_ICEBAT, 26, 9); }
  px = 4 * 16; py = 13 * 16 + 8; pdir = 1;
  camX = clampf(px - VW / 2.0, 0, m.W * 16 - VW); camY = clampf(py - VH / 2.0, 0, m.H * 16 - VH);
  setMood(3);
  toast(id == 0 ? "YAŞLI BEKÇİNİN MAĞARASI" : "YETİ MAĞARASI");
}
Ent* Game::findEnt(int uid) { if (!uid) return nullptr; for (auto& e : ents) if (e->uid == uid) return e.get(); return nullptr; }
Ent* Game::firstEnt(int type) { for (auto& e : ents) if (e->alive && e->type == type) return e.get(); return nullptr; }
// Kemal Usta'nın yakınında mıyız (kahkaha için)
bool Game::nearKemal() {
  if (firstEnt(E_KEMAL)) return true;
  if (map.kind != MAP_OVER) return false;
  return std::fabs(px - STALL_POS[0]) < 170 && std::fabs(py - STALL_POS[1]) < 120;
}
// klavyeden yazılan harfler (bilgisayar)
void Game::typed(int ch) {
  if (ch >= 'A' && ch <= 'Z') ch += 32;
  if (ch < 'a' || ch > 'z') return;
  typedBuf += (char)ch;
  if (typedBuf.size() > 24) typedBuf.erase(0, typedBuf.size() - 24);
  const string key = "hammerofjustice";
  if (typedBuf.size() >= key.size() && typedBuf.compare(typedBuf.size() - key.size(), key.size(), key) == 0) { typedBuf.clear(); hammerOfJustice(); }
}
void Game::hammerOfJustice() {
  if (state != S_PLAY) return;
  if (nearKemal()) {
    sfx(SFX_LAUGH); sec |= SEC_LAUGH; shake = 0.3;
    Ent* k = firstEnt(E_KEMAL);
    if (k) { k->rage = 6; toast("Kemal Usta: GYAH GYAH GYAH! Adaletin çekici iner!"); }
    else toast("Kemal Usta: GYAH GYAH GYAH! O sözü nereden duydun sen?!");
  } else { sfx(SFX_LAUGH, 0.3); toast("Uzaklardan yaşlı bir kahkaha yankılandı..."); }
}
void Game::startKemalFight() {
  if (firstEnt(E_KEMAL)) return;
  Ent& k = spawn(E_KEMAL, STALL_POS[0], STALL_POS[1] + 24); k.hx = k.x; k.hy = k.y; k.dir = 2;
  say({ L("Kemal Usta", "Demek madalyonu sen getirdin... Onu kazandığımız gün Kara Balçık'ı ilk kez yenmiştik, Yaşlı Bekçi'yle ikimiz."),
    L("Kemal Usta", "Sonra bir hazine yüzünden küstük. Kırk yıl! Kırk yıl tezgâh başında çürüdüm..."),
    L("Kemal Usta", "Ama madalyonu görünce damarlarımdaki kan yeniden kaynadı. Ben Kemal! Yeşilvadi'nin DEMİR ÇEKİCİ!"),
    L("Kemal Usta", "Bakalım yeni bekçi ne kadar güçlü. Çekicimi geri çevirebilir misin? HAZIR OL!") },
    [this] { toast("GİZLİ BOSS: DEMİR ÇEKİÇ KEMAL"); setMood(4); sfx(SFX_RUMBLE); shake = 0.5; });
}
// mermiler: çekiç (bumerang gibi döner), gökten yağan altınlar
void Game::stepHammer(Ent& e, double dt) {
  Ent* o = findEnt(e.own); if (o && !o->alive) o = nullptr;
  if (e.t < 0.55) { e.x += e.vx * dt; e.y += e.vy * dt; }
  else if (o) { double ax = o->x - e.x, ay = o->y - 10 - e.y, al = std::hypot(ax, ay) + 0.01; e.x += ax / al * 190 * dt; e.y += ay / al * 190 * dt; if (al < 10) e.alive = false; }
  else e.alive = false;
  if (e.t > 3) e.alive = false;
  projHit(e, 2, 10);
}
void Game::stepCoin(Ent& e, double dt) {
  e.vz -= 320 * dt; e.z += e.vz * dt;
  if (e.z <= 0) {
    e.alive = false; burst(1, e.x, e.y - 4, 4, 0xf8d848); sfx(SFX_CLICK, 0.4);
    for (auto& p : heroes()) if (std::fabs(p.x - e.x) < 12 && std::fabs(p.y - e.y) < 10) hurtAt(p, 1, e.x, e.y);
  }
}
// mermi oyuncuya değdi mi
void Game::projHit(Ent& e, int dm, double r) { for (auto& p : heroes()) if (std::fabs(p.x - e.x) < r && std::fabs(p.y - 6 - e.y) < r) { hurtAt(p, dm, e.x, e.y); if (e.type != E_HAMMER) e.alive = false; } }
// iki kişilik oyunda her iki kahraman; tek kişide yalnızca birinci
std::vector<Hero> Game::heroes() { std::vector<Hero> h{ { px, py, 1 } }; if (p2 && !p2->deadT) h.push_back({ p2->px, p2->py, 2 }); return h; }
void Game::hurtAt(const Hero& p, int d, double fx, double fy) { if (p.n == 2) hurtP2(d, fx, fy); else hurtPlayer(d, fx, fy); }

void Game::initGizli() {
  EXT.hp[E_KEMAL] = 48; EXT.hp[E_SYETI] = 30;
  EXT.mood[MAP_CAVE] = 3;
  // ---------------- Kemal Usta ----------------
  EXT.enemy[E_KEMAL] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (dlg) return;
    bool fast = e.hp <= e.maxHp / 2 || e.rage > 0;
    if (e.rage > 0) e.rage -= dt;
    auto clampSq = [&] { e.x = clampf(e.x, 37 * 16, 60 * 16); e.y = clampf(e.y, 49 * 16, 66 * 16); };
    if (e.state == 1) {   // hücum
      bool hit = moveE(e, e.vx * dt, e.vy * dt, 7, 6); clampSq();
      if (hit || e.t > 0.6) { e.state = 0; e.t = 0; if (hit) { shake = 0.2; sfx(SFX_HIT, 0.6); } }
    } else if (e.state == 3) {   // sıçrayıp çekiçle yere vurma
      e.vz -= 340 * dt; e.z += e.vz * dt; moveE(e, e.vx * dt, e.vy * dt, 7, 6); clampSq();
      if (e.z <= 0) {
        e.z = 0; e.vz = 0; e.state = 0; e.t = 0; shake = 0.5; sfx(SFX_RUMBLE); haptic("big");
        slamRing(e);
        burst(4, e.x, e.y, 14, 0x9094a4);
      }
    } else {
      moveE(e, dx / d * (fast ? 34 : 24) * dt, dy / d * (fast ? 34 : 24) * dt, 7, 6); clampSq();
      if (e.t > (fast ? 0.85 : 1.25)) {
        e.t = 0; e.cd += 1;
        int act = I(e.cd) % 4;
        double ex = e.x, ey = e.y; int room = e.room, uid = e.uid;
        if (act == 0) {   // çekiç fırlat
          int n = fast ? 2 : 1;
          for (int i = 0; i < n; i++) {
            double a = std::atan2(dy, dx) + (n == 2 ? (i ? 0.35 : -0.35) : 0);
            Ent& h = shoot(E_HAMMER, ex, ey - 12, std::cos(a) * 170, std::sin(a) * 170, room); h.own = uid; h.hx = 0; h.hy = 0;
          }
          sfx(SFX_SWING);
        } else if (act == 1) { e.state = 1; e.t = 0; e.vx = dx / d * 175; e.vy = dy / d * 175; sfx(SFX_SNORT, 0.6); }
        else if (act == 2) { e.state = 3; e.vz = 230; e.vx = dx / 1.5; e.vy = dy / 1.5; }
        else {   // altın yağmuru: gölgesi düşen yere dikkat!
          int n = fast ? 9 : 6; double tx = px, ty = py;
          for (int i = 0; i < n; i++) {
            double a = i * PI * 2 / n + rnd(), r = i == 0 ? 0 : 18 + rnd() * 40;
            Ent& c = shoot(E_COINP, tx + std::cos(a) * r, ty + std::sin(a) * r * 0.7, 0, 0, room); c.z = 90 + i * 14; c.hx = 0; c.hy = 0;
          }
          toast("Kemal Usta: Al sana altın! Gyah!"); sfx(SFX_CHIME, 0.5);
        }
      }
    }
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.enemy[E_HAMMER] = [this](Ent& e, double dt, double, double, double) { stepHammer(e, dt); };
  EXT.enemy[E_COINP] = [this](Ent& e, double dt, double, double, double) { stepCoin(e, dt); };
  EXT.draw[E_KEMAL] = [this](Ent& e, double x, double y, bool fl) {
    double sc = 1.7, bob = e.state == 0 ? std::fabs(std::sin(e.t * 6)) : 0; const Spr* s0 = A.kemalB;
    spr(A.shadow, x - 13, y - 5, false, 1, 1.7, 1.5);
    spr(s0, x - s0->w * sc / 2, y - s0->h * sc - e.z + 2 - bob, e.dir == 2, 1, sc, sc, fl);
    bool thrown = false; for (auto& h : ents) if (h->alive && h->type == E_HAMMER && h->own == e.uid) thrown = true;
    if (!thrown) rot(A.hammer, x + (e.dir == 2 ? -12 : 12), y - 22 - e.z - bob, 7, 12, (e.dir == 2 ? -0.6 : 0.6) + (e.state == 3 ? -1.2 : 0));
  };
  EXT.draw[E_HAMMER] = [this](Ent& e, double x, double y, bool) { spr(A.shadow, x - 4, y - 1, false, 0.6, 0.5); rot(A.hammer, x, y - 8, 7, 7, e.t * 16); };
  EXT.draw[E_COINP] = [this](Ent& e, double x, double y, bool) {
    double k = clampf(1 - e.z / 140, 0.2, 1);
    spr(A.shadow, x - 5 * k, y - 2, false, 0.4 + 0.5 * k, 0.6 * k, 0.6 * k);
    const Spr* s0 = A.coin[I(e.t * 10) & 3]; spr(s0, x - s0->w / 2, y - 10 - e.z);
  };
  EXT.kill[E_KEMAL] = [this](Ent& e) {
    shake = 0.8; haptic("big");
    EACH(o, ents) if (o.alive && (o.type == E_HAMMER || o.type == E_COINP)) o.alive = false;
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 4; i++) poof(ex + (rnd() - 0.5) * 30, ey - 10 - rnd() * 20);
    say({ L("Kemal Usta", "Of... of... Dizlerim! Tamam, tamam, yeter! Yendin beni, evlat. Gyah gyah... uff."),
      L("Kemal Usta", "Yaşlı Bekçi'ye söyle: kırk yıllık küslük bitti. Bu akşam onun mağarasına çay içmeye gidiyorum."),
      L("Kemal Usta", "Al şunu. Gençliğimin kalkanı: Bekçi Kalkanı. Darbelerin acısını o yesin. Bir de kesemden yüz altın... Kimseye söyleme!") },
      [this] {
        sec |= SEC_KEMAL; coins = std::min(999, coins + 100); maxHp += 2; hp = maxHp;
        showItem(A.shield, "BEKÇİ KALKANI! Aldığın her darbe 1 azalır. +1 kalp kabı");
        placeNPCs(); setMood(cured ? 5 : 0); saveGame();
      });
    return true;
  };
  // ---------------- Gölge Yeti (2. bölüm gizli bossu) ----------------
  EXT.enemy[E_SYETI] = [this](Ent& e, double dt, double dx, double dy, double d) {
    e.type = E_YETI; updateEnemy2(e, dt * 1.25, dx, dy, d); e.type = E_SYETI;   // Yeti gibi ama daha hızlı
    if (e.t < dt * 1.3 && I(e.cd) % 5 == 4 && !e.called) {
      e.called = true; double ex = e.x, ey = e.y;
      for (int sg = -1; sg <= 1; sg += 2) spawn(E_SNOWWOLF, ex + sg * 30, ey + 10);
      toast("Gölge Yeti kurtlarını çağırdı!"); sfx(SFX_GROWL);
    }
    if (I(e.cd) % 5 != 4) e.called = false;
  };
  EXT.draw[E_SYETI] = [this](Ent& e, double x, double y, bool fl) {
    const Spr* s0 = A.syeti[e.state == 1 || e.state == 3 ? 1 : I(e.t * 3) & 1]; double sc = 1.25;
    spr(A.shadow, x - 22, y - 7, false, 1, 2.8, 2.1);
    spr(s0, x - s0->w * sc / 2, y - s0->h * sc - e.z + 3, e.dir == 2, 1, sc, sc, fl);
  };
  EXT.kill[E_SYETI] = [this](Ent& e) {
    sec |= SEC_YCAVE; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 6; i++) poof(ex + (rnd() - 0.5) * 50, ey - 10 - rnd() * 30);
    addPick(P_HEARTC, ex, ey, 90);
    for (int i = 0; i < 12; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 40, ey + (rnd() - 0.5) * 26, 80 + rnd() * 40, 5);
    toast("GİZLİ BOSS YENİLDİ: GÖLGE YETİ"); setMood(5); saveGame();
    return true;
  };
  // ---------------- sandıklar ----------------
  EXT.chest[27] = [this](int) {
    sec |= SEC_MEDAL; showItem(A.medal, "DOSTLUK MADALYONU!");
    say({ L("", "Sandığın içinde, kadife bir bezin üstünde eski bir madalyon duruyor. Arkasında iki harf kazılı: K ve Y."),
      L("Arda", "K ve Y... Yaşlı Bekçi'nin adı Y ile mi başlıyordu? Bunu ona sormalıyım.") });
  };
  EXT.chest[28] = [this](int) { coins += 50; showItem(A.coin[0], "50 altın buldun!"); };
  // ---------------- konuşmalar ----------------
  EXT.talkPre[N_HERMIT] = [this](Npc*) {
    if (mainStep < 3) return false;
    int s0 = sec;
    if (!(s0 & SEC_MEDAL)) {
      say({ L("Yaşlı Bekçi", "Mağaramın derinliklerine yıllardır inmedim. Orada eski bir anım kaldı... Dizlerim artık izin vermiyor."),
        L("Yaşlı Bekçi", "Cesaretin varsa sen in. Fenerini yanına al; içerisi zifiri karanlık ve kemikler hâlâ yürüyor.") });
      return true;
    }
    if (!(s0 & SEC_HERMIT)) {
      say({ L("Yaşlı Bekçi", "Bu... Dostluk Madalyonu! Nereden buldun? Ah, mağaranın dibinden tabii."),
        L("Yaşlı Bekçi", "Gençken Kemal'le ben Yeşilvadi'nin iki bekçisiydik. O 'Demir Çekiç'ti, ben 'Yaprak Kılıç'."),
        L("Yaşlı Bekçi", "Kara Balçık'ı ilk yendiğimiz gün bu madalyonu yaptırdık. Sonra bir hazine yüzünden küstük. Aptalca..."),
        L("Yaşlı Bekçi", "Bu madalyonu Kemal'e götürür müsün? Belki... belki hâlâ beni hatırlıyordur.") },
        [this] { sec |= SEC_HERMIT; toast("Madalyonu pazardaki Kemal Usta'ya götür."); saveGame(); });
      return true;
    }
    if (s0 & SEC_KEMAL) say({ L("Yaşlı Bekçi", "Kemal dün akşam çay içmeye geldi. Kırk yıl sonra! Sabaha kadar eski maceraları anlattık. Sağ ol, evlat.") });
    else if (s0 & SEC_GAVE) say({ L("Yaşlı Bekçi", "Kemal kaçtı mı? Hah! Hep böyleydi. Pazara geri dön, o mutlaka döner. Ama dikkat: eski Demir Çekiç uyanmış olabilir.") });
    else say({ L("Yaşlı Bekçi", "Madalyonu Kemal'e ver. Pazarda, tezgâhının başındadır.") });
    return true;
  };
  EXT.talkPre[N_SHOP] = [this](Npc*) {
    int s0 = sec;
    if ((s0 & SEC_MEDAL) && (s0 & SEC_HERMIT) && !(s0 & SEC_GAVE)) {
      say({ L("Arda", "Kemal Usta, Yaşlı Bekçi bunu size göndermiş."),
        L("Kemal Usta", "Bu... Bu madalyon... Kırk yıl oldu. O ihtiyar hâlâ saklıyor muymuş?"),
        L("Kemal Usta", "Ben... Ben şey... Tezgâha göz kulak ol evlat! Hemen dönerim!"),
        L("", "Kemal Usta madalyonu kaptığı gibi ormana doğru koşmaya başladı. Yaşına göre çok hızlıydı.") },
        [this] {
          sec |= SEC_GAVE; kemalWait = 25;
          for (auto& n : npcs) if (n->id == N_SHOP) { poof(n->x, n->y - 8); break; }
          placeNPCs(); toast("Kemal Usta kaçtı! Sonra pazara geri dön..."); saveGame();
        });
      return true;
    }
    if ((s0 & SEC_GAVE) && !(s0 & SEC_KEMAL)) { say({ L("", "Tezgâh bomboş. Üstünde bir not: 'Gençliğimi geri getirdin. Hazırlan, bekçi. — K'") }); return true; }
    return false;
  };
  // Kemal kaçtıysa tezgâhta durmaz
  EXT.npcs.push_back([this] {
    if (map.kind != MAP_OVER || !(sec & SEC_GAVE) || (sec & SEC_KEMAL)) return;
    for (size_t i = 0; i < npcs.size(); i++) if (npcs[i]->id == N_SHOP) { if (npcs[i]->blkI >= 0) map.blk[npcs[i]->blkI] = 0; npcs.erase(npcs.begin() + i); break; }
  });
  // pazara geri dönünce dövüş başlar
  EXT.areaOver.push_back([this] {
    if (!(sec & SEC_GAVE) || (sec & SEC_KEMAL) || dlg || night()) return;
    if (kemalWait > 0) { kemalWait -= 1 / 60.0; return; }
    if (std::fabs(px - STALL_POS[0]) < 70 && std::fabs(py - STALL_POS[1]) < 60) startKemalFight();
  });
  // ---------------- mağara girişleri ve çıkışları ----------------
  EXT.transOver.push_back([this](int tx, int ty, bool up, bool) {
    if (!(tx >= 10 && tx <= 11 && ty <= 12 && up && py < 12 * 16 + 14)) return false;
    if (mainStep < 3) { if (toastT <= 0) toast("Mağaranın derinlikleri karanlık. Yaşlı Bekçi izin vermez."); return true; }
    if (!hasLantern) { if (toastT <= 0) toast("İçerisi zifiri karanlık. Bir fener lazım."); return true; }
    if (fadeState == 0) { sfx(SFX_CLICK); fadeTo([this] { enterCave(0); }); }
    return true;
  });
  EXT.trans[MAP_CAVE] = [this](int tx, int ty, bool, bool down) {
    if (map.get(tx, ty) == T_STAIRS && down && fadeState == 0) {
      int id = caveId;
      fadeTo([this, id] { if (id == 1) enterSnow(13 * 16 + 8, 7 * 16 + 4); else enterOverworld(10 * 16 + 8, 13 * 16 + 4); pdir = 0; });
    }
  };
  EXT.area[MAP_CAVE] = [this] {
    bool boss = false, sy = false; for (auto& e : ents) { if (e->alive && isBigT(e->type)) boss = true; if (e->type == E_SYETI) sy = true; }
    setMood(boss ? 11 : 3);
    if (caveId == 1 && !(sec & SEC_YCAVE) && px > 34 * 16 && !sy) {
      Ent& y = spawn(E_SYETI, 40 * 16, 6 * 16); y.hx = y.x; y.hy = y.y;
      toast("GİZLİ BOSS: GÖLGE YETİ"); shake = 0.6; sfx(SFX_GROWL);
    }
  };
  EXT.saveAs[MAP_CAVE] = [this] { return caveId == 1 ? (int)MAP_SNOW : (int)MAP_OVER; };
  EXT.enter[MAP_CAVE] = [this] { enterOverworld(38 * 16 + 8, 64 * 16 + 12); };
  EXT.dark[MAP_CAVE] = [this](double ox, double oy, std::vector<LightSrc>& Ls) {
    EACH(o, map.objs) if (o.alive && o.type == O_TORCH && o.var == 0) Ls.push_back({ o.x - ox, o.y - 20 - oy, 46 + std::sin(time * 9 + o.x) * 3 });
    EACH(o, map.objs) if (o.alive && o.type == O_CRYSTAL) Ls.push_back({ o.x - ox, o.y - 10 - oy, 34 });
    return caveId == 1 ? DarkInfo{ 0.82, { 4, 10, 30 } } : DarkInfo{ 0.86, { 10, 6, 4 } };
  };
  EXT.tile[T_CFLOOR] = [this](int, int x, int y, double sx, double sy) { spr(A.cfloor[caveId == 1 ? 1 : 0][(x + y) & 1], sx, sy); };
  EXT.tile[T_CWALL] = [this](int, int, int, double sx, double sy) { spr(A.cwall[caveId == 1 ? 1 : 0], sx, sy); };
  EXT.tile[T_CTOP] = [this](int, int, int, double sx, double sy) { spr(A.ctop[caveId == 1 ? 1 : 0], sx, sy); };
}
