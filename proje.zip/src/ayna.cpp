// ORMANIN KALBİ - 4. bölümün gizli bossu: Ayna Şövalyesi "Yankı" (Ayna Salonu)
// Yol: Bulut Bekçisi Tan'ın sırrı -> köyün kuzeybatısındaki gizli bulut taşı -> Ayna Adası -> gece kırık aynaya dokun.
// Yalnızca vurarak yenilmez; üç evre:
//  1) Kalkan her darbeyi geri çevirir. Fırlattığı ışık küresini kılıçla geri vur: küre ona çarpınca sersemler.
//  2) Dört yansımaya bölünür. Yanlış yansımaya vurmak cam kırıkları saçar. Gerçek olanın gölgesi vardır,
//     dokununca can yakar ve geri vurulan her küre gerçeğe uçar.
//  3) Aynaların gücüyle korunur. Dört ayna sırayla yanar; aynı sırayla vur. Her turda sıra bir uzar.
#include "game.h"

// salon tek ekrana sığar (26 x 11 kare); kamera sabittir, dört ayna hep görünür
static const double ARENA_C[2] = { 13 * 16, 5 * 16 + 8 };
static const int MIRROR_POS[4][2] = { {4, 3}, {21, 3}, {4, 8}, {21, 8} };

void buildMirrorHall(WorldMap& m) {
  m.init(26, 11, MAP_MIRROR, T_DTOP);
  for (int y = 1; y < 10; y++) for (int x = 1; x < 25; x++) m.set(x, y, y == 1 ? T_DWALL : T_MARBLE);
  m.set(12, 9, T_STAIRS); m.set(13, 9, T_STAIRS);
  for (auto p : { std::pair{2, 2}, {23, 2}, {2, 9}, {23, 9} }) m.add(O_CRYSTAL, p.first, p.second);
}
void Game::enterMirror() {
  buildMirrorHall(map);
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1; pvx = pvy = 0;
  px = 13 * 16; py = 8 * 16 + 8; pdir = 1;
  for (int i = 0; i < 4; i++) { Ent& m = spawn(E_MIRROR, MIRROR_POS[i][0] * 16 + 8, MIRROR_POS[i][1] * 16 + 12); m.hy = i; m.state = (f4 & G4_KNIGHT) ? 2 : 0; }
  kPhase = 0; kMode = 0; kRound = 0; kPos = 0; kShowI = -1; kSeq.clear(); kTime = 0;
  camX = (map.W * 16 - VW) / 2.0; camY = (map.H * 16 - VH) / 2.0;
  if (f4 & G4_KNIGHT) { setMood(5); toast("AYNA SALONU"); return; }
  Ent& k = spawn(E_KNIGHT, ARENA_C[0], ARENA_C[1] - 16); k.hx = k.x; k.hy = 0; k.cd = 1.5; k.inv = true;
  k.invMsg = "Kalkanı her darbeyi geri çeviriyor! Işık küresini kılıcınla ona geri vur.";
  kPhase = 1; setMood(22);
  if (!(f4 & G4_KNIGHTMET)) {
    f4 |= G4_KNIGHTMET;
    say({ L("Ayna Şövalyesi", "Ay ışığında aynaya dokunan... Yüz yıldır kimse bu salona girmedi."),
      L("Ayna Şövalyesi", "Ben Yankı'yım. Bu kuleye tırmanan her kahramanın yansımasıyım. Hepsini yendim; çünkü hepsi yalnızca vurmayı bildi."),
      L("Ayna Şövalyesi", "Kalkanım her darbeyi geri çevirir. Beni yenmek istiyorsan önce kendi ışığımı bana geri çevir."),
      L("Arda", "Işığı geri çevirmek... Kılıcımla mı? Peki, deneyelim!") },
      [this] { toast("GİZLİ BOSS: AYNA ŞÖVALYESİ"); sfx(SFX_SHATTER, 0.6); shake = 0.4; });
  } else say({ L("Ayna Şövalyesi", "Yine mi sen? Bu sefer yansımanı yenebilecek misin?") }, [this] { toast("AYNA ŞÖVALYESİ"); });
}
// en yakın kahramana ışık küresi
void Game::knightOrb(Ent& src, double sp) {
  double tx = px, ty = py;
  for (auto& q : pp) if (q && !q->deadT && std::hypot(q->px - src.x, q->py - src.y) < std::hypot(tx - src.x, ty - src.y)) { tx = q->px; ty = q->py; }
  double ax = tx - src.x, ay = ty - 6 - (src.y - 14), al = std::hypot(ax, ay) + 0.01;
  double sx = src.x, sy = src.y - 14; int uid = src.uid;
  Ent& o = shoot(E_ORB, sx, sy, ax / al * sp, ay / al * sp, -1); o.own = uid; o.hx = 0; o.hy = 0;
  sfx(SFX_MAGIC, 0.35);
}
// geri vurulan küre şövalyeye çarptı
void Game::knightStruck(Ent& k) {
  burst(1, k.x, k.y - 16, 10, 0xf8d848);
  if (kPhase == 3) { if (toastT <= 0) toast("Kalkan ışığı yuttu! Aynaların sırasını izle."); sfx(SFX_CLICK); return; }
  if (k.state == 5) return;
  k.state = 5; k.t = 0; k.inv = false; shake = 0.35; sfx(SFX_SHATTER, 0.5); haptic("hit");
  toast(kPhase == 2 ? "Işık gerçek şövalyeyi buldu! Sersemledi, şimdi vur!" : "Işık şövalyeye çarptı! Sersemledi, şimdi vur!");
}
// gerçek şövalye ve yansımaları yer değiştirir
void Game::knightShuffle() {
  std::vector<Ent*> v; for (auto& e : ents) if (e->alive && (e->type == E_KNIGHT || e->type == E_ECHO)) v.push_back(e.get());
  std::vector<double> slots; for (auto* e : v) slots.push_back(e->hy);
  for (int i = (int)slots.size() - 1; i > 0; i--) { int j = I(rnd() * (i + 1)); std::swap(slots[i], slots[j]); }
  double a0 = time * 0.6;
  for (size_t i = 0; i < v.size(); i++) {
    Ent& e = *v[i]; poof(e.x, e.y - 12); e.hy = slots[i];
    e.x = ARENA_C[0] + std::cos(a0 + e.hy) * 84; e.y = ARENA_C[1] + std::sin(a0 + e.hy) * 44; poof(e.x, e.y - 12);
  }
  sfx(SFX_MAGIC, 0.5);
}
void Game::knightPhase(Ent& k, int n) {
  kPhase = n; k.state = 0; k.t = 0; k.cd = 1.4; k.hits = 0;
  EACH(o, ents) if (o.alive && o.type == E_ORB) o.alive = false;
  shake = 0.5; sfx(SFX_SHATTER); haptic("big");
  if (n == 2) {
    double kx0 = k.x, ky0 = k.y; int uid = k.uid;
    k.hy = 0;
    for (int i = 1; i < 4; i++) { Ent& e = spawn(E_ECHO, kx0, ky0); e.hy = i * PI / 2; e.own = uid; }
    knightShuffle();
    toast("Şövalye yansımalarına bölündü! Hangisi gerçek?");
  } else {
    EACH(o, ents) if (o.alive && o.type == E_ECHO) { o.alive = false; poof(o.x, o.y - 12); }
    poof(k.x, k.y - 12); k.x = ARENA_C[0]; k.y = ARENA_C[1] - 16; poof(k.x, k.y - 12);
    kSeq.clear(); for (int i = 0; i < 3; i++) { int v; do v = I(rnd() * 4) & 3; while (i && v == kSeq.back()); kSeq.push_back(v); }
    kMode = 0; kTime = -1.2; kShowI = -1; kPos = 0; kRound = 0;
    toast("Şövalye aynaların gücünü çağırdı! Aynaların yanma sırasını izle.");
  }
}
void Game::knightNextRound() {
  kRound++;
  if (kSeq.size() < 7) { int v; do v = I(rnd() * 4) & 3; while (v == kSeq.back()); kSeq.push_back(v); }
  kMode = 0; kTime = -0.8; kShowI = -1; kPos = 0;
  EACH(m, ents) if (m.alive && m.type == E_MIRROR) m.state = 0;
  toast(fmt("Aynalar yeniden karardı... Bu sefer %d ışık!", (int)kSeq.size()));
}
// 3. evre: aynaların sırası
void Game::knightSimon(Ent& k, double dt) {
  kTime += dt;
  if (kMode == 0) {
    const double step = 0.8; int n = (int)kSeq.size(), i = (int)std::floor(kTime / step);
    if (kTime >= 0 && i < n && i != kShowI) {
      kShowI = i;
      EACH(m, ents) if (m.alive && m.type == E_MIRROR && I(m.hy) == kSeq[i]) { m.state = 1; m.t = 0; }
      sfx(SFX_CHIME, 0.35 + 0.12 * kSeq[i]);
    }
    if (kTime > n * step + 0.2) { kMode = 1; kPos = 0; kTime = 0; toast("Sıra sende! Aynaları aynı sırayla vur."); }
  } else if (kMode == 1) {
    if (k.cd <= 0) { k.cd = 2.8; knightOrb(k, 75); }
    if (kTime > 15) { kMode = 0; kTime = -0.6; kShowI = -1; toast("Çok yavaş! Sırayı yeniden izle."); }
  }
}

void Game::initAyna() {
  EXT.hp[E_KNIGHT] = 48; EXT.hp[E_MIRROR] = 99; EXT.hp[E_ECHO] = 99;
  EXT.harmless[E_MIRROR] = true; EXT.harmless[E_ECHO] = true;
  EXT.mood[MAP_MIRROR] = 22;
  EXT.saveAs[MAP_MIRROR] = [] { return (int)MAP_SKY; };
  EXT.trans[MAP_MIRROR] = [this](int tx, int ty, bool, bool down) {
    if (map.get(tx, ty) == T_STAIRS && down && fadeState == 0) fadeTo([this] { enterSky(21 * 16 + 8, 11 * 16 + 8); pdir = 0; });
  };
  EXT.area[MAP_MIRROR] = [this] { setMood(firstEnt(E_KNIGHT) ? 22 : 5); };
  EXT.dark[MAP_MIRROR] = [this](double ox, double oy, std::vector<LightSrc>& Ls) {
    EACH(o, map.objs) if (o.alive && o.type == O_CRYSTAL) Ls.push_back({ o.x - ox, o.y - 10 - oy, 38 });
    EACH(e, ents) if (e.alive) {
      if (e.type == E_MIRROR) Ls.push_back({ e.x - ox, e.y - 18 - oy, e.state ? 64.0 : 30.0 });
      else if (e.type == E_ORB) Ls.push_back({ e.x - ox, e.y - 8 - oy, 20 });
      else if (e.type == E_KNIGHT || e.type == E_ECHO) Ls.push_back({ e.x - ox, e.y - 20 - oy, 26 });
    }
    return DarkInfo{ 0.55, { 8, 8, 28 } };
  };
  EXT.tileAll[MAP_MIRROR] = [this](int t, int x, int y, double sx, double sy) {
    switch (t) {
      case T_MARBLE: {   // ortada parlak ayna halkası, çevresi koyu
        double dx = (x + 0.5) * 16 - ARENA_C[0], dy = ((y + 0.5) * 16 - ARENA_C[1]) * 1.6, r = std::hypot(dx, dy);
        if (r < 70 && r > 52) spr(A.marble[(x + y) & 1], sx, sy); else spr(A.dfloor4[(x + y) & 1], sx, sy);
        break;
      }
      case T_DWALL: spr(A.dwall4, sx, sy); break;
      case T_STAIRS: spr(A.stairs4, sx, sy); break;
      default: spr(A.dwallTop4, sx, sy); break;
    }
  };
  // kırık ayna (Ayna Adası)
  EXT.interact[O_PEDESTAL] = [this](Obj&) {
    if (f4 & G4_KNIGHT) { say({ L("", "Kırık ayna. İçinde artık yalnızca senin yansıman var, ve gülümsüyor.") }); return; }
    if (!night()) { say({ L("", (f4 & G4_RIDDLE) ? "Kırık bir aynanın parçaları. Gündüz ışığında sıradan görünüyor... Tan 'ay ışığında' demişti." : "Kırık bir ayna. Kenarına eski bir yazı kazınmış: 'Ay doğunca bak.'") }); return; }
    if (fadeState) return;
    ask({ L("", "Aynanın içinde ay ışığı dalgalanıyor. Gümüş zırhlı bir şövalye sana bakıyor. Dokunmak ister misin?") }, { "Dokun", "Vazgeç" }, [this](int c) {
      if (!c) { sfx(SFX_MAGIC); fadeTo([this] { enterMirror(); }); }
    });
  };
  // ---------------- şövalye ----------------
  EXT.enemy[E_KNIGHT] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (dlg) return;
    double fr = e.hp / e.maxHp;
    if (kPhase == 1 && fr <= 2.0 / 3) knightPhase(e, 2);
    else if (kPhase == 2 && fr <= 1.0 / 3) knightPhase(e, 3);
    e.dir = dx < 0 ? 2 : 3;
    if (e.state == 5) {   // sersem: savunmasız
      e.inv = false;
      if (e.t > (kPhase == 3 ? 4.5 : 2.6)) { e.state = 0; e.t = 0; e.cd = 1.2; if (kPhase == 3) knightNextRound(); }
      return;
    }
    if (kPhase == 1) {
      e.inv = true; e.invMsg = "Kalkanı her darbeyi geri çeviriyor! Işık küresini kılıcınla ona geri vur.";
      if (e.state == 2) { if (e.t > 0.55) { e.state = 3; e.t = 0; e.vx = dx / d * 250; e.vy = dy / d * 250; sfx(SFX_SWING); } }   // hücuma hazırlanır
      else if (e.state == 3) { bool hit = moveE(e, e.vx * dt, e.vy * dt, 7, 6); if (hit || e.t > 0.4) { e.state = 0; e.t = 0; } }
      else {
        double want = d < 70 ? -1 : d > 110 ? 1 : 0, side = std::sin(e.t * 0.9) * 26;
        moveE(e, (dx / d * want * 34 - dy / d * side) * dt, 0, 7, 6); moveE(e, 0, (dy / d * want * 34 + dx / d * side) * dt, 7, 6);
        if (e.cd <= 0) {
          e.cd = 1.7; e.vz += 1;
          if (I(e.vz) % 4 == 3) { e.state = 2; e.t = 0; sfx(SFX_GROWL, 0.4); }
          else knightOrb(e, 95);
        }
      }
    } else if (kPhase == 2) {
      e.inv = false;
      double a = time * 0.6 + e.hy, tx = ARENA_C[0] + std::cos(a) * 84, ty = ARENA_C[1] + std::sin(a) * 44, ax = tx - e.x, ay = ty - e.y, al = std::hypot(ax, ay) + 0.01;
      e.x += ax / al * std::min(al, 140 * dt); e.y += ay / al * std::min(al, 140 * dt);
      if (e.cd <= 0) {
        e.cd = 3.0; knightOrb(e, 85);
        EACH(o, ents) if (o.alive && o.type == E_ECHO) knightOrb(o, 85);
      }
    } else if (kPhase == 3) {
      e.inv = true; e.invMsg = "Aynaların gücüyle korunuyor! Aynaların yanma sırasını izle, sonra aynı sırayla vur.";
      double ax = ARENA_C[0] - e.x, ay = ARENA_C[1] - 16 - e.y, al = std::hypot(ax, ay) + 0.01;
      e.x += ax / al * std::min(al, 60 * dt); e.y += ay / al * std::min(al, 60 * dt);
      knightSimon(e, dt);
    }
  };
  EXT.hit[E_KNIGHT] = [this](Ent& e, double) { if (kPhase == 2 && ++e.hits >= 2) { e.hits = 0; knightShuffle(); } };
  EXT.enemy[E_ECHO] = [this](Ent& e, double dt, double dx, double, double) {
    if (dlg) return;
    double a = time * 0.6 + e.hy, tx = ARENA_C[0] + std::cos(a) * 84, ty = ARENA_C[1] + std::sin(a) * 44, ax = tx - e.x, ay = ty - e.y, al = std::hypot(ax, ay) + 0.01;
    e.x += ax / al * std::min(al, 140 * dt); e.y += ay / al * std::min(al, 140 * dt);
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.hitPre[E_ECHO] = [this](Ent& e) {
    sfx(SFX_SHATTER, 0.7); burst(5, e.x, e.y - 14, 12); burst(1, e.x, e.y - 14, 6, 0xd4f0ff); shake = 0.25;
    double a0 = std::atan2(py - e.y, px - e.x), ex = e.x, ey = e.y - 12;
    for (int k = -2; k <= 2; k++) { double a = a0 + k * 0.3; Ent& s = shoot(E_SHARD, ex, ey, std::cos(a) * 110, std::sin(a) * 110, -1); s.hx = 0; s.hy = 0; }
    toast("Yanlış yansıma! Gerçek olanın gölgesi vardır.");
    knightShuffle();
    return true;
  };
  EXT.enemy[E_ORB] = [this](Ent& e, double dt, double, double, double) {
    if (e.state == 1) {   // geri vuruldu: gerçek şövalyeye uçar
      Ent* k = firstEnt(E_KNIGHT);
      if (!k || e.t > 4) { e.alive = false; return; }
      double ax = k->x - e.x, ay = k->y - 16 - e.y, al = std::hypot(ax, ay) + 0.01;
      e.vx = ax / al * 185; e.vy = ay / al * 185; e.x += e.vx * dt; e.y += e.vy * dt;
      if (al < 14) { e.alive = false; knightStruck(*k); }
      return;
    }
    stepShot(e, dt, 1, 4.0);
  };
  EXT.parry[E_ORB] = [this](Ent& e) {
    if (e.state == 1) return;
    e.state = 1; e.t = 0; sfx(SFX_CHIME, 0.7); burst(1, e.x, e.y - 6, 6, 0xf8d848); haptic("hit");
  };
  // ---------------- aynalar ----------------
  EXT.enemy[E_MIRROR] = [this](Ent& e, double, double, double, double) {
    if (f4 & G4_KNIGHT) { e.state = 2; return; }
    double life = e.state == 1 ? 0.55 : e.state == 2 ? 0.45 : 0.7;
    if (e.state && e.t > life && kMode != 2) e.state = 0;
  };
  EXT.hitPre[E_MIRROR] = [this](Ent& e) {
    if ((f4 & G4_KNIGHT) || kPhase != 3 || kMode != 1) { sfx(SFX_CLICK); burst(1, e.x, e.y - 16, 3, 0xd0d4e0); return true; }
    int idx = I(e.hy);
    if (kPos < (int)kSeq.size() && idx == kSeq[kPos]) {
      e.state = 2; e.t = 0; sfx(SFX_CHIME, 0.4 + 0.12 * idx); burst(1, e.x, e.y - 18, 6, 0xfff4c0); kPos++;
      if (kPos >= (int)kSeq.size()) {
        kMode = 2; kTime = 0; shake = 0.5; sfx(SFX_MAGIC); haptic("big");
        EACH(m, ents) if (m.alive && m.type == E_MIRROR) { m.state = 2; m.t = 0; }
        Ent* k = firstEnt(E_KNIGHT); if (k) { k->state = 5; k->t = 0; k->inv = false; }
        toast("Dört ayna birden parladı! Şövalye savunmasız, vur!");
      }
    } else {
      e.state = 3; e.t = 0; sfx(SFX_SHATTER, 0.6); shake = 0.3;
      double a0 = std::atan2(py - e.y, px - e.x), ex = e.x, ey = e.y - 14;
      for (int k = -2; k <= 2; k++) { double a = a0 + k * 0.28; Ent& s = shoot(E_SHARD, ex, ey, std::cos(a) * 100, std::sin(a) * 100, -1); s.hx = 0; s.hy = 0; }
      kMode = 0; kTime = -0.8; kShowI = -1; kPos = 0;
      toast("Yanlış ayna! Sırayı yeniden izle.");
    }
    return true;
  };
  EXT.kill[E_KNIGHT] = [this](Ent& e) {
    f4 |= G4_KNIGHT; sec |= SEC_MIRROR; shake = 1.0; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 8; i++) poof(ex + (rnd() - 0.5) * 50, ey - 10 - rnd() * 30);
    EACH(o, ents) if (o.alive && (o.type == E_ORB || o.type == E_ECHO || o.type == E_SHARD)) { o.alive = false; poof(o.x, o.y - 6); }
    EACH(m, ents) if (m.alive && m.type == E_MIRROR) m.state = 2;
    kPhase = 0; kMode = 0;
    for (int i = 0; i < 12; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 50, ey + (rnd() - 0.5) * 30, 80 + rnd() * 40, 5);
    say({ L("Ayna Şövalyesi", "Işığımı bana geri çevirdin, yansımaları birbirinden ayırdın, aynaların şarkısını ezberledin..."),
      L("Ayna Şövalyesi", "Sen yalnızca vurmayı bilen biri değilsin. Yüz yıl sonra ilk kez yenildim, ve ilk kez mutluyum."),
      L("Ayna Şövalyesi", "Kılıcını uzat. Aynaların ışığı artık onda yaşayacak. Yolun hep aydınlık olsun, yeryüzünün bekçisi.") },
      [this] {
        swordLv = std::max(swordLv, 4); maxHp += 2; hp = maxHp;
        showItem(A.sword, "AYNA KILICI! Artık dört kat vuruyor. +1 kalp kabı");
        toast("GİZLİ BOSS YENİLDİ: AYNA ŞÖVALYESİ"); setMood(5); saveGame();
      });
    return true;
  };
  // ---------------- çizimler ----------------
  auto knightDraw = [this](Ent& e, double x, double y, bool fl, bool real) {
    const Spr* s0 = A.knight[(e.state == 3 || (std::fabs(e.vx) + std::fabs(e.vy) > 1 && I(e.t * 6) & 1)) ? 1 : I(e.t * 2) & 1]; double sc = 1.3;
    if (real) spr(A.shadow, x - 11, y - 5, false, 1, 1.4, 1.3);
    double a = 1;
    if (!real && std::fmod(time + e.hy, 2.3) < 0.08) a = 0.45;   // yansıma ara sıra titrer
    if (e.state == 2) a = std::fmod(time, 0.16) < 0.08 ? 0.5 : 1;
    spr(s0, x - s0->w * sc / 2, y - s0->h * sc + 2, e.dir == 2, a, sc, sc, fl);
    rot(A.knightSword, x + (e.dir == 2 ? -12 : 12), y - 18, 2, 18, (e.dir == 2 ? -0.5 : 0.5) + (e.state == 3 ? (e.dir == 2 ? -1.4 : 1.4) : 0), a);
    if (real && e.inv && e.state != 5) g->ellipse(x, y - 16, 15, 21, rgba(170, 230, 255, 0.3 + 0.2 * std::sin(time * 6)), 1);
    if (e.state == 5) for (int i = 0; i < 3; i++) spr(A.spark, x - 4 + std::cos(time * 6 + i * 2.1) * 12, y - 36 + std::sin(time * 6 + i * 2.1) * 4, false, 0.9, 0.7, 0.7);
  };
  EXT.draw[E_KNIGHT] = [this, knightDraw](Ent& e, double x, double y, bool fl) { knightDraw(e, x, y, fl, true); };
  EXT.draw[E_ECHO] = [this, knightDraw](Ent& e, double x, double y, bool fl) { knightDraw(e, x, y, fl, false); };
  EXT.draw[E_ORB] = [this](Ent& e, double x, double y, bool) {
    spr(A.shadow, x - 4, y - 2, false, 0.4, 0.5);
    spr(A.spark, x - 8, y - 18, false, 0.5 + 0.3 * std::sin(e.t * 18), 2.2, 2.2);
    spr(A.orb[e.state == 1 ? 1 : 0], x - 5, y - 15);
  };
  EXT.draw[E_MIRROR] = [this](Ent& e, double x, double y, bool) {
    spr(A.shadow, x - 8, y - 4, false, 1, 1);
    spr(A.mirror[e.state == 1 || e.state == 2 ? 1 : 0], x - 7, y - 30);
    if (e.state == 1 || e.state == 2) spr(A.spark, x - 10, y - 30, false, 0.6 + 0.4 * std::sin(time * 10), 2.8, 2.8);
    if (e.state == 3) g->ellipse(x, y - 16, 10, 16, rgba(255, 70, 70, 0.7), 2);
  };
}
