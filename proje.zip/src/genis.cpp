// ORMANIN KALBİ - eski bölümlerin haritalarına eklenen yeni bölgeler (haritalar doğuya doğru genişledi)
// 1. bölüm: Sisli Bataklık (köyün doğusu): sığ bataklık, gölcükler, dört ateşli eski sunak -> kalp kabı
// 2. bölüm: Buzul Vadisi (Ayazköy'ün doğusu): donmuş göl, buz halkasının içinde hazine (Alev Feneri ile erir)
// 3. bölüm: Fırtına Adaları (Mercan Resifi'nin doğusu): uzun köprü, Martı Adası, gelgit yolu, Kayalık Ada
#include "game.h"

static void blob(WorldMap& m, double cx, double cy, double rx, double ry, int v, int only = -1) {
  for (int y = 0; y < m.H; y++) for (int x = 0; x < m.W; x++) {
    double dx = (x - cx) / rx, dy = (y - cy) / ry, wob = 0.08 * std::sin(x * 0.9 + y * 0.7);
    if (dx * dx + dy * dy < 1 + wob && (only < 0 || m.get(x, y) == only)) m.set(x, y, v);
  }
}
static const int SHRINE[2] = { 118, 42 };
static const int RING[2] = { 98, 15 };

// ---------------- 1. bölüm ----------------
void extendOverworld(WorldMap& m) {
  for (auto b : { std::array<double, 4>{ 104, 62, 7, 4 }, { 126, 52, 7, 5 }, { 108, 28, 6, 4 }, { 128, 30, 5, 6 }, { 100, 40, 4, 5 } }) blob(m, b[0], b[1], b[2], b[3], T_SHALLOW, T_GRASS);
  for (auto b : { std::array<double, 4>{ 105, 63, 3.5, 2 }, { 127, 52, 3.5, 2.5 }, { 108, 27, 3, 2 }, { 129, 31, 2.5, 3 } }) blob(m, b[0], b[1], b[2], b[3], T_WATER);
  mline(m, 56, 57, 100, 57, T_PATH, 2); mline(m, 100, 57, 114, 48, T_PATH, 1); mline(m, 114, 48, 118, 42, T_PATH, 1);
  mline(m, 118, 42, 120, 18, T_PATH, 1); mline(m, 120, 18, 131, 15, T_PATH, 1);
  blob(m, SHRINE[0], SHRINE[1], 5.5, 4.5, T_PATH);
  for (auto p : { std::pair{99, 55}, {113, 39}, {132, 14} }) m.set(p.first, p.second, T_PATH);   // tabela ve sandık yerleri boş kalsın
}
void extendOverworldObjs(WorldMap& m, int flags) {
  for (auto p : { std::pair{115, 40}, {121, 40}, {115, 45}, {121, 45} }) m.add(O_BRAZIER, p.first, p.second).var = (flags & F_MARSH) ? 0 : 1;
  if (flags & F_MARSH) m.add(O_CHEST, SHRINE[0], SHRINE[1]).var = 29;
  m.add(O_SIGN, 99, 55, 1, 1).text = "SİSLİ BATAKLIK\nSığ sularda yürünür, derin gölcüklerde boğulursun.";
  m.add(O_SIGN, 113, 39, 1, 1).text = "ESKİ SUNAK\nDört ateşi birlikte yakan, bataklığın hazinesini uyandırır.\nAteşler çabuk söner.";
  m.add(O_CHEST, 132, 14).var = 30;
  for (auto p : { std::pair{110, 44}, {126, 42}, {104, 34}, {124, 62}, {112, 20} }) if (m.free(p.first, p.second, 1, 1)) m.add(O_ROCK, p.first, p.second).var = 1;
}
// ---------------- 2. bölüm ----------------
void extendSnow(WorldMap& m) {
  mline(m, 60, 26, 84, 24, T_SNOWPATH, 1); mline(m, 84, 24, 92, 34, T_SNOWPATH, 1); mline(m, 84, 24, 96, 19, T_SNOWPATH, 1);
  blob(m, 92, 44, 10, 6, T_ICE);
  for (auto p : { std::pair{88, 42}, {95, 46}, {92, 41}, {98, 43} }) m.set(p.first, p.second, T_ICEWATER);
  blob(m, RING[0], RING[1], 3.6, 3.2, T_SNOWPATH);
}
void extendSnowObjs(WorldMap& m, uint32_t iceMask) {
  int bit = 18;
  auto wall = [&](int x, int y) { if (!((iceMask >> bit) & 1)) { Obj& o = m.add(O_ICEWALL, x, y); o.var = bit; } bit++; };
  for (int x = RING[0] - 1; x <= RING[0] + 1; x++) { wall(x, RING[1] - 2); wall(x, RING[1] + 2); }
  for (int y = RING[1] - 1; y <= RING[1] + 1; y++) { wall(RING[0] - 2, y); wall(RING[0] + 2, y); }
  m.add(O_CHEST, RING[0], RING[1]).var = 31;
  m.add(O_SIGN, 85, 22, 1, 1).text = "BUZUL VADİSİ\nBuz halkasının içindeki hazine yalnızca sönmeyen alevle açılır.";
  m.add(O_CHEST, 103, 50).var = 0;
  for (auto p : { std::pair{80, 30}, {101, 30}, {86, 50} }) m.add(O_CRYSTAL, p.first, p.second, 1, 1);
}
// ---------------- 3. bölüm ----------------
void extendSea(WorldMap& m) {
  auto isl = [&](double cx, double cy, double rx, double ry, int inner, double innerR) {
    for (int y = 0; y < m.H; y++) for (int x = 0; x < m.W; x++) {
      double dx = (x - cx) / rx, dy = (y - cy) / ry, d = dx * dx + dy * dy, wob = 0.07 * std::sin(x * 0.9 + y * 0.6);
      if (d < 1 + wob) m.set(x, y, d < innerR ? inner : T_SAND);
      else if (d < 1.45 + wob && m.get(x, y) == T_WATER) m.set(x, y, T_SHALLOW);
    }
  };
  isl(99, 20, 8, 6, T_GRASS, 0.4);    // Martı Adası
  isl(106, 46, 7, 5, T_SAND, 0);      // Kayalık Ada
  for (int x = 57; x <= 93; x++) if (m.get(x, 17) == T_WATER || m.get(x, 17) == T_SHALLOW) m.set(x, 17, T_BRIDGEH);
  mline(m, 100, 25, 105, 42, 99, 2);
  for (auto& v : m.t) if (v == 99) v = T_TIDE;
  for (int y = 24; y <= 43; y++) for (int x = 97; x <= 108; x++) { int t = m.get(x, y); if (t == T_TIDE) { double dx = (x - 99) / 8.0, dy = (y - 20) / 6.0, ex = (x - 106) / 7.0, ey = (y - 46) / 5.0; if (dx * dx + dy * dy < 0.9 || ex * ex + ey * ey < 0.9) m.set(x, y, T_SAND); } }
}
void extendSeaObjs(WorldMap& m) {
  m.add(O_SIGN, 93, 19, 1, 1).text = "FIRTINA ADALARI\nGüneydeki kayalığa yol ancak su çekilince açılır.";
  m.add(O_PILLAR, 101, 23, 1, 1);
  m.add(O_CHEST, 102, 17).var = 40;
  m.add(O_CHEST, 108, 47).var = 41;
  for (auto p : { std::pair{95, 22}, {104, 19}, {103, 48} }) m.add(O_BARREL, p.first, p.second);
}

// ---------------- düşmanlar ve ödüller ----------------
void Game::extEnemies(bool nightOnly) {
  int k = map.kind;
  if (k == MAP_OVER && !cured) {
    if (nightOnly) { scatterEnemies(E_GHOST, 4, 96, 14, 132, 66); scatterEnemies(E_WOLF, 2, 96, 14, 132, 66); return; }
    scatterEnemies(E_SLIME, 5, 96, 14, 132, 66); scatterEnemies(E_SLIMER, 3, 96, 14, 132, 66); scatterEnemies(E_THORN, 3, 100, 30, 132, 60);
    scatterEnemies(E_BAT, 3, 100, 14, 132, 30); scatterEnemies(E_BOAR, 2, 96, 50, 132, 68); scatterEnemies(E_OCTO, 2, 100, 58, 110, 66);
  } else if (k == MAP_SNOW && mainStep < 13) {
    if (nightOnly) { scatterEnemies(E_SNOWWOLF, 4, 74, 10, 104, 52); return; }
    scatterEnemies(E_ICESLIME, 5, 74, 10, 104, 52); scatterEnemies(E_ICEBAT, 3, 80, 8, 104, 30); scatterEnemies(E_SNOWWOLF, 2, 76, 28, 104, 52);
  } else if (k == MAP_SEA && mainStep < 21 && !nightOnly) {
    scatterEnemies(E_CRAB, 4, 91, 14, 107, 26); scatterEnemies(E_GULL, 3, 60, 10, 110, 30); scatterEnemies(E_JELLY, 2, 99, 41, 113, 51); scatterEnemies(E_CRAB, 2, 99, 41, 113, 51);
  }
}
void Game::initGenis() {
  EXT.chest[29] = [this](int) { giveHeartC(); };
  EXT.chest[30] = [this](int) { coins += 40; showItem(A.coin[0], "40 altın buldun!"); };
  EXT.chest[31] = [this](int) { givePiece(); };
  EXT.chest[0] = [this](int) { coins += 50; potions++; showItem(A.potion, "50 altın ve bir can iksiri!"); };
  EXT.chest[40] = [this](int) { givePiece(); };
  EXT.chest[41] = [this](int) { coins += 80; potions++; showItem(A.potion, "80 altın ve bir can iksiri!"); };
}
// dört ateş bulmacası: bataklık sunağı (1. bölüm) ve kule (4. bölüm)
bool Game::brazierSolved() { return map.kind == MAP_OVER ? (flags & F_MARSH) != 0 : (f4 & G4_BRAZIER) != 0; }
void Game::brazierDone() {
  if (map.kind == MAP_OVER) { flags |= F_MARSH; map.add(O_CHEST, SHRINE[0], SHRINE[1]).var = 29; markChests(); toast("Dört ateş birden yandı! Sunakta bir sandık belirdi."); }
  else { f4 |= G4_BRAZIER; addRoomChest(11, 66, 10, 5); markChests(); toast("Dört ateş birden yandı. Bir sandık belirdi!"); }
  sfx(SFX_MAGIC); shake = 0.3; saveGame();
}
