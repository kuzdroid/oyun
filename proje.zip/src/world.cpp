// ORMANIN KALBİ - haritalar: dış dünya, ev içleri, tapınak zindanı, Karlı Dağlar, Buz Tapınağı
#include "core.h"
#include <cstdarg>

// ---------------- yardımcılar ----------------
size_t u8len(const string& s) { size_t n = 0; for (unsigned char c : s) if ((c & 0xC0) != 0x80) n++; return n; }
string u8prefix(const string& s, size_t n) {
  size_t i = 0, k = 0;
  while (i < s.size()) { if (((unsigned char)s[i] & 0xC0) != 0x80) { if (k == n) break; k++; } i++; }
  return s.substr(0, i);
}
std::vector<string> u8chars(const string& s) {
  std::vector<string> r;
  for (size_t i = 0; i < s.size();) { size_t j = i + 1; while (j < s.size() && ((unsigned char)s[j] & 0xC0) == 0x80) j++; r.push_back(s.substr(i, j - i)); i = j; }
  return r;
}
std::vector<string> splitStr(const string& s, char c) {
  std::vector<string> r; size_t a = 0;
  for (;;) { size_t b = s.find(c, a); if (b == string::npos) { r.push_back(s.substr(a)); break; } r.push_back(s.substr(a, b - a)); a = b + 1; }
  return r;
}
string fmt(const char* f, ...) {
  char buf[1024]; va_list ap; va_start(ap, f); vsnprintf(buf, sizeof buf, f, ap); va_end(ap); return buf;
}

bool SOLID_X[256];
bool tileSolid(int v) {
  return SOLID_X[v & 255] || v == T_WATER || v == T_CLIFF || v == T_PLATEAU || v == T_DWALL || v == T_DTOP || v == T_DOOR_SHUT || v == T_DOOR_LOCK || v == T_DOOR_BOSS || v == T_IWALL || v == T_ITOP
    || v == 25 || v == 26 || v == 28;
}
void WorldMap::init(int w, int h, int k, int fill) {
  gen++; W = w; H = h; kind = k; t.assign(w * h, (uint8_t)fill); blk.assign(w * h, 0); lockId.assign(w * h, 0); objs.clear();
}
int WorldMap::get(int x, int y) const {
  if (x < 0 || y < 0 || x >= W || y >= H) return kind == MAP_DUNGEON ? T_DTOP : kind == MAP_INTERIOR ? 255 : kind == MAP_SKY ? T_VOID : T_CLIFF;
  return t[y * W + x];
}
bool WorldMap::solid(int x, int y) const { if (x < 0 || y < 0 || x >= W || y >= H) return true; return tileSolid(t[y * W + x]) || blk[y * W + x] != 0; }
Obj& WorldMap::add(int type, int tx, int ty, int tw, int th, bool solid) {
  auto o = std::make_unique<Obj>();
  o->type = type; o->x = (tx + tw * 0.5) * 16; o->y = (ty + th) * 16.0; o->id = (int)objs.size(); o->tx = tx; o->ty = ty; o->tw = tw; o->th = th; o->solid = solid;
  objs.push_back(std::move(o));
  if (solid) for (int y = ty; y < ty + th; y++) for (int x = tx; x < tx + tw; x++) if (x >= 0 && y >= 0 && x < W && y < H) blk[y * W + x] = 1;
  return *objs.back();
}
bool WorldMap::free(int tx, int ty, int tw, int th) const {
  for (int y = ty; y < ty + th; y++) for (int x = tx; x < tx + tw; x++) {
    if (x < 0 || y < 0 || x >= W || y >= H) return false;
    if (blk[y * W + x] || t[y * W + x] != T_GRASS) return false;
  }
  return true;
}
void WorldMap::removeObj(Obj& o) {
  o.alive = false;
  if (o.solid) for (int y = o.ty; y < o.ty + o.th; y++) for (int x = o.tx; x < o.tx + o.tw; x++) if (x >= 0 && y >= 0 && x < W && y < H) blk[y * W + x] = 0;
}

void mline(WorldMap& m, int x0, int y0, int x1, int y1, int v, int r) {
  int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0));
  for (int i = 0; i <= n; i++) {
    int x = x0 + (int)std::trunc((double)(x1 - x0) * i / std::max(1, n)), y = y0 + (int)std::trunc((double)(y1 - y0) * i / std::max(1, n));
    for (int dy = -r + 1; dy < r; dy++) for (int dx = -r + 1; dx < r; dx++) m.set(x + dx, y + dy, v);
  }
}
void buildOverworld(WorldMap& m) {
  m.init(OW, OH, MAP_OVER, T_GRASS);
  for (int x = 0; x < OW; x++) {
    int cy = 9 + (int)std::trunc(2 * std::sin(x * 0.21)) + (x > 40 && x < 56 ? 1 : 0);
    for (int y = 0; y < cy; y++) m.set(x, y, T_PLATEAU);
    m.set(x, cy, T_CLIFF); m.set(x, cy + 1, T_CLIFF);
  }
  for (int y = 0; y < OH; y++) for (int x = 0; x < OW; x++) {
    double dx = (x - 78) / 13.0, dy = (y - 38) / 11.0, d = dx * dx + dy * dy, wob = 0.08 * std::sin(x * 0.7) * std::cos(y * 0.5);
    if (d < 1 + wob) m.set(x, y, T_WATER); else if (d < 1.35 + wob) m.set(x, y, T_SAND);
    double ix = (x - 81) / 3.2, iy = (y - 37) / 2.6;
    if (ix * ix + iy * iy < 1) m.set(x, y, T_SAND);
  }
  for (int x = 64; x <= 78; x++) m.set(x, 37, T_BRIDGEH);
  mline(m, 47, 66, 47, 12, T_PATH, 2); mline(m, 47, 58, 20, 58, T_PATH, 2); mline(m, 20, 58, 20, 40, T_PATH, 1);
  mline(m, 20, 40, 12, 26, T_PATH, 1); mline(m, 12, 26, 11, 13, T_PATH, 1); mline(m, 48, 54, 64, 40, T_PATH, 1); mline(m, 64, 40, 64, 37, T_PATH, 1);
  for (int y = 52; y < 64; y++) for (int x = 40; x < 56; x++) if (m.get(x, y) == T_GRASS && std::abs(x - 47) + std::abs(y - 58) < 8) m.set(x, y, T_PATH);
  extendOverworld(m);
}
void populateOverworld(WorldMap& m) {
  Rng r(2024);
  auto tree = [&](int x, int y) { if (m.free(x, y, 2, 1) && m.free(x, y - 1, 2, 1)) { Obj& o = m.add(r.f() < 0.25 ? O_TREE2 : O_TREE, x, y, 2, 1); o.var = I(r.f() * 2); } };
  { Obj& h = m.add(O_HOUSE, 37, 51, 3, 3); h.var = 0; h.text = "0"; }
  { Obj& h = m.add(O_HOUSE, 53, 51, 3, 3); h.var = 1; h.text = "1"; }
  { Obj& h = m.add(O_HOUSE, 37, 61, 3, 3); h.var = 2; h.text = "2"; }
  { Obj& h = m.add(O_HOUSE, 54, 61, 3, 3); h.var = 0; h.text = "L"; }
  m.add(O_WELL, 47, 56, 1, 1);
  m.add(O_STALL, 51, 59, 2, 1).text = "stall";
  for (int x = 34; x < 43; x++) m.add(O_FENCE, x, 67, 1, 1);
  for (int x = 52; x < 63; x++) m.add(O_FENCE, x, 67, 1, 1);
  for (int x = 58; x <= 62; x++) if (x != 59) m.add(O_FENCE, x, 63, 1, 1);
  for (int y = 64; y <= 66; y++) { m.add(O_FENCE, 58, y, 1, 1); m.add(O_FENCE, 62, y, 1, 1); }
  for (auto l : { std::pair{44, 53}, {50, 53}, {44, 62}, {50, 62}, {47, 47} }) m.add(O_LAMP, l.first, l.second, 1, 1);
  m.add(O_SIGN, 57, 63, 1, 1).text = "TAVUK AĞILI\nKapıyı açık bırakan, tavuk kovalar.";
  m.add(O_SIGN, 45, 50, 1, 1).text = "KUZEY: Eski Tapınak\nBATI: Fısıltılı Orman\nDOĞU: Ayna Gölü";
  m.add(O_SIGN, 49, 21, 1, 1).text = "ESKİ TAPINAK\nIşığı olmayan, içindeki karanlıkta kaybolur.";
  m.add(O_SIGN, 22, 44, 1, 1).text = "FISILTILI ORMAN\nBalçıklara dikkat. Yaşlı bekçinin mağarası kuzeyde.";
  m.add(O_SIGN, 62, 42, 1, 1).text = "AYNA GÖLÜ\nTaş tükürenler köprüyü bekler.";
  { int cy = 9 + (int)std::trunc(2 * std::sin(11 * 0.21)); m.add(O_CAVE, 10, cy, 2, 2, true).text = "cave"; }
  m.add(O_TEMPLE, 46, 10, 3, 2, true).text = "temple";
  for (int x = 33; x <= 62; x++) if (m.get(x, 31) == T_GRASS || m.get(x, 31) == T_PATH) { m.set(x, 31, T_GRASS); m.add(O_THORN, x, 31); }
  for (int y = 10; y <= 36; y++) for (int x = 30; x <= 32; x++) if (m.get(x, y) == T_GRASS && !m.blk[y * OW + x]) m.add(O_ROCK, x, y);
  for (int y = 10; y <= 34; y++) for (int x = 63; x <= 65; x++) if ((m.get(x, y) == T_GRASS || m.get(x, y) == T_SAND) && !m.blk[y * OW + x]) m.add(O_ROCK, x, y);
  for (int y = 10; y < OH; y++) for (int x = 0; x < OW; x += 2) {
    bool edge = x < 4 || x > OW - 6 || y > OH - 4;
    if (edge && r.f() < 0.9) tree(x, y);
  }
  for (int y = 12; y < 66; y++) for (int x = 4; x < 34; x++) {
    if (m.get(x, y) != T_GRASS) continue;
    bool nearPath = false;
    for (int dy = -2; dy <= 2 && !nearPath; dy++) for (int dx = -2; dx <= 2; dx++) if (m.get(x + dx, y + dy) == T_PATH) { nearPath = true; break; }
    int dSecret = (x - 14) * (x - 14) + (y - 46) * (y - 46), dGrove = (x - 9) * (x - 9) + (y - 36) * (y - 36), dMush = (x - 22) * (x - 22) + (y - 24) * (y - 24);
    if (nearPath || dSecret < 9 || dGrove < 26 || dMush < 6 || (std::abs(x - 11) < 3 && y < 16)) continue;
    if (r.f() < 0.33) tree(x, y);
  }
  for (int i = 0; i < 400; i++) {
    int x = I(r.range(4, OW - 5)), y = I(r.range(12, OH - 4));
    if (m.get(x, y) != T_GRASS || m.blk[y * OW + x]) continue;
    if (x > 34 && x < 62 && y > 49 && y < 67) { if (r.f() < 0.5) { Obj& o = m.add(O_FLOWER, x, y, 1, 1, false); o.var = I(r.f() * 2); } continue; }
    double k = r.f();
    if (k < 0.3) { Obj& o = m.add(O_FLOWER, x, y, 1, 1, false); o.var = I(r.f() * 2); }
    else if (k < 0.55 && m.free(x, y, 1, 1)) m.add(O_BUSH, x, y);
    else if (k < 0.65 && m.free(x, y, 1, 1)) m.add(O_ROCK, x, y);
    else if (k < 0.85 && x > 34) tree(x, y);
  }
  m.add(O_CHEST, 82, 36).var = 1;
  m.add(O_CHEST, 14, 46).var = 2;
  m.add(O_CHEST, 58, 40).var = 3;
  for (int i = 0; i < 6; i++) { int x = 41 + i * 2 + (i > 2 ? 4 : 0), y = 60; if (m.free(x, y, 1, 1)) m.add(O_POT, x, y); }
}
void buildInterior(WorldMap& m, int id) {
  m.init(IW, IH, MAP_INTERIOR, T_WFLOOR);
  for (int x = 0; x < IW; x++) { m.set(x, 0, T_ITOP); m.set(x, 1, T_IWALL); m.set(x, IH - 1, T_ITOP); }
  for (int y = 0; y < IH; y++) { m.set(0, y, T_ITOP); m.set(IW - 1, y, T_ITOP); }
  m.set(6, IH - 1, T_EXIT); m.set(7, IH - 1, T_EXIT);
  m.add(O_WINDOW, 3, 1, 1, 1, false); m.add(O_WINDOW, 10, 1, 1, 1, false);
  m.add(O_RUG, 6, 5, 2, 2, false);
  if (id == 0) {
    m.add(O_FIRE, 6, 1, 2, 1); m.add(O_SHELF, 1, 2); m.add(O_SHELF, 2, 2); m.add(O_BED, 11, 2, 1, 2);
    m.add(O_TABLE, 3, 6, 2, 1); m.add(O_CHAIR, 5, 6); m.add(O_PLANT, 12, 7); m.add(O_PLANT, 1, 7);
  } else if (id == 1) {
    m.add(O_OVEN, 2, 2, 2, 1); m.add(O_OVEN, 10, 2, 2, 1); m.add(O_COUNTER, 5, 4, 3, 1); m.add(O_SHELF, 12, 2);
    m.add(O_TABLE, 2, 7, 2, 1); m.add(O_CHAIR, 4, 7); m.add(O_PLANT, 12, 7);
  } else if (id >= 3 && id <= 5) {
    buildInn(m);
  } else {
    m.add(O_BED, 2, 2, 1, 2); m.add(O_SHELF, 11, 2); m.add(O_SHELF, 12, 2); m.add(O_TABLE, 9, 6, 2, 1); m.add(O_CHAIR, 8, 6);
    m.add(O_FIRE, 5, 1, 2, 1); m.add(O_PLANT, 1, 7); m.add(O_PLANT, 12, 7);
    m.add(O_CHEST, 4, 2).var = 4;
  }
}
// zindan iskeleti (üç zindan da aynı 3x3 oda düzenini kullanır)
static void dgRooms(WorldMap& m, std::vector<Room>& rooms) {
  rooms.clear();
  const int used[9][2] = { {1, 2}, {1, 1}, {2, 1}, {0, 1}, {0, 0}, {2, 0}, {1, 0}, {0, 2}, {2, 2} };
  for (auto& u : used) {
    int ox = u[0] * RW, oy = u[1] * RH;
    for (int y = 0; y < RH; y++) for (int x = 0; x < RW; x++) {
      int v = T_DFLOOR;
      if (y == 0 || y == RH - 1 || x == 0 || x == RW - 1) v = T_DTOP; else if (y == 1) v = T_DWALL;
      m.set(ox + x, oy + y, v);
    }
    rooms.push_back({ u[0], u[1], u[0] == 0 && u[1] == 0, false });
  }
}
void dgDoorV(WorldMap& m, int rx, int ry, int type, int lock) {
  int x = rx * RW + RW / 2 - 1, y0 = ry * RH;
  for (int dx = 0; dx < 2; dx++) for (int y = y0 - 1; y <= y0 + 1; y++) { m.set(x + dx, y, type); if (y >= 0) m.lockId[y * m.W + x + dx] = lock; }
}
void dgDoorH(WorldMap& m, int rx, int ry, int type, int lock) {
  int y = ry * RH + (RH >> 1), x0 = (rx + 1) * RW;
  for (int dy = 0; dy < 2; dy++) for (int x = x0 - 1; x <= x0; x++) { m.set(x, y + dy, type); m.lockId[(y + dy) * m.W + x] = lock; }
}
void buildDungeon(WorldMap& m, std::vector<Room>& rooms) {
  m.init(RW * 3, RH * 3, MAP_DUNGEON, T_DTOP);
  dgRooms(m, rooms);
  dgDoorV(m, 1, 2, T_DOOR_OPEN, 0); dgDoorH(m, 0, 2, T_DOOR_OPEN, 0); dgDoorH(m, 1, 2, T_DOOR_OPEN, 0);
  m.set(4, RH * 2 + 5, T_PLATE);
  m.add(O_BLOCK, 11, RH * 2 + 6).var = 0;
  m.add(O_SIGN, 2, RH * 2 + 2, 1, 1).text = "Ağır taş, uyuyan kapıyı uyandırır.";
  for (auto t : { std::pair{RW * 2 + 4, RH * 2 + 3}, {RW * 2 + 15, RH * 2 + 3}, {RW * 2 + 4, RH * 2 + 8}, {RW * 2 + 15, RH * 2 + 8} }) m.add(O_TORCH, t.first, t.second).var = 1;
  m.add(O_SIGN, RW * 2 + 17, RH * 2 + 2, 1, 1).text = "Dört alev yanınca, hazine uyanır.";
  dgDoorH(m, 0, 1, T_DOOR_SHUT, 10); dgDoorH(m, 1, 1, T_DOOR_SHUT, 10);
  dgDoorV(m, 0, 1, T_DOOR_LOCK, 1); dgDoorV(m, 2, 1, T_DOOR_LOCK, 2); dgDoorV(m, 1, 1, T_DOOR_BOSS, 3);
  for (int x = 9; x <= 10; x++) m.set(RW + x, 2 * RH + RH - 2, T_STAIRS);
  for (int y = 2; y < RH - 2; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, RH * 2 + y, T_CARPET);
  for (int y = 2; y < RH - 1; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, y, T_CARPET);
  for (auto t : { std::pair{RW + 3, RH * 2 + 2}, {RW + 16, RH * 2 + 2}, {RW + 3, RH + 2}, {RW + 16, RH + 2}, {3, 2}, {16, 2}, {RW + 3, 2}, {RW + 16, 2},
    {RW * 2 + 3, RH + 2}, {RW * 2 + 16, RH + 2}, {3, RH + 2}, {16, RH + 2}, {RW * 2 + 3, 2}, {RW * 2 + 16, 2} }) m.add(O_TORCH, t.first, t.second);
  for (auto p : { std::pair{RW + 2, RH * 2 + 8}, {RW + 17, RH * 2 + 8}, {RW * 2 + 2, 3}, {RW * 2 + 17, 3}, {2, RH + 8}, {17, RH + 8} }) m.add(O_POT, p.first, p.second);
  m.add(O_CHEST, 10, 4).var = 11;
  m.add(O_CHEST, RW * 2 + 9, 5).var = 12;
  m.add(O_CHEST, RW * 2 + 11, 5).var = 13;
  for (auto p : { std::pair{5, 4}, {14, 4}, {5, 7}, {14, 7} }) m.add(O_ROCK, p.first, p.second).var = 1;
}

// ---------------- 2. bölüm ----------------
void addNorthPass(WorldMap& m, bool open) {
  for (int y = 0; y <= 11; y++) for (int x = PASS_X; x <= PASS_X + 1; x++) {
    int t = m.get(x, y);
    if (t == T_CLIFF || t == T_PLATEAU) m.set(x, y, T_PASS);
  }
  for (int y = 11; y <= 13; y++) for (int x = PASS_X; x <= PASS_X + 1; x++) if (m.get(x, y) == T_GRASS) m.set(x, y, T_PATH);
  EACH(o, m.objs) if (o.alive && o.tx >= PASS_X - 2 && o.tx <= PASS_X + 2 && o.ty >= 9 && o.ty <= 14 && o.type != O_THORN) m.removeObj(o);
  if (!open) m.add(O_SNOWPILE, PASS_X, 11, 2, 1).text = "pile";
  m.add(O_SIGN, PASS_X + 2, 13, 1, 1).text = open ? "KUZEY GEÇİDİ\nKarlı Dağlar ve Ayazköy. Sıkı giyin!" : "KUZEY GEÇİDİ\nKar fırtınası yüzünden kapalı.";
}
void buildSnow(WorldMap& m) {
  m.init(SW, SH, MAP_SNOW, T_SNOW);
  for (int x = 0; x < SW; x++) {
    int cy = 4 + (int)std::trunc(1.5 * std::sin(x * 0.27));
    for (int y = 0; y < cy; y++) m.set(x, y, T_SNOWTOP);
    m.set(x, cy, T_SNOWCLIFF); m.set(x, cy + 1, T_SNOWCLIFF);
  }
  for (int y = 0; y < SH; y++) for (int x = 0; x < SW; x++) {
    double dx = (x - 14) / 9.5, dy = (y - 32) / 7.5;
    if (dx * dx + dy * dy < 1) m.set(x, y, T_ICE);
  }
  for (auto p : { std::pair{9, 35}, {19, 28}, {16, 36}, {8, 29} }) m.set(p.first, p.second, T_ICEWATER);
  mline(m, 35, SH - 1, 35, 22, T_SNOWPATH, 2);
  mline(m, 35, 22, 35, 9, T_SNOWPATH, 1);
  mline(m, 34, 44, 24, 40, T_SNOWPATH, 1);
  mline(m, 24, 40, 24, 22, T_SNOWPATH, 1);
  mline(m, 24, 22, 14, 13, T_SNOWPATH, 1);
  mline(m, 37, 44, 54, 40, T_SNOWPATH, 1);
  mline(m, 54, 40, 60, 26, T_SNOWPATH, 1);
  for (auto p : { std::pair{35, SH - 1}, {36, SH - 1}, {35, SH - 2}, {36, SH - 2} }) m.set(p.first, p.second, T_PASS);
  for (int y = 38; y < 50; y++) for (int x = 28; x < 46; x++) if (std::abs(x - 36) + std::abs(y - 44) < 8 && m.get(x, y) == T_SNOW) m.set(x, y, T_SNOWPATH);
  extendSnow(m);
}
void populateSnow(WorldMap& m, uint32_t iceMask) {
  Rng r(77);
  auto free = [&](int x, int y, int w, int h) {
    for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) {
      if (xx < 0 || yy < 0 || xx >= m.W || yy >= m.H) return false;
      if (m.blk[yy * m.W + xx] || m.t[yy * m.W + xx] != T_SNOW) return false;
    }
    return true;
  };
  auto pine = [&](int x, int y) { if (free(x, y, 2, 1) && free(x, y - 1, 2, 1)) m.add(O_PINE, x, y, 2, 1).var = r.f() < 0.4 ? 1 : 0; };
  m.add(O_CABIN, 29, 36, 3, 3).text = "3"; m.last().var = 1;
  { Obj& h = m.add(O_CABIN, 40, 36, 3, 3); h.text = "M"; h.var = 0; }
  { Obj& h = m.add(O_CABIN, 25, 45, 3, 3); h.text = "A"; h.var = 2; }
  m.add(O_ANVIL, 45, 45, 1, 1);
  m.add(O_CAMPFIRE, 36, 44, 1, 1);
  for (auto p : { std::pair{32, 47}, {41, 41}, {31, 41} }) m.add(O_SNOWMAN, p.first, p.second, 1, 1);
  m.add(O_SIGN, 37, 50, 1, 1).text = "AYAZKÖY\nKuzeyde Buz Tapınağı, batıda Donmuş Göl.";
  m.add(O_SIGN, 26, 22, 1, 1).text = "YETİ MAĞARASI\nKuzeybatı. Geri dönmeyen çok oldu.";
  m.add(O_SIGN, 37, 23, 1, 1).text = "BUZ TAPINAĞI\nYol, sönmeyen bir alevle açılır.";
  m.add(O_SIGN, 50, 39, 1, 1).text = "KEÇİ AĞILI\nKapı batıda. Keçiler inatçıdır!";
  for (int x = 52; x <= 57; x++) { m.add(O_FENCE, x, 39, 1, 1); m.add(O_FENCE, x, 44, 1, 1); }
  for (int y = 40; y <= 43; y++) { if (y != 42) m.add(O_FENCE, 52, y, 1, 1); m.add(O_FENCE, 57, y, 1, 1); }
  { int cy = 4 + (int)std::trunc(1.5 * std::sin(13 * 0.27)); m.add(O_YETICAVE, 13, cy, 2, 2, true).text = "yeti"; }
  m.add(O_ICETEMPLE, 34, 5, 3, 2, true).text = "temple2";
  int bit = 0;
  for (int x = 27; x <= 44; x++) { if (!((iceMask >> (bit % 30)) & 1)) { Obj& o = m.add(O_ICEWALL, x, 20); o.var = bit; } bit++; }
  for (int y = 6; y <= 20; y++) for (int x : { 25, 26, 45, 46 }) if (!m.blk[y * SW + x]) m.add(O_SNOWROCK, x, y);
  m.add(O_FROZEN, 14, 31, 1, 1).text = "frozen";
  for (auto p : { std::pair{30, 12}, {40, 12}, {33, 16}, {38, 16}, {8, 18}, {62, 30} }) m.add(O_CRYSTAL, p.first, p.second, 1, 1);
  extendSnowObjs(m, iceMask);
  for (int y = 6; y < SH; y++) for (int x = 0; x < SW; x += 2) {
    bool edge = x < 3 || x > SW - 5 || (y > SH - 4 && std::abs(x - 35) > 3);
    if (edge && r.f() < 0.92) pine(x, y);
  }
  for (int i = 0; i < 520; i++) {
    int x = I(r.range(3, SW - 4)), y = I(r.range(7, SH - 3));
    if (!free(x, y, 1, 1)) continue;
    bool nearPath = false;
    for (int dy = -1; dy <= 1 && !nearPath; dy++) for (int dx = -1; dx <= 1; dx++) { int t = m.get(x + dx, y + dy); if (t == T_SNOWPATH || t == T_PASS || t == T_ICE) { nearPath = true; break; } }
    if (nearPath) continue;
    if (x > 26 && x < 47 && y > 33 && y < 52) continue;
    if (x > 50 && x < 59 && y > 37 && y < 46) continue;
    if (std::abs(x - 14) < 5 && y > 8 && y < 18) continue;
    if (x > 26 && x < 45 && y > 6 && y < 20) { if (r.f() < 0.12) m.add(O_SNOWROCK, x, y); continue; }
    double k = r.f();
    if (k < 0.45) pine(x, y);
    else if (k < 0.7) m.add(O_SNOWBUSH, x, y);
    else if (k < 0.8) m.add(O_SNOWROCK, x, y);
  }
  m.add(O_CHEST, 64, 14).var = 25;
  m.add(O_CHEST, 5, 46).var = 26;
}
void buildIceTemple(WorldMap& m, std::vector<Room>& rooms) {
  m.init(RW * 3, RH * 3, MAP_DUNGEON2, T_DTOP);
  dgRooms(m, rooms);
  dgDoorV(m, 1, 2, T_DOOR_OPEN, 0); dgDoorH(m, 0, 2, T_DOOR_OPEN, 0); dgDoorH(m, 1, 2, T_DOOR_OPEN, 0);
  dgDoorH(m, 0, 1, T_DOOR_SHUT, 11); dgDoorH(m, 1, 1, T_DOOR_SHUT, 11);
  dgDoorV(m, 0, 1, T_DOOR_LOCK, 4); dgDoorV(m, 2, 1, T_DOOR_LOCK, 5); dgDoorV(m, 1, 1, T_DOOR_BOSS, 6);
  for (int x = 9; x <= 10; x++) m.set(RW + x, 2 * RH + RH - 2, T_STAIRS);
  for (int y = 2; y < RH - 2; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, RH * 2 + y, T_CARPET);
  for (int y = 2; y < RH - 1; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, y, T_CARPET);
  m.add(O_SIGN, RW + 2, RH * 2 + 2, 1, 1).text = "Buz kalpli bekçi uyur.\nAnahtarlar kayan zeminde ve dört alevde.";
  for (int y = 2; y < RH - 1; y++) for (int x = 1; x < RW - 1; x++) if (m.get(x, RH * 2 + y) == T_DFLOOR) m.set(x, RH * 2 + y, T_ICE);
  for (auto p : { std::pair{5, 4}, {9, 7}, {13, 3}, {15, 7}, {7, 8} }) m.add(O_ROCK, p.first, RH * 2 + p.second).var = 1;
  m.add(O_CHEST, 3, RH * 2 + 3).var = 18;
  for (auto t : { std::pair{RW * 2 + 4, RH * 2 + 3}, {RW * 2 + 15, RH * 2 + 3}, {RW * 2 + 4, RH * 2 + 8}, {RW * 2 + 15, RH * 2 + 8} }) m.add(O_TORCH, t.first, t.second).var = 1;
  m.add(O_SIGN, RW * 2 + 17, RH * 2 + 2, 1, 1).text = "Dört alev yanınca, anahtar uyanır.";
  for (int y = 2; y < RH - 1; y++) m.add(O_ICEWALL, 7, RH + y).var = 30 + y;
  m.add(O_CHEST, 3, RH + 5).var = 20;
  m.set(RW * 2 + 15, RH + 5, T_PLATE);
  m.add(O_BLOCK, RW * 2 + 8, RH + 6).var = 0;
  m.add(O_SIGN, RW * 2 + 2, RH + 2, 1, 1).text = "Ağır taş, donmuş kilidi çözer.";
  for (auto t : { std::pair{RW + 3, RH * 2 + 2}, {RW + 16, RH * 2 + 2}, {RW + 3, RH + 2}, {RW + 16, RH + 2}, {3, 2}, {16, 2}, {RW + 3, 2}, {RW + 16, 2},
    {RW * 2 + 3, RH + 2}, {RW * 2 + 16, RH + 2}, {3, RH + 2}, {16, RH + 2}, {RW * 2 + 3, 2}, {RW * 2 + 16, 2} }) m.add(O_TORCH, t.first, t.second);
  for (auto p : { std::pair{RW + 2, RH * 2 + 8}, {RW + 17, RH * 2 + 8}, {RW * 2 + 2, 3}, {RW * 2 + 17, 3}, {17, RH + 8} }) m.add(O_POT, p.first, p.second);
  m.add(O_CHEST, 10, 4).var = 22;
  m.add(O_CHEST, RW * 2 + 9, 5).var = 23;
  for (auto p : { std::pair{5, 4}, {14, 4}, {5, 7}, {14, 7} }) m.add(O_ROCK, p.first, p.second).var = 1;
  for (auto p : { std::pair{RW + 4, RH + 4}, {RW + 15, RH + 4}, {RW + 4, RH + 7}, {RW + 15, RH + 7} }) m.add(O_CRYSTAL, p.first, p.second);
}
void buildInn(WorldMap& m) {
  m.add(O_FIRE, 6, 1, 2, 1);
  m.add(O_BED, 2, 2, 1, 2); m.add(O_BED, 4, 2, 1, 2);
  m.add(O_COUNTER, 9, 4, 3, 1);
  m.add(O_SHELF, 12, 2);
  m.add(O_TABLE, 3, 6, 2, 1); m.add(O_CHAIR, 5, 6); m.add(O_TABLE, 9, 7, 2, 1); m.add(O_CHAIR, 8, 7);
  m.add(O_PLANT, 12, 7);
}
