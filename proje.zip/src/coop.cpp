// ORMANIN KALBİ - menüler, bölüm seçme, iki kişilik oyun (aynı bilgisayar) ve online (oda koduyla)
// Online: ücretsiz PeerJS aracı servisiyle iki cihaz doğrudan bağlanır. Oyunu kuran (ev sahibi) dünyayı yönetir,
// katılan (misafir) kendi kahramanını yürütür ve ev sahibinin gönderdiği görüntüyü çizer.
#include "game.h"
#include "net.h"

static const char* ROOM_PREFIX = "ormanin-kalbi-oda-";
static const char* CODE_LETTERS = "ABCDEFGHJKLMNPRSTUVYZ";
static const char* CH_NAMES[5] = { "Bölüm 1-1: Kara Sis", "Bölüm 1-2: Karlı Dağlar", "Bölüm 1-3: Batık Şehir", "Bölüm 1-4: Göklerdeki Kule", "Bölüm 1-5: Oyun Adası" };
static const char* P2_NAME = "Ece";

// ---------------- başlık menüleri ----------------
std::vector<string> Game::titleItems() {
  const string& mode = menuMode;
  std::vector<string> save; if (hasSave()) save.push_back("Devam Et");
  auto cat = [](std::vector<string> a, const std::vector<string>& b, std::vector<string> c) { std::vector<string> r = a; r.insert(r.end(), b.begin(), b.end()); r.insert(r.end(), c.begin(), c.end()); return r; };
  if (netRole == "guest") return { "Bekleniyor...", "Odadan Ayrıl" };   // yanlışlıkla basınca odadan çıkmasın
  if (mode == "chapters") return { CH_NAMES[0], CH_NAMES[1], CH_NAMES[2], CH_NAMES[3], CH_NAMES[4], "Geri" };
  if (mode == "online") return netRole == "host" ? cat({ "Yeni Oyun" }, save, { "Bölüm Seç", "Odayı Kapat" }) : std::vector<string>{ "Oda Kur", "Odaya Katıl", "Geri" };
  if (mode == "local") return cat({ "Yeni Oyun" }, save, { "Bölüm Seç", fmt("Oyuncu sayısı: %d", localN), "Geri" });
  std::vector<string> v = cat({ "Yeni Oyun" }, save, { "Bölüm Seç" });
  if (desktop) v.push_back("Aynı Bilgisayarda (2-4 Kişi)");
  v.push_back("Online (2-4 Kişi)");
  v.push_back(langLabel());
  return v;
}
void Game::titleChoose(int i) {
  auto it = titleItems();
  if (fadeState != 0 || i >= (int)it.size()) return;
  string lab = it[i], mode = menuMode;
  sfx(SFX_CHIME);
  auto go = [this](std::function<void()> fn) { fadeTo([this, fn] { fn(); state = S_PLAY; afterStart(); }); };
  auto to = [this](const string& m, const string& note) { menuMode = m; menuSel = 0; menuNote = note; };
  if (lab == langLabel()) { setLang(!lang); return; }
  if (lab == "Odadan Ayrıl") { netLost(); return; }
  if (lab == "Bekleniyor...") return;
  if (mode == "chapters") {
    if (lab == "Geri") { to(chapBack, ""); return; }
    int n = i + 1; go([this, n] { startChapter(n); }); return;
  }
  if (lab == "Yeni Oyun") go([this] { newGame(); });
  else if (lab == "Devam Et") go([this] { if (!loadGame()) newGame(); });
  else if (lab == "Bölüm Seç") { chapBack = mode; to("chapters", "Seçtiğin bölüm kayıtlı oyunun yerine geçer."); }
  else if (lab == "Aynı Bilgisayarda (2-4 Kişi)") { coop = "local"; to("local", "1. oyuncu: WASD + F G R  •  2. oyuncu: oklar + K L O  •  3. ve 4. oyuncu: oyun kolu"); }
  else if (lab.rfind("Oyuncu sayısı", 0) == 0) { localN = localN >= 4 ? 2 : localN + 1; menuNote = localN > 2 ? "3. ve 4. oyuncu oyun koluyla oynar (kol 1 -> 3. oyuncu, kol 2 -> 4. oyuncu)." : "1. oyuncu: WASD + F G R  •  2. oyuncu: oklar + K L O"; }
  else if (lab == "Online (2-4 Kişi)") to("online", "Oda kur ya da arkadaşının odasına kodla katıl. Odaya en fazla 4 kişi girer.");
  else if (lab == "Oda Kur") netHost();
  else if (lab == "Odaya Katıl") { joinOpen = true; joinCode.clear(); if (onJoinRequest) onJoinRequest(); }
  else if (lab == "Odayı Kapat") { netClose(); to("online", "Oda kapatıldı."); }
  else if (lab == "Geri") { if (mode == "local") coop.clear(); to("main", ""); }
}
// oyun başlayınca ortak kahramanlar: aynı bilgisayarda localN kişi, online her bağlı misafir için bir kahraman
void Game::afterStart() {
  if (coop == "local") { for (int i = 0; i < std::max(1, std::min(3, localN - 1)); i++) makePartner(i, false); }
  else if (netRole == "host" && netLive) { makePartner(0, true); for (int e = 0; e < 2; e++) if (extraOn[e]) makePartner(e + 1, true); }
}
// bölüm seçme: o bölümün başındaki eşyalarla başlar
void Game::startChapter(int n) {
  resetProgress();
  if (n >= 2) {
    swordLv = 2; hasLantern = true; hasGem = true; cured = true; bossDead = true; mainStep = 6; maxHp = 10;
    potions = 2; coins = 80; mushMask = 7; flags |= F_STUMP; doorMask |= (1u << 20) | 2 | 4 | 8 | (1u << 10); clearMask = 511;
  }
  if (n >= 3) {
    hasFireStone = true; hasFireLantern = true; hasGem2 = true; bossKey2 = true; golemDead = true; mainStep = 13; maxHp = 14;
    swordLv = 3; coins = 150; potions = 3; flags |= F2_YETI | F2_SNOWINTRO; iceMask = (1u << 18) - 1; clear2 = 511; doorMask |= 16 | 32 | 64 | (1u << 11);
  }
  if (n >= 4) {
    hasCharm = true; hasGem3 = true; bossKey3 = true; krakenDead = true; mainStep = 21; maxHp = 18; coins = 200; potions = 3;
    flags |= F3_CRABKING | F3_INTRO; clear3 = 511; doorMask |= (1u << 7) | (1u << 8) | (1u << 9) | (1u << 12);
  }
  if (n >= 5) {
    hasHorn = true; hasGem4 = true; bossKey4 = true; mainStep = 29; maxHp = 22; coins = 250; potions = 4; f4 |= G4_INTRO | G4_EAGLE | 4 | 8 | 16 | G4_BRAZIER | G4_LORD | G4_HOME;
    clear4 = (1u << 15) - 1; f5 |= G5_TWIST;
  }
  hikayeOnce(n); hp = maxHp;
  enterOverworld(38 * 16 + 8, 64 * 16 + 12); pdir = 3; state = S_PLAY;
  // büyük harf (Türkçe): yalnızca bu dört başlık için
  static const char* UP[5] = { "BÖLÜM 1-1: KARA SİS", "BÖLÜM 1-2: KARLI DAĞLAR", "BÖLÜM 1-3: BATIK ŞEHİR", "BÖLÜM 1-4: GÖKLERDEKİ KULE", "BÖLÜM 1-5: OYUN ADASI" };
  say({ L("", UP[n - 1]), L("Arda", n == 1 ? "Yeni bir gün... Nine meydanda beni bekliyor olmalı." : "Nine'nin yanına gitmeliyim. Yeni bir yolculuk başlıyor.") });
}

// ---------------- ortak kahramanlar (2., 3., 4. oyuncu) ----------------
static const char* P_NAMES[3] = { "Ece", "Ela", "Toprak" };
int Game::partnerCount() { int n = 0; for (auto& q : pp) if (q) n++; return n; }
const std::vector<std::vector<const Spr*>>* Game::partnerSet(int i) { return i == 0 ? &A.hero2 : i == 1 ? &A.hero3 : &A.hero4; }
string Game::partnerName(int i) { return netRole == "host" ? fmt("%d. oyuncu", i + 2) : string(P_NAMES[i % 3]); }
void Game::makePartner(int i, bool remote) {
  if (i < 0 || i > 2 || pp[i]) return;
  pp[i] = std::make_unique<P2>(); P2& q = *pp[i];
  q.px = px + 14 * (i + 1); q.py = py; q.pdir = pdir; q.invT = 1.5; q.hp = maxHp; q.gen = map.gen; q.remote = remote; q.set = partnerSet(i);
  if (boxHit(q.px, q.py, PHW, PHH)) q.px = px;
}
void Game::makeP2() { makePartner(0, false); }
void Game::swapP2() {
  P2& q = *pp[curP];
  std::swap(px, q.px); std::swap(py, q.py); std::swap(pdir, q.pdir); std::swap(attackT, q.attackT); std::swap(attackId, q.attackId); std::swap(invT, q.invT);
  std::swap(kT, q.kT); std::swap(kx, q.kx); std::swap(ky, q.ky); std::swap(animT, q.animT); std::swap(moving, q.moving); std::swap(pvx, q.pvx); std::swap(pvy, q.pvy);
  std::swap(freezeT, q.freezeT); std::swap(dustT, q.dustT); std::swap(pushT, q.pushT); std::swap(hp, q.hp);
  std::swap(inp, q.inp);
}
void Game::teleportP2() {
  if (!pp[curP]) return; P2& q = *pp[curP];
  double off = 12 * (curP + 1) * (curP == 1 ? -1 : 1);
  q.px = px + off; q.py = py + (curP == 2 ? 10 : 0); if (boxHit(q.px, q.py, PHW, PHH)) { q.px = px; q.py = py; }
  q.pvx = q.pvy = 0; q.kT = 0; q.gen = map.gen; q.tp++;
}
void Game::updateP2(double dt) {
  P2& q = *pp[curP];
  if (q.gen != map.gen || (isDg(map.kind) && roomT <= 0 && roomOf(q.px, q.py) != curRoom)) teleportP2();
  if (coop == "local" && (std::fabs(q.px - px) > VW / 2.0 + 30 || std::fabs(q.py - py) > VH / 2.0 + 20)) teleportP2();   // aynı ekranda kalsınlar
  Press I = q.inp.pressed;
  if (dlg) { if (I.act || I.attack || I.confirm) dlgAdvance(); q.inp.pressed.clear(); return; }
  if (roomT > 0) { q.inp.pressed.clear(); return; }
  if (q.deadT > 0) {
    q.deadT -= dt;
    if (q.deadT <= 0) { q.deadT = 0; q.hp = maxHp; teleportP2(); q.invT = 2; poof(q.px, q.py - 8); }
    q.inp.pressed.clear(); return;
  }
  if (q.invT > 0) q.invT -= dt;
  if (q.remote) { q.inp.ax = 0; q.inp.ay = 0; q.pvx = q.pvy = 0; if (I.attack) q.attackT = 0; }
  bool rm = q.remoteMoving; double ra = q.animT;
  swapP2(); dlgClosed = false; heroStep(dt, I); interact(); swapP2();
  if (q.remote) { q.moving = rm; q.animT = ra; }
  q.inp.pressed.clear();
}
void Game::updatePartners(double dt) {
  for (curP = 0; curP < 3; curP++) if (pp[curP] && state == S_PLAY) updateP2(dt);
  curP = 0;
}
void Game::hurtP2(int d, double fx, double fy) {
  if (!pp[curP]) return; P2& q = *pp[curP];
  if (q.invT > 0 || q.deadT > 0 || state != S_PLAY) return;
  if (sec & 16) d = std::max(1, d - 1);
  q.hp -= d; q.invT = 1.1; sfx(SFX_HURT); shake = std::max(shake, 0.15);
  if (!q.remote) { double dx = q.px - fx, dy = q.py - fy, l = std::hypot(dx, dy) + 0.01; q.kx = dx / l * 170; q.ky = dy / l * 170; q.kT = 0.18; }
  if (q.hp <= 0) {
    q.hp = 0; q.deadT = 5; poof(q.px, q.py - 8); sfx(SFX_SHATTER, 0.6);
    toast(fmt("%s bayıldı! 5 saniye sonra yanına döner.", partnerName(curP).c_str()));
  }
}
void Game::drawP2(double ox, double oy) {
  if (!pp[curP]) return; P2& q = *pp[curP];
  auto prev = heroSet; heroSet = q.set ? q.set : partnerSet(curP);
  swapP2(); int st = state; if (st == S_OVER) state = S_PLAY;
  drawHero(ox, oy);
  state = st; swapP2(); heroSet = prev;
}
void Game::hudP2() {
  P2& q = *pp[curP]; double hy = hudRowY + 29 + curP * 17, n = maxHp / 2.0;
  fillLo(3, hy, 12 + std::min(10.0, n) * 8, 10 + (n > 10 ? 7 : 0), rgba(0, 0, 0, 0.35));
  const Spr* face = (q.set ? *q.set : *partnerSet(curP))[0][0]; spr(face, 3, hy - 3, false, 1, 0.55, 0.55);
  for (int i = 0; i < n; i++) { int v = q.hp - i * 2; const Spr* sp = v >= 2 ? A.heart : v == 1 ? A.heartHalf : A.heartEmpty; spr(sp, 14 + (i % 10) * 8, hy + 2 + (i / 10) * 7, false, q.deadT ? 0.4 : 1, 0.75, 0.75); }
}
// aynı bilgisayarda: kamera bütün kahramanların ortasına bakar
void Game::camFocus(double& x, double& y) {
  x = px; y = py; int n = 1;
  if (coop == "local") for (auto& q : pp) if (q && !q->deadT) { x += q->px; y += q->py; n++; }
  x /= n; y /= n;
}
// ---------------- online ----------------
void Game::sfx(int t, double a /*= 1*/) {
  if (netRole == "host" && netLive && netFx.size() < 80) { WBuf w; w.u8('s'); w.u8(t); w.f32(a); netFx.push_back(w.b); }
  sfx0(t, a);
}
void Game::burst(int kind, double x, double y, int n, uint32_t col /*= 0*/) {
  if (netRole == "host" && netLive && netFx.size() < 80) { WBuf w; w.u8('b'); w.u8(kind); w.f32(x); w.f32(y); w.u8(std::min(12, n)); w.i32((int32_t)col); netFx.push_back(w.b); }
  burst0(kind, x, y, n, col);
}
void Game::poof(double x, double y) {
  if (netRole == "host" && netLive && netFx.size() < 80) { WBuf w; w.u8('p'); w.f32(x); w.f32(y); netFx.push_back(w.b); }
  poof0(x, y);
}
void Game::netHost() {
  if (netRole.size()) return;
  if (!net) net.reset(makeTransport());
  if (!net) { menuNote = "Online bu sürümde kullanılamıyor."; return; }
  string code; for (int i = 0; i < 5; i++) code += CODE_LETTERS[(int)(std::rand() % 21)];
  if (const char* c = getenv("ORMAN_ODA")) code = c;   // yalnızca testler için
  if (!net->host(ROOM_PREFIX + code)) { menuNote = "Bağlantı servisine ulaşılamadı. İnterneti kontrol edip tekrar dene."; netClose(); return; }
  netRole = "host"; roomCode = code; netWait = 15; netOpen = false;
  menuNote = "Oda kuruluyor...";
}
void Game::netJoin(const string& codeIn) {
  string code; for (char c : codeIn) { char u = (char)toupper((unsigned char)c); if (u >= 'A' && u <= 'Z') code += u; }
  if (code.size() != 5) { menuNote = "Oda kodu 5 harf olmalı."; return; }
  if (netRole.size()) netClose();
  if (!net) net.reset(makeTransport());
  if (!net) { menuNote = "Online bu sürümde kullanılamıyor."; return; }
  if (!net->join(ROOM_PREFIX + code)) { menuNote = "Bağlantı servisine ulaşılamadı. İnterneti kontrol et."; netClose(); return; }
  netRole = "guest"; netWait = 25; netOpen = false; gKey.clear();
  menuNote = "Bağlanıyor...";
}
void Game::netClose() {
  if (net) net->close();
  bool wasGuest = netRole == "guest";
  netRole.clear(); netLive = false; heroSet = nullptr; gKey.clear(); guestMenu = false; netOpen = false; extraOn[0] = extraOn[1] = false; gSeat = 1;
  for (auto& q : pp) if (q && (q->remote || wasGuest)) q.reset();
}
void Game::netLost() {
  if (netRole.empty()) return;
  bool guest = netRole == "guest";
  netClose();
  if (guest) {
    state = S_TITLE; setMood(7); buildOverworld(map); populateOverworld(map); ents.clear(); npcs.clear(); picks.clear(); dlg = false;
    menuMode = "online"; menuSel = 0; menuNote = "Bağlantı koptu."; fade = 0; fadeState = 0;
  } else { toast("Arkadaşının bağlantısı koptu."); menuNote = "Oda kapandı."; }
}
void Game::netPress(const char* k) {
  if (!strcmp(k, "attack")) gPress |= 1; else if (!strcmp(k, "act")) gPress |= 2; else if (!strcmp(k, "item")) gPress |= 4; else if (!strcmp(k, "confirm")) gPress |= 8;
  else if (!strcmp(k, "up")) gPress |= 16; else if (!strcmp(k, "down")) gPress |= 32; else if (!strcmp(k, "left")) gPress |= 64; else if (!strcmp(k, "right")) gPress |= 128;
}
void Game::netSendChoice(int i) { if (net && netLive) { WBuf w; w.u8('c'); w.u8(i); net->send(w.b); } }
// bağlantı olaylarını işle (her karede)
void Game::netPoll(double dt) {
  if (!net || netRole.empty()) return;
  NetEvent ev;
  while (net && net->poll(ev)) {
    switch (ev.kind) {
      case NetEvent::OPEN:   // aracı servise bağlandık
        netOpen = true;
        if (netRole == "host") menuNote = "ODA KODU: " + roomCode + "  •  Arkadaşın \"Odaya Katıl\" deyip bu kodu yazsın";
        else menuNote = "Arkadaşının odası aranıyor...";
        break;
      case NetEvent::PEER:   // iki cihaz birbirine bağlandı
        if (netRole == "host" && ev.who > 0) {   // 3. ya da 4. kişi
          extraOn[ev.who - 1] = true;
          { WBuf w; w.u8('w'); w.u8(ev.who + 1); net->sendTo(ev.who, w.b); }
          if (state == S_PLAY) makePartner(ev.who, true);
          toast(fmt("%d. oyuncu odaya katıldı!", ev.who + 2));
          break;
        }
        if (netRole == "host") { WBuf w; w.u8('w'); w.u8(1); net->sendTo(0, w.b); }
        netLive = true; netWait = 0; netFx.clear();
        if (netRole == "host") { toast("Arkadaşın odaya katıldı!"); menuNote = "ODA " + roomCode + ": arkadaşın bağlandı! Oyunu başlat."; }
        else { menuNote = "Bağlandı! Arkadaşının oyunu başlatmasını bekle."; heroSet = &A.hero2; gKey.clear(); }
        break;
      case NetEvent::DATA:
        if (netRole == "host") netOnHost(ev.data, ev.who); else netOnGuest(ev.data);
        break;
      case NetEvent::CLOSE:
        if (netRole == "host" && ev.who > 0) { extraLeft(ev.who); break; }
        if (netLive) netLost(); else { menuNote = netRole == "guest" ? "Bu kodla açık bir oda bulunamadı." : "Bağlantı kapandı."; netClose(); }
        return;
      case NetEvent::ERR:
        if (netRole == "host" && ev.who > 0) { extraLeft(ev.who); break; }
        if (netLive) { netLost(); return; }
        menuNote = ev.data == "peer-unavailable" ? "Bu kodla açık bir oda bulunamadı." : "Bağlantı hatası (" + ev.data + "). Tekrar dene.";
        netClose(); return;
    }
  }
  if (netWait > 0 && !netLive) {
    netWait -= dt;
    if (netWait <= 0) {
      if (netRole == "host" && netOpen) return;   // ev sahibi arkadaşını bekler
      menuNote = netOpen ? "Arkadaşına ulaşılamadı. Kodu kontrol et; olmazsa ikiniz de aynı Wi-Fi'ye bağlanın." : "Bağlantı servisine ulaşılamadı. İnterneti kontrol et.";
      netClose();
    }
  }
}
// ev sahibi: misafirden gelen girdi
// 3. ve 4. kişi ayrıldı: yuvası boşalır, okeydeki yerine bilgisayar geçer
void Game::extraLeft(int who) {
  if (who < 1 || who > 2 || !extraOn[who - 1]) return;
  extraOn[who - 1] = false; if (net) net->drop(who);
  mgSeatLeft(who + 1); pp[who].reset();
  toast(fmt("%d. oyuncu ayrıldı.", who + 2));
}
void Game::netOnHost(const string& data, int who /*= 0*/) {
  RBuf r(data); int t = r.u8();
  if (t == 'i' && who >= 0 && who < 3 && pp[who] && pp[who]->remote) {
    P2& q = *pp[who];
    double x = r.f32(), y = r.f32(); int d = r.u8(), m = r.u8(); double a = r.f32(); int pr = r.u8(), tp = r.i32();
    if (r.bad) return;
    if (tp == q.tp && std::isfinite(x) && std::isfinite(y)) { q.px = x; q.py = y; }
    q.pdir = d & 3; q.remoteMoving = m != 0; q.animT = a;
    if (pr & 1) q.inp.pressed.attack = true; if (pr & 2) q.inp.pressed.act = true; if (pr & 4) q.inp.pressed.item = true; if (pr & 8) q.inp.pressed.confirm = true;
    if (pr & 16) q.inp.pressed.up = true; if (pr & 32) q.inp.pressed.down = true; if (pr & 64) q.inp.pressed.left = true; if (pr & 128) q.inp.pressed.right = true;
  } else if (t == 'c' && dlg && dChoices.size()) { int i = r.u8(); if (!r.bad) dlgChoose(i); }
  else if (t == 'm') { int tb = r.u8(); int cell = r.i32(); if (!r.bad) mgRemoteTap(tb, cell, who + 1); }
}
string Game::progBlob() {
  WBuf w;
  saveFields([&](const char*, double* dv, int* iv, bool* bv, uint32_t* uv) { if (dv) w.f64(*dv); else if (iv) w.i32(*iv); else if (bv) w.u8(*bv); else w.i32((int32_t)*uv); });
  return w.b;
}
void Game::applyProg(const string& b) {
  RBuf r(b);
  saveFields([&](const char*, double* dv, int* iv, bool* bv, uint32_t* uv) { if (dv) *dv = r.f64(); else if (iv) *iv = r.i32(); else if (bv) *bv = r.u8() != 0; else *uv = (uint32_t)r.i32(); });
}
string Game::netSnapshot() {
  for (auto& e : ents) if (!e->nid) e->nid = ++netId;
  WBuf w; w.u8('s');
  w.u8(state); w.u8(map.kind); w.i32(interior); w.u8(caveId); w.i32(interiorRet[0]); w.i32(interiorRet[1]); w.i32(mood);
  w.f32(std::max(0.0, shake)); w.f32(fade); w.i32(curRoom); w.i32(p2 ? p2->tp : 0); w.f32(state == S_CREDITS ? creditsT : 0); w.f32(deathT);
  // ev sahibinin kahramanı
  w.f32(px); w.f32(py); w.u8(pdir); w.f32(attackT); w.f32(animT); w.u8(moving); w.u8(invT > 0); w.i32(hp); w.u8(freezeT > 0); w.u8(swordLv);
  // misafirin kahramanı (ev sahibinin gözünden)
  // ortak kahramanlar (her misafir kendi yuvasını alır, ötekileri çizer)
  for (auto& q : pp) { w.u8(q ? 1 : 0); if (q) { w.f32(q->px); w.f32(q->py); w.i32(q->hp); w.u8(q->invT > 0); w.u8(q->deadT > 0); w.u8(q->pdir); w.f32(q->attackT); w.f32(q->animT); w.u8(q->moving || q->remoteMoving); w.i32(q->tp); } }
  int ne = 0; for (auto& e : ents) if (e->alive) ne++;
  w.i32(ne);
  for (auto& e : ents) if (e->alive) { w.i32(e->nid); w.u8(e->type); w.f32(e->x); w.f32(e->y); w.f32(e->z); w.i32(e->state); w.f32(e->t); w.u8(e->dir); w.u8(e->flash > 0); w.f32(e->vx); w.f32(e->vy); w.u8(e->inv); }
  w.i32((int32_t)picks.size());
  for (auto& k : picks) { w.u8(k->type); w.f32(k->x); w.f32(k->y); w.f32(k->z); w.f32(k->t); w.i32(k->val); }
  w.u8(dlg ? 1 : 0);
  if (dlg) { w.str(dl[di].who); w.str(dl[di].text); w.i32((int32_t)dChoices.size()); for (auto& c : dChoices) w.str(c); w.u8(dSel); w.i32(I(dchars)); }
  w.u8(toastT > 0); if (toastT > 0) { w.str(toastS); w.f32(toastT); }
  w.i32((int32_t)netFx.size()); for (auto& f : netFx) w.str(f); netFx.clear();
  // ilerleme ve nesneler: değişince (ya da arada bir) gönderilir
  string pb = progBlob();
  if (pb != netLastProg || ++netProgN > 30) { w.u8(1); w.str(pb); netLastProg = pb; netProgN = 0; } else w.u8(0);
  string al; for (auto& o : map.objs) al += o->alive ? '1' : '0';
  WBuf sp; int nsp = 0;
  for (size_t i = 0; i < map.objs.size(); i++) { Obj& o = *map.objs[i]; if (o.type == O_BLOCK || o.type == O_TORCH || o.type == O_CHEST || o.type == O_BRAZIER || o.type == O_CLOUDSTONE || o.text == "open") { sp.i32((int)i); sp.i32(o.tx); sp.i32(o.ty); sp.i32(o.var); sp.u8(o.text == "open"); nsp++; } }
  string os = al + sp.b;
  if (os != netLastObj || ++netObjN > 45) { w.u8(1); w.str(al); w.i32(nsp); w.b += sp.b; netLastObj = os; netObjN = 0; } else w.u8(0);
  mgSave(w);   // masa oyunu (Oyun Adası)
  return w.b;
}
void Game::netTick(double dt) {
  netAcc += dt;
  if (netAcc < 1 / 15.0 || !net) return;
  netAcc = 0;
  net->send(netSnapshot());
}
// misafir: ev sahibinin görüntüsünü uygula
void Game::netOnGuest(const string& data) {
  if (netRole != "guest") return;
  RBuf r(data); int t = r.u8();
  if (t == 'f') { menuNote = "Oda dolu: içeride zaten dört kişi var."; netClose(); return; }
  if (t == 'w') { int s = r.u8(); if (!r.bad) gSeat = s; return; }   // masadaki yerim (1: arkadaş, 2-3: izleyici/okey)
  if (t != 's') return;
  Snap s;
  s.st = r.u8(); s.k = r.u8(); s.i = r.i32(); s.cv = r.u8(); s.rr[0] = r.i32(); s.rr[1] = r.i32(); s.mood = r.i32();
  s.sh = r.f32(); s.fd = r.f32(); s.room = r.i32(); s.tp = r.i32(); s.cr = r.f32(); s.dt = r.f32();
  s.a[0] = r.f32(); s.a[1] = r.f32(); s.a[2] = r.u8(); s.a[3] = r.f32(); s.a[4] = r.f32(); s.a[5] = r.u8(); s.a[6] = r.u8(); s.a[7] = r.i32(); s.a[8] = r.u8(); s.a[9] = r.u8();
  for (auto& q : s.ps) { q.on = r.u8() != 0; if (q.on) { q.x = r.f32(); q.y = r.f32(); q.hp = r.i32(); q.inv = r.u8() != 0; q.dead = r.u8() != 0; q.dir = r.u8(); q.at = r.f32(); q.an = r.f32(); q.mv = r.u8() != 0; q.tp = r.i32(); } }
  { int me = std::max(0, std::min(2, gSeat - 1)); auto& o = s.ps[me]; s.hasB = o.on; if (o.on) { s.b[0] = o.x; s.b[1] = o.y; s.b[2] = o.hp; s.b[3] = o.inv; s.b[4] = o.dead; s.tp = o.tp; } }
  if (r.bad) return;
  // ilerleme bilgisi en sonda; önce düşmanları oku
  int ne = r.i32(); std::vector<SnapEnt> se;
  for (int i = 0; i < ne && !r.bad; i++) { SnapEnt e; e.nid = r.i32(); e.type = r.u8(); e.x = r.f32(); e.y = r.f32(); e.z = r.f32(); e.st = r.i32(); e.t = r.f32(); e.dir = r.u8(); e.fl = r.u8(); e.vx = r.f32(); e.vy = r.f32(); e.inv = r.u8(); se.push_back(e); }
  int np = r.i32(); std::vector<Pick> sp;
  for (int i = 0; i < np && !r.bad; i++) { Pick k; k.type = r.u8(); k.x = r.f32(); k.y = r.f32(); k.z = r.f32(); k.t = r.f32(); k.val = r.i32(); sp.push_back(k); }
  bool hasD = r.u8(); Line dln; std::vector<string> dch; int dsel = 0, dn = 0;
  if (hasD) { dln.who = r.str(); dln.text = r.str(); int nc = r.i32(); for (int i = 0; i < nc && !r.bad; i++) dch.push_back(r.str()); dsel = r.u8(); dn = r.i32(); }
  bool hasT = r.u8(); string ts; double tt = 0; if (hasT) { ts = r.str(); tt = r.f32(); }
  int nfx = r.i32(); std::vector<string> fx; for (int i = 0; i < nfx && !r.bad; i++) fx.push_back(r.str());
  bool hasG = r.u8(); string prog; if (hasG) prog = r.str();
  bool hasO = r.u8(); string al; std::vector<std::array<int, 5>> osp;
  if (hasO) { al = r.str(); int n = r.i32(); for (int i = 0; i < n && !r.bad; i++) { std::array<int, 5> a{}; a[0] = r.i32(); a[1] = r.i32(); a[2] = r.i32(); a[3] = r.i32(); a[4] = r.u8(); osp.push_back(a); } }
  if (r.bad) return;
  mgLoad(r);

  if (hasG) applyProg(prog);
  if (s.st == S_TITLE) { if (gKey.size()) { gKey.clear(); state = S_TITLE; menuNote = "Arkadaşın menüye döndü. Bekle..."; } return; }
  string key = fmt("%d|%d|%d", s.k, s.i, s.cv);
  if (key != gKey) { gKey = key; guestBuild(s); }
  setTide(tide);
  for (auto& f : EXT.sync) f();
  // nesneler, kapılar
  if (hasO && al.size() == map.objs.size()) {
    for (size_t i = 0; i < al.size(); i++) { Obj& o = *map.objs[i]; if (al[i] == '0' && o.alive) map.removeObj(o); }
    for (auto& a : osp) { if (a[0] < 0 || a[0] >= (int)map.objs.size()) continue; Obj& o = *map.objs[a[0]]; if (o.type == O_BLOCK && (o.tx != a[1] || o.ty != a[2])) moveBlockTo(o, a[1], a[2]); o.var = a[3]; if (a[4]) o.text = "open"; }
  }
  for (size_t i = 0; i < map.t.size(); i++) { int lid = map.lockId[i]; if (lid && ((doorMask >> lid) & 1)) map.t[i] = T_DOOR_OPEN; }
  state = s.st == S_PAUSE ? S_PLAY : s.st; hostPaused = s.st == S_PAUSE;
  curRoom = s.room; shake = s.sh; fade = s.fd; creditsT = s.cr; deathT = s.dt;
  if (s.mood != mood && s.mood >= 0) setMood(s.mood);
  // ev sahibinin kahramanı
  if (!p2) { p2 = std::make_unique<P2>(); p2->set = &A.hero; p2->px = s.a[0]; p2->py = s.a[1]; }
  P2& q = *p2;
  q.gx = s.a[0]; q.gy = s.a[1]; if (std::fabs(q.px - s.a[0]) > 80 || std::fabs(q.py - s.a[1]) > 80) { q.px = s.a[0]; q.py = s.a[1]; }
  q.pdir = (int)s.a[2]; q.attackT = s.a[3]; q.animT = s.a[4]; q.moving = s.a[5] != 0; q.invT = s.a[6] ? 0.5 : 0; q.hp = (int)s.a[7]; q.freezeT = s.a[8] ? 1 : 0;
  // kendi kahramanım (ev sahibinin gözünden)
  if (s.hasB) {
    hp = (int)s.b[2]; if (s.b[3] && invT <= 0) invT = 1; gDead = s.b[4] != 0;
    if (s.tp != gTp) { gTp = s.tp; px = s.b[0]; py = s.b[1]; pvx = pvy = 0; }
  }
  {   // öteki ortaklar (benim dışımdakiler): pp[1], pp[2]
    int k = 1, me = std::max(0, std::min(2, gSeat - 1));
    for (int j = 0; j < 3; j++) {
      auto& o = s.ps[j]; if (!o.on || j == me) continue; if (k > 2) break;
      if (!pp[k]) { pp[k] = std::make_unique<P2>(); pp[k]->px = o.x; pp[k]->py = o.y; }
      P2& q = *pp[k]; q.set = partnerSet(j); q.gx = o.x; q.gy = o.y; if (std::fabs(q.px - o.x) > 80 || std::fabs(q.py - o.y) > 80) { q.px = o.x; q.py = o.y; }
      q.pdir = o.dir; q.attackT = o.at; q.animT = o.an; q.moving = o.mv; q.invT = o.inv ? 0.5 : 0; q.hp = o.hp; q.deadT = o.dead ? 1 : 0;
      k++;
    }
    for (; k < 3; k++) pp[k].reset();
  }
  // düşmanlar (kimliğe göre yumuşak geçiş)
  std::unordered_map<int, std::unique_ptr<Ent>> old;
  for (auto& e : ents) { int id = e->nid; old[id] = std::move(e); }
  ents.clear();
  for (auto& x : se) {
    auto it = old.find(x.nid); std::unique_ptr<Ent> e;
    if (it != old.end() && it->second) e = std::move(it->second);
    else { e = std::make_unique<Ent>(); e->nid = x.nid; e->x = x.x; e->y = x.y; e->room = s.room; e->hx = x.x; e->hy = x.y; }
    e->gx = x.x; e->gy = x.y; e->z = x.z; e->state = x.st; e->t = x.t; e->dir = x.dir; e->flash = x.fl ? 0.1 : 0; e->vx = x.vx; e->vy = x.vy; e->inv = x.inv != 0; e->type = x.type;
    ents.push_back(std::move(e));
  }
  picks.clear(); for (auto& k : sp) picks.push_back(std::make_unique<Pick>(k));
  if (hasD) { dlg = true; dl = { dln }; di = 0; dchars = dn; dChoices = dch; dSel = dsel; dChoice = nullptr; }
  else dlg = false;
  if (hasT) { toastS = ts; toastT = tt; }
  for (auto& f : fx) {
    RBuf fr(f); int k = fr.u8();
    if (k == 's') { int ty = fr.u8(); double a = fr.f32(); if (!fr.bad) sfx0(ty, a); }
    else if (k == 'b') { int kind = fr.u8(); double x = fr.f32(), y = fr.f32(); int n = fr.u8(); uint32_t col = (uint32_t)fr.i32(); if (!fr.bad) burst0(kind, x, y, n, col); }
    else if (k == 'p') { double x = fr.f32(), y = fr.f32(); if (!fr.bad) poof0(x, y); }
  }
}
void Game::guestBuild(const Snap& s) {
  double x = s.hasB ? s.b[0] : s.a[0], y = s.hasB ? s.b[1] : s.a[1];
  int k = s.k;
  if (k == MAP_OVER) enterOverworld(x, y);
  else if (k == MAP_DUNGEON) enterDungeon();
  else if (k == MAP_INTERIOR) enterInterior(s.i, s.rr[0], s.rr[1]);
  else if (k == MAP_SNOW) enterSnow(x, y);
  else if (k == MAP_DUNGEON2) enterIceTemple();
  else if (k == MAP_CAVE) enterCave(s.cv);
  else if (k == MAP_SEA) enterSea(x, y);
  else if (k == MAP_DUNGEON3) enterPalace();
  else if (k == MAP_SKY) enterSky(x, y);
  else if (k == MAP_DUNGEON4) enterTower();
  else if (k == MAP_MIRROR) enterMirror();
  else if (k == MAP_GAMEISLE) enterGameIsle();
  ents.clear(); picks.clear(); dlg = false;
  px = x; py = y; gTp = s.tp;
  camX = clampf(x - VW / 2.0, -400, map.W * 16); camY = clampf(y - VH / 2.0, -200, map.H * 16);
}
void Game::guestUpdate(double dt) {
  time += dt;
  if (toastT > 0) toastT -= dt;
  if (itemShowT > 0) itemShowT -= dt;
  if (fadeState) { fade = 0; fadeState = 0; fadeCb = nullptr; }
  Press& I = inp.pressed;
  if (state == S_PLAY) {
    if (I.pause) { guestMenu = !guestMenu; menuSel = 0; sfx(SFX_SELECT); }
    else if (guestMenu) { if (menuNav(3)) guestMenuChoose(menuSel); }
    else if (dlg) { if (I.act || I.attack || I.confirm) netPress("act"); }
    else if (mg) { if (I.up) netPress("up"); if (I.down) netPress("down"); if (I.left) netPress("left"); if (I.right) netPress("right"); if (I.act || I.attack || I.confirm) netPress("act"); if (I.item) netPress("item"); }
    else if (!gDead && !hostPaused) guestMove(dt, I);
    if (I.log && !dlg) questLog = !questLog;
  }
  // yumuşak geçişler
  double k = std::min(1.0, dt * 12);
  for (auto& e : ents) { e->x += (e->gx - e->x) * k; e->y += (e->gy - e->y) * k; }
  for (auto& q : pp) if (q) { q->px += (q->gx - q->px) * k; q->py += (q->gy - q->py) * k; }
  if (invT > 0) invT -= dt;
  for (auto& n : npcs) n->t += dt;
  updateParticles(dt);
  updateCamera(dt);
  // girdiyi ev sahibine gönder (saniyede 20 kez)
  gAcc += dt;
  if (gAcc >= 0.05 && net) {
    gAcc = 0;
    WBuf w; w.u8('i'); w.f32(px); w.f32(py); w.u8(pdir); w.u8(moving); w.f32(animT); w.u8(gPress); w.i32(gTp);
    net->send(w.b);
    gPress = 0;
  }
}
// misafirin kendi hareketi (çarpışma yerel haritayla); saldırı ve etkileşim ev sahibine gider
void Game::guestMove(double dt, Press& I) {
  WorldMap& m = map;
  if (freezeT > 0) freezeT -= dt;
  double mx = inp.ax, my = inp.ay, ml = std::hypot(mx, my);
  if (ml < 0.18) { mx = my = 0; ml = 0; }
  bool onIce = m.get((int)std::trunc(px / 16), (int)std::trunc((py - 3) / 16)) == T_ICE;
  double tvx = 0, tvy = 0;
  if (ml > 0 && attackT <= 0) {
    double dmx = std::fabs(mx) > 0.38 * ml ? sgn(mx) : 0, dmy = std::fabs(my) > 0.38 * ml ? sgn(my) : 0;
    if (dmy != 0 && dmx == 0) pdir = dmy > 0 ? 0 : 1; else if (dmx != 0) pdir = dmx < 0 ? 2 : 3;
    double sp = 78 * clampf((ml - 0.18) / 0.45 + 0.35, 0.35, 1) * (freezeT > 0 ? 0.5 : 1);
    tvx = mx / ml * sp; tvy = my / ml * sp;
  }
  if (onIce) { double kk = std::min(1.0, dt * (ml > 0 ? 1.7 : 0.6)); pvx += (tvx - pvx) * kk; pvy += (tvy - pvy) * kk; } else { pvx = tvx; pvy = tvy; }
  double spd = std::hypot(pvx, pvy);
  moving = spd > 4 && attackT <= 0;
  if (spd > 0.5) { movePlayer(pvx * dt, 0); movePlayer(0, pvy * dt); animT += dt * std::min(1.0, spd / 78); }
  windStep(dt, px, py);
  if (attackT > 0) attackT -= dt;
  if (I.attack && swordLv > 0 && attackT <= 0) { attackT = 0.24; sfx0(SFX_SWING, 1); netPress("attack"); }
  if (I.act) netPress("act");
  if (I.item) netPress("item");
}
void Game::guestMenuChoose(int i) {
  if (i == 0) guestMenu = false;
  else if (i == 1) { if (au) au->muted = !au->muted; storeSet("orman_ses", au && au->muted ? "0" : "1"); }
  else netLost();
}
// misafir ekranı üstüne yazılar, oda kodu kutusu
void Game::render2() {
  if (netRole == "guest" && gKey.size() && state == S_PLAY) {
    if (hostPaused) text("Arkadaşın oyunu duraklattı", VW / 2.0, 52, 0.4, hexc(0xf8e8c0), 1, true);
    if (gDead) text(string(P2_NAME) + " bayıldı... birazdan döneceksin", VW / 2.0, 70, 0.34, hexc(0xff9090), 1);
    if (guestMenu) {
      g->rect(0, 0, W, H, rgba(0, 0, 0, 0.5));
      menu({ "Devam Et", au && au->muted ? "Ses: Kapalı" : "Ses: Açık", "Odadan Ayrıl" }, 66, 20, [this](int i) { guestMenuChoose(i); });
    }
  }
  if (joinOpen) joinBox();
}
// oda kodu kutusu: klavyeyle yazılır ya da harflere dokunulur
void Game::joinBox() {
  hits.clear();
  g->rect(0, 0, W, H, rgba(8, 6, 16, 0.75));
  double w = std::min(VW - 20.0, 300.0), x0 = (VW - w) / 2, y0 = 10, h = VH - 20;
  panel(x0, y0, w, h);
  text("Arkadaşının oda kodunu yaz:", VW / 2.0, y0 + 6, 0.34, hexc(0xf8d878), 1, true);
  string shown; for (int i = 0; i < 5; i++) { shown += i < (int)joinCode.size() ? joinCode.substr(i, 1) : string("_"); if (i < 4) shown += " "; }
  text(shown, VW / 2.0, y0 + 20, 0.6, hexc(0xffffff), 1, true);
  // harf düğmeleri
  int cols = 7; double bw = (w - 16) / cols, bh = 17, gy = y0 + 44;
  for (int i = 0; i < 21; i++) {
    double bx = x0 + 8 + (i % cols) * bw, by = gy + (i / cols) * (bh + 3);
    rectV(bx + 1, by, bw - 2, bh, rgba(59, 53, 82, 1));
    string L1(1, CODE_LETTERS[i]);
    text(L1, bx + bw / 2, by + 3, 0.38, hexc(0xffffff), 1, true);
    char c = CODE_LETTERS[i];
    hit(bx, by, bw, bh, [this, c] { if (joinCode.size() < 5) joinCode += c; sfx(SFX_SELECT); });
  }
  double ry = gy + 3 * (bh + 3) + 4, b3 = (w - 16) / 3;
  const char* labs[3] = { "Sil", "Katıl", "Vazgeç" };
  for (int i = 0; i < 3; i++) {
    double bx = x0 + 8 + i * b3;
    rectV(bx + 2, ry, b3 - 4, 18, i == 1 ? rgba(46, 125, 50, 1) : rgba(59, 53, 82, 1));
    text(labs[i], bx + b3 / 2, ry + 3.5, 0.36, hexc(0xffffff), 1, true);
    hit(bx, ry, b3, 18, [this, i] { joinKey(i == 0 ? 8 : i == 1 ? 13 : 27); });
  }
}
// oda kodu kutusuna tuş: harf, 8 = sil, 13 = katıl, 27 = vazgeç
void Game::joinKey(int k) {
  if (k == 8) { if (joinCode.size()) joinCode.pop_back(); return; }
  if (k == 27) { joinOpen = false; return; }
  if (k == 13) { if (joinCode.size() == 5) { joinOpen = false; netJoin(joinCode); } return; }
  if (k >= 'a' && k <= 'z') k -= 32;
  if (k >= 'A' && k <= 'Z' && joinCode.size() < 5) joinCode += (char)k;
}
