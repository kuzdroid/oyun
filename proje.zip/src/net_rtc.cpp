// ORMANIN KALBİ - online: ücretsiz PeerJS sinyal servisi (0.peerjs.com) + WebRTC veri kanalı (libdatachannel)
// Oda kuran bu kimlikle servise kaydolur; katılan teklif (OFFER) gönderir, cevap (ANSWER) ve ICE adayları servis üzerinden gelir.
// Sonra iki cihaz doğrudan (gerekirse ücretsiz PeerJS TURN aktarıcısıyla) bağlanır; oyun verisi sunucudan geçmez.
#include "net.h"
#include <rtc/rtc.hpp>
#include <nlohmann/json.hpp>
#include <mutex>
#include <deque>
#include <random>
#include <chrono>
#include <thread>
#include <atomic>

using json = nlohmann::json;

class RtcTransport : public NetTransport {
  std::mutex mu; std::deque<NetEvent> q;
  std::shared_ptr<rtc::WebSocket> ws; std::shared_ptr<rtc::PeerConnection> pc; std::shared_ptr<rtc::DataChannel> dc;
  std::string myId, peerId, connId; bool isHost = false;
  std::atomic<bool> alive{ false }; std::thread beat;

  void push(NetEvent::Kind k, std::string d = "") { std::lock_guard<std::mutex> l(mu); q.push_back({ k, std::move(d) }); }
  static std::string rnd(int n) {
    static std::mt19937 g((unsigned)std::chrono::steady_clock::now().time_since_epoch().count());
    const char* a = "abcdefghijklmnopqrstuvwxyz0123456789"; std::string s;
    for (int i = 0; i < n; i++) s += a[g() % 36];
    return s;
  }
  void sendSig(const json& j) { try { if (ws && ws->isOpen()) ws->send(j.dump()); } catch (...) {} }
  rtc::Configuration config() {
    rtc::Configuration c;
    c.iceServers.emplace_back("stun:stun.l.google.com:19302");
    c.iceServers.emplace_back("stun:stun.cloudflare.com:3478");
    c.iceServers.emplace_back("turn:peerjs:peerjsp@eu-0.turn.peerjs.com:3478");
    c.iceServers.emplace_back("turn:peerjs:peerjsp@us-0.turn.peerjs.com:3478");
    return c;
  }
  void attachDc(std::shared_ptr<rtc::DataChannel> d) {
    dc = d;
    dc->onOpen([this] { push(NetEvent::PEER); });
    dc->onClosed([this] { push(NetEvent::CLOSE); });
    dc->onMessage([this](rtc::message_variant m) {
      if (auto b = std::get_if<rtc::binary>(&m)) push(NetEvent::DATA, std::string((const char*)b->data(), b->size()));
      else if (auto s = std::get_if<std::string>(&m)) push(NetEvent::DATA, *s);
    });
  }
  void makePc() {
    pc = std::make_shared<rtc::PeerConnection>(config());
    pc->onLocalDescription([this](rtc::Description d) {
      json p = { { "sdp", { { "type", d.typeString() }, { "sdp", std::string(d) } } }, { "type", "data" }, { "connectionId", connId }, { "browser", "ormaninkalbi" },
        { "label", connId }, { "reliable", true }, { "serialization", "binary" } };
      sendSig({ { "type", d.type() == rtc::Description::Type::Offer ? "OFFER" : "ANSWER" }, { "payload", p }, { "dst", peerId } });
    });
    pc->onLocalCandidate([this](rtc::Candidate c) {
      json p = { { "candidate", { { "candidate", std::string(c) }, { "sdpMid", c.mid() }, { "sdpMLineIndex", 0 } } }, { "type", "data" }, { "connectionId", connId } };
      sendSig({ { "type", "CANDIDATE" }, { "payload", p }, { "dst", peerId } });
    });
    pc->onStateChange([this](rtc::PeerConnection::State s) {
      if (s == rtc::PeerConnection::State::Failed) push(NetEvent::ERR, "baglanti");
      if (s == rtc::PeerConnection::State::Closed && dc) push(NetEvent::CLOSE);
    });
    pc->onDataChannel([this](std::shared_ptr<rtc::DataChannel> d) { if (!dc) attachDc(d); });
  }
  void onSignal(const std::string& txt) {
    json m; try { m = json::parse(txt); } catch (...) { return; }
    std::string t = m.value("type", "");
    if (t == "OPEN") {
      push(NetEvent::OPEN);
      if (!isHost) {   // katılan: teklif hazırla
        connId = "dc_" + rnd(10); makePc();
        rtc::DataChannelInit init; init.reliability.unordered = false;
        attachDc(pc->createDataChannel(connId, init));
      }
    } else if (t == "ID-TAKEN") push(NetEvent::ERR, "unavailable-id");
    else if (t == "ERROR") push(NetEvent::ERR, "server-error");
    else if (t == "EXPIRE" || t == "LEAVE") { if (!dc || !dc->isOpen()) push(NetEvent::ERR, "peer-unavailable"); else push(NetEvent::CLOSE); }
    else if (t == "OFFER" && isHost) {
      if (pc) return;   // oda dolu: yalnızca bir arkadaş
      peerId = m.value("src", ""); auto& p = m["payload"]; connId = p.value("connectionId", "dc");
      makePc();
      pc->setRemoteDescription(rtc::Description(p["sdp"].value("sdp", ""), p["sdp"].value("type", "offer")));
    } else if (t == "ANSWER" && pc) {
      auto& p = m["payload"]; pc->setRemoteDescription(rtc::Description(p["sdp"].value("sdp", ""), p["sdp"].value("type", "answer")));
    } else if (t == "CANDIDATE" && pc) {
      auto& c = m["payload"]["candidate"];
      try { pc->addRemoteCandidate(rtc::Candidate(c.value("candidate", ""), c.value("sdpMid", "0"))); } catch (...) {}
    }
  }
  bool start(const std::string& id) {
    close();
    myId = id; alive = true;
    std::string url = "wss://0.peerjs.com:443/peerjs?key=peerjs&id=" + id + "&token=" + rnd(10) + "&version=1.5.4";
    try {
      ws = std::make_shared<rtc::WebSocket>();
      ws->onMessage([this](rtc::message_variant m) { if (auto s = std::get_if<std::string>(&m)) onSignal(*s); });
      ws->onError([this](std::string e) { push(NetEvent::ERR, "server"); });
      ws->onClosed([this] { if (!dc || !dc->isOpen()) push(NetEvent::ERR, "server"); });
      ws->open(url);
    } catch (...) { return false; }
    // servis bağlantısı canlı kalsın
    beat = std::thread([this] { int k = 0; while (alive) { std::this_thread::sleep_for(std::chrono::milliseconds(250)); if (++k % 20 == 0) sendSig({ { "type", "HEARTBEAT" } }); } });
    return true;
  }
 public:
  RtcTransport() { rtc::InitLogger(rtc::LogLevel::None); }
  ~RtcTransport() override { close(); }
  bool host(const std::string& id) override { isHost = true; peerId.clear(); return start(id); }
  bool join(const std::string& id) override { isHost = false; peerId = id; return start("ormanin-kalbi-" + rnd(12)); }
  void send(const std::string& b) override {
    try { if (dc && dc->isOpen() && dc->bufferedAmount() < 256 * 1024) dc->send((const std::byte*)b.data(), b.size()); } catch (...) {}
  }
  bool poll(NetEvent& ev) override { std::lock_guard<std::mutex> l(mu); if (q.empty()) return false; ev = std::move(q.front()); q.pop_front(); return true; }
  void close() override {
    alive = false; if (beat.joinable()) beat.join();
    try { if (dc) dc->close(); } catch (...) {}
    try { if (pc) pc->close(); } catch (...) {}
    try { if (ws) ws->close(); } catch (...) {}
    dc.reset(); pc.reset(); ws.reset();
    std::lock_guard<std::mutex> l(mu); q.clear();
  }
};
NetTransport* makeTransport() { return new RtcTransport(); }
