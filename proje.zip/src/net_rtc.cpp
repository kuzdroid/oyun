// ORMANIN KALBİ - online: ücretsiz PeerJS sinyal servisi (0.peerjs.com) + WebRTC veri kanalı (libdatachannel)
// Oda kuran bu kimlikle servise kaydolur; katılan teklif (OFFER) gönderir, cevap (ANSWER) ve ICE adayları servis üzerinden gelir.
// Sonra cihazlar doğrudan (gerekirse ücretsiz PeerJS TURN aktarıcısıyla) bağlanır; oyun verisi sunucudan geçmez.
// Oda sahibi en fazla 3 misafir kabul eder (toplam 4 kişi): 0. yuva maceradaki arkadaş, 1-2. yuvalar okey masası için.
#include "net.h"
#include <rtc/rtc.hpp>
#include <nlohmann/json.hpp>
#include <mutex>
#include <deque>
#include <random>
#include <chrono>
#include <thread>
#include <atomic>
#if defined(__ANDROID__) || defined(__APPLE__)
#include "kokler.inc"
#endif

using json = nlohmann::json;
static const int MAXP = 3;

class RtcTransport : public NetTransport {
  std::mutex mu; std::deque<NetEvent> q;
  std::shared_ptr<rtc::WebSocket> ws;
  struct Peer { std::string id, connId; std::shared_ptr<rtc::PeerConnection> pc; std::shared_ptr<rtc::DataChannel> dc; };
  Peer peers[MAXP];   // misafirde yalnızca peers[0] (oda sahibi) kullanılır
  std::string myId, hostId; bool isHost = false;
  std::atomic<bool> alive{ false }; std::thread beat;

  void push(NetEvent::Kind k, std::string d = "", int who = 0) { std::lock_guard<std::mutex> l(mu); q.push_back({ k, std::move(d), who }); }
  static std::string rnd(int n) {
    static std::mt19937 g((unsigned)std::chrono::steady_clock::now().time_since_epoch().count());
    const char* a = "abcdefghijklmnopqrstuvwxyz0123456789"; std::string s;
    for (int i = 0; i < n; i++) s += a[g() % 36];
    return s;
  }
  void sendSig(const json& j) { try { if (ws && ws->isOpen()) ws->send(j.dump()); } catch (...) {} }
  rtc::Configuration config() {
    rtc::Configuration c;
    c.iceServers.emplace_back("stun:stun.l.google.com:19302");
    c.iceServers.emplace_back("stun:stun.cloudflare.com:3478");
    c.iceServers.emplace_back("turn:peerjs:peerjsp@eu-0.turn.peerjs.com:3478");
    c.iceServers.emplace_back("turn:peerjs:peerjsp@us-0.turn.peerjs.com:3478");
    return c;
  }
  void attachDc(int i, std::shared_ptr<rtc::DataChannel> d) {
    peers[i].dc = d;
    d->onOpen([this, i] { push(NetEvent::PEER, "", i); });
    d->onClosed([this, i] { push(NetEvent::CLOSE, "", i); });
    d->onMessage([this, i](rtc::message_variant m) {
      if (auto b = std::get_if<rtc::binary>(&m)) push(NetEvent::DATA, std::string((const char*)b->data(), b->size()), i);
      else if (auto s = std::get_if<std::string>(&m)) push(NetEvent::DATA, *s, i);
    });
  }
  void makePc(int i) {
    Peer& P = peers[i];
    P.pc = std::make_shared<rtc::PeerConnection>(config());
    P.pc->onLocalDescription([this, i](rtc::Description d) {
      Peer& P = peers[i];
      json p = { { "sdp", { { "type", d.typeString() }, { "sdp", std::string(d) } } }, { "type", "data" }, { "connectionId", P.connId }, { "browser", "ormaninkalbi" },
        { "label", P.connId }, { "reliable", true }, { "serialization", "binary" } };
      sendSig({ { "type", d.type() == rtc::Description::Type::Offer ? "OFFER" : "ANSWER" }, { "payload", p }, { "dst", P.id } });
    });
    P.pc->onLocalCandidate([this, i](rtc::Candidate c) {
      Peer& P = peers[i];
      json p = { { "candidate", { { "candidate", std::string(c) }, { "sdpMid", c.mid() }, { "sdpMLineIndex", 0 } } }, { "type", "data" }, { "connectionId", P.connId } };
      sendSig({ { "type", "CANDIDATE" }, { "payload", p }, { "dst", P.id } });
    });
    P.pc->onStateChange([this, i](rtc::PeerConnection::State s) {
      if (s == rtc::PeerConnection::State::Failed) push(NetEvent::ERR, "baglanti", i);
      if (s == rtc::PeerConnection::State::Closed && peers[i].dc) push(NetEvent::CLOSE, "", i);
    });
    P.pc->onDataChannel([this, i](std::shared_ptr<rtc::DataChannel> d) { if (!peers[i].dc) attachDc(i, d); });
  }
  int slotOf(const std::string& src) { for (int i = 0; i < MAXP; i++) if (peers[i].pc && peers[i].id == src) return i; return -1; }
  void onSignal(const std::string& txt) {
    json m; try { m = json::parse(txt); } catch (...) { return; }
    std::string t = m.value("type", ""), src = m.value("src", "");
    if (t == "OPEN") {
      push(NetEvent::OPEN);
      if (!isHost) {   // katılan: teklif hazırla
        Peer& P = peers[0]; P.id = hostId; P.connId = "dc_" + rnd(10); makePc(0);
        rtc::DataChannelInit init; init.reliability.unordered = false;
        attachDc(0, P.pc->createDataChannel(P.connId, init));
      }
    } else if (t == "ID-TAKEN") push(NetEvent::ERR, "unavailable-id");
    else if (t == "ERROR") push(NetEvent::ERR, "server-error");
    else if (t == "EXPIRE" || t == "LEAVE") {
      if (!isHost) { if (!peers[0].dc || !peers[0].dc->isOpen()) push(NetEvent::ERR, "peer-unavailable"); else push(NetEvent::CLOSE); }
      else { int i = slotOf(src); if (i >= 0) push(NetEvent::CLOSE, "", i); }
    } else if (t == "OFFER" && isHost) {
      if (slotOf(src) >= 0) return;
      int i = -1; for (int k = 0; k < MAXP; k++) if (!peers[k].pc) { i = k; break; }
      if (i < 0) return;   // oda dolu (4 kişi)
      Peer& P = peers[i]; auto& p = m["payload"];
      P.id = src; P.connId = p.value("connectionId", "dc"); makePc(i);
      P.pc->setRemoteDescription(rtc::Description(p["sdp"].value("sdp", ""), p["sdp"].value("type", "offer")));
    } else if (t == "ANSWER") {
      int i = isHost ? slotOf(src) : 0; if (i < 0 || !peers[i].pc) return;
      auto& p = m["payload"]; peers[i].pc->setRemoteDescription(rtc::Description(p["sdp"].value("sdp", ""), p["sdp"].value("type", "answer")));
    } else if (t == "CANDIDATE") {
      int i = isHost ? slotOf(src) : 0; if (i < 0 || !peers[i].pc) return;
      auto& c = m["payload"]["candidate"];
      try { peers[i].pc->addRemoteCandidate(rtc::Candidate(c.value("candidate", ""), c.value("sdpMid", "0"))); } catch (...) {}
    }
  }
  bool anyOpen() { for (auto& P : peers) if (P.dc && P.dc->isOpen()) return true; return false; }
  bool start(const std::string& id) {
    close();
    myId = id; alive = true;
    std::string url = "wss://0.peerjs.com:443/peerjs?key=peerjs&id=" + id + "&token=" + rnd(10) + "&version=1.5.4";
    try {
      rtc::WebSocket::Configuration wc;
#if defined(__ANDROID__) || defined(__APPLE__)
      // telefonda (mbedTLS) sistem sertifika deposu yok: sunucuyu oyuna gömülü kök sertifikalarla doğrula
      wc.caCertificatePemFile = std::string(ROOT_CERTS);
#endif
      ws = std::make_shared<rtc::WebSocket>(wc);
      ws->onMessage([this](rtc::message_variant m) { if (auto s = std::get_if<std::string>(&m)) onSignal(*s); });
      ws->onError([this](std::string e) { push(NetEvent::ERR, "server"); });
      ws->onClosed([this] { if (!anyOpen()) push(NetEvent::ERR, "server"); });
      ws->open(url);
    } catch (...) { return false; }
    // servis bağlantısı canlı kalsın (oda sahibi yeni misafirleri bekleyebilsin)
    beat = std::thread([this] { int k = 0; while (alive) { std::this_thread::sleep_for(std::chrono::milliseconds(250)); if (++k % 20 == 0) sendSig({ { "type", "HEARTBEAT" } }); } });
    return true;
  }
  void sendDc(Peer& P, const std::string& b) { try { if (P.dc && P.dc->isOpen() && P.dc->bufferedAmount() < 256 * 1024) P.dc->send((const std::byte*)b.data(), b.size()); } catch (...) {} }
 public:
  RtcTransport() { rtc::InitLogger(rtc::LogLevel::None); }
  ~RtcTransport() override { close(); }
  bool host(const std::string& id) override { isHost = true; hostId.clear(); return start(id); }
  bool join(const std::string& id) override { isHost = false; hostId = id; return start("ormanin-kalbi-" + rnd(12)); }
  void send(const std::string& b) override { for (auto& P : peers) sendDc(P, b); }
  void sendTo(int who, const std::string& b) override { if (who >= 0 && who < MAXP) sendDc(peers[who], b); }
  bool poll(NetEvent& ev) override { std::lock_guard<std::mutex> l(mu); if (q.empty()) return false; ev = std::move(q.front()); q.pop_front(); return true; }
  void close() override {
    alive = false; if (beat.joinable()) beat.join();
    for (auto& P : peers) {
      try { if (P.dc) P.dc->close(); } catch (...) {}
      try { if (P.pc) P.pc->close(); } catch (...) {}
      P.dc.reset(); P.pc.reset(); P.id.clear();
    }
    try { if (ws) ws->close(); } catch (...) {}
    ws.reset();
    std::lock_guard<std::mutex> l(mu); q.clear();
  }
  // bir misafir ayrılınca yuvası yeniden kullanılabilsin
  void drop(int i) override { if (i < 0 || i >= MAXP) return; Peer& P = peers[i]; try { if (P.dc) P.dc->close(); if (P.pc) P.pc->close(); } catch (...) {} P.dc.reset(); P.pc.reset(); P.id.clear(); }
};
NetTransport* makeTransport() { return new RtcTransport(); }
