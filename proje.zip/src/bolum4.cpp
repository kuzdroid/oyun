// ORMANIN KALBİ - 4. Bölüm: Göklerdeki Kule
// Köy kuyusundan göğe çıkış, gök adaları (uzun harita), Rüzgârköy, rüzgâr akıntıları, Fırtına Kartalı, Rüzgâr Borusu,
// bulut köprüleri, 15 odalı Göklerdeki Kule, Sis Efendisi (üç evreli final boss), babanın kurtuluşu ve oyunun sonu.
// yan görevler: Altın Tüyler, Yavru Kuşlar, Fırtına Ruhları. Gizli boss (Ayna Şövalyesi) ayna.cpp'de.
#include "game.h"

void dgDoorV(WorldMap& m, int rx, int ry, int type, int lock);
void dgDoorH(WorldMap& m, int rx, int ry, int type, int lock);
constexpr int G4_LANDED = 4096;
// bulut köprüleri: [başlangıç x, y, bitiş x, y]; 3. köprü gizli (Ayna Adası'na)
static const int BRIDGES[4][4] = { {54, 29, 66, 28}, {78, 26, 90, 23}, {127, 32, 137, 28}, {34, 21, 23, 12} };
static const int STONES[4][2] = { {52, 25}, {75, 23}, {122, 28}, {36, 22} };
static const int FEATHER_POS[6][2] = { {49, 7}, {19, 10}, {83, 45}, {103, 7}, {116, 35}, {142, 34} };
static const double NEST_HOME[2] = { 44 * 16, 7 * 16 + 8 };
// kümes (yavru kuşlar): içi
static const double PEN[4] = { 44 * 16, 34 * 16 + 4, 47 * 16, 37 * 16 };
static const double LIGHT_HOUSE4[2] = { 26, 14 }, LIGHT_BEAM[2] = { 70, 30 }, LIGHT_TOWER[2] = { 80, 50 }, LIGHT_STONE[2] = { 34, 20 }, LIGHT_PED[2] = { 30, 16 };

// ---------------- gök adaları haritası ----------------
static void isle(WorldMap& m, double cx, double cy, double rx, double ry, int inner) {
  for (int y = 0; y < m.H; y++) for (int x = 0; x < m.W; x++) {
    double dx = (x - cx) / rx, dy = (y - cy) / ry, wob = 0.08 * std::sin(x * 0.8 + y * 1.3);
    if (dx * dx + dy * dy < 1 + wob) m.set(x, y, inner);
  }
}
// bulut yolu: yalnızca boşluğu (ve istenirse ada kenarını) değiştirir, adaların içine dokunmaz
static void skyPath(WorldMap& m, int x0, int y0, int x1, int y1, int v, bool overEdge) {
  int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0));
  for (int i = 0; i <= n; i++) {
    int x = x0 + (int)std::trunc((double)(x1 - x0) * i / std::max(1, n)), y = y0 + (int)std::trunc((double)(y1 - y0) * i / std::max(1, n));
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
      int t = m.get(x + dx, y + dy);
      if (t == T_VOID || t == T_CLOUDGAP || t == T_CLOUD || isWindT(t) || (overEdge && t == T_ISLEEDGE)) m.set(x + dx, y + dy, v);
    }
  }
}
void buildSky(WorldMap& m) {
  m.init(SKY_W, SKY_H, MAP_SKY, T_VOID);
  isle(m, 12, 28, 8, 6, T_SKYGRASS);     // Yıldız İskelesi
  isle(m, 40, 29, 15, 10, T_SKYGRASS);   // Rüzgârköy
  isle(m, 44, 7, 12, 5.5, T_SKYGRASS);   // Kartal Yuvası
  isle(m, 21, 10, 5, 3, T_SKYGRASS);     // Ayna Adası (gizli)
  isle(m, 72, 28, 7, 6, T_SKYGRASS);     // Bulut Bahçesi
  isle(m, 80, 44, 6, 4, T_SKYGRASS);     // Güney Adacığı
  isle(m, 97, 22, 8, 6, T_SKYGRASS);     // Fırtına Boğazı
  isle(m, 100, 7, 6, 3.5, T_SKYGRASS);   // Kuzey Adacığı
  isle(m, 120, 32, 8, 7, T_SKYGRASS);    // Yıldırım Adası
  isle(m, 150, 26, 15, 13, T_SKYGRASS);  // Kule Adası
  isle(m, 40, 29, 6, 4, T_MARBLE);       // köy meydanı
  for (int x = 27; x <= 53; x++) for (int y = 28; y <= 30; y++) if (m.get(x, y) == T_SKYGRASS) m.set(x, y, T_MARBLE);
  for (int y = 20; y <= 28; y++) for (int x = 39; x <= 41; x++) if (m.get(x, y) == T_SKYGRASS) m.set(x, y, T_MARBLE);
  for (int y = 30; y <= 38; y++) for (int x = 146; x <= 152; x++) if (m.get(x, y) == T_SKYGRASS && std::abs(x - 149) <= 1) m.set(x, y, T_MARBLE);
  // ada kenarları: altı boşluk olan kara kareleri uçurum olur
  for (int y = 0; y < SKY_H - 1; y++) for (int x = 0; x < SKY_W; x++) {
    int t = m.get(x, y); if ((t == T_SKYGRASS || t == T_MARBLE) && m.get(x, y + 1) == T_VOID) m.set(x, y, T_ISLEEDGE);
  }
  // kalıcı bulut yolları ve rüzgâr akıntıları
  skyPath(m, 19, 28, 26, 29, T_CLOUD, true);
  skyPath(m, 44, 20, 44, 11, T_WIND_D, true);                     // köy -> Kartal Yuvası (rüzgâr aşağı iter)
  for (int y = 11; y <= 20; y++) if (y % 4 == 0) for (int x = 43; x <= 45; x++) if (isWindT(m.get(x, y))) m.set(x, y, T_CLOUD);
  skyPath(m, 72, 32, 79, 41, T_CLOUD, true);                       // Bulut Bahçesi -> Güney Adacığı
  skyPath(m, 98, 17, 100, 9, T_WIND_D, true);                      // Boğaz -> Kuzey Adacığı
  for (int y = 9; y <= 17; y++) if (y % 4 == 1) for (int x = 96; x <= 101; x++) if (isWindT(m.get(x, y))) m.set(x, y, T_CLOUD);
  skyPath(m, 104, 24, 113, 30, T_WIND_L, true);                    // Boğaz -> Yıldırım Adası (rüzgâr batıya iter)
  for (int x = 102; x <= 115; x++) if (x % 5 == 0) for (int y = 20; y <= 33; y++) if (isWindT(m.get(x, y))) m.set(x, y, T_CLOUD);
}
// köprüler: açılmışsa bulut, değilse soluk bulut izi (geçilmez)
void Game::skyBridges(WorldMap& m) {
  for (int g0 = 0; g0 < 4; g0++) {
    bool open = (f4 & (G4_BRIDGE0 << g0)) != 0; const int* b = BRIDGES[g0];
    skyPath(m, b[0], b[1], b[2], b[3], open ? T_CLOUD : T_CLOUDGAP, open);
  }
}
void populateSky(WorldMap& m) {
  m.add(O_STARBEAM, 11, 25, 1, 1, false);
  m.add(O_SIGN, 15, 31, 1, 1).text = "YILDIZ İSKELESİ\nIşığa dokunan yeryüzüne iner.\nDoğuda Rüzgârköy.";
  { Obj& h = m.add(O_SKYHOUSE, 30, 22, 3, 3); h.var = 0; h.text = "L"; }
  { Obj& h = m.add(O_SKYHOUSE, 46, 21, 3, 3); h.var = 1; h.text = "5"; }
  { Obj& h = m.add(O_SKYHOUSE, 31, 33, 3, 3); h.var = 2; h.text = "L"; }
  { Obj& h = m.add(O_SKYHOUSE, 48, 33, 3, 3); h.var = 0; h.text = "M"; }
  m.add(O_WINDMILL, 28, 24, 2, 2);
  m.add(O_SIGN, 37, 32, 1, 1).text = "RÜZGÂRKÖY\nKuzeyde Kartal Yuvası. Doğuda bulutların ötesinde Kule.";
  m.add(O_SIGN, 42, 21, 1, 1).text = "KARTAL YUVASI\nRüzgâr eserken sakin bulutta bekle, dinince yürü!";
  m.add(O_SIGN, 104, 21, 1, 1).text = "FIRTINA BOĞAZI\nRüzgâr batıya eser. Acele eden geri savrulur.";
  m.add(O_SIGN, 140, 26, 1, 1).text = "GÖKLERDEKİ KULE\nKalbin son parçası tepede.";
  for (auto p : { std::pair{36, 26}, {44, 26}, {35, 31}, {45, 31}, {148, 30}, {150, 30} }) m.add(O_LAMP, p.first, p.second);
  // kümes
  for (int x = 43; x <= 47; x++) { m.add(O_FENCE, x, 33); m.add(O_FENCE, x, 37); }
  for (int y = 34; y <= 36; y++) m.add(O_FENCE, 47, y);
  m.add(O_FENCE, 43, 34); m.add(O_FENCE, 43, 36);
  m.add(O_NEST, 41, 5, 3, 1, false);
  m.add(O_TOWER, 148, 17, 3, 2);
  for (int i = 0; i < 4; i++) m.add(O_CLOUDSTONE, STONES[i][0], STONES[i][1]).var = i;
  for (auto p : { std::pair{35, 21}, {37, 21}, {35, 22}, {37, 22}, {35, 23}, {36, 23}, {37, 23} }) m.add(O_CLOUDBUSH, p.first, p.second);
  m.add(O_PEDESTAL, 21, 9);
  m.add(O_CHEST, 81, 43).var = 74; m.add(O_CHEST, 100, 20).var = 75; m.add(O_CHEST, 101, 6).var = 76; m.add(O_CHEST, 140, 30).var = 77;
  Rng r(4404);
  for (int i = 0; i < 520; i++) {
    int x = I(r.range(1, SKY_W - 2)), y = I(r.range(1, SKY_H - 2));
    bool ok = true; for (int k = 0; k < 5 && ok; k++) { static const int nx[5] = { 0, 1, -1, 0, 0 }, ny[5] = { 0, 0, 0, 1, -1 }; if (m.get(x + nx[k], y + ny[k]) != T_SKYGRASS) ok = false; }
    if (!ok || !m.free(x - 1, y - 1, 3, 3)) continue;
    if (x > 24 && x < 57 && y > 18 && y < 40) continue;   // köy içi açık
    if (x > 141 && x < 158 && y > 16 && y < 40) continue;   // kule önü açık
    if (x < 21 && y > 22 && y < 34 && x > 4 && r.f() < 0.6) continue;
    bool near = false; for (auto& f : FEATHER_POS) if (std::abs(f[0] - x) <= 1 && std::abs(f[1] - y) <= 1) near = true;
    if (near) continue;
    double k = r.f();
    if (k < 0.22) m.add(O_TREE, x, y).var = 0;
    else if (k < 0.45) { Obj& o = m.add(O_FLOWER, x, y, 1, 1, false); o.var = I(r.f() * 2); }
    else if (k < 0.72) m.add(O_CLOUDBUSH, x, y);
    else if (k < 0.8) m.add(O_ROCK, x, y);
  }
}

// ---------------- kule (15 oda: 3 sütun x 5 kat) ----------------
void buildTower(WorldMap& m, std::vector<Room>& rooms) {
  m.init(RW * 3, RH * TOWER_ROWS, MAP_DUNGEON4, T_DTOP);
  rooms.clear();
  for (int r = 0; r < 3 * TOWER_ROWS; r++) {
    int ox = (r % 3) * RW, oy = (r / 3) * RH;
    for (int y = 0; y < RH; y++) for (int x = 0; x < RW; x++) m.set(ox + x, oy + y, (y == 0 || y == RH - 1 || x == 0 || x == RW - 1) ? T_DTOP : y == 1 ? T_DWALL : T_DFLOOR);
    rooms.push_back({ r % 3, r / 3, r == 9, false });
  }
  dgDoorH(m, 0, 4, T_DOOR_OPEN, 0); dgDoorH(m, 1, 4, T_DOOR_OPEN, 0); dgDoorV(m, 1, 4, T_DOOR_LOCK, 13);
  dgDoorH(m, 0, 3, T_DOOR_OPEN, 0); dgDoorH(m, 1, 3, T_DOOR_LOCK, 15); dgDoorV(m, 1, 3, T_DOOR_SHUT, 18);
  dgDoorH(m, 0, 2, T_DOOR_LOCK, 14); dgDoorH(m, 1, 2, T_DOOR_OPEN, 0); dgDoorV(m, 1, 2, T_DOOR_SHUT, 19);
  dgDoorH(m, 0, 1, T_DOOR_OPEN, 0); dgDoorH(m, 1, 1, T_DOOR_OPEN, 0); dgDoorV(m, 1, 1, T_DOOR_BOSS, 21);
  dgDoorV(m, 0, 1, T_DOOR_OPEN, 0); dgDoorV(m, 2, 1, T_DOOR_OPEN, 0);
  // giriş merdiveni ve orta halı
  for (int x = 9; x <= 10; x++) m.set(RW + x, RH * 4 + RH - 2, T_STAIRS);
  for (int ry = 1; ry < TOWER_ROWS; ry++) for (int y = 2; y < RH - (ry == 4 ? 2 : 1); y++) for (int x = 9; x <= 10; x++) if (m.get(RW + x, ry * RH + y) == T_DFLOOR) m.set(RW + x, ry * RH + y, T_CARPET);
  for (int y = 3; y < RH - 1; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, y, T_CARPET);
  m.add(O_SIGN, RW + 3, RH * 4 + 3, 1, 1).text = "Göklerdeki Kule. Beş kat, on beş oda.\nTaş bekçiler yaklaşınca uyanır.";
  // 12: taş bulmacası
  m.set(4, RH * 4 + 4, T_PLATE); m.add(O_BLOCK, 11, RH * 4 + 6).var = 0;
  m.add(O_SIGN, 16, RH * 4 + 2, 1, 1).text = "Taşı plakaya it. Kule kapısının anahtarı uyanır.";
  // 11: dört ateş bulmacası
  for (auto p : { std::pair{4, 3}, {15, 3}, {4, 8}, {15, 8} }) m.add(O_BRAZIER, RW * 2 + p.first, RH * 3 + p.second).var = 1;
  m.add(O_SIGN, RW * 2 + 17, RH * 3 + 2, 1, 1).text = "Dört ateş aynı anda yanmalı.\nAlevler çabuk söner; hızlı ol!";
  // 6: rüzgâr odası (doğuya iter)
  for (int y = 3; y <= 8; y++) for (int x = 2; x <= 17; x++) m.set(x, RH * 2 + y, x % 4 == 1 ? T_DFLOOR : T_WIND_R);
  m.add(O_CHEST, 2, RH * 2 + 5).var = 69;
  m.add(O_SIGN, 17, RH * 2 + 2, 1, 1).text = "Rüzgâr eserken düz zeminde bekle.";
  // 9: karanlık oda
  m.add(O_CHEST, 10, RH * 3 + 5).var = 67;
  // 0 ve 2: hazineler
  m.add(O_CHEST, 10, 5).var = 72; m.add(O_CHEST, RW * 2 + 10, 5).var = 73;
  // ışık kristalleri
  for (auto p : { std::pair{RW + 3, RH * 4 + 7}, {RW + 16, RH * 4 + 7}, {RW + 3, RH * 2 + 3}, {RW + 16, RH * 2 + 3}, {RW + 3, RH + 3}, {RW + 16, RH + 3},
         {RW + 3, 3}, {RW + 16, 3}, {RW * 2 + 3, RH * 4 + 3}, {3, RH + 8}, {RW * 2 + 16, RH + 8}, {3, 3}, {RW * 2 + 16, 3}, {RW * 2 + 3, RH * 2 + 8} }) m.add(O_CRYSTAL, p.first, p.second);
}

// ---------------- bölüm akışı ----------------
string Game::objective4() {
  switch (mainStep) {
    case 21: return "Bilge Nine ile konuş: Göklerdeki Kule.";
    case 22: return "Köy meydanındaki kuyuya bak.";
    case 23: return "Gök adalarında doğudaki Rüzgârköy'ü bul, Rüzgâr Ana ile konuş.";
    case 24: return "Kuzeydeki Kartal Yuvası'nda Fırtına Kartalı'nı yen.";
    case 25: return hasHorn ? "Bulut taşlarını Rüzgâr Borusu'yla öttür; köprülerle doğudaki Kule'ye ulaş." : "Rüzgâr Borusu'nu al.";
    case 26: return "Göklerdeki Kule'nin tepesine tırman.";
    case 27: return "Kuleden in; babanla birlikte Bilge Nine'ye dön.";
  }
  return "Ormanın Kalbi bütün! Dilediğin gibi gez. Bütün gizli bossları buldun mu?";
}
std::vector<string> Game::credits4() {
  int bosses = ((sec & SEC_KEMAL) ? 1 : 0) + ((sec & SEC_YCAVE) ? 1 : 0) + ((flags & F3_GCAPTAIN) ? 1 : 0) + ((f4 & G4_KNIGHT) ? 1 : 0);
  return { "SON", "", "Sis Efendisi yenildi; Göklerdeki Kule yeniden ışıdı.", "Ormanın Kalbi'nin dört parçası birleşti.",
    "Arda'nın babası eve döndü. Bilge Nine o gece hiç uyumadı.", "", "Rüzgârköy'ün değirmenleri dönüyor, Mercanköy'ün tekneleri balıkta.",
    "Ayazköy'de keçiler hâlâ inatçı. Kemal Usta hâlâ indirim yapmıyor.", fmt("Gizli bosslar: %d/4   •   Altın tüyler: %d/6", bosses, std::min(6, qc[Q_FEATHER])), "",
    "ORMANIN KALBİ", "", "Oynadığın için teşekkürler!", "Devam Et ile gökyüzüne yeniden çıkabilirsin." };
}
void Game::talkElder4() {
  int s0 = mainStep;
  if (s0 == 21) {
    say({ L("Bilge Nine", "Arda, otur evladım. Göklerdeki Kule'yi düşünmekten gözüme uyku girmedi."),
      L("Bilge Nine", "Baban yola çıkmadan önce bana bir bilmece bırakmıştı: 'Dört ışığın üçü birleşince, yıldızlar kuyudan yukarı akar.'"),
      L("Arda", "Kuyu... Meydandaki kuyu mu? Hep dibinde yıldızlar parlıyor sanırdım!"),
      L("Bilge Nine", "Belki de gerçekten parlıyordu. Üç parça yanındayken kuyuya bir bak. Ve Arda... babanı bulursan, ona söyle: annesi onu bekliyor.") },
      [this] { mainStep = 22; toast("4. BÖLÜM: GÖKLERDEKİ KULE"); saveGame(); });
    return;
  }
  if (s0 == 27) {
    mainStep = 28; f4 |= G4_HOME; saveGame();
    say({ L("Bilge Nine", "Arda! Ve... Oğlum? Oğlum, sen misin?! Yaşıyorsun!"),
      L("Baba", "Döndüm anne. Arda beni kurtardı. Bak, son parçayı da getirdi."),
      L("", "Arda dört parçayı yan yana koydu. Yeşil, mavi, kırmızı ve altın ışık birbirine kenetlendi: Ormanın Kalbi yeniden bütündü."),
      L("", "Işık yeryüzünden göğe yükseldi. Göklerdeki Kule'yi saran son sis dağıldı; Rüzgârköy'ün değirmenleri yeniden şarkı söyledi."),
      L("Bilge Nine", "Kara sis bir daha dönmeyecek. Yeşilvadi'nin Bekçisi... yok, bütün dünyanın bekçisi sensin artık."),
      L("Arda", "Bekçi olmak güzel ama... önce bir hafta uyuyacağım. Sonra da Kemal Usta'nın indirimini kullanacağım!"),
      L("Baba", "Kemal mi? İndirim mi? Ben yokken dünya çok değişmiş...") },
      [this] { fadeTo([this] { state = S_CREDITS; creditsT = 0; setMood(5); }); });
    return;
  }
  say({ L("Bilge Nine", s0 == 22 ? "Kuyu meydanın ortasında. Parçalar yanındaysa yıldızlar seni çağıracak." :
    s0 < 27 ? "Gökyüzü... Baban da o yoldan gitmişti. Kendine dikkat et, Arda." : "Oğlum evde, torunum kahraman. Bu yaşlı kadının daha ne dileği olabilir?") });
}
// kuyu: 22. adımdan sonra göğe çıkarır
bool Game::useWell() {
  if (mainStep < 22) return false;
  if (fadeState) return true;
  ask({ L("", mainStep >= 28 ? "Kuyunun dibindeki yıldızlar seni selamlıyor. Gökyüzüne yeniden çıkmak ister misin?" :
    "Kuyunun dibindeki yıldızlar kıpırdıyor. Cebindeki parçalar ısınmaya başladı. Kuyuya eğilmek ister misin?") }, { "Eğil", "Vazgeç" }, [this](int c) {
    if (c) return;
    sfx(SFX_MAGIC);
    fadeTo([this] { enterSky(12 * 16 + 8, 27 * 16 + 12); pdir = 3; });
  });
  return true;
}
void Game::enterSky(double x, double y) {
  WorldMap& m = map;
  buildSky(m); skyBridges(m); populateSky(m);
  lastF4 = f4;
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1; pvx = pvy = 0;
  markChests();
  EACH(o, m.objs) if (o.type == O_CLOUDSTONE && (f4 & (G4_BRIDGE0 << o.var))) o.var |= 0x10;
  if (f4 & G4_SECRET) EACH(o, m.objs) if (o.type == O_CLOUDBUSH && o.alive && std::abs(o.tx - 36) <= 1 && std::abs(o.ty - 22) <= 1) m.removeObj(o);
  px = x; py = y;
  placeNPCs();
  for (int i = 0; i < 6; i++) if (!((feathers >> i) & 1)) addPick(P_FEATHER, FEATHER_POS[i][0] * 16 + 8, FEATHER_POS[i][1] * 16 + 12, 0, i);
  // yavru kuşlar
  static const int BL[4][2] = { {14, 25}, {21, 31}, {34, 27}, {52, 31} };
  for (int i = 0; i < 4; i++) {
    Ent& b = qs[Q_BIRDS] == 2 ? spawn(E_BIRDLING, (44.5 + (i % 2) * 1.5) * 16, (34.6 + (i / 2)) * 16) : spawn(E_BIRDLING, BL[i][0] * 16 + 8, BL[i][1] * 16 + 8);
    b.state = qs[Q_BIRDS] == 2 ? 3 : 0;
  }
  if (mainStep < 28) {
    scatterEnemies(E_CLOUDLING, 3, 65, 23, 79, 33); scatterEnemies(E_SKYBIRD, 2, 62, 20, 82, 36);
    scatterEnemies(E_CLOUDLING, 2, 75, 41, 86, 47);
    scatterEnemies(E_CLOUDLING, 3, 90, 17, 105, 27); scatterEnemies(E_SKYBIRD, 2, 88, 14, 108, 30);
    scatterEnemies(E_SKYBIRD, 2, 95, 4, 106, 10);
    scatterEnemies(E_CLOUDLING, 3, 113, 26, 127, 38); scatterEnemies(E_GARGOYLE, 1, 114, 27, 126, 37);
    for (auto p : { std::pair{144, 24}, {155, 24}, {144, 31}, {155, 31} }) { Ent& gg = spawn(E_GARGOYLE, p.first * 16 + 8, p.second * 16 + 8); gg.hx = gg.x; gg.hy = gg.y; }
    scatterEnemies(E_SKYBIRD, 2, 136, 14, 164, 38);
    if (night()) spawnNight4();
  }
  if (mainStep >= 24 && !(f4 & G4_EAGLE)) { Ent& k = spawn(E_EAGLE, NEST_HOME[0], NEST_HOME[1]); k.hx = k.x; k.hy = k.y; k.z = 46; }
  camX = clampf(px - VW / 2.0, 0, m.W * 16 - VW); camY = clampf(py - VH / 2.0, 0, m.H * 16 - VH);
  if (mainStep == 22) mainStep = 23;
  if (!(f4 & G4_INTRO)) {
    f4 |= G4_INTRO;
    say({ L("", "Yıldızlar kuyudan fışkırdı ve Arda'yı bir tüy gibi havaya kaldırdı. Bulutları delip geçti..."),
      L("", "4. BÖLÜM: GÖKLERDEKİ KULE"),
      L("Arda", "Ayaklarımın altında bulut var! Uzakta, doğuda... bir kule! Ama arada koca bir boşluk var."),
      L("Arda", "Hemen doğuda bir köy görünüyor; yel değirmenleri dönüyor. Önce oraya gideyim.") });
  }
  saveGame();
}
void Game::spawnNight4() {
  if (mainStep >= 28 || map.kind != MAP_SKY) return;
  scatterEnemies(E_WISP, 2, 23, 18, 56, 40); scatterEnemies(E_WISP, 2, 64, 22, 80, 34); scatterEnemies(E_WISP, 2, 89, 16, 106, 28);
  scatterEnemies(E_WISP, 2, 112, 25, 128, 39); scatterEnemies(E_WISP, 3, 136, 14, 165, 39); scatterEnemies(E_WISP, 1, 4, 22, 20, 34);
}
void Game::enterTower() {
  WorldMap& m = map;
  buildTower(m, rooms);
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); pvx = pvy = 0;
  for (int i = 0; i < m.W * m.H; i++) { int lid = m.lockId[i]; if (lid && ((doorMask >> lid) & 1)) m.t[i] = T_DOOR_OPEN; }
  if (flags & F4_BLOCK) { EACH(o, m.objs) if (o.type == O_BLOCK) moveBlockTo(o, 4, RH * 4 + 4); addRoomChest(12, 64, 10, 4); }
  if (f4 & G4_BRAZIER) { EACH(o, m.objs) if (o.type == O_BRAZIER) o.var = 0; addRoomChest(11, 66, 10, 5); }
  static const int CLR[4][2] = { {14, 65}, {8, 68}, {3, 70}, {5, 71} };
  for (auto& c : CLR) if ((clear4 >> c[0]) & 1) addRoomChest(c[0], c[1], 10, 5);
  markChests();
  px = RW * 16 + RW * 8; py = (RH * 4 + RH - 3) * 16; pdir = 1; curRoom = -1;
  enterRoom(roomOf(px, py), true);
  camX = (curRoom % 3) * RW * 16 - (VW - RW * 16) / 2.0; camY = (curRoom / 3) * RH * 16 - (VH - RH * 16) / 2.0;
  if (mainStep < 26) mainStep = 26;
  saveGame();
}
bool Game::windOn() { return std::fmod(time, 4.2) < 2.0; }
// rüzgâr akıntısı: esintide akıntı karesindeki kahramanı iter
void Game::windStep(double dt, double& x, double& y) {
  int t = map.get((int)std::trunc(x / 16), (int)std::trunc((y - 3) / 16));
  if (!isWindT(t) || !windOn()) return;
  double sp = 104 * dt, dx = t == T_WIND_L ? -sp : t == T_WIND_R ? sp : 0, dy = t == T_WIND_U ? -sp : t == T_WIND_D ? sp : 0;
  moveBox(x, y, dx, 0, PHW, PHH); moveBox(x, y, 0, dy, PHW, PHH);
}
// kahramanları bir noktadan uzağa savur (kartal kanat çırpınca)
void Game::pushHeroes(double fx, double fy, double force) {
  double dx = px - fx, dy = py - fy, l = std::hypot(dx, dy) + 0.01;
  kx = dx / l * force; ky = dy / l * force; kT = 0.3;
  if (p2 && !p2->remote && !p2->deadT) { P2& q = *p2; double qx = q.px - fx, qy = q.py - fy, ql = std::hypot(qx, qy) + 0.01; q.kx = qx / ql * force; q.ky = qy / ql * force; q.kT = 0.3; }
}
void Game::clampRoom(Ent& e) {
  if (!isDg(map.kind) || e.room < 0) return;
  double ox = (e.room % 3) * RW * 16, oy = (e.room / 3) * RH * 16;
  e.x = clampf(e.x, ox + 24, ox + RW * 16 - 24); e.y = clampf(e.y, oy + 40, oy + RH * 16 - 20);
}
// düz giden mermi (tüy, kıvılcım, kara küre)
void Game::stepShot(Ent& e, double dt, int dm, double life) {
  e.x += e.vx * dt; e.y += e.vy * dt;
  int cx = (int)std::trunc(e.x / 16), cy = (int)std::trunc((e.y - 2) / 16), t = map.get(cx, cy);
  if (map.solid(cx, cy) && t != T_VOID && t != T_CLOUDGAP && t != T_WATER) { e.alive = false; burst(1, e.x, e.y - 4, 3, 0xd0d4e0); return; }
  if (e.t > life) e.alive = false;
  projHit(e, dm, 8);
}
void Game::blowHorn(Obj& o) {
  int g0 = o.var & 0xF;
  if (f4 & (G4_BRIDGE0 << g0)) { say({ L("", "Bulut köprüsü sapasağlam. Rüzgâr onu omzunda taşıyor.") }); return; }
  if (!hasHorn) { say({ L("", g0 == 3 ? "Yosun tutmuş eski bir bulut taşı. Tepesinde boru biçimli bir oyuk var." : "Bulut taşı. Tepesinde boru biçimli bir oyuk var; rüzgârın sesini bekliyor gibi.") }); return; }
  f4 |= G4_BRIDGE0 << g0; o.var |= 0x10;
  skyBridges(map); lastF4 = f4;
  sfx(SFX_HOWL, 0.7); sfx(SFX_MAGIC); shake = 0.3; haptic("item");
  const int* b = BRIDGES[g0];
  for (int i = 0; i < 10; i++) { double k = i / 9.0; burst(5, lerpf(b[0], b[2], k) * 16 + 8, lerpf(b[1], b[3], k) * 16 + 8, 4); }
  toast(g0 == 3 ? "Gizli bir köprü örüldü! Batıdaki küçük adaya uzanıyor..." : "Rüzgâr Borusu öttü: bulutlar köprü oldu!");
  saveGame();
}

void Game::initBolum4() {
  EXT.hp[E_EAGLE] = 30; EXT.hp[E_WISP] = 2; EXT.hp[E_SKYBIRD] = 3; EXT.hp[E_CLOUDLING] = 3; EXT.hp[E_GARGOYLE] = 5;
  EXT.hp[E_LORD] = 60; EXT.hp[E_MISTHAND] = 99;
  EXT.bossKey[MAP_DUNGEON4] = &Game::bossKey4;
  EXT.interiorMap[5] = MAP_SKY;
  SOLID_X[T_VOID] = SOLID_X[T_CLOUDGAP] = SOLID_X[T_ISLEEDGE] = true;
  EXT.harmless[E_MISTHAND] = true;
  // ---------------- harita olayları ----------------
  EXT.enter[MAP_SKY] = [this] { enterSky(40 * 16 + 8, 31 * 16 + 4); };
  EXT.enter[MAP_DUNGEON4] = [this] { enterTower(); };
  EXT.enterAt[MAP_SKY] = [this](int rx, int ry) { enterSky(rx * 16 + 8, ry * 16 + 12); };
  EXT.saveAs[MAP_SKY] = [] { return (int)MAP_SKY; };
  EXT.saveAs[MAP_DUNGEON4] = [] { return (int)MAP_DUNGEON4; };
  EXT.night[MAP_SKY] = [this] { spawnNight4(); };
  EXT.exitDg[MAP_DUNGEON4] = [this] {
    if (mainStep >= 27) {
      enterOverworld(47 * 16 + 8, 58 * 16 + 4);
      if (!(f4 & G4_LANDED)) { f4 |= G4_LANDED; saveGame(); say({ L("", "Kulenin ışığı baba ile oğlu bir yıldız gibi aşağı taşıdı. Kuyunun başına yumuşacık indiler."), L("Baba", "Yeşilvadi... Hiç değişmemiş. Hadi Arda, anneme gidelim.") }); }
    } else enterSky(149 * 16 + 8, 20 * 16 + 4);
  };
  EXT.trans[MAP_SKY] = [this](int tx, int ty, bool up, bool) {
    EACH(o, map.objs) if (o.alive && o.type == O_SKYHOUSE && up && tx == o.tx + 1 && std::fabs(py - o.y) < 14 + PHH) {
      if (o.text == "5") { if (fadeState == 0) { int rx = o.tx + 1, ry = o.ty + 3; sfx(SFX_CLICK); fadeTo([this, rx, ry] { enterInterior(5, rx, ry); }); } }
      else if (toastT <= 0) toast(o.text == "M" ? "Değirmencinin evi. Kapıda: 'Değirmendeyim. — Poyraz'" : "Kapı kilitli. İçeriden rüzgâr çanlarının sesi geliyor.");
      return;
    }
    if (tx >= 148 && tx <= 150 && ty <= 19 && up && py < 19 * 16 + 14) {
      if (mainStep >= 28) { if (toastT <= 0) toast("Kule artık huzurlu. Işığı bütün gökyüzünü aydınlatıyor."); }
      else if (fadeState == 0) fadeTo([this] { enterTower(); toast("GÖKLERDEKİ KULE"); });
    }
  };
  EXT.area[MAP_SKY] = [this] {
    int tx = (int)std::trunc(px / 16), ty = (int)std::trunc(py / 16); bool nt = night();
    Ent* eg = firstEnt(E_EAGLE);
    if (eg && std::hypot(eg->x - px, eg->y - py) < 230) setMood(4);
    else if (mainStep >= 28) setMood(5); else if (nt) setMood(6);
    else if (tx > 24 && tx < 57 && ty > 17 && ty < 41) setMood(19); else if (tx > 132) setMood(20); else setMood(18);
    if (eg && !eg->called && std::hypot(eg->x - px, eg->y - py) < 150 && !dlg) {
      eg->called = true; toast("FIRTINA KARTALI"); sfx(SFX_GROWL); shake = 0.4;
    }
    if (!nt) EACH(e, ents) if (e.alive && e.type == E_WISP) { e.alive = false; poof(e.x, e.y - 8); }
    if (qs[Q_BIRDS] == 1) {
      int n = 0;
      EACH(e, ents) if (e.alive && e.type == E_BIRDLING) {
        bool inside = e.x > PEN[0] && e.x < PEN[2] && e.y > PEN[1] && e.y < PEN[3];
        if (inside && e.state != 3) { e.state = 3; sfx(SFX_CHIME, 0.5); burst(1, e.x, e.y - 8, 4, 0xffffff); }
        if (e.state == 3) n++;
      }
      if (n != qc[Q_BIRDS]) { qc[Q_BIRDS] = n; toast(fmt("Kümesteki yavrular: %d/4", n)); }
    }
  };
  EXT.tick.push_back([this](double dt) {
    windStep(dt, px, py);
    if (p2 && !p2->remote && !p2->deadT) windStep(dt, p2->px, p2->py);
    // kule: ateşler söner
    if ((map.kind == MAP_DUNGEON4 || map.kind == MAP_OVER) && !brazierSolved()) EACH(o, map.objs) if (o.type == O_BRAZIER && o.var == 0) {
      o.a -= dt;
      if (o.a <= 0) { o.var = 1; sfx(SFX_CLICK, 0.6); burst(4, o.x, o.y - 18, 4, 0x8a8aa0); if (toastT <= 0) toast("Bir ateş söndü!"); }
    }
  });
  EXT.sync.push_back([this] { if (map.kind == MAP_SKY && f4 != lastF4) { skyBridges(map); lastF4 = f4; } });
  // ---------------- kule ----------------
  EXT.room[MAP_DUNGEON4] = Ext::RoomX{
    [this](int r) { return ((clear4 >> r) & 1) != 0; },
    [this](int r, bool instant) {
      curRoom = r; roomT = instant ? 0 : 0.5; ents.clear();
      bool boss = r == 1 && !(f4 & G4_LORD);
      if ((clear4 >> r) & 1) { setMood(boss ? 21 : 20); return; }
      double ox = (r % 3) * RW * 16, oy = (r / 3) * RH * 16;
      auto at = [&](int t, double x, double y) { Ent& e = spawn(t, ox + x * 16 + 8, oy + y * 16 + 12); e.room = r; e.hx = e.x; e.hy = e.y; };
      switch (r) {
        case 13: at(E_GARGOYLE, 5, 5); at(E_GARGOYLE, 14, 5); break;
        case 12: at(E_CLOUDLING, 14, 4); at(E_CLOUDLING, 14, 8); break;
        case 14: at(E_WISP, 6, 4); at(E_WISP, 13, 4); at(E_CLOUDLING, 10, 7); at(E_GARGOYLE, 15, 8); break;
        case 10: at(E_GARGOYLE, 5, 4); at(E_GARGOYLE, 14, 4); at(E_WISP, 6, 7); at(E_WISP, 13, 7); break;
        case 9: at(E_SKEL, 5, 5); at(E_SKEL, 14, 5); at(E_SKEL, 10, 7); break;
        case 11: at(E_WISP, 8, 5); at(E_WISP, 12, 6); break;
        case 7: at(E_GARGOYLE, 4, 4); at(E_GARGOYLE, 15, 4); at(E_CLOUDLING, 7, 7); at(E_CLOUDLING, 12, 7); break;
        case 8: at(E_WISP, 5, 4); at(E_WISP, 14, 4); at(E_WISP, 10, 7); at(E_SKEL, 10, 5); break;
        case 6: at(E_CLOUDLING, 8, 4); at(E_CLOUDLING, 12, 7); break;
        case 4: at(E_GARGOYLE, 4, 4); at(E_GARGOYLE, 15, 4); at(E_GARGOYLE, 10, 8); at(E_WISP, 6, 6); at(E_WISP, 13, 6); break;
        case 3: at(E_SKEL, 6, 5); at(E_SKEL, 13, 6); at(E_WISP, 10, 4); break;
        case 5: at(E_CLOUDLING, 5, 4); at(E_CLOUDLING, 14, 4); at(E_CLOUDLING, 10, 7); break;
        case 0: at(E_GARGOYLE, 6, 5); at(E_GARGOYLE, 13, 5); break;
        case 2: at(E_WISP, 6, 4); at(E_WISP, 13, 4); at(E_SKEL, 10, 7); break;
        case 1:
          if (!(f4 & G4_LORD)) {
            Ent& k = spawn(E_LORD, ox + 10 * 16, oy + 5 * 16 + 8); k.room = r; k.hx = k.x; k.hy = k.y; k.z = 14; k.inv = true; k.rage = 1;
            say({ L("Sis Efendisi", "Demek yeryüzünün küçük bekçisi buraya kadar tırmandı. Babanın inadı sende de var."),
              L("Sis Efendisi", "Üç parçayı bana getirdiğin için teşekkür ederim. Dördüncüsüyle Kalp benim olacak; dünya sonsuza dek sisle örtülecek!"),
              L("Arda", "Babam nerede?!"),
              L("Sis Efendisi", "Kulenin kalbindeki kristalde uyuyor. Onu uyandırmak istiyorsan... önce beni yen!") },
              [this] { toast("SİS EFENDİSİ"); sfx(SFX_RUMBLE); shake = 0.5; });
          } else if (mainStep == 27) addFather();
          break;
      }
      if (ents.empty()) clear4 |= 1u << r;
      setMood(boss ? 21 : 20);
      if (r == 9) toast("Zifiri karanlık... Fenerin ışığı ancak yetiyor.");
      if (r == 1 && boss) spawnHands();
    },
    [this](int r) {
      clear4 |= 1u << r; sfx(SFX_MAGIC);
      if (r == 10) { openLock(18); toast("Kapı açıldı! Yukarı kat seni bekliyor."); shake = 0.3; sfx(SFX_RUMBLE); }
      if (r == 7) { openLock(19); toast("Kapı açıldı!"); shake = 0.3; sfx(SFX_RUMBLE); }
      if (r == 14) { addRoomChest(14, 65, 10, 5); toast("Bir sandık belirdi!"); }
      if (r == 8) { addRoomChest(8, 68, 10, 5); toast("Bir sandık belirdi!"); }
      if (r == 3) { addRoomChest(3, 70, 10, 5); toast("Bir sandık belirdi!"); }
      if (r == 5) { addRoomChest(5, 71, 10, 5); toast("Bir sandık belirdi!"); }
      saveGame();
    } };
  EXT.push[MAP_DUNGEON4] = Ext::PushX{ F4_BLOCK, [this] { addRoomChest(12, 64, 10, 4); } };
  EXT.dark[MAP_DUNGEON4] = [this](double ox, double oy, std::vector<LightSrc>& Ls) {
    int r = curRoom < 0 ? roomOf(px, py) : curRoom; bool dim = false;
    EACH(e, ents) if (e.alive && e.type == E_LORD && e.rage >= 3) { dim = true; if (e.state == 6 || e.state == 7) Ls.push_back({ e.x - ox, e.y - 30 - e.z - oy, 22 }); }
    EACH(o, map.objs) if (o.alive && o.type == O_CRYSTAL && !(r == 1 && dim)) Ls.push_back({ o.x - ox, o.y - 10 - oy, 40 + std::sin(time * 2 + o.x) * 3 });
    EACH(o, map.objs) if (o.alive && o.type == O_BRAZIER && o.var == 0) Ls.push_back({ o.x - ox, o.y - 20 - oy, 46 + std::sin(time * 9 + o.x) * 3 });
    EACH(e, ents) if (e.alive && e.type == E_WISP) Ls.push_back({ e.x - ox, e.y - 14 - oy, 24 });
    return DarkInfo{ r == 9 ? 0.95 : (r == 1 && dim) ? 0.92 : 0.38, { 12, 6, 26 } };
  };
  EXT.tileAll[MAP_DUNGEON4] = [this](int t, int x, int y, double sx, double sy) {
    switch (t) {
      case T_DFLOOR: case T_DOOR_OPEN: spr(A.dfloor4[(x + y) & 1], sx, sy); break;
      case T_CARPET: spr(A.carpet4, sx, sy); break;
      case T_STAIRS: spr(A.stairs4, sx, sy); break;
      case T_DWALL: spr(A.dwall4, sx, sy); break;
      case T_DTOP: spr(A.dwallTop4, sx, sy); break;
      case T_DOOR_SHUT: spr(A.doorShut4, sx, sy); break;
      case T_DOOR_LOCK: spr(A.doorLock4, sx, sy); break;
      case T_DOOR_BOSS: spr(A.doorBoss4, sx, sy); break;
      case T_PLATE: spr(A.plate4[(flags & F4_BLOCK) ? 1 : 0], sx, sy); break;
      default: if (isWindT(t)) { spr(A.dfloor4[(x + y) & 1], sx, sy); windFx(t, x, y, sx, sy); } break;
    }
  };
  // ---------------- karolar ----------------
  EXT.tile[T_VOID] = [this](int, int x, int y, double sx, double sy) {
    double k = clampf(sy / VH, 0, 1);
    fillLo(sx, sy, 16, 16, rgba(lerpf(118, 200, k), lerpf(186, 228, k), lerpf(240, 255, k), 1));
    if (map.get(x, y - 1) == T_ISLEEDGE) spr(A.isleUnder, sx, sy);
    else if (hash2(x * 7 + 3, y * 3 + 1) > 0.93) spr(A.cloudPuff, sx - 5 + std::sin(time * 0.3 + x) * 3, sy + 3, false, 0.85);
  };
  EXT.tile[T_CLOUD] = [this](int, int x, int y, double sx, double sy) { spr(A.cloudT[(x + y) & 1], sx, sy); };
  EXT.tile[T_CLOUDGAP] = [this](int t, int x, int y, double sx, double sy) { EXT.tile[T_VOID](t, x, y, sx, sy); spr(A.cloudGap, sx, sy, false, 0.55 + 0.25 * std::sin(time * 2 + x * 0.5)); };
  EXT.tile[T_SKYGRASS] = [this](int, int x, int y, double sx, double sy) { spr(A.skyGrass[I(hash2(x, y) * 4) & 3], sx, sy); };
  EXT.tile[T_MARBLE] = [this](int, int x, int y, double sx, double sy) { spr(A.marble[(x + y) & 1], sx, sy); };
  EXT.tile[T_ISLEEDGE] = [this](int, int, int, double sx, double sy) { spr(A.isleEdge, sx, sy); };
  for (int t = T_WIND_L; t <= T_WIND_D; t++) EXT.tile[t] = [this](int t0, int x, int y, double sx, double sy) { spr(A.cloudT[(x + y) & 1], sx, sy); windFx(t0, x, y, sx, sy); };
  // ---------------- nesneler ----------------
  EXT.obj[O_SKYHOUSE] = [this](Obj& o, double x, double y) { spr(A.skyHouse[o.var % 3], x - 26, y - 53); };
  EXT.obj[O_WINDMILL] = [this](Obj&, double x, double y) { spr(A.shadow, x - 12, y - 4, false, 1, 1.5, 1.2); spr(A.millBody, x - 11, y - 44); rot(A.millBlades, x, y - 37, 20, 20, time * (mainStep >= 28 ? 2.4 : 1.2)); };
  EXT.obj[O_CLOUDSTONE] = [this](Obj& o, double x, double y) {
    bool lit = (o.var & 0x10) != 0;
    spr(A.shadow, x - 8, y - 4, false, 1, 1); spr(A.cloudStone[lit ? 1 : 0], x - 8, y - 30);
    if (lit) spr(A.spark, x - 9, y - 36, false, 0.4 + 0.3 * std::sin(time * 4 + o.tx), 2.6, 2.6);
  };
  EXT.obj[O_NEST] = [this](Obj&, double x, double y) { spr(A.nest, x - 24, y - 14); };
  EXT.obj[O_TOWER] = [this](Obj&, double x, double y) { spr(A.shadow, x - 30, y - 6, false, 1, 3.8, 2); spr(A.tower, x - 28, y - 94); };
  EXT.obj[O_STARBEAM] = [this](Obj&, double x, double y) {
    spr(A.beam, x - 9, y - 62, false, 0.45 + 0.2 * std::sin(time * 3), 1.5, 1.3);
    for (int k = 0; k < 3; k++) { double ph = std::fmod(time * 0.7 + k * 0.33, 1.0); spr(A.spark, x - 4 + std::sin(k * 2 + time) * 4, y - 6 - ph * 56, false, 1 - ph, 0.8, 0.8); }
  };
  EXT.obj[O_CLOUDBUSH] = [this](Obj&, double x, double y) { spr(A.shadow, x - 8, y - 4); spr(A.cloudBush, x - 9, y - 15); };
  EXT.obj[O_BRAZIER] = [this](Obj& o, double x, double y) {
    spr(map.kind == MAP_OVER ? A.torchBase : A.torchBase2, x - 6, y - 15);
    if (o.var == 0) { double a = brazierSolved() || o.a > 2.5 || std::fmod(time, 0.3) < 0.2 ? 1 : 0.5; spr(A.flame[I(time * 10 + o.x) % 3], x - 5, y - 26, false, a); }
  };
  EXT.obj[O_PEDESTAL] = [this](Obj&, double x, double y) {
    spr(A.shadow, x - 9, y - 4, false, 1, 1.1); spr(A.pedestal, x - 10, y - 20);
    if (night()) spr(A.spark, x - 9, y - 26, false, 0.4 + 0.4 * std::sin(time * 3), 2.6, 2.6);
  };
  EXT.light[O_SKYHOUSE] = [](Obj&) { return LIGHT_HOUSE4; };
  EXT.light[O_STARBEAM] = [](Obj&) { return LIGHT_BEAM; };
  EXT.light[O_TOWER] = [](Obj&) { return LIGHT_TOWER; };
  EXT.light[O_CLOUDSTONE] = [](Obj& o) { return (o.var & 0x10) ? LIGHT_STONE : nullptr; };
  EXT.light[O_PEDESTAL] = [](Obj&) { return LIGHT_PED; };
  EXT.cut[O_CLOUDBUSH] = [this](Obj& o) { map.removeObj(o); burst(5, o.x, o.y - 8, 10); burst(1, o.x, o.y - 8, 3, 0xffffff); sfx(SFX_SWING, 0.5); drop(o.x, o.y - 4, 0.3, 0.12); };
  EXT.interact[O_CLOUDSTONE] = [this](Obj& o) { blowHorn(o); };
  EXT.interact[O_STARBEAM] = [this](Obj&) {
    if (fadeState) return;
    if (mainStep < 27) { ask({ L("", "Yıldız ışığı yere doğru akıyor. Yeşilvadi'ye, köy kuyusuna inmek ister misin?") }, { "İn", "Kal" }, [this](int c) { if (!c) fadeTo([this] { enterOverworld(47 * 16 + 8, 58 * 16 + 4); pdir = 0; }); }); return; }
    ask({ L("", "Yıldız ışığı seni eve çağırıyor. Yeşilvadi'ye inmek ister misin?") }, { "İn", "Kal" }, [this](int c) { if (!c) fadeTo([this] { enterOverworld(47 * 16 + 8, 58 * 16 + 4); pdir = 0; }); });
  };
  EXT.interact[O_WINDMILL] = [this](Obj&) { say({ L("", mainStep >= 28 ? "Değirmenin kanatları neşeyle dönüyor. İçeriden taze un kokusu geliyor." : "Değirmenin kanatları ağır ağır dönüyor. Rüzgâr bile yorgun gibi.") }); };
  EXT.interact[O_NEST] = [this](Obj&) { say({ L("", (f4 & G4_EAGLE) ? "Boş bir kartal yuvası. Kuru dalların arasında altın renkli bir tüy parlıyor." : "Dev bir yuva. Yumurtaların üstünde kocaman pençe izleri var.") }); };
  EXT.interact[O_BRAZIER] = [this](Obj& o) {
    if (brazierSolved()) { say({ L("", "Dört ateş de harıl harıl yanıyor.") }); return; }
    if (!hasLantern) { say({ L("", "Sönük bir ateş kabı. Yakmak için bir fener lazım.") }); return; }
    if (o.var == 0) { toast(fmt("Bu ateş yanıyor (%d sn)", std::max(1, I(o.a + 0.99)))); return; }
    o.var = 0; o.a = 9; sfx(SFX_FIRE); burst(1, o.x, o.y - 22, 6, 0xf8b030);
    int lit = 0; EACH(t, map.objs) if (t.type == O_BRAZIER && t.var == 0) lit++;
    toast(fmt("Ateş yandı (%d/4)", lit));
    if (lit >= 4) brazierDone();
  };
  // ---------------- köylüler ----------------
  EXT.npcs.push_back([this] {
    WorldMap& m = map; bool n = night();
    if (m.kind == MAP_SKY) {
      if (!n) {
        addNPC(N_WINDMA, 40, 26, A.windMa, "Rüzgâr Ana");
        addNPC(N_BIRDKEEPER, 41, 36, A.birdKeeper, "Kuşçu Serçe", true);
        addNPC(N_MILLER, 29, 29, A.innkeep, "Değirmenci Poyraz");
      }
      addNPC(N_CLOUDGUARD, 36, 35, A.cloudGuard, "Bulut Bekçisi Tan");
    } else if (m.kind == MAP_INTERIOR && interior == 5) addNPC(N_INNKEEP4, 10, 3, A.innkeep4, "Hancı Meltem");
    else if (m.kind == MAP_OVER && mainStep >= 27 && !n) addNPC(N_FATHER, 43, 56, A.father, "Baba");
    else if (m.kind == MAP_INTERIOR && interior == 2 && mainStep >= 27 && n) addNPC(N_FATHER, 6, 4, A.father, "Baba");
  });
  EXT.talk[N_INNKEEP4] = [this](Npc&) { innShop(); };
  EXT.talk[N_FATHER] = [this](Npc&) {
    if (mainStep == 27) { say({ L("Baba", map.kind == MAP_DUNGEON4 ? "Merdivenden inelim, Arda. Kulenin ışığı bizi eve götürecek." : "Nine'ye gidelim, Arda. Yıllardır annemin yüzünü görmedim.") }); return; }
    static const char* t[4] = { "Kılıcını bilemeyi unutma. Bekçinin kılıcı hiç körelmemeli.", "Kemal hâlâ o feneri satıyor mu? O feneri ben de ondan almıştım!",
      "Gökteki dostlarımızı görmek istersen kuyu hep orada.", "Gökyüzündeki aynaya dair bir masal duymuştum... Ay ışığında bakanı içine çekermiş." };
    say({ L("Baba", t[(dayN + (int)(time / 7)) % 4]) });
  };
  EXT.talk[N_WINDMA] = [this](Npc&) {
    int s0 = mainStep;
    if (s0 <= 23) {
      say({ L("Rüzgâr Ana", "Bir yeryüzü çocuğu! Yıldız kuyusundan mı geldin? O kuyuyu en son... bir adam kullanmıştı. Yıllar önce."),
        L("Arda", "Babam! Babamı gördünüz mü? Benim gibi kahverengi saçlı, inatçı biri!"),
        L("Rüzgâr Ana", "İnatçıydı, evet. Kalbin dördüncü parçasını Sis Efendisi'nden korumak için Kule'ye gitti. Bir daha dönmedi."),
        L("Rüzgâr Ana", "O gittiğinden beri Kule'yi kara bir sis sardı. Bulut köprüleri dağıldı. Yeryüzüne inen sis de oradan geliyor."),
        L("Rüzgâr Ana", "Köprüleri ancak Rüzgâr Borusu yeniden örebilir. Ama Fırtına Kartalı onu kaptı, kuzeydeki yuvasına götürdü."),
        L("Rüzgâr Ana", "Yuvanın yolu rüzgâr akıntısından geçer. Rüzgâr eserken sakin bulutta bekle, dinince yürü.") },
        [this] {
          mainStep = std::max(mainStep, 24);
          if (!(f4 & G4_EAGLE) && !firstEnt(E_EAGLE)) { Ent& k = spawn(E_EAGLE, NEST_HOME[0], NEST_HOME[1]); k.hx = k.x; k.hy = k.y; k.z = 46; }
          toast("Kartal Yuvası'nda Fırtına Kartalı'nı yen."); saveGame();
        });
      return;
    }
    say({ L("Rüzgâr Ana", s0 == 24 ? "Kartal yüksekten uçarken ona yetişemezsin. Dalıp yere çakıldığında vur! Kanat çırpınca da savrulmamaya bak." :
      s0 == 25 ? "Bulut taşlarını boruyla öttür; köprüler yeniden örülür. Kule'ye üç köprü var: köyün doğusunda, bahçede ve Yıldırım Adası'nda." :
      s0 == 26 ? "Kule'nin tepesinde Sis Efendisi bekliyor. Rüzgâr seninle olsun, çocuğum." :
      "Sis dağıldı! Gökyüzü yıllardır bu kadar mavi olmamıştı. Babana selam söyle.") });
  };
  EXT.talk[N_BIRDKEEPER] = [this](Npc&) {
    int q = qs[Q_FEATHER], n = qc[Q_FEATHER];
    if (q == 0) { say({ L("Kuşçu Serçe", "Fırtınada kuşlarımın altın tüyleri döküldü! Altısı adalara saçıldı."), L("Kuşçu Serçe", "Bazıları uzak adacıklarda, biri kartalın yuvasında bile olabilir. Altısını getirirsen sana güzel bir şey veririm!") },
      [this] { qs[Q_FEATHER] = 1; toast("Yeni görev: Altın Tüyler"); saveGame(); }); return; }
    if (q == 1 && n >= 6) { say({ L("Kuşçu Serçe", "Altısı da! Kuşlarım yeniden pırıl pırıl olacak. Al, bunu yuvanın dibinde bulmuştum.") }, [this] { qs[Q_FEATHER] = 2; coins += 40; givePiece(); saveGame(); }); return; }
    say({ L("Kuşçu Serçe", q == 1 ? fmt("%d tüy buldun. Altısı lazım! Gizli adacıkları unutma.", n) : string("Kuşlarım şarkı söylüyor, duyuyor musun?")) });
  };
  EXT.talk[N_MILLER] = [this](Npc&) {
    int q = qs[Q_BIRDS];
    if (q == 0) { say({ L("Değirmenci Poyraz", "Değirmenin çatısındaki yuvadan dört yavru kuş düştü! Adalara dağıldılar."),
      L("Değirmenci Poyraz", "Onları köyün güneydoğusundaki kümese sokabilir misin? Kapı batı tarafta. Senden kaçarlar; arkalarından dolanıp kapıya doğru sür!") },
      [this] { qs[Q_BIRDS] = 1; qc[Q_BIRDS] = 0; toast("Yeni görev: Yavru Kuşlar"); saveGame(); }); return; }
    if (q == 1 && qc[Q_BIRDS] >= 4) { say({ L("Değirmenci Poyraz", "Dördü de kümeste! Cik cik cik... Sağ ol, gökyüzünün en sabırlı çobanı sensin. Al bakalım.") }, [this] { qs[Q_BIRDS] = 2; givePiece(); saveGame(); }); return; }
    say({ L("Değirmenci Poyraz", q == 1 ? fmt("Kümeste %d yavru var. Dördü lazım! Biri iskelede, biri bulut yolunda...", qc[Q_BIRDS]) : string("Yavrular büyüyor. Yakında değirmenin çevresinde uçacaklar.")) });
  };
  EXT.talk[N_CLOUDGUARD] = [this](Npc&) {
    int q = qs[Q_WISPS];
    if (!night() && q == 0) { say({ L("Bulut Bekçisi Tan", "Hıı... Ben gece bekçisiyim, gündüzleri uyuklarım. Gece gel, sana anlatacaklarım var. Hıı...") }); return; }
    if (q == 0) { say({ L("Bulut Bekçisi Tan", "Geceleri fırtına ruhları adaların üstünde dolaşıyor. Kule'nin sisinden doğdular."),
      L("Bulut Bekçisi Tan", "Sekizini söndürürsen sana bir sır veririm. Bu gökyüzünde benden başka kimsenin bilmediği bir sır.") },
      [this] { qs[Q_WISPS] = 1; qc[Q_WISPS] = 0; toast("Yeni görev: Fırtına Ruhları"); saveGame(); }); return; }
    if (q == 1 && qc[Q_WISPS] >= 8) {
      say({ L("Bulut Bekçisi Tan", "Sekiz ruh! Gökyüzü rahat bir nefes aldı. Al bakalım, söz verdiğim gibi."),
        L("Bulut Bekçisi Tan", "Şimdi sırrı dinle: Köyün kuzeybatısında, bulut çalılarının arasında unutulmuş bir taş var."),
        L("Bulut Bekçisi Tan", "Onu öttürürsen batıdaki küçük adaya köprü uzanır. Oradaki kırık aynaya gece, ay ışığında dokun."),
        L("Bulut Bekçisi Tan", "Ama dikkat et: aynanın içindeki şövalye kimseye yenilmedi. Kılıcın yetmez; aklını da kullanman gerekecek.") },
        [this] { qs[Q_WISPS] = 2; f4 |= G4_RIDDLE; givePiece(); saveGame(); });
      return;
    }
    if (q == 2) { say({ L("Bulut Bekçisi Tan", (f4 & G4_KNIGHT) ? "Ayna Şövalyesi'ni yendin mi? Hıı... Bu gökyüzü artık sana emanet." : "Kuzeybatıdaki taş, batıdaki ada, gece, kırık ayna... Unutma: ışığı ona geri çevir.") }); return; }
    say({ L("Bulut Bekçisi Tan", fmt("%d ruh söndürdün. Sekizi lazım. Yalnızca geceleri çıkarlar.", qc[Q_WISPS])) });
  };
  // ---------------- eşyalar, sandıklar ----------------
  EXT.pick[P_FEATHER] = [this](Pick& k) {
    feathers |= 1 << (k.val & 7); int n = 0; for (int i = 0; i < 6; i++) n += (feathers >> i) & 1;
    qc[Q_FEATHER] = n; showItem(A.feather, fmt("Altın tüy! (%d/6)", n)); saveGame();
  };
  EXT.pick[P_HORN] = [this](Pick&) {
    hasHorn = true; mainStep = std::max(mainStep, 25); showItem(A.horn, "RÜZGÂR BORUSU! Bulut taşlarının yanında konuş düğmesine bas.");
    say({ L("Arda", "Borunun sesi rüzgârı çağırıyor... Köyün doğusundaki bulut taşına gideyim. Kule'nin yolu oradan başlıyor.") });
    saveGame();
  };
  EXT.pick[P_GEM4] = [this](Pick&) {
    hasGem4 = true; mainStep = 27; showItem(A.gem4, "KALBİN DÖRDÜNCÜ PARÇASI!");
    say({ L("", "Altın bir ışık kuleyi baştan başa doldurdu. Duvarın içindeki kristal çatırdayarak kırıldı."),
      L("Baba", "Arda...? Oğlum, sen misin? Ne kadar büyümüşsün!"),
      L("Arda", "Baba! Yıllardır... yıllardır seni bekledik!"),
      L("Baba", "Sis Efendisi beni kristale hapsetti. Ama son parçayı ona vermedim. Sen de vermedin. Seninle gurur duyuyorum."),
      L("Baba", "Dört parça yanında. Hadi eve, anneme gidelim. Kulenin ışığı bizi aşağı indirir; merdivenden inmemiz yeter.") },
      [this] { poof(RW * 16 + 10 * 16 + 8, 4 * 16 + 8); addFather(); toast("Merdivenden inip Yeşilvadi'ye dön."); saveGame(); });
  };
  EXT.chest[64] = [this](int) { keys++; showItem(A.key, "Küçük anahtar buldun."); };
  EXT.chest[65] = [this](int) { keys++; showItem(A.key, "Küçük anahtar buldun."); };
  EXT.chest[66] = [this](int) { keys++; showItem(A.key, "Küçük anahtar buldun."); };
  EXT.chest[67] = [this](int) { giveHeartC(); };
  EXT.chest[68] = [this](int) { potions += 2; showItem(A.potion, "2 can iksiri!"); };
  EXT.chest[69] = [this](int) { bossKey4 = true; showItem(A.bossKey, "BÜYÜK YILDIZ ANAHTARI! Kulenin tepesindeki kapıyı açar."); };
  EXT.chest[70] = [this](int) { givePiece(); };
  EXT.chest[71] = [this](int) { coins += 80; showItem(A.coin[0], "80 altın buldun!"); };
  EXT.chest[72] = [this](int) { coins += 100; showItem(A.coin[0], "100 altın buldun!"); };
  EXT.chest[73] = [this](int) { potions += 2; coins += 50; showItem(A.potion, "2 can iksiri ve 50 altın!"); };
  EXT.chest[74] = [this](int) { givePiece(); };
  EXT.chest[75] = [this](int) { coins += 60; showItem(A.coin[0], "60 altın buldun!"); };
  EXT.chest[76] = [this](int) { giveHeartC(); };
  EXT.chest[77] = [this](int) { potions += 2; showItem(A.potion, "2 can iksiri!"); };
  // ---------------- düşmanlar ----------------
  EXT.enemy[E_SKYBIRD] = EXT.enemy[E_GULL];
  EXT.enemy[E_WISP] = [this](Ent& e, double dt, double dx, double dy, double d) {
    e.z = 7 + std::sin(e.t * 3) * 3;
    if (d < 150) { double want = d > 56 ? 1 : d < 40 ? -1 : 0; e.x += dx / d * want * 26 * dt + std::cos(e.t * 1.7) * 10 * dt; e.y += dy / d * want * 26 * dt + std::sin(e.t * 2.1) * 8 * dt; }
    else { e.x += std::cos(e.t * 0.8 + e.hx) * 14 * dt; e.y += std::sin(e.t * 0.6) * 10 * dt; }
    if (d < 140 && e.cd <= 0) { e.cd = 2.4; Ent& s = shoot(E_SPARK, e.x, e.y - 8, dx / d * 85, dy / d * 85, e.room); s.hx = 0; s.hy = 0; sfx(SFX_CLICK, 0.4); }
    clampRoom(e);
  };
  EXT.enemy[E_CLOUDLING] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (e.z <= 0 && e.vz <= 0) {
      e.z = 0;
      if (e.t > 0.8) { e.t = rnd() * 0.3; e.vz = 100; double a = d < 120 ? std::atan2(dy, dx) + (rnd() - 0.5) * 0.5 : rnd() * 6.28; e.vx = std::cos(a) * 52; e.vy = std::sin(a) * 52; }
      else e.vx = e.vy = 0;
    }
    if (e.z > 0 || e.vz > 0) { e.vz -= 400 * dt; e.z += e.vz * dt; moveE(e, e.vx * dt, 0, 5, 5); moveE(e, 0, e.vy * dt, 5, 5); if (e.z <= 0) { e.z = 0; e.vz = 0; } }
  };
  EXT.enemy[E_GARGOYLE] = [this](Ent& e, double dt, double dx, double dy, double d) {
    e.invMsg = "Taş heykel! Yaklaşınca uyanır; uyanıkken vur.";
    if (e.state == 1) {   // uyanık: kovalar, savunmasız
      e.inv = false; moveE(e, dx / d * 48 * dt, 0, 6, 5); moveE(e, 0, dy / d * 48 * dt, 6, 5);
      if (e.t > 3.6) { e.state = 2; e.t = 0; }
    } else if (e.state == 2) { e.inv = true; if (e.t > 1.2) { e.state = 0; e.t = 0; e.cd = 1.4; } }   // taşa dönüyor
    else { e.inv = true; if (d < 58 && e.cd <= 0) { e.state = 1; e.t = 0; sfx(SFX_GROWL, 0.5); burst(4, e.x, e.y - 10, 6, 0x9094a4); } }
    e.dir = dx < 0 ? 2 : 3;
    clampRoom(e);
  };
  EXT.enemy[E_FEATHERP] = [this](Ent& e, double dt, double, double, double) { stepShot(e, dt, 1, 2.6); };
  EXT.enemy[E_SPARK] = [this](Ent& e, double dt, double, double, double) { stepShot(e, dt, 1, 2.6); };
  EXT.enemy[E_DARKORB] = [this](Ent& e, double dt, double, double, double) { stepShot(e, dt, 2, 3.2); };
  EXT.enemy[E_BIRDLING] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (e.state == 3) {   // kümeste
      if (e.t > 2) { e.t = 0; e.vx = (rnd() - 0.5) * 14; e.vy = (rnd() - 0.5) * 10; e.dir = e.vx < 0 ? 2 : 3; }
      double nx = e.x + e.vx * dt, ny = e.y + e.vy * dt;
      if (nx > PEN[0] + 4 && nx < PEN[2] - 4 && ny > PEN[1] + 2 && ny < PEN[3]) { e.x = nx; e.y = ny; }
      return;
    }
    if (qs[Q_BIRDS] == 1 && d < 50) { moveE(e, -dx / d * 64 * dt, 0, 4, 4); moveE(e, 0, -dy / d * 64 * dt, 4, 4); e.dir = dx > 0 ? 2 : 3; e.state = 1; return; }
    if (e.state == 2) { moveE(e, -dx / d * 70 * dt, -dy / d * 70 * dt, 4, 4); if (e.t > 1.0) e.state = 0; return; }
    if (e.t > 2) { e.t = 0; e.state = rnd() < 0.5 ? 1 : 0; e.dir = rnd() < 0.5 ? 2 : 3; e.vy = (rnd() - 0.5) * 12; }
    if (e.state == 1) moveE(e, (e.dir == 2 ? -14 : 14) * dt, e.vy * dt, 4, 4);
  };
  EXT.hitPre[E_BIRDLING] = [this](Ent& e) { e.flash = 0.2; e.state = e.state == 3 ? 3 : 2; e.t = 0; sfx(SFX_SELECT, 0.5); burst(1, e.x, e.y - 6, 4, 0xffffff); return true; };
  EXT.kill[E_WISP] = [this](Ent&) { if (qs[Q_WISPS] == 1 && night() && map.kind == MAP_SKY) { qc[Q_WISPS]++; toast(fmt("Fırtına ruhları: %d/8", std::min(8, qc[Q_WISPS]))); } return false; };
  // ---------------- Fırtına Kartalı ----------------
  EXT.enemy[E_EAGLE] = [this](Ent& e, double dt, double dx, double dy, double) {
    if (dlg) return;
    bool fast = e.hp < e.maxHp / 2;
    e.invMsg = "Kartal çok yüksekte! Dalıp yere çakılınca vur.";
    if (fast && e.hits == 0) {
      e.hits = 1; double ex = e.x, ey = e.y;
      for (int sg = -1; sg <= 1; sg += 2) { Ent& b = spawn(E_SKYBIRD, ex + sg * 40, ey + 20); b.hx = b.x; b.hy = b.y; }
      toast("Kartal sürüsünü çağırdı!"); sfx(SFX_GROWL);
    }
    auto home = [&] { e.x = clampf(e.x, e.hx - 170, e.hx + 170); e.y = clampf(e.y, e.hy - 60, e.hy + 90); };
    switch (e.state) {
      case 1: {   // dalış
        e.inv = true; e.x += e.vx * dt; e.y += e.vy * dt; e.z = std::max(0.0, e.z - 80 * dt);
        if (e.t > 0.58) {
          e.state = 2; e.t = 0; e.z = 0; shake = 0.35; sfx(SFX_HIT); haptic("hit");
          burst(5, e.x, e.y - 4, 10); burst(0, e.x, e.y - 6, 6);
          if (fast) { double ex = e.x, ey = e.y; for (int k = 0; k < 6; k++) { double a = k * PI / 3 + e.cd; Ent& f = shoot(E_FEATHERP, ex, ey - 8, std::cos(a) * 75, std::sin(a) * 75, -1); f.hx = 0; f.hy = 0; } }
          toast("Kartal yere çakıldı! Şimdi vur!");
        }
        break;
      }
      case 2: e.inv = false; if (e.t > (fast ? 1.4 : 1.9)) { e.state = 4; e.t = 0; } break;   // sersem
      case 4: e.inv = true; e.z += 70 * dt; if (e.z >= 46) { e.z = 46; e.state = 0; e.t = 0; } break;   // yükselme
      case 3:   // kanat çırpma: savurur, tüy atar
        e.inv = true; e.z = std::max(28.0, e.z - 40 * dt);
        if (e.t > 0.7) {
          pushHeroes(e.x, e.y, 240); shake = 0.25; sfx(SFX_SWING); sfx(SFX_HOWL, 0.4);
          double a0 = std::atan2(dy, dx), ex = e.x, ey = e.y;
          for (int k = -2; k <= 2; k++) { double a = a0 + k * 0.25; Ent& f = shoot(E_FEATHERP, ex, ey - 10, std::cos(a) * 120, std::sin(a) * 120, -1); f.hx = 0; f.hy = 0; }
          e.state = 0; e.t = 0;
        }
        break;
      default: {   // yüksekte süzülme
        e.inv = true; e.z = std::min(46.0, e.z + 30 * dt);
        double tx = px + std::cos(e.t * 1.3) * 70, ty = py - 30 + std::sin(e.t * 1.3) * 26, ax = tx - e.x, ay = ty - e.y, al = std::hypot(ax, ay) + 0.01;
        e.x += ax / al * std::min(al, 80 * dt); e.y += ay / al * std::min(al, 80 * dt); home();
        if (e.t > (fast ? 1.6 : 2.4)) {
          e.t = 0; e.cd += 1;
          if (I(e.cd) % 3 == 2) { e.state = 3; sfx(SFX_GROWL, 0.6); }
          else {   // dalış: hedef yuva adasının içinde kalsın
            double gx = clampf(px, 35 * 16, 54 * 16), gy = clampf(py, 4 * 16, 11 * 16);
            e.state = 1; e.vx = (gx - e.x) / 0.58; e.vy = (gy - e.y) / 0.58; sfx(SFX_SNORT, 0.7);
          }
        }
      }
    }
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.kill[E_EAGLE] = [this](Ent& e) {
    f4 |= G4_EAGLE; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 6; i++) poof(ex + (rnd() - 0.5) * 50, ey - 10 - rnd() * 24);
    EACH(o, ents) if (o.alive && (o.type == E_FEATHERP || o.type == E_SKYBIRD)) { o.alive = false; poof(o.x, o.y - 6); }
    addPick(P_HORN, clampf(ex, 36 * 16, 52 * 16), clampf(ey, 4 * 16, 10 * 16), 100);
    for (int i = 0; i < 8; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 34, ey + (rnd() - 0.5) * 22, 80 + rnd() * 40);
    toast("Fırtına Kartalı yenildi!"); setMood(5); saveGame();
    return true;
  };
  // ---------------- Sis Efendisi ----------------
  EXT.enemy[E_LORD] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (dlg) return;
    double ox = (e.room % 3) * RW * 16, oy = (e.room / 3) * RH * 16, fr = e.hp / e.maxHp;
    int ph = fr > 2.0 / 3 ? 1 : fr > 1.0 / 3 ? 2 : 3;
    if (ph != I(e.rage)) {   // evre değişti
      e.rage = ph; e.t = 0; e.state = ph == 3 ? 6 : 0;
      EACH(o, ents) if (o.alive && (o.type == E_MISTHAND || o.type == E_DARKORB)) { o.alive = false; poof(o.x, o.y - 8); }
      shake = 0.6; sfx(SFX_RUMBLE);
      toast(ph == 2 ? "Sis Efendisi öfkelendi! Gölgeden gölgeye atlıyor!" : "Işıklar söndü... Kızıl gözlerine dikkat et!");
    }
    auto orbs = [&](int n, double spread, double sp) {
      double a0 = std::atan2(dy, dx), ex = e.x, ey = e.y - 10; int room = e.room;
      for (int k = 0; k < n; k++) { double a = a0 + (k - (n - 1) / 2.0) * spread; Ent& b = shoot(E_DARKORB, ex, ey, std::cos(a) * sp, std::sin(a) * sp, room); b.hx = 0; b.hy = 0; }
      sfx(SFX_MAGIC, 0.5);
    };
    if (ph == 1) {
      if (e.state == 5) {   // sis dağıldı: savunmasız
        e.inv = false; e.z = std::max(0.0, e.z - 30 * dt);
        if (e.t > 4.5) { e.state = 0; e.t = 0; spawnHands(); toast("Sis yeniden toplandı!"); }
      } else {
        e.inv = true; e.invMsg = "Sis kalkanı! Önce sis ellerini yok et: yere vurduktan sonra savunmasızlar.";
        e.z = 14 + std::sin(e.t * 2) * 3; e.x = e.hx + std::sin(e.t * 0.7) * 40;
        int hands = 0; for (auto& h : ents) if (h->alive && h->type == E_MISTHAND) hands++;
        if (!hands && e.t > 0.4) { e.state = 5; e.t = 0; shake = 0.3; sfx(SFX_SHATTER, 0.6); toast("Sis dağıldı! Sis Efendisi savunmasız!"); }
        if (e.cd <= 0) { e.cd = 3.2; orbs(3, 0.3, 80); }
      }
    } else if (ph == 2) {
      e.inv = false; e.z = 6 + std::sin(e.t * 3) * 2;
      if (e.t > 2.1) {
        e.t = 0; e.vz += 1;
        static const int C4[4][2] = { {4, 4}, {15, 4}, {4, 8}, {15, 8} };
        int k = (I(e.vz) * 3 + 1) % 4; poof(e.x, e.y - 14);
        e.x = ox + C4[k][0] * 16 + 8; e.y = oy + C4[k][1] * 16 + 8; poof(e.x, e.y - 14); sfx(SFX_MAGIC, 0.4);
        if (I(e.vz) % 2) orbs(5, 0.28, 95);
        else { double ex = e.x, ey = e.y - 10; int room = e.room; for (int j = 0; j < 10; j++) { double a = j * PI / 5 + e.vz * 0.3; Ent& b = shoot(E_DARKORB, ex, ey, std::cos(a) * 70, std::sin(a) * 70, room); b.hx = 0; b.hy = 0; } }
        if (I(e.vz) % 3 == 0) { int room = e.room; for (int sg = -1; sg <= 1; sg += 2) { Ent& w = spawn(E_WISP, e.x + sg * 30, e.y + 10); w.room = room; } }
      }
    } else {
      if (e.state == 7) {   // karanlıkta hücum
        e.inv = true; e.invMsg = "Karanlıkta hücum ediyor! Duvara çarpınca sersemler.";
        bool hit = moveE(e, e.vx * dt, e.vy * dt, 12, 8); e.z = 2;
        if (hit || e.t > 1.3) { e.state = 8; e.t = 0; shake = 0.4; sfx(SFX_HIT); burst(4, e.x, e.y - 10, 10, 0x4a3460); toast("Sis Efendisi duvara çarptı!"); }
      } else if (e.state == 8) { e.inv = false; e.z = 0; if (e.t > 2.3) { e.state = 6; e.t = 0; } }   // sersem
      else {   // nişan alma (gözler parlar)
        e.inv = true; e.invMsg = "Karanlıkta hücum ediyor! Duvara çarpınca sersemler.";
        e.z = 4;
        if (e.t > 0.95) { e.state = 7; e.t = 0; e.vx = dx / d * 230; e.vy = dy / d * 230; sfx(SFX_GROWL, 0.7); }
      }
    }
    e.x = clampf(e.x, ox + 28, ox + RW * 16 - 28); e.y = clampf(e.y, oy + 46, oy + RH * 16 - 22);
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.enemy[E_MISTHAND] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (dlg) return;
    e.invMsg = "Sis eli! Yere vurduktan sonra savunmasız.";
    if (e.state == 1) {   // yukarı kalkıp nişan alır
      e.inv = true; e.z = std::min(26.0, e.z + 40 * dt);
      if (e.t > 0.7) { e.state = 2; e.t = 0; }
    } else if (e.state == 2) {   // yere çarpar
      e.inv = true; e.z = std::max(0.0, e.z - 200 * dt);
      if (e.z <= 0) {
        e.state = 3; e.t = 0; shake = 0.25; sfx(SFX_HIT, 0.7); burst(4, e.x, e.y, 8, 0x4a3460);
        for (auto& h : heroes()) if (std::fabs(h.x - e.x) < 18 && std::fabs(h.y - e.y) < 14) hurtAt(h, 2, e.x, e.y);
      }
    } else if (e.state == 3) { e.inv = false; if (e.t > 1.1) { e.state = 0; e.t = 0; e.cd = 1.0; } }   // yerde: savunmasız
    else {
      e.inv = true; e.z = 10 + std::sin(e.t * 4) * 2;
      double sp = 46; moveE(e, dx / d * sp * dt, 0, 6, 5); moveE(e, 0, dy / d * sp * dt, 6, 5);
      if (d < 22 && e.cd <= 0) { e.state = 1; e.t = 0; sfx(SFX_SNORT, 0.5); }
    }
    clampRoom(e);
  };
  EXT.hit[E_MISTHAND] = [this](Ent& e, double) {
    e.hits++; e.hp = 99;
    if (e.hits >= 3) { e.alive = false; poof(e.x, e.y - 8); burst(4, e.x, e.y - 8, 10, 0x4a3460); sfx(SFX_SHATTER, 0.6); toast("Bir sis eli dağıldı!"); }
  };
  EXT.kill[E_LORD] = [this](Ent& e) {
    f4 |= G4_LORD; shake = 1.2; haptic("big");
    double ex = e.x, ey = e.y; int room = e.room;
    for (int i = 0; i < 10; i++) poof(ex + (rnd() - 0.5) * 70, ey - 10 - rnd() * 40);
    EACH(o, ents) if (o.alive && &o != &e && o.room == room) { o.alive = false; poof(o.x, o.y - 6); }
    EACH(o, ents) if (o.alive && (o.type == E_DARKORB || o.type == E_MISTHAND)) o.alive = false;
    double gx = RW * 16 + 10 * 16, gy = 6 * 16;
    addPick(P_GEM4, gx, gy, 90); addPick(P_HEARTC, gx + 30, gy, 90);
    say({ L("Sis Efendisi", "Hayır... Işık... çok parlak... Sis... dağılıyor..."), L("", "Sis Efendisi binlerce kara tüye dönüşüp rüzgâra karıştı.") });
    setMood(5); saveGame();
    return true;
  };
  // ---------------- çizimler ----------------
  EXT.draw[E_SKYBIRD] = [this](Ent& e, double x, double y, bool fl) { spr(A.shadow, x - 5, y - 3, false, 0.6, 0.6); spr(A.skybird[I(e.t * 8) & 1], x - 7, y - 10 - e.z, e.dir == 3, 1, 1, 1, fl); };
  EXT.draw[E_WISP] = [this](Ent& e, double x, double y, bool fl) { spr(A.shadow, x - 4, y - 3, false, 0.4, 0.5); spr(A.wisp[I(e.t * 6) & 1], x - 6, y - 16 - e.z, false, 0.9, 1, 1, fl); };
  EXT.draw[E_CLOUDLING] = [this](Ent& e, double x, double y, bool fl) {
    double sq = e.z > 0 ? 0.9 : 1 + 0.08 * std::sin(e.t * 8), st = e.z > 0 ? 1.15 : 1 / sq; const Spr* s0 = A.cloudling[e.z > 0 ? 1 : 0];
    spr(A.shadow, x - 7, y - 4, false, 1, 0.9); spr(s0, x - s0->w * sq / 2, y - s0->h * st - e.z + 1, false, 1, sq, st, fl);
  };
  EXT.draw[E_GARGOYLE] = [this](Ent& e, double x, double y, bool fl) {
    double bob = e.state == 1 ? -std::fabs(std::sin(e.t * 10)) * 2 : 0, shk = e.state == 0 && e.cd <= 0 && std::hypot(px - e.x, py - e.y) < 80 ? std::sin(time * 40) * 0.6 : 0;
    spr(A.shadow, x - 9, y - 4, false, 1, 1.1); spr(A.gargoyle[e.state == 1 ? 1 : 0], x - 9 + shk, y - 16 + bob, e.dir == 2, e.state == 2 ? 0.8 : 1, 1, 1, fl);
  };
  EXT.draw[E_FEATHERP] = [this](Ent& e, double x, double y, bool) { rot(A.featherP, x, y - 8, 4, 6, std::atan2(e.vy, e.vx) + PI / 2); };
  EXT.draw[E_SPARK] = [this](Ent& e, double x, double y, bool) { spr(A.spark, x - 5, y - 11, false, 0.7 + 0.3 * std::sin(e.t * 20), 1.4, 1.4); };
  EXT.draw[E_DARKORB] = [this](Ent& e, double x, double y, bool) { spr(A.shadow, x - 4, y - 2, false, 0.5, 0.5); spr(A.darkOrb, x - 6, y - 14, false, 0.85 + 0.15 * std::sin(e.t * 14)); };
  EXT.draw[E_BIRDLING] = [this](Ent& e, double x, double y, bool fl) {
    spr(A.shadow, x - 6, y - 3, false, 1, 0.7);
    spr(A.birdling[(e.state ? I(e.t * 8) : 0) & 1], x - 7, y - 11 - (e.state == 2 ? std::fabs(std::sin(e.t * 20)) * 3 : 0), e.dir == 3, 1, 1, 1, fl);
  };
  EXT.draw[E_EAGLE] = [this](Ent& e, double x, double y, bool fl) {
    double k = clampf(1 - e.z / 70, 0.35, 1);
    spr(A.shadow, x - 20 * k, y - 5, false, 0.4 + 0.5 * k, 2.6 * k, 1.8 * k);
    const Spr* s0 = A.eagle[e.state == 2 ? 1 : I(e.t * (e.state == 3 ? 14 : 6)) & 1];
    spr(s0, x - s0->w / 2, y - s0->h - e.z + 2, e.dir == 2, e.state == 2 ? 0.75 + 0.25 * std::sin(e.t * 20) : 1, 1, 1, fl);
    if (e.state == 2) for (int i = 0; i < 3; i++) spr(A.spark, x - 4 + std::cos(time * 6 + i * 2.1) * 12, y - 32 + std::sin(time * 6 + i * 2.1) * 4, false, 0.9, 0.7, 0.7);
  };
  EXT.draw[E_LORD] = [this](Ent& e, double x, double y, bool fl) {
    const Spr* s0 = A.lord[I(e.t * 2) & 1]; double sc = 1.15;
    bool dark = e.rage >= 3 && e.state != 8; double a = dark ? 0.3 : e.state == 5 ? 0.6 + 0.3 * std::sin(time * 12) : 1;
    spr(A.shadow, x - 18, y - 6, false, 0.8, 2.2, 1.8);
    spr(s0, x - s0->w * sc / 2, y - s0->h * sc - e.z + 4, e.dir == 2, a, sc, sc, fl);
    if (dark) for (int s = -1; s <= 1; s += 2) spr(A.spark, x + s * 5 - 3, y - 48 - e.z, false, e.state == 6 ? 0.6 + 0.4 * std::sin(time * 20) : 0.9, 0.9, 0.9);
    if (e.state == 8) for (int i = 0; i < 3; i++) spr(A.spark, x - 4 + std::cos(time * 6 + i * 2.1) * 14, y - 64 + std::sin(time * 6 + i * 2.1) * 4, false, 0.9, 0.7, 0.7);
  };
  EXT.draw[E_MISTHAND] = [this](Ent& e, double x, double y, bool fl) {
    double k = clampf(1 - e.z / 40, 0.4, 1);
    spr(A.shadow, x - 10 * k, y - 4, false, 0.5 + 0.4 * k, 1.3 * k, 1.1 * k);
    if (e.state == 1) g->ellipse(x, y - 2, 10, 5, rgba(255, 80, 120, 0.4 + 0.4 * std::sin(time * 20)), 1);
    spr(A.mistHand, x - 12, y - 18 - e.z, e.dir == 2, e.state == 3 ? 1 : 0.85, 1, 1, fl);
  };
}
// kuledeki baba (bir kez)
void Game::addFather() {
  if (map.kind != MAP_DUNGEON4) return;
  for (auto& n : npcs) if (n->id == N_FATHER) return;
  addNPC(N_FATHER, RW + 10, 4, A.father, "Baba");
}
// Sis Efendisi'nin iki eli
void Game::spawnHands() {
  Ent* lord = firstEnt(E_LORD); if (!lord) return;
  double lx = lord->x, ly = lord->y; int room = lord->room, uid = lord->uid;
  for (int sg = -1; sg <= 1; sg += 2) { Ent& h = spawn(E_MISTHAND, lx + sg * 50, ly + 30); h.room = room; h.own = uid; h.z = 10; h.inv = true; h.hp = 99; poof(h.x, h.y - 10); }
}
// rüzgâr çizgileri: esinti varken hızlı ve parlak
void Game::windFx(int t, int x, int y, double sx, double sy) {
  bool on = windOn(); double dx = t == T_WIND_L ? -1 : t == T_WIND_R ? 1 : 0, dy = t == T_WIND_U ? -1 : t == T_WIND_D ? 1 : 0;
  double ang = std::atan2(dy, dx);
  for (int k = 0; k < 2; k++) {
    double ph = std::fmod(time * (on ? 64 : 14) + hash2(x * 3 + k, y * 5) * 16 + k * 8, 16.0) - 8;
    double cx = sx + 8 + dx * ph + (dx == 0 ? (k ? 4 : -4) : 0), cy = sy + 8 + dy * ph + (dy == 0 ? (k ? 4 : -4) : 0);
    rot(A.windStreak, cx, cy, 7, 1, ang, on ? 1.0 : 0.4);
  }
}
