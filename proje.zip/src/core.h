// ORMANIN KALBİ - çekirdek: matematik, rastgelelik, renkler, harita, varlıklar
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <algorithm>
#include <unordered_map>
#include <map>
#include "gen_art.h"

using std::string;
constexpr double PI = 3.14159265358979323846;
inline double clampf(double v, double a, double b) { return v < a ? a : v > b ? b : v; }
inline double lerpf(double a, double b, double t) { return a + (b - a) * t; }
inline double sstep(double a, double b, double x) { double t = clampf((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
inline double angWrap(double a) { while (a > PI) a -= 2 * PI; while (a < -PI) a += 2 * PI; return a; }
inline double sgn(double v) { return v > 0 ? 1 : v < 0 ? -1 : 0; }
// JavaScript'in "x | 0" işlemi: sıfıra doğru kes, 32 bit tamsayı
inline int I(double v) { return (int)(int64_t)std::trunc(v); }
// JavaScript'in % işlemi (kalan, bölünenin işaretini taşır)
inline double fmodj(double a, double b) { return std::fmod(a, b); }
inline double hash2(double xd, double yd) {
  uint32_t x = (uint32_t)I(xd), y = (uint32_t)I(yd);
  uint32_t h = x * 374761393u + y * 668265263u;
  h = (h ^ (h >> 13)) * 1274126177u;
  h = h ^ (h >> 16);
  return (h & 0xFFFFFF) / 16777216.0;
}
struct Rng {
  uint32_t s;
  explicit Rng(uint32_t seed) { s = seed * 2654435761u + 12345u; if (!s) s = 1; }
  uint32_t next() { uint32_t v = s; v ^= v << 13; v ^= v >> 17; v ^= v << 5; s = v; return v; }
  double f() { return (next() & 0xFFFFFF) / 16777216.0; }
  double range(double a, double b) { return a + (b - a) * f(); }
};

// renk: 0xRRGGBB + saydamlık (0..1)
struct Col { float r, g, b, a; };
inline Col hexc(uint32_t h, double a = 1) { return { ((h >> 16) & 255) / 255.f, ((h >> 8) & 255) / 255.f, (h & 255) / 255.f, (float)a }; }
inline Col rgba(double r, double g, double b, double a) { return { (float)(r / 255), (float)(g / 255), (float)(b / 255), (float)clampf(a, 0, 1) }; }

// UTF-8 yardımcıları (diyaloglar harf harf yazılır)
size_t u8len(const string& s);
string u8prefix(const string& s, size_t n);
std::vector<string> u8chars(const string& s);
std::vector<string> splitStr(const string& s, char c);
string fmt(const char* f, ...);
// kalıcı küçük kayıtlar (platform uygular: dosya)
string storeGet(const string& key);
void storeSet(const string& key, const string& val);

// ---------------- harita ----------------
enum {
  T_GRASS = 0, T_PATH = 1, T_SAND = 2, T_WATER = 3, T_BRIDGEH = 4, T_BRIDGEV = 5, T_CLIFF = 6, T_PLATEAU = 7, T_DFLOOR = 8, T_DWALL = 9, T_DTOP = 10,
  T_DOOR_OPEN = 11, T_DOOR_SHUT = 12, T_DOOR_LOCK = 13, T_DOOR_BOSS = 14, T_STAIRS = 15, T_CARPET = 16, T_WFLOOR = 17, T_IWALL = 18, T_ITOP = 19, T_EXIT = 20, T_PLATE = 21,
  T_SNOW = 22, T_SNOWPATH = 23, T_ICE = 24, T_SNOWCLIFF = 25, T_SNOWTOP = 26, T_PASS = 27, T_ICEWATER = 28,
  T_CFLOOR = 29, T_CWALL = 30, T_CTOP = 31,
  T_SHALLOW = 32, T_TIDE = 33, T_REEF = 34, T_RUIN = 35, T_RUINWALL = 36,
  T_VOID = 37, T_CLOUD = 38, T_CLOUDGAP = 39, T_WIND_L = 40, T_WIND_R = 41, T_WIND_U = 42, T_WIND_D = 43, T_SKYGRASS = 44, T_MARBLE = 45, T_ISLEEDGE = 46,
};
inline bool isWindT(int t) { return t >= T_WIND_L && t <= T_WIND_D; }
enum {
  O_TREE = 0, O_TREE2 = 1, O_BUSH = 2, O_ROCK = 3, O_HOUSE = 4, O_WELL = 5, O_STALL = 6, O_FENCE = 7, O_SIGN = 8, O_FLOWER = 9, O_CHEST = 10, O_POT = 11,
  O_TORCH = 12, O_CAVE = 13, O_TEMPLE = 14, O_STUMP = 15, O_THORN = 16, O_LAMP = 17, O_BED = 18, O_TABLE = 19, O_CHAIR = 20, O_SHELF = 21, O_FIRE = 22, O_WINDOW = 23, O_PLANT = 24,
  O_OVEN = 25, O_COUNTER = 26, O_RUG = 27, O_BLOCK = 28,
  O_PINE = 29, O_SNOWBUSH = 30, O_SNOWROCK = 31, O_SNOWMAN = 32, O_ICEWALL = 33, O_FROZEN = 34, O_ANVIL = 35, O_CABIN = 36,
  O_ICETEMPLE = 37, O_YETICAVE = 38, O_SNOWPILE = 39, O_CRYSTAL = 40, O_CAMPFIRE = 41,
  O_HUT = 42, O_PALM = 43, O_BOAT = 44, O_PILLAR = 45, O_SHELL = 46, O_LIGHTHOUSE = 47, O_WRECK = 48, O_PALACE = 49, O_CORAL = 50, O_BARREL = 51,
  O_SKYHOUSE = 52, O_WINDMILL = 53, O_CLOUDSTONE = 54, O_NEST = 55, O_TOWER = 56, O_STARBEAM = 57, O_CLOUDBUSH = 58, O_BRAZIER = 59, O_PEDESTAL = 60, O_GAMETABLE = 61,
};
enum { MAP_OVER = 0, MAP_DUNGEON = 1, MAP_INTERIOR = 2, MAP_SNOW = 3, MAP_DUNGEON2 = 4, MAP_CAVE = 5, MAP_SEA = 6, MAP_DUNGEON3 = 7, MAP_SKY = 8, MAP_DUNGEON4 = 9, MAP_MIRROR = 10, MAP_GAMEISLE = 11 };
constexpr int OW = 136, OH = 72, IW = 14, IH = 10, RW = 20, RH = 11, SW = 108, SH = 56, PASS_X = 58, SEA_W = 120, SEA_H = 58, SKY_W = 168, SKY_H = 52, TOWER_ROWS = 5;
inline bool isDg(int k) { return k == MAP_DUNGEON || k == MAP_DUNGEON2 || k == MAP_DUNGEON3 || k == MAP_DUNGEON4; }
inline bool isOut(int k) { return k == MAP_OVER || k == MAP_SNOW || k == MAP_SEA || k == MAP_SKY || k == MAP_GAMEISLE; }

extern bool SOLID_X[256];
bool tileSolid(int v);

struct Obj {
  int type = 0; double x = 0, y = 0; int var = 0, id = 0, tx = 0, ty = 0, tw = 1, th = 1; bool alive = true, solid = true; string text;
  double a = 0; int lock = 0, room = -1;
};
struct WorldMap {
  int W = 0, H = 0, kind = 0, gen = 0;
  std::vector<uint8_t> t, blk; std::vector<int> lockId;
  std::vector<std::unique_ptr<Obj>> objs;
  void init(int w, int h, int k, int fill);
  void set(int x, int y, int v) { if (x >= 0 && y >= 0 && x < W && y < H) t[y * W + x] = (uint8_t)v; }
  int get(int x, int y) const;
  bool solid(int x, int y) const;
  Obj& add(int type, int tx, int ty, int tw = 1, int th = 1, bool solid = true);
  bool free(int tx, int ty, int tw, int th) const;
  void removeObj(Obj& o);
  Obj& last() { return *objs.back(); }
};
// JavaScript'teki "for (const o of dizi)" gibi: döngü sırasında eklenenler de gezilir
#define EACH(v, arr) for (size_t _i_##v = 0; _i_##v < (arr).size(); _i_##v++) if (auto& v = *(arr)[_i_##v]; true)

void mline(WorldMap& m, int x0, int y0, int x1, int y1, int v, int r = 1);
struct Room { int ix, iy; bool dark, cleared; };
void buildOverworld(WorldMap& m);
void populateOverworld(WorldMap& m);
void buildInterior(WorldMap& m, int id);
void buildDungeon(WorldMap& m, std::vector<Room>& rooms);
void addNorthPass(WorldMap& m, bool open);
void buildSnow(WorldMap& m);
void populateSnow(WorldMap& m, uint32_t iceMask);
void buildIceTemple(WorldMap& m, std::vector<Room>& rooms);
void buildInn(WorldMap& m);
// doğuya eklenen yeni bölgeler (genis.cpp)
void extendOverworld(WorldMap& m);
void extendOverworldObjs(WorldMap& m, int flags);
void extendSnow(WorldMap& m);
void extendSnowObjs(WorldMap& m, uint32_t iceMask);
void extendSea(WorldMap& m);
void extendSeaObjs(WorldMap& m);

// ---------------- varlıklar ----------------
inline int nextUid() { static int n = 0; return ++n; }
struct Ent {
  int uid = nextUid();
  int type = 0; double x = 0, y = 0, vx = 0, vy = 0, z = 0, vz = 0, hp = 1, maxHp = 1; int dir = 0, state = 0, lastHit = -1, room = -1;
  double t = 0, cd = 0, flash = 0, kt = 0, kx = 0, ky = 0, hx = 0, hy = 0, gx = 0, gy = 0, rage = 0; bool alive = true, inv = false, called = false;
  string invMsg; int hits = 0, own = 0, nid = 0;
};
struct Pick { int type = 0; double x = 0, y = 0, z = 0, vz = 0, t = 0; bool alive = true; int val = 1; };
struct Part { int kind = 0; double x = 0, y = 0, vx = 0, vy = 0, t = 0, life = 0, rot = 0; uint32_t col = 0; };
struct Npc { int id = 0; double x = 0, y = 0; const Spr* spr = nullptr; string name; bool flip = false; double t = 0; int blkI = -1, gen = 0; };
struct Line { string who, text; };
inline Line L(const string& who, const string& text) { return { who, text }; }

// girdi: o karede basılanlar ve çubuk
struct Press {
  bool up = false, down = false, left = false, right = false, attack = false, act = false, item = false, log = false, pause = false, confirm = false;
  void clear() { *this = Press(); }
  bool any() const { return up || down || left || right || attack || act || item || log || pause || confirm; }
};
struct Input { Press pressed; double ax = 0, ay = 0; };
