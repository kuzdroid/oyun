// ORMANIN KALBİ - kodla üretilen müzik ve ses efektleri
#include "audio.h"
#include "core.h"

// 8-bit macera havası: kök, dizi, akor yürüyüşü, akor süresi, vuruş, arpej olasılığı, ses düzeyleri, arpej oktavı, melodi, davul
static const Mood MOODS[] = {
  { 261.6, {0, 2, 4, 5, 7, 9, 11}, {0, 3, 4, 0}, 2.4, 0.2, 0.75, 0.022, 0.10, 0.08, 1, 0.7, 0.06, 1 },     // 0 köy
  { 196.0, {0, 2, 4, 5, 7, 9, 10}, {0, 6, 3, 4}, 2.0, 0.16, 0.8, 0.022, 0.10, 0.09, 2, 0.65, 0.055, 2 },   // 1 ova
  { 146.8, {0, 2, 3, 5, 7, 9, 10}, {0, 3, 0, 6}, 3.2, 0.27, 0.6, 0.025, 0.10, 0.08, 2, 0.5, 0.05, 0 },     // 2 orman
  { 110.0, {0, 2, 3, 5, 7, 8, 10}, {0, 5, 6, 4}, 3.6, 0.3, 0.5, 0.026, 0.09, 0.10, 4, 0.35, 0.045, 0 },    // 3 zindan
  { 164.8, {0, 2, 3, 5, 7, 8, 11}, {0, 5, 3, 4}, 1.6, 0.125, 0.85, 0.028, 0.10, 0.12, 2, 0.7, 0.055, 2 },  // 4 boss
  { 174.6, {0, 2, 4, 5, 7, 9, 11}, {0, 4, 5, 3}, 2.4, 0.2, 0.8, 0.024, 0.10, 0.08, 2, 0.8, 0.06, 1 },      // 5 zafer
  { 130.8, {0, 2, 3, 5, 7, 8, 10}, {0, 5, 3, 4}, 4.0, 0.5, 0.3, 0.024, 0.08, 0.06, 2, 0.3, 0.045, 0 },     // 6 gece
  { 196.0, {0, 2, 4, 5, 7, 9, 11}, {0, 5, 3, 4}, 3.0, 0.25, 0.7, 0.024, 0.10, 0.08, 2, 0.6, 0.055, 0 },    // 7 başlık
  { 146.8, {0, 2, 4, 6, 7, 9, 11}, {0, 4, 5, 3}, 3.0, 0.25, 0.55, 0.026, 0.08, 0.07, 4, 0.5, 0.05, 0 },    // 8 Karlı Dağlar
  { 196.0, {0, 2, 3, 5, 7, 9, 10}, {0, 3, 0, 4}, 2.16, 0.18, 0.7, 0.024, 0.09, 0.08, 2, 0.75, 0.06, 1 },  // 9 Ayazköy
  { 123.5, {0, 1, 3, 5, 7, 8, 10}, {0, 1, 5, 6}, 3.6, 0.3, 0.45, 0.026, 0.08, 0.09, 4, 0.35, 0.045, 0 },   // 10 Buz Tapınağı
  { 155.6, {0, 2, 3, 5, 7, 8, 11}, {0, 5, 4, 0}, 1.6, 0.125, 0.9, 0.028, 0.10, 0.12, 2, 0.75, 0.055, 2 }, // 11 Buz Devi
  { 116.5, {0, 2, 3, 5, 7, 8, 10}, {0, 5, 3, 6}, 4.4, 0.55, 0.3, 0.026, 0.07, 0.06, 2, 0.3, 0.04, 0 },     // 12 kar fırtınası gecesi
  { 220.0, {0, 2, 4, 5, 7, 9, 11}, {0, 3, 4, 3}, 1.92, 0.16, 0.8, 0.022, 0.09, 0.09, 2, 0.8, 0.06, 1 },   // 13 Mercanköy
  { 164.8, {0, 2, 4, 7, 9, 11, 12}, {0, 3, 1, 4}, 2.7, 0.225, 0.65, 0.026, 0.08, 0.07, 2, 0.6, 0.05, 0 }, // 14 açık deniz
  { 130.8, {0, 2, 4, 6, 8, 10, 12}, {0, 1, 0, 3}, 3.6, 0.3, 0.45, 0.026, 0.08, 0.08, 4, 0.35, 0.045, 0 },  // 15 Batık Saray
  { 146.8, {0, 1, 4, 5, 7, 8, 10}, {0, 1, 5, 0}, 1.6, 0.125, 0.9, 0.028, 0.10, 0.13, 2, 0.7, 0.055, 2 },  // 16 Derin Kraken
  { 110.0, {0, 2, 3, 6, 7, 8, 11}, {0, 3, 4, 0}, 2.4, 0.2, 0.7, 0.026, 0.09, 0.1, 2, 0.6, 0.05, 1 },      // 17 Hayalet Kaptan
};
constexpr double TAU = 2 * PI;

double Synth::noise() { ns = ns * 1664525u + 1013904223u; return ((ns >> 9) & 0x7FFF) / 16384.0 - 1; }
double Synth::noteF(const Mood& m, int deg) {
  int key = mood * 1000 + deg + 200;
  auto it = nf.find(key);
  if (it != nf.end()) return it->second;
  int oct = deg >= 0 ? (int)std::floor(deg / 7.0) : -(int)std::floor((-deg + 6) / 7.0), d = deg - oct * 7;
  double f = m.root * std::pow(2.0, (m.scale[d] + 12 * oct) / 12.0); nf[key] = f;
  return f;
}
Synth::PadC& Synth::padFreqs(const Mood& m, int k) {
  PadC& c = padC[k & 1];
  if (c.k != k || c.mood != mood) {
    int deg = m.prog[((k % 4) + 4) % 4];
    c.k = k; c.mood = mood; c.f[0] = noteF(m, deg); c.f[1] = noteF(m, deg + 2); c.f[2] = noteF(m, deg + 4); c.fb = noteF(m, deg - 7) * 0.5;
  }
  return c;
}
double Synth::chordPad(const Mood& m, int k, double tt, double env) {
  if (env <= 0) return 0;
  PadC& c = padFreqs(m, k); double w = TAU * tt, s = 0;
  for (int n = 0; n < 3; n++) { double f = c.f[n]; s += std::sin(std::fmod(w * f, TAU)) + 0.3 * std::sin(std::fmod(w * f * 2.003, TAU)); }
  return (s * m.padAmp + std::sin(std::fmod(w * c.fb, TAU)) * m.bassAmp) * env;
}
Synth::ArpC& Synth::arpEv(const Mood& m, long bb) {
  ArpC& c = arpC[bb & 7];
  if (c.bb != bb || c.mood != mood) {
    c.bb = bb; c.mood = mood; c.play = hash2((double)bb, mood * 97 + 3) <= m.arpProb;
    static const int ar[4] = { 0, 2, 4, 7 };
    if (c.play) { long ck = (long)std::floor(bb * m.beat / m.chordDur); c.f = noteF(m, m.prog[ck % 4] + ar[I(hash2((double)bb, 7) * 4) & 3]) * m.arpOct; }
  }
  return c;
}
double Synth::music(double tt) {
  const Mood& m = MOODS[mood]; int k = (int)std::floor(tt / m.chordDur); double local = tt - k * m.chordDur;
  double s = chordPad(m, k, tt, std::min(1.0, local / 1.2));
  if (k > 0) s += chordPad(m, k - 1, tt, std::max(0.0, 1 - local / 1.5));
  long b = (long)std::floor(tt / m.beat);
  for (int j = 0; j < 3; j++) {
    long bb = b - j; if (bb < 0) continue;
    ArpC& ev = arpEv(m, bb); if (!ev.play) continue;
    double dt = tt - bb * m.beat, env = std::exp(-dt * 4) * std::min(1.0, dt * 200), ph = TAU * ev.f * dt;
    s += (std::sin(ph) + 0.25 * std::sin(2 * ph) * env) * env * m.arpAmp;
  }
  return s + melody(m, tt, k) + drums(m, tt);
}
Synth::MelC& Synth::melEv(const Mood& m, long bb, int sec, double step) {
  MelC& c = melC[bb & 3];
  if (c.bb != bb || c.mood != mood || c.sec != sec) {
    c.bb = bb; c.mood = mood; c.sec = sec;
    int pos = (int)(bb % 16), seed = mood * 131 + sec * 17;
    c.play = !(hash2(pos, seed) > m.mel || (pos % 8 == 7 && hash2(pos, seed + 1) > 0.3));
    if (c.play) {
      int chord = m.prog[(long)std::floor(bb * step / m.chordDur) % 4]; double h = hash2(pos + 40, seed + 3);
      c.f = noteF(m, chord + (h < 0.4 ? 0 : h < 0.7 ? 2 : h < 0.9 ? 4 : 5) + (pos >= 8 && sec ? 7 : 0)) * 2;
      c.len = step * (hash2(pos, seed + 9) > 0.7 ? 1.9 : 0.9);
    }
  }
  return c;
}
double Synth::melody(const Mood& m, double tt, int k) {
  if (!m.mel) return 0;
  double step = m.beat * 2; long b = (long)std::floor(tt / step); int sec = (int)std::floor(k / 4.0) & 1;
  double s = 0;
  for (int j = 0; j < 2; j++) {
    long bb = b - j; if (bb < 0) continue;
    MelC& ev = melEv(m, bb, sec, step); if (!ev.play) continue;
    double dt = tt - bb * step, len = ev.len;
    if (dt > len + 0.25) continue;
    double env = std::min(1.0, dt * 120) * std::exp(-dt * 2.2) * (dt > len ? std::max(0.0, 1 - (dt - len) * 4) : 1);
    double ph = TAU * ev.f * dt * (1 + 0.004 * std::sin(TAU * 5.5 * dt) * std::min(1.0, dt * 3));
    s += (std::sin(ph) + 0.3 * std::sin(3 * ph) + 0.12 * std::sin(5 * ph)) * env * m.melAmp;
  }
  return s;
}
double Synth::drums(const Mood& m, double tt) {
  if (!m.drum) return 0;
  double st = m.beat; long b = (long)std::floor(tt / st); double dt = tt - b * st; int pos = (int)(b % 8);
  double s = 0;
  if (pos == 0 || pos == 4 || (m.drum == 2 && pos == 6)) s += std::sin(TAU * (48 + 110 * std::exp(-dt * 28)) * dt) * std::exp(-dt * 11) * 0.22;
  if (m.drum == 2 && (pos == 2 || pos == 6)) s += noise() * std::exp(-dt * 22) * 0.07;
  if (pos % 2 == 1) s += noise() * std::exp(-dt * 70) * (m.drum == 2 ? 0.045 : 0.03);
  return s;
}
double Synth::sfx(Voice& v) {
  double t = v.t, s = 0, n;
  switch (v.type) {
    case SFX_CHIME: s = std::sin(TAU * (t < 0.1 ? 880 : 1318.5) * t) * std::exp(-t * 5) * 0.22; if (t > 0.8) v.amp = 0; break;
    case SFX_FIRE: n = noise(); v.lp += (n - v.lp) * 0.15; s = v.lp * std::exp(-t * 3) * 0.5 + std::sin(TAU * 70 * t) * std::exp(-t * 9) * 0.25; if (t > 1.2) v.amp = 0; break;
    case SFX_HURT: s = std::sin(TAU * (200 * t - 70 * t * t)) * std::exp(-t * 4) * 0.3 + noise() * std::exp(-t * 10) * 0.08; if (t > 0.8) v.amp = 0; break;
    case SFX_BLIP: s = std::sin(TAU * 1100 * t) * std::exp(-t * 45) * 0.07; if (t > 0.12) v.amp = 0; break;
    case SFX_MAGIC: { const double fs[4] = { 523.3, 659.3, 784.0, 1046.5 }; for (int i = 0; i < 4; i++) { double lt = t - i * 0.09; if (lt > 0) s += std::sin(TAU * fs[i] * lt) * std::exp(-lt * 5) * 0.12; } if (t > 1.4) v.amp = 0; break; }
    case SFX_RUMBLE: { n = noise(); v.lp += (n - v.lp) * 0.03; double e = std::min(1.0, t * 3) * std::max(0.0, 1 - t / 2.2); s = (v.lp * 1.4 + std::sin(TAU * 42 * t) * 0.4) * e * 0.5; if (t > 2.2) v.amp = 0; break; }
    case SFX_SHATTER: { s = noise() * std::exp(-t * 7) * 0.25; const double fs[3] = { 1568, 2093, 2637 }; for (int i = 0; i < 3; i++) s += std::sin(TAU * fs[i] * t) * std::exp(-t * (3 + i)) * 0.08; if (t > 1.5) v.amp = 0; break; }
    case SFX_GROWL: { n = noise(); v.lp += (n - v.lp) * 0.04; double rough = 0.6 + 0.4 * std::sin(TAU * 23 * t), env = std::min(1.0, t * 5) * std::max(0.0, 1 - t / 1.1);
      s = (v.lp * 2.2 * rough + std::sin(TAU * (65 + 10 * std::sin(t * 9)) * t) * 0.35 * rough) * env * 0.35; if (t > 1.1) v.amp = 0; break; }
    case SFX_SNORT: { n = noise(); v.lp += (n - v.lp) * 0.12; double ph = std::fmod(t, 0.22), env = (ph < 0.12 ? std::sin(ph / 0.12 * PI) : 0) * std::max(0.0, 1 - t / 0.7);
      s = (v.lp * 1.6 + std::sin(TAU * 110 * t) * 0.3) * env * 0.35; if (t > 0.7) v.amp = 0; break; }
    case SFX_SWING: { n = noise(); double w = std::sin(std::min(1.0, t / 0.25) * PI); v.lp += (n - v.lp) * (0.05 + 0.4 * w); s = (n - v.lp) * w * 0.18; if (t > 0.25) v.amp = 0; break; }
    case SFX_HIT: n = noise(); v.lp += (n - v.lp) * 0.25; s = (v.lp * 1.5 + std::sin(TAU * 90 * t) * 0.8) * std::exp(-t * 25) * 0.45; if (t > 0.25) v.amp = 0; break;
    case SFX_EAT: n = noise(); v.lp += (n - v.lp) * 0.3; s = (n - v.lp) * std::exp(-std::fmod(t, 0.16) * 40) * 0.25; if (t > 0.5) v.amp = 0; break;
    case SFX_CLICK: s = noise() * std::exp(-t * 300) * 0.25 + std::sin(TAU * 900 * t) * std::exp(-t * 80) * 0.05; if (t > 0.06) v.amp = 0; break;
    case SFX_SELECT: s = std::sin(TAU * 760 * t) * std::exp(-t * 30) * 0.08; if (t > 0.15) v.amp = 0; break;
    case SFX_LAUGH: {   // yaşlı, hırıltılı "gyah gyah gyah": üç hece, formant sentezi
      for (int i = 0; i < 3; i++) {
        double lt = t - i * 0.26; if (lt < 0 || lt > 0.22) continue;
        double f0 = 165 - lt * 140 + (2 - i) * 12 + std::sin(lt * 70) * 6;
        double env = std::min(1.0, lt * 35) * std::pow(std::max(0.0, 1 - lt / 0.22), 0.6);
        double vow = std::min(1.0, lt / 0.06), F1 = 300 + 450 * vow, F2 = 2100 - 900 * vow, vo = 0;
        for (int h = 1; h <= 18; h++) { double hf = h * f0, a = (hf - F1) / 160, b = (hf - F2) / 260, g = std::exp(-a * a) + 0.7 * std::exp(-b * b) + 0.05; vo += std::sin(TAU * hf * lt) * g / std::sqrt((double)h); }
        if (lt < 0.025) vo += noise() * (1 - lt / 0.025) * 1.2;
        vo += noise() * 0.25;
        s += vo * env * 0.09;
      }
      if (t > 0.8) v.amp = 0; break;
    }
    case SFX_SPLASH: n = noise(); v.lp += (n - v.lp) * 0.35; s = (n - v.lp) * std::exp(-t * 9) * 0.3 + std::sin(TAU * (300 - t * 400) * t) * std::exp(-t * 14) * 0.08; if (t > 0.5) v.amp = 0; break;
    default: v.amp = 0;
  }
  return s * v.amp;
}
void Synth::fill(float* out, int N) {
  std::lock_guard<std::mutex> lk(mu);
  int dec = std::max(1, (int)std::lround(SR / 24000)); double sr = SR / dec, dt = 1 / sr;
  if (muted) { for (int i = 0; i < N; i++) out[i] = 0; voices.clear(); return; }
  for (int i = 0; i < N; i += dec) {
    if (nextMood != mood) { mgain -= 1 / (sr * 1.2); if (mgain <= 0) { mgain = 0; mood = nextMood; t = 0; } }
    else if (mgain < 1) mgain = std::min(1.0, mgain + 1 / (sr * 2.5));
    double s = mgain > 0 ? music(t) * mgain * 0.8 : 0;
    t += dt;
    for (auto& v : voices) { s += sfx(v); v.t += dt; }
    s *= master;
    s = s / (1 + std::fabs(s) * 0.3);
    float o = (float)(clampf(s, -1, 1) * 0.92);
    for (int j = 0; j < dec && i + j < N; j++) out[i + j] = o;
  }
  voices.erase(std::remove_if(voices.begin(), voices.end(), [](const Voice& v) { return v.amp <= 0; }), voices.end());
}
void Synth::play(int type, double amp) { std::lock_guard<std::mutex> lk(mu); if (ok && voices.size() < 24) voices.push_back({ type, 0, amp, 0 }); }
void Synth::setMood(int m) { std::lock_guard<std::mutex> lk(mu); nextMood = m; if (!ok) mood = m; }
