// ORMANIN KALBİ - çizim: düşük çözünürlüklü dünya ve ekran çözünürlüğünde arayüz
#include "game.h"

// ---------------- çizim: düşük çözünürlüklü tuval ----------------
// s: atlas sprite'ı; flash: beyaz yanıp sönme; a: saydamlık
void Game::spr(const Spr* sp, double x, double y, bool flip /*= false*/, double a /*= 1*/, double sx /*= 1*/, double sy /*= 1*/, bool flash /*= false*/) {
  if (!sp) return;
  const Spr* src = flash && sp->f ? sp->f : sp;
  double w = sp->w * sx, h = sp->h * sy;
  g->sprite(src, std::round(x), std::round(y), w, h, flip, clampf(a, 0, 1));
}
void Game::rot(const Spr* sp, double x, double y, double ox, double oy, double ang, double a /*= 1*/, double sc /*= 1*/, bool flash /*= false*/) {
  if (!sp) return;
  const Spr* src = flash && sp->f ? sp->f : sp;
  g->spriteRot(src, x, y, ox, oy, ang, sc, std::max(0.0, std::min(1.0, a)));
}
void Game::fillLo(double x, double y, double w, double h, Col c) { g->rect(x, y, w, h, c); }
void Game::drawTile(int x, int y, double sx, double sy) {
  int t = map.get(x, y); double tm = time;
  if (EXT.tileAll.count(map.kind)) { EXT.tileAll[map.kind](t, x, y, sx, sy); return; }
  if (map.kind == MAP_DUNGEON2 || t >= T_SNOW || EXT.mood.count(map.kind)) { drawTile2(t, x, y, sx, sy); return; }
  switch (t) {
    case T_GRASS: spr(A.grass[I(hash2(x, y) * 4) & 3], sx, sy); break;
    case T_PATH: spr(A.path, sx, sy); break;
    case T_SAND: spr(A.sand, sx, sy); break;
    case T_WATER: spr(A.water[(I(tm * 3) + ((x + y * 3) & 3)) & 3], sx, sy); break;
    case T_BRIDGEH: spr(A.water[I(tm * 3) & 3], sx, sy); spr(A.bridgeH, sx, sy); break;
    case T_CLIFF: spr(A.cliff, sx, sy); break;
    case T_PLATEAU: spr(A.plateau, sx, sy); break;
    case T_DFLOOR: case T_DOOR_OPEN: spr(A.dfloor[(x + y) & 1], sx, sy); break;
    case T_CARPET: spr(A.carpet, sx, sy); break;
    case T_STAIRS: spr(A.stairs, sx, sy); break;
    case T_DWALL: spr(A.dwall, sx, sy); break;
    case T_DTOP: spr(A.dwallTop, sx, sy); break;
    case T_DOOR_SHUT: spr(A.doorShut, sx, sy); break;
    case T_DOOR_LOCK: spr(A.doorLock, sx, sy); break;
    case T_DOOR_BOSS: spr(A.doorBoss, sx, sy); break;
    case T_PLATE: spr(A.plate[(flags & F_BLOCK) ? 1 : 0], sx, sy); break;
    case T_WFLOOR: spr(A.wfloor, sx, sy); break;
    case T_IWALL: spr(A.iwall, sx, sy); break;
    case T_ITOP: spr(A.iwallTop, sx, sy); break;
    case T_EXIT: spr(A.wfloor, sx, sy); if ((x & 1) == 0) spr(A.mat, sx, sy + 4); break;
  }
  if (t == T_WATER) {
    static const int nx[4] = { 0, 1, 0, -1 }, ny[4] = { -1, 0, 1, 0 };
    for (int k = 0; k < 4; k++) {
      int o = map.get(x + nx[k], y + ny[k]);
      if (o != T_WATER && o != T_BRIDGEH) { double wob = std::sin(tm * 2 + x + y) * 0.6; rot(A.foam, sx + 8, sy + 8, 8, 8 - wob, k * PI / 2, 0.85); }
    }
  }
}
void Game::drawObj(Obj& o, double ox, double oy, int idx) {
  double x = o.x - ox, y = o.y - oy, tm = time;
  switch (o.type) {
    case O_TREE: case O_TREE2: spr(A.shadow, x - 14, y - 4, false, 1, 1.8, 1.3); spr(A.tree[o.type == O_TREE2 ? 1 : 0], x - 17, y - 41); break;
    case O_BUSH: spr(A.shadow, x - 8, y - 4); spr(A.bush, x - 9, y - 15); break;
    case O_THORN: spr(A.shadow, x - 8, y - 4); spr(A.thornBush, x - 9, y - 15); break;
    case O_ROCK: spr(A.shadow, x - 8, y - 4); spr(A.rockBig, x - 9, y - 15); break;
    case O_HOUSE: spr(A.house[o.var % 3], x - 26, y - 53); break;
    case O_WELL: spr(A.well, x - 13, y - 26); break;
    case O_STALL: spr(A.stall, x - 18, y - 30); break;
    case O_FENCE: spr(A.fence, x - 9, y - 15); break;
    case O_SIGN: spr(A.sign, x - 8, y - 14); break;
    case O_FLOWER: spr(A.flower[o.var & 1], x - 8 + std::sin(tm * 2.2 + o.x * 0.1) * 0.8, y - 16); break;
    case O_CHEST: spr(A.shadow, x - 8, y - 4); spr((o.var & 0x100) ? A.chestOpen : A.chest, x - 9, y - 14); break;
    case O_POT: spr(A.shadow, x - 7, y - 4, false, 1, 0.9); spr(A.pot, x - 7, y - 12); break;
    case O_TORCH: spr(map.kind == MAP_DUNGEON2 ? A.torchBase2 : A.torchBase, x - 6, y - 15); if (o.var == 0) spr(A.flame[I(tm * 10 + o.x) % 3], x - 5, y - 26); break;
    case O_CAVE: spr(A.cave, x - 17, y - 25); break;
    case O_TEMPLE: spr(A.temple, x - 25, y - 43); break;
    case O_LAMP: spr(A.shadow, x - 5, y - 3, false, 1, 0.6); spr(A.lamp, x - 6, y - 28); break;
    case O_BED: spr(A.bed, x - 9, y - 30); break;
    case O_TABLE: spr(A.table, x - 14, y - 19); break;
    case O_CHAIR: spr(A.chair, x - 6, y - 15); break;
    case O_SHELF: spr(A.shelf, x - 9, y - 27); break;
    case O_FIRE: spr(A.fireplace, x - 14, y - 25); spr(A.flame[I(tm * 10) % 3], x - 5, y - 17); break;
    case O_WINDOW: spr(A.window, x - 8, y - 14); break;
    case O_PLANT: spr(A.plant, x - 7, y - 17); break;
    case O_OVEN: spr(A.oven, x - 15, y - 29); spr(A.flame[I(tm * 10) % 3], x - 5, y - 19); break;
    case O_COUNTER: spr(A.counter, x - 18, y - 17); break;
    case O_BLOCK: {
      double bx = x, by = y;
      if (idx == pushObj && pushAnim > 0) { double k = pushAnim / 0.25; bx = lerpf(x, pushFX - ox, k); by = lerpf(y, pushFY - oy, k); }
      spr(map.kind == MAP_DUNGEON2 ? A.block2 : map.kind == MAP_DUNGEON3 ? A.block3 : map.kind == MAP_DUNGEON4 ? A.block4 : A.block, bx - 9, by - 17); break;
    }
    default: drawObj2(o, x, y); break;
  }
}
const std::vector<std::vector<const Spr*>>& Game::heroSprites() { return heroSet ? *heroSet : A.hero; }
void Game::drawHero(double ox, double oy) {
  auto& HS = heroSprites();
  if (state == S_OVER) {
    static const int dd4[4] = { 0, 3, 1, 2 };
    int dd = dd4[I(deathT * 12) % 4];
    const Spr* sp = dd == 0 ? HS[0][0] : dd == 1 ? HS[1][0] : HS[2][0];
    spr(sp, px - ox - 9, py - oy - 17, dd == 2, deathT > 1 ? std::max(0.0, 2 - deathT) : 1);
    return;
  }
  if (invT > 0 && std::fmod(invT, 0.12) < 0.06) return;
  int frame = moving ? I(animT * 7) % 4 : 0, f = (frame == 1 || frame == 3) ? 1 : 0;
  bool flip = pdir == 2, mirrorStep = frame == 3 && (pdir == 0 || pdir == 1);
  const Spr* sp = pdir == 0 ? HS[0][f] : pdir == 1 ? HS[1][f] : HS[2][f];
  double lx = 0, ly = 0;
  if (attackT > 0) { double dx, dy; dirVec(pdir, dx, dy); lx = dx * 2; ly = dy * 2; }
  double bob = moving ? -std::fabs(std::sin(animT * 11)) : 0;
  spr(A.shadow, px - ox - 8, py - oy - 4);
  auto sword = [&] {
    if (attackT <= 0) return;
    double p = 1 - attackT / 0.24; int pd = pdir; double base = faceAng(pd);
    double ang = pd == 2 ? base + 1.3 - p * 1.9 : base - 1.3 + p * 1.9;
    double hx = px - ox + (pd == 3 ? 4 : pd == 2 ? -4 : pd == 0 ? 3 : -3), hy = py - oy - 7 + (pd == 0 ? 2 : pd == 1 ? -3 : 0);
    double sa = std::min(1.0, (1 - p) * 2.5) * 0.9;
    rot(A.swoosh, hx, hy, 2, 26, base - 0.8, sa, swordLv >= 2 ? 1.1 : 0.95);
    rot(swordLv >= 2 ? A.sword : A.woodSword, hx, hy, 4.5, swordLv >= 2 ? 13.5 : 12.5, ang);
  };
  if (pdir == 1) sword();
  spr(sp, px - ox - 9 + lx, py - oy - 17 + ly + bob, flip != mirrorStep);
  if (pdir != 1) sword();
  if ((flags & F_BASKET) && attackT <= 0) spr(A.bread, px - ox + (pdir == 2 ? -12 : 2), py - oy - 10 + bob, false, 1, 0.8, 0.8);
  if (freezeT > 0) spr(A.iceWall, px - ox - 9, py - oy - 19, false, std::min(0.55, freezeT * 0.6), 1, 1);
}
void Game::drawEnt(Ent& e, double ox, double oy) {
  double x = e.x - ox, y = e.y - oy; bool fl = e.flash > 0;
  switch (e.type) {
    case E_SLIME: case E_SLIMER: {
      auto& sp = e.type == E_SLIMER ? A.slimeR : A.slime;
      double sq = e.z > 0 ? 0.9 : 1 + 0.08 * std::sin(e.t * 8), st = e.z > 0 ? 1.15 : 1 / sq;
      spr(A.shadow, x - 7, y - 4, false, 1, 0.9);
      const Spr* s0 = sp[e.z > 0 ? 1 : 0];
      spr(s0, x - s0->w * sq / 2, y - s0->h * st - e.z + 1, false, 1, sq, st, fl);
      break;
    }
    case E_BOSS: {
      double sc = 3, sq = e.z > 0 ? 0.88 : 1 + 0.06 * std::sin(e.t * 6), st = e.z > 0 ? 1.15 : 1 / sq;
      spr(A.shadow, x - 24, y - 8, false, 1, 3, 2.5);
      int fr = e.z > 0 ? 1 : 0; const Spr* s0 = fl ? A.slime[fr] : A.bossSlime[fr];
      double w = s0->w * sc * sq, h = s0->h * sc * st;
      spr(s0, x - w / 2, y - h - e.z + 3, false, 1, sc * sq, sc * st, fl);
      spr(A.crown, x - A.crown->w * 1.2, y - h - e.z - 6 + std::sin(e.t * 6), false, 1, 2.4, 2.4);
      break;
    }
    case E_STUMP: {
      spr(A.shadow, x - 20, y - 6, false, 1, 2.5, 2);
      const Spr* s0 = A.stumpBoss[e.state ? 1 : 0]; double sq = 1 + 0.04 * std::sin(e.t * 4);
      spr(s0, x - s0->w * sq / 2, y - s0->h / sq + 2, false, 1, sq, 1 / sq, fl);
      break;
    }
    case E_BAT: { spr(A.shadow, x - 5, y - 4, false, 0.6, 0.7); const Spr* s0 = A.bat[I(e.t * 10) & 1]; spr(s0, x - s0->w / 2, y - s0->h - e.z, false, 1, 1, 1, fl); break; }
    case E_GHOST: { const Spr* s0 = A.ghost[I(e.t * 4) & 1]; spr(s0, x - s0->w / 2, y - s0->h - e.z, e.dir == 2, fl ? 1 : 0.62 + 0.12 * std::sin(e.t * 5), 1, 1, fl); break; }
    case E_OCTO: {
      spr(A.shadow, x - 8, y - 4);
      const Spr* s0 = A.octo[I(e.t * 6) & 1]; double r = e.dir == 0 ? 0 : e.dir == 1 ? PI : e.dir == 2 ? PI / 2 : -PI / 2;
      rot(s0, x, y - 7, s0->w / 2, s0->h / 2, r, 1, 1, fl);
      break;
    }
    case E_SKEL: { spr(A.shadow, x - 8, y - 4); spr(A.skel[I(e.t * 5) & 1], x - 9, y - 17 - e.z, e.dir == 2, 1, 1, 1, fl); break; }
    case E_WOLF: { spr(A.shadow, x - 8, y - 4); spr(A.wolf[I(e.t * (e.state == 1 ? 14 : 7)) & 1], x - 9, y - 13, e.dir == 2, 1, 1, 1, fl); break; }
    case E_BOAR: { spr(A.shadow, x - 8, y - 4); spr(A.boar[I(e.t * (e.state == 1 ? 14 : 5)) & 1], x - 9, y - 12, e.dir == 2, e.state == 2 ? 0.7 + 0.3 * std::sin(e.t * 20) : 1, 1, 1, fl); break; }
    case E_THORN: { spr(A.shadow, x - 7, y - 4, false, 1, 0.9); spr(A.thorn[e.state ? 1 : 0], x - 9, y - 15, false, 1, 1, 1, fl); break; }
    case E_CHICK: {
      spr(A.shadow, x - 6, y - 3, false, 1, 0.7);
      spr(A.chicken[(e.state ? I(e.t * 8) : 0) & 1], x - 7, y - 11 - (e.state == 2 ? std::fabs(std::sin(e.t * 20)) * 3 : 0), e.dir == 3, 1, 1, 1, fl);
      break;
    }
    case E_CAT: { spr(A.shadow, x - 6, y - 3, false, 1, 0.7); spr(A.cat[(e.vx != 0 ? I(e.t * 8) : 0) & 1], x - 7, y - 10, e.dir == 2); break; }
    case E_ROCKP: if (e.state == 9) break; spr(A.shadow, x - 4, y - 2, false, 1, 0.5); spr(A.rock, x - 4, y - 10); break;
    case E_SEED: spr(A.shadow, x - 4, y - 2, false, 1, 0.5); rot(A.seed, x, y - 7, 4, 4, e.t * 10); break;
    default: drawEnt2(e, x, y, fl); break;
  }
}
void Game::drawPick(Pick& k, double ox, double oy) {
  double x = k.x - ox, y = k.y - oy;
  if (k.t > 9 && (k.type == P_COIN || k.type == P_HEART) && std::fmod(k.t, 0.2) < 0.1) return;
  spr(A.shadow, x - 5, y - 3, false, 1, 0.6);
  double bob = k.z + (k.z <= 0 ? std::fabs(std::sin(k.t * 4)) * 2 : 0);
  switch (k.type) {
    case P_COIN: { const Spr* s0 = (k.val > 1 ? A.coinBlue : A.coin)[I(k.t * 8) & 3]; spr(s0, x - s0->w / 2, y - 12 - bob); break; }
    case P_HEART: spr(A.heart, x - 4, y - 11 - bob); break;
    case P_HEARTC: spr(A.heartBig, x - 9, y - 16 - bob); break;
    case P_GEM: spr(A.gem, x - 7, y - 18 - bob); break;
    case P_MUSH: spr(A.spark, x - 6, y - 18 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 1.6, 1.6); spr(A.mush, x - 6, y - 14 - bob); break;
    case P_FIRESTONE: spr(A.spark, x - 7, y - 19 - bob, false, 0.5 + 0.4 * std::sin(k.t * 6), 1.8, 1.8); spr(A.fireStone, x - 6, y - 15 - bob); break;
    case P_GEM2: spr(A.spark, x - 9, y - 22 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 2.2, 2.2); spr(A.gem2, x - 7, y - 18 - bob); break;
    default: drawPick2(k, x, y, bob); break;
  }
}
void Game::drawWorld(double ox, double oy) {
  WorldMap& m = map;
  int tx0 = (int)std::floor(ox / 16) - 1, ty0 = (int)std::floor(oy / 16) - 1;
  for (int y = ty0; y < ty0 + VH / 16 + 3; y++) for (int x = tx0; x < tx0 + VW / 16 + 3; x++) drawTile(x, y, x * 16 - ox, y * 16 - oy);
  EACH(o, m.objs) if (o.alive && o.type == O_RUG) for (int yy = 0; yy < o.th; yy++) for (int xx = 0; xx < o.tw; xx++) spr(A.rug, (o.tx + xx) * 16 - ox, (o.ty + yy) * 16 - oy);
  EACH(o, m.objs) if (o.alive && (o.type == O_FLOWER || o.type == O_WINDOW) && std::fabs(o.x - ox - VW / 2.0) < VW && std::fabs(o.y - oy - VH / 2.0) < VH) drawObj(o, ox, oy, -1);
  struct Item { double y; int kind, idx; };
  std::vector<Item> items;
  for (size_t i = 0; i < m.objs.size(); i++) {
    Obj& o = *m.objs[i];
    if (!o.alive || o.type == O_FLOWER || o.type == O_RUG || o.type == O_WINDOW) continue;
    if (o.x - ox < -60 || o.x - ox > VW + 60 || o.y - oy < -20 || o.y - oy > VH + 70) continue;
    items.push_back({ o.y, 0, (int)i });
  }
  for (size_t i = 0; i < ents.size(); i++) if (ents[i]->alive) items.push_back({ ents[i]->type == E_GHOST ? ents[i]->y + 30 : ents[i]->y, 1, (int)i });
  for (size_t i = 0; i < npcs.size(); i++) items.push_back({ npcs[i]->y, 2, (int)i });
  for (size_t i = 0; i < picks.size(); i++) items.push_back({ picks[i]->y, 3, (int)i });
  if (state == S_PLAY || state == S_OVER || state == S_PAUSE) items.push_back({ py, 4, 0 });
  if (p2 && !p2->deadT && (state == S_PLAY || state == S_PAUSE || state == S_OVER)) items.push_back({ p2->py, 5, 0 });
  std::stable_sort(items.begin(), items.end(), [](const Item& a, const Item& b) { return a.y < b.y; });
  for (auto& it : items) {
    if (it.kind == 0) drawObj(*m.objs[it.idx], ox, oy, it.idx);
    else if (it.kind == 1) drawEnt(*ents[it.idx], ox, oy);
    else if (it.kind == 2) {
      Npc& n = *npcs[it.idx]; double bob = std::sin(n.t * 2) > 0.7 ? -1 : 0;
      spr(A.shadow, n.x - ox - 8, n.y - oy - 4);
      spr(n.spr, n.x - ox - n.spr->w / 2, n.y - oy - n.spr->h + 1 + bob, n.flip);
    } else if (it.kind == 3) drawPick(*picks[it.idx], ox, oy);
    else if (it.kind == 4) drawHero(ox, oy);
    else drawP2(ox, oy);
  }
  for (auto& p : pts) {
    double x = p.x - ox, y = p.y - oy, k = p.t / p.life;
    switch (p.kind) {
      case 0: rot(A.leaf, x, y, 2, 2, p.rot, 1 - k); break;
      case 1: { double sc = 0.6 + (1 - k) * 0.6; spr(A.spark, x - 3, y - 3, false, 1 - k, sc, sc); break; }
      case 2: spr(A.poof[std::min(3, I(k * 4))], x - 8, y - 8); break;
      case 3: spr(A.poof[std::min(3, 1 + I(k * 3))], x - 4, y - 6, false, 0.5 * (1 - k), 0.5, 0.5); break;
      case 4: { uint32_t col = p.col; fillLo(std::round(x - 1), std::round(y - 1), 3, 3, rgba(I(std::min(255.0, ((col >> 16) & 255) * 1.3)), I(std::min(255.0, ((col >> 8) & 255) * 1.3)), I(std::min(255.0, (col & 255) * 1.3)), 1 - k)); break; }
      case 5: fillLo(std::round(x - 1), std::round(y - 1), 2, 2, rgba(240, 248, 255, 0.9 * (1 - k))); break;
    }
  }
  EACH(e, ents) if (e.alive && e.type == E_ROCKP && e.state == 9) {
    double R = (e.t / 0.55) * 70, a = std::max(0.0, 1 - e.t / 0.6);
    g->ellipse(e.x - ox, e.y - oy, std::max(0.1, R), std::max(0.1, R * 0.55), m.kind == MAP_DUNGEON2 || m.kind == MAP_SNOW ? rgba(170, 230, 255, a) : rgba(204, 153, 255, a), 2);
  }
}
// karanlık (zindan, gece): ışık kaynaklarının çevresi aydınlık
void Game::drawDarkness(double ox, double oy) {
  WorldMap& m = map; double tm = time; std::vector<LightSrc> Ls;
  double base = 0; int col[3] = { 5, 3, 13 };
  double lr = hasFireLantern ? 92 : hasLantern ? 76 : 30;
  if (EXT.dark.count(m.kind)) {
    DarkInfo d = EXT.dark[m.kind](ox, oy, Ls); base = d.base; col[0] = d.col[0]; col[1] = d.col[1]; col[2] = d.col[2];
  } else if (isDg(m.kind)) {
    int r = curRoom < 0 ? roomOf(px, py) : curRoom;
    base = r == 0 ? 0.95 : m.kind == MAP_DUNGEON2 ? 0.4 : 0.32;
    if (m.kind == MAP_DUNGEON2) { col[0] = 4; col[1] = 10; col[2] = 28; }
    EACH(o, m.objs) if (o.alive && o.type == O_TORCH && o.var == 0) Ls.push_back({ o.x - ox, o.y - 20 - oy, 44 + std::sin(tm * 9 + o.x) * 3 });
    EACH(o, m.objs) if (o.alive && o.type == O_CRYSTAL) Ls.push_back({ o.x - ox, o.y - 10 - oy, 34 + std::sin(tm * 2 + o.x) * 3 });
  } else {
    base = (m.kind == MAP_INTERIOR ? 0.45 : m.kind == MAP_SNOW ? 0.66 : 0.72) * nightAmt();
    if (m.kind == MAP_SNOW) { col[0] = 6; col[1] = 14; col[2] = 40; } else { col[0] = 5; col[1] = 8; col[2] = 31; }
    if (base < 0.01) return;
    EACH(o, m.objs) if (o.alive) {
      if (o.type == O_LAMP) Ls.push_back({ o.x - ox, o.y - 24 - oy, 56 + std::sin(tm * 3 + o.x) * 2 });
      if (o.type == O_HOUSE || o.type == O_CABIN) { Ls.push_back({ o.x - 16 - ox, o.y - 14 - oy, 26 }); Ls.push_back({ o.x + 16 - ox, o.y - 14 - oy, 26 }); }
      if (o.type == O_FIRE || o.type == O_OVEN || o.type == O_CAMPFIRE) Ls.push_back({ o.x - ox, o.y - 10 - oy, 80 + std::sin(tm * 8) * 4 });
      if (o.type == O_CRYSTAL) Ls.push_back({ o.x - ox, o.y - 10 - oy, 40 + std::sin(tm * 2 + o.x) * 3 });
      if (EXT.light.count(o.type)) { const double* lr2 = EXT.light[o.type](o); if (lr2) Ls.push_back({ o.x - ox, o.y - lr2[1] - oy, lr2[0] }); }
    }
    EACH(e, ents) if (e.alive && (e.type == E_GHOST || e.type == E_WISP)) Ls.push_back({ e.x - ox, e.y - 14 - oy, e.type == E_WISP ? 26.0 : 18.0 });
  }
  if (state == S_PLAY || state == S_PAUSE || state == S_OVER) Ls.push_back({ px - ox, py - 8 - oy, lr });
  g->darkBegin(rgba(col[0], col[1], col[2], base));
  for (auto& L0 : Ls) {
    double r = L0.r;
    if (L0.x < -r || L0.y < -r || L0.x > VW + r || L0.y > VH + r) continue;
    g->darkCut(L0.x, L0.y, r);
  }
  g->darkEnd();
  if (!isDg(m.kind) && base > 0.1) for (auto& L0 : Ls) { if (L0.r > 70) continue; g->glow(L0.x, L0.y, L0.r * 0.5, 0.18 * base); }
}

// ---------------- arayüz: ekran çözünürlüğünde ----------------
// sz: masaüstündeki yazı ölçeğiyle aynı (0.34 = diyalog)
double Game::fontPx(double sz) { return std::round(sz * 27 * s); }
double Game::vx(double x) { return ox0 + x * s; }
void Game::text(const string& str, double x, double y, double sz, Col color, int align /*= 0*/, bool bold /*= false*/, int n /*= -1*/) {
  string t = n >= 0 ? u8prefix(str, n) : str;
  double X = vx(x), Y = y * s, o = std::max(1.0, std::round(s * 0.45)), fp = fontPx(sz);
  g->text(t, X + o, Y + o, fp, rgba(10, 6, 20, 0.6 * color.a), align, bold);   // okunurluk için gölge
  g->text(t, X, Y, fp, color, align, bold);
}
double Game::textW(const string& str, double sz, bool bold /*= false*/) { return g->textW(str, fontPx(sz), bold) / s; }
// satırlara böler; kelime tek başına sığmıyorsa harf harf böler
const std::vector<string>& Game::wrap(const string& str, double sz, double maxW, bool bold /*= false*/) {
  string key = fmt("%g|%g|%d|", sz, maxW, bold ? 1 : 0) + str;
  auto it = textCache.find(key);
  if (it != textCache.end()) return it->second;
  std::vector<string> r, words; string cur;
  for (auto& w : splitStr(str, ' ')) {
    if (textW(w, sz, bold) <= maxW) { words.push_back(w); continue; }
    string part;
    for (auto& ch : u8chars(w)) { if (part.size() && textW(part + ch, sz, bold) > maxW) { words.push_back(part); part = ch; } else part += ch; }
    if (part.size()) words.push_back(part);
  }
  for (auto& w : words) {
    string t = cur.size() ? cur + " " + w : w;
    if (cur.size() && textW(t, sz, bold) > maxW) { r.push_back(cur); cur = w; } else cur = t;
  }
  if (cur.size()) r.push_back(cur);
  return textCache[key] = r;
}
void Game::fontsReady() { textCache.clear(); }
void Game::rectV(double x, double y, double w, double h, Col color) { g->rect(vx(x), y * s, w * s, h * s, color); }
void Game::panel(double x, double y, double w, double h) {
  Col edge = hexc(0xf2e6bf);
  rectV(x, y, w, h, rgba(15, 13, 41, 0.93));
  rectV(x, y, w, 1, edge); rectV(x, y + h - 1, w, 1, edge); rectV(x, y, 1, h, edge); rectV(x + w - 1, y, 1, h, edge);
  rectV(x + 1, y + 1, w - 2, 1, hexc(0x7366a6));
}
void Game::hit(double x, double y, double w, double h, std::function<void()> fn) { hits.push_back({ x, y, w, h, fn }); }
// dokunmatik: sanal koordinatlarda dokunuş
bool Game::tap(double x, double y) {
  for (int i = (int)hits.size() - 1; i >= 0; i--) { Hit h = hits[i]; if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) { h.fn(); return true; } }
  if (state == S_PLAY && dlg) { dlgAdvance(); return true; }
  if (state == S_PLAY && questLog) { questLog = false; return true; }
  if (state == S_OVER && deathT > 1.5) { continueAfterDeath(); return true; }
  if (state == S_CREDITS && creditsT > 2) { toTitle(); return true; }
  return false;
}
void Game::toVirt(double sx, double sy, double& x, double& y) { x = (sx - ox0) / s; y = sy / s; }
// ekrana dokunmak oyunu mu yönetir (menü, diyalog), yoksa çubuğa mı gider
bool Game::uiMode() { if (netRole == "guest" && gKey.size() && state == S_PLAY && guestMenu) return true; return state != S_PLAY || dlg || questLog || fadeState != 0; }

void Game::hudSprites() {
  double nh = maxHp / 2.0; int perRow = 10, rows = nh > perRow ? 2 : 1; double cols = std::min(nh, (double)perRow);
  double hy = rows == 2 ? 9 : 0;
  hudRowY = hy;
  fillLo(3, 3, 6 + cols * 10, 24 + hy, rgba(0, 0, 0, 0.35));
  for (int i = 0; i < nh; i++) {
    int v = hp - i * 2; const Spr* sp = v >= 2 ? A.heart : v == 1 ? A.heartHalf : A.heartEmpty;
    double pulse = (hp <= 2 && v > 0) ? 1 + 0.15 * std::sin(time * 10) : 1;
    spr(sp, 6 + (i % perRow) * 10 - (pulse - 1) * 4, 5 + (i / perRow) * 9 - (pulse - 1) * 4, false, 1, pulse, pulse);
  }
  spr(A.coin[0], 6, 17 + hy);
  if (hpPieces > 0) spr(A.heartPiece, 6 + cols * 10 + 2, 5);
  if (keys > 0) spr(A.key, 40, 15 + hy, false, 1, 0.8, 0.8);
  if (isDg(map.kind) && hasBossKey()) spr(A.bossKey, keys > 0 ? 66 : 42, 14 + hy, false, 1, 0.75, 0.75);
  double dy = dlg ? 4 : objH + 2;
  dayY = dy;
  fillLo(VW - 52, dy - 1, 49, 11, rgba(0, 0, 0, 0.35));
  spr(night() ? A.moon : A.sun, VW - 50, dy);
  double ix = VW - 62;
  if (hasFireLantern) { spr(A.fireLantern, ix, dy - 2, false, 1, 0.85, 0.85); ix -= 14; }
  else if (hasLantern) { spr(A.lantern, ix, dy - 2, false, 1, 0.85, 0.85); ix -= 14; }
  if (swordLv > 0) { rot(swordLv >= 2 ? A.sword : A.woodSword, ix + 5, dy + 4, 4.5, 8, 0.7, 1, 0.75); ix -= 14; }
  if (hasHorn && mainStep < 28) spr(A.horn, ix - 2, dy - 1, false, 1, 0.8, 0.8);
  if (itemShowT > 0 && itemShow) {
    double a = std::min(1.0, itemShowT * 2), x = px - drawOX, y = py - drawOY - 30 - (2.2 - itemShowT) * 3; const Spr* sp = itemShow;
    spr(A.spark, x - 8, y - 4, false, a * 0.8, 2.2, 2.2);
    spr(sp, x - sp->w / 2, y - sp->h / 2, false, a);
  }
}
void Game::hudText() {
  double hy = hudRowY;
  text(std::to_string(coins), 17, 15.5 + hy, 0.32, hexc(0xfff0b0), 0, true);
  if (hpPieces > 0) text(fmt("%d/4", hpPieces), 6 + std::min(10.0, maxHp / 2.0) * 10 + 11, 4.5, 0.24, hexc(0xffd0d0));
  if (keys > 0) text(fmt("x%d", keys), 49, 15.5 + hy, 0.3, hexc(0xfff0b0), 0, true);
  text(fmt("Gün %d", dayN), VW - 38, dayY + 0.3, 0.26, hexc(0xf8f0d8));
  if (!dlg) {
    string ob = objective(); auto lines = wrap(ob, 0.27, std::min(180, VW - 170));
    double w = 0; for (auto& l : lines) w = std::max(w, textW(l, 0.27));
    double lh = 8.5;
    rectV(VW - w - 10, 4 - 1, w + 7, lines.size() * lh + 1.5, rgba(0, 0, 0, 0.45));
    for (size_t i = 0; i < lines.size(); i++) text(lines[i], VW - w - 7, 3.6 + i * lh, 0.27, hexc(0xf8e8c0));
    objH = 4 + lines.size() * lh;
  }
  if (toastT > 0) {
    double a = std::min(1.0, toastT * 2); auto lines = wrap(toastS, 0.33, std::min(VW - 40, 300));
    double tw = 0; for (auto& l : lines) tw = std::max(tw, textW(l, 0.33));
    rectV((VW - tw) / 2 - 6, 30, tw + 12, lines.size() * 10 + 2, rgba(13, 10, 38, 0.8 * a));
    for (size_t i = 0; i < lines.size(); i++) text(lines[i], VW / 2.0, 30.8 + i * 10, 0.33, rgba(255, 242, 204, a), 1);
  }
}
void Game::questPanel() {
  g->rect(0, 0, W, H, rgba(0, 0, 0, 0.5));
  double x0 = std::max(16.0, (VW - 330) / 2.0), w = VW - x0 * 2;
  panel(x0, 14, w, VH - 28);
  bool ch2 = mainStep >= 6;
  text(mainStep >= 21 ? "GÖREV GÜNLÜĞÜ — 4. BÖLÜM: GÖKLERDEKİ KULE" : mainStep >= 13 ? "GÖREV GÜNLÜĞÜ — 3. BÖLÜM: BATIK ŞEHİR" : ch2 ? "GÖREV GÜNLÜĞÜ — 2. BÖLÜM: KARLI DAĞLAR" : "GÖREV GÜNLÜĞÜ — 1. BÖLÜM: KARA SİS", VW / 2.0, 19, 0.34, hexc(0xf8d878), 1, true);
  double y = 34;
  text("ANA GÖREV", x0 + 10, y, 0.28, hexc(0x9af0a0), 0, true); y += 9;
  for (auto& l : wrap("• " + objective(), 0.27, w - 20)) { text(l, x0 + 14, y, 0.27, hexc(0xffffff)); y += 9; }
  y += 4;
  text("GÖREVLER", x0 + 10, y, 0.28, hexc(0x9af0a0), 0, true); y += 9;
  // satırları topla (hikâye görevleri + eski yan görevler), sonra kaydırarak çiz
  struct Row { string s; Col c; }; std::vector<Row> rows;
  static const char* where[Q_COUNT] = { "Kemal Usta (pazar)", "Küçük Efe (ağıl)", "Fırıncı Hatice (fırın)", "Balıkçı Çocuk (göl)", "Bilge Nine (gece, evinde)",
    "Çoban Lale (Ayazköy)", "Donmuş Göl'de bir şey var", "Avcı Tolga (Ayazköy)", "İnci Ana (Mercanköy)", "Aşçı Ozan (Mercanköy)", "Fenerci Nur (deniz feneri)",
    "Kuşçu Serçe (Rüzgârköy)", "Değirmenci Poyraz (Rüzgârköy)", "Bulut Bekçisi Tan (gece, Rüzgârköy)" };
  auto chap = [](int i) { return i >= Q_FEATHER ? 4 : i >= Q_PEARLS ? 3 : i >= Q_GOAT ? 2 : 1; };
  int cur = mainStep >= 21 ? 4 : mainStep >= 13 ? 3 : ch2 ? 2 : 1;
  static const Col HC[3] = { hexc(0xffe9a8), hexc(0x8a8aa0), hexc(0x9af0a0) };
  for (auto& r : hikayeGunluk(cur)) rows.push_back({ r.first, HC[r.second] });
  for (int i = 0; i < Q_COUNT; i++) {
    if (!(chap(i) == cur || (chap(i) < cur && qs[i] == 1))) continue;
    string st; Col c = hexc(0xd0d0e0);
    if (qs[i] == 0) { st = string("? ? ?  — ") + where[i]; c = hexc(0x8a8aa0); }
    else if (qs[i] == 2) { st = string(QNAME[i]) + "  — TAMAMLANDI"; c = hexc(0x9af0a0); }
    else {
      st = QNAME[i];
      if (i == Q_CHICK) st += fmt("  — ağıldaki tavuklar %d/4", qc[i]);
      if (i == Q_OCTO) st += fmt("  — taş tükürenler %d/6", std::min(6, qc[i]));
      if (i == Q_GHOST) st += fmt("  — hortlaklar %d/5", std::min(5, qc[i]));
      if (i == Q_CAT) st += "  — Tekir'i bulup Kemal Usta'ya götür";
      if (i == Q_BREAD) st += (flags & F_BASKET) ? "  — sepeti balıkçı çocuğa götür" : "";
      if (i == Q_GOAT) st += fmt("  — ağıldaki keçiler %d/3", qc[i]);
      if (i == Q_FROZEN) st += "  — buzu eritmek için ateş lazım";
      if (i == Q_WOLVES) st += fmt("  — kar kurtları %d/6 (gece)", std::min(6, qc[i]));
      if (i == Q_PEARLS) st += fmt("  — inciler %d/5", std::min(5, qc[i]));
      if (i == Q_CRABS) st += fmt("  — yengeçler %d/8", std::min(8, qc[i]));
      if (i == Q_LIGHT) st += "  — feneri gece yak";
      if (i == Q_FEATHER) st += fmt("  — altın tüyler %d/6", std::min(6, qc[i]));
      if (i == Q_BIRDS) st += fmt("  — kümesteki yavrular %d/4", qc[i]);
      if (i == Q_WISPS) st += fmt("  — fırtına ruhları %d/8 (gece)", std::min(8, qc[i]));
    }
    rows.push_back({ st, c });
  }
  // kaydırma: yukarı/aşağı ile; görünmeyen satır varsa ok işaretleri
  double yEnd = VH - 40; std::vector<std::pair<string, Col>> flat; std::vector<int> start;
  for (auto& r : rows) { start.push_back((int)flat.size()); auto ls = wrap("• " + r.s, 0.27, w - 24); for (size_t k = 0; k < ls.size(); k++) flat.push_back({ (k ? "   " : "") + ls[k], r.c }); }
  int fit = std::max(1, (int)((yEnd - y) / 8.6)), maxS = std::max(0, (int)flat.size() - fit);
  qScroll = std::max(0, std::min(qScroll, maxS));
  for (int i = qScroll; i < (int)flat.size() && i < qScroll + fit; i++) { text(flat[i].first, x0 + 14, y, 0.27, flat[i].second); y += 8.6; }
  // dokunmatik: listenin sağ üst/alt köşesine dokununca kayar
  if (qScroll > 0) { text("^ yukarı", x0 + w - 8, 34, 0.24, hexc(0xf8d878), 2); hit(x0 + w * 0.6, 14, w * 0.4, (yEnd - 14) / 2, [this] { qScroll -= 4; }); }
  if (qScroll < maxS) { text("v aşağı", x0 + w - 8, yEnd - 2, 0.24, hexc(0xf8d878), 2); hit(x0 + w * 0.6, 14 + (yEnd - 14) / 2, w * 0.4, (yEnd - 14) / 2, [this] { qScroll += 4; }); }
  y = yEnd + 2;
  text(fmt("Kalp parçası: %d/4   Gün: %d%s", hpPieces, dayN, night() ? " (gece)" : " (gündüz)"), x0 + 10, y, 0.26, hexc(0xf8e8c0));
  text(desktop ? "L ya da Esc ile kapat" : "Kapatmak için dokun", VW / 2.0, VH - 24, 0.24, hexc(0xa0a0b8), 1);
}
void Game::dialogueBox() {
  const Line& ln = dl[di];
  double bw = std::min(VW - 28.0, 340.0), bx = (VW - bw) / 2, ts = 0.34;
  auto lines = wrap(ln.text, ts, bw - 16); double bh = std::max(48.0, lines.size() * 10.2 + 8), by = VH - 6 - bh;
  panel(bx, by, bw, bh);
  if (ln.who.size()) {
    double nw = textW(ln.who, ts, true) + 10;
    panel(bx + 6, by - 10, nw, 13);
    text(ln.who, bx + 11, by - 8.6, ts, hexc(0xf8d878), 0, true);
  }
  int shown = I(dchars); double y = by + 5;
  for (auto& l : lines) {
    int len = (int)u8len(l), n = std::min(len, shown);
    if (n > 0) text(l, bx + 8, y, ts, ln.who.size() ? hexc(0xffffff) : hexc(0xd8d8f0), 0, false, n);
    shown -= len + 1; y += 10.2;
  }
  bool typed = dchars >= u8len(ln.text), last = di == (int)dl.size() - 1;
  if (last && dChoices.size() && typed) {
    double cw = 0; for (auto& c : dChoices) cw = std::max(cw, textW(c, ts));
    double rowH = 17, cx = bx + bw - cw - 26, cy = by - 14 - dChoices.size() * rowH;
    panel(cx, cy, cw + 22, dChoices.size() * rowH + 6);
    for (size_t i = 0; i < dChoices.size(); i++) {
      bool sel = (int)i == dSel; double ry = cy + 3 + i * rowH;
      if (sel) rectV(cx + 2, ry, cw + 18, rowH - 1, rgba(248, 216, 120, 0.14));
      text((sel ? "› " : "  ") + dChoices[i], cx + 5, ry + 3.5, ts, sel ? hexc(0xf8d878) : hexc(0xc8c8d8));
      int ii = (int)i;
      hit(cx, ry, cw + 22, rowH, [this, ii] { dSel = ii; dlgChoose(ii); });
    }
  } else if (typed && std::fmod(time, 0.8) < 0.5) {
    rectV(bx + bw - 10, by + bh - 7, 4, 2, hexc(0xffe699)); rectV(bx + bw - 9, by + bh - 5, 2, 1, hexc(0xffe699));
  }
}
// orijinal olmayan kopya uyarısı
double Game::pirateNote(double y) {
  double w = std::min(VW - 24.0, 330.0), x = (VW - w) / 2;
  string msg = "Ormanın Kalbi zaten bedava! App Store'dan ve Google Play'den ücretsiz indirebilirsin.";
  auto lines = wrap(msg, 0.29, w - 14); double h = 15 + lines.size() * 9;
  g->rect(vx(x), y * s, w * s, h * s, rgba(90, 14, 24, 0.92));
  rectV(x, y, w, 1, hexc(0xff8a80)); rectV(x, y + h - 1, w, 1, hexc(0xff8a80));
  text("BU KOPYA ORİJİNAL DEĞİL", VW / 2.0, y + 3, 0.32, hexc(0xffd54f), 1, true);
  for (size_t i = 0; i < lines.size(); i++) text(lines[i], VW / 2.0, y + 13 + i * 9, 0.29, hexc(0xffffff), 1);
  return h;
}
void Game::menu(const std::vector<string>& items, double y0, double rowH, std::function<void(int)> onPick) {
  double w = 120;
  panel(VW / 2.0 - w / 2, y0, w, items.size() * rowH + 8);
  for (size_t i = 0; i < items.size(); i++) {
    bool sel = (int)i == menuSel; double ry = y0 + 4 + i * rowH;
    if (sel) rectV(VW / 2.0 - w / 2 + 3, ry, w - 6, rowH - 1, rgba(248, 216, 120, 0.14));
    text(items[i], VW / 2.0, ry + rowH / 2 - 5.2, 0.38, sel ? hexc(0xf8d878) : hexc(0xd0d0e0), 1, sel);
    int ii = (int)i;
    hit(VW / 2.0 - w / 2, ry, w, rowH, [this, ii, onPick] { menuSel = ii; onPick(ii); });
  }
}

void Game::render() {
  int st = state;
  hits.clear();
  g->target(0);
  fillLo(0, 0, VW, VH, hexc(0x0d0a14));
  double ox, oy;
  bool guestView = netRole == "guest" && gKey.size();
  if ((st == S_TITLE || st == S_CREDITS) && !guestView) { ox = std::floor(30 * 16 + std::fmod(titleCam, 40 * 16)); oy = std::floor(44 * 16 + std::sin(titleCam * 0.01) * 40); }
  else {
    double shx = 0, shy = 0; if (shake > 0) { shx = (rnd() - 0.5) * 4 * std::min(1.0, shake * 4); shy = (rnd() - 0.5) * 4 * std::min(1.0, shake * 4); }
    ox = std::floor(camX + shx); oy = std::floor(camY + shy);
  }
  drawOX = ox; drawOY = oy;
  drawWorld(ox, oy);
  // zindanda yan odaları gizle
  if (isDg(map.kind) && st != S_TITLE && st != S_CREDITS) {
    int r = curRoom < 0 ? roomOf(px, py) : curRoom; double rx = (r % 3) * RW * 16 - ox, ry = (r / 3) * RH * 16 - oy;
    Col bg = hexc(0x0d0a14);
    fillLo(0, 0, std::max(0.0, rx), VH, bg); fillLo(rx + RW * 16, 0, VW, VH, bg);
    fillLo(0, 0, VW, std::max(0.0, ry), bg); fillLo(0, ry + RH * 16, VW, VH, bg);
  }
  if (st != S_TITLE && st != S_CREDITS) drawDarkness(ox, oy);
  if (map.kind == MAP_OVER && st != S_TITLE && st != S_CREDITS) {
    double na = nightAmt();
    if (!cured) fillLo(0, 0, VW, VH, rgba(64, 20, 89, 0.14 * (1 - na)));
    double dusk = (dayT > 0.66 && dayT < 0.82) ? std::sin((dayT - 0.66) / 0.16 * PI) : 0;
    if (dusk > 0) fillLo(0, 0, VW, VH, rgba(255, 115, 38, 0.16 * dusk));
  }
  if (map.kind == MAP_SNOW && st != S_TITLE && st != S_CREDITS) drawWeather2(ox, oy);
  if (st == S_OVER) fillLo(0, 0, VW, VH, rgba(102, 0, 0, std::min(0.55, deathT * 0.4)));
  if (st == S_PLAY || st == S_PAUSE || st == S_OVER) { hudSprites(); if (p2) hudP2(); }
  // düşük çözünürlüklü görüntüyü ekrana büyüt
  g->target(1);
  g->rect(0, 0, W, H, hexc(0x0d0a14));
  g->blitLow(ox0, 0, VW * s, VH * s);

  if (st == S_TITLE) {
    g->vgrad(0, H * 0.6, rgba(5, 5, 20, 0.8), rgba(0, 0, 0, 0));
    double gl = 0.85 + 0.15 * std::sin(time * 2);
    text("ORMANIN KALBİ", VW / 2.0 + 1.2, 15.2, 0.95, rgba(13, 38, 13, 1), 1, true);
    text("ORMANIN KALBİ", VW / 2.0, 14, 0.95, rgba(I(140 * gl), I(255 * gl), I(153 * gl), 1), 1, true);
    text("KARA SİS  •  KARLI DAĞLAR  •  BATIK ŞEHİR  •  GÖKLERDEKİ KULE", VW / 2.0, 48, 0.3, hexc(0xf8e8c0), 1, true);
    text("Yeşilvadi Efsanesi", VW / 2.0, 63, 0.3, hexc(0xc8d8b8), 1);
    auto it = titleItems();
    if (menuSel >= (int)it.size()) menuSel = 0;
    double rowH = std::min(20.0, std::floor((pirate ? 62 : 92) / (double)it.size()));
    menu(it, it.size() > 3 ? 74 : pirate ? 78 : 92, rowH, [this](int i) { titleChoose(i); });
    if (menuNote.size() && !pirate) text(menuNote, VW / 2.0, VH - 26, 0.26, hexc(0xf8d878), 1);
    if (pirate) pirateNote(VH - 36);
    else text(desktop ? "Hareket: WASD / ok tuşları • Kılıç: Boşluk • Konuş: E • İksir: Q • Görevler: L • Duraklat: Esc • Tam ekran: F11" : "Seçmek için dokun", VW / 2.0, VH - 13, desktop ? 0.22 : 0.24, hexc(0xb8b8d0), 1);
  } else if (st == S_PLAY || st == S_PAUSE || st == S_OVER) {
    hudText();
    if (dlg) dialogueBox();
    if (questLog) questPanel();
    if (st == S_PAUSE) {
      g->rect(0, 0, W, H, rgba(0, 0, 0, 0.5));
      text("DURAKLATILDI", VW / 2.0, 50, 0.45, hexc(0xf8e8c0), 1, true);
      menu({ "Devam Et", au && au->muted ? "Ses: Kapalı" : "Ses: Açık", "Kaydet ve Menü" }, 66, 20, [this](int i) { pauseChoose(i); });
      if (pirate) pirateNote(VH - 36);
    }
    if (st == S_OVER && deathT > 1.2) {
      text("YENİLDİN", VW / 2.0, 55, 0.75, hexc(0xff8080), 1, true);
      text(desktop ? "Devam etmek için Enter" : "Devam etmek için dokun", VW / 2.0, 98, 0.34, hexc(0xffffff), 1);
    }
  } else if (st == S_CREDITS) {
    g->rect(0, 0, W, H, rgba(0, 0, 8, 0.55));
    std::vector<string> cr = mainStep >= 28 ? credits4() : mainStep >= 21 ? credits3() : mainStep >= 13
      ? std::vector<string>{ "2. BÖLÜM SONU", "", "Buz Devi devrildi ve dağlara bahar geldi.", "Ayazköy'ün ocakları yeniden tütüyor.",
        "Kalbin iki parçası birleşti. İki parça hâlâ kayıp...", "", "Keçiler hâlâ inatçı.", "Demirci Bora bir kılıç daha dövmek istiyor.", "", "",
        "3. BÖLÜM YAKINDA", "", "Oynadığın için teşekkürler!" }
      : std::vector<string>{ "1. BÖLÜM SONU", "", "Kara sis şimdilik dağıldı ve Yeşilvadi yeniden yeşerdi.", "Arda, Yeşilvadi'nin Bekçisi oldu.",
        "Ama Ormanın Kalbi'nin üç parçası hâlâ kayıp...", "", "Kemal Usta ona hiç indirim yapmadı.", "Tavuklar hâlâ kızgın.", "", "",
        "2. BÖLÜM: KARLI DAĞLAR", "", "Devam Et ile kaldığın yerden sürdür!" };
    double y = VH - creditsT * 22;
    for (size_t i = 0; i < cr.size(); i++) {
      const string& l = cr[i];
      if (i == 0 || i == 10) { text(l, VW / 2.0, y, 0.55, i == 0 ? hexc(0x9af0a0) : hexc(0xf8d878), 1, true); y += 30; }
      else if (l.empty()) y += 14;
      else { for (auto& p : wrap(l, 0.34, VW - 30)) { text(p, VW / 2.0, y, 0.34, hexc(0xf8f0e0), 1); y += 11; } y += 5; }
    }
  }
  render2();
  if (fade > 0) g->rect(0, 0, W, H, rgba(0, 0, 0, fade));
}
