// ORMANIN KALBİ - dil seçimi (Türkçe / English)
// Kaynak kod Türkçe yazılır; yazılar ekrana çıkarken çevrilir. Çeviriler ceviri/en/*.json'da, tablo ceviri_en.inc'te (tools/ceviri.js uret).
// Sıra: 1) yazının tamamı tabloda mı, 2) fmt kalıbına uyuyor mu ("Altın: %d" -> "Gold: %d"), 3) içindeki bilinen parçaları değiştir.
#include "game.h"
#include <regex>

static const char* const EN[][2] = {
#include "ceviri_en.inc"
  { nullptr, nullptr } };

namespace {
struct Kalip { std::regex re; std::vector<char> kind; string en; bool lit0; };   // lit0: %s ile başlıyor
struct Dil {
  std::unordered_map<string, string> exact, cache;
  std::vector<Kalip> pats;
  std::vector<std::pair<string, string>> segs;
  bool ready = false;
  void init() {
    if (ready) return; ready = true;
    for (int i = 0; EN[i][0]; i++) {
      string k = EN[i][0], v = EN[i][1]; exact[k] = v;
      if (k.find('%') != string::npos) {
        string re = "^"; std::vector<char> kind;
        for (size_t j = 0; j < k.size(); j++) {
          char c = k[j];
          if (c == '%' && j + 1 < k.size()) {
            size_t e = j + 1; while (e < k.size() && (isdigit((unsigned char)k[e]) || k[e] == '.' || k[e] == '-' || k[e] == '+')) e++;
            char t = e < k.size() ? k[e] : 0;
            if (t == '%') { re += "%"; j = e; continue; }
            if (t == 'd' || t == 'i' || t == 'u') { re += "(-?\\d+)"; kind.push_back('d'); j = e; continue; }
            if (t == 'f' || t == 'g') { re += "(-?[0-9.]+)"; kind.push_back('f'); j = e; continue; }
            if (t == 's') { re += "([\\s\\S]+?)"; kind.push_back('s'); j = e; continue; }
          }
          if (strchr("\\^$.|?*+()[]{}", c)) re += '\\';
          re += c;
        }
        re += "$";
        try { pats.push_back({ std::regex(re), kind, v, k.compare(0, 2, "%s") == 0 }); } catch (...) {}
      } else if (u8len(k) >= 3) segs.push_back({ k, v });
    }
    std::sort(segs.begin(), segs.end(), [](auto& a, auto& b) { return a.first.size() > b.first.size(); });
  }
};
Dil D;
bool letter(unsigned char c) { return c >= 0x80 || isalnum(c); }
}

string Game::tr(const string& s) {
  if (lang == 0 || s.empty()) return s;
  D.init();
  auto it = D.exact.find(s); if (it != D.exact.end()) return it->second;
  auto c = D.cache.find(s); if (c != D.cache.end()) return c->second;
  if (D.cache.size() > 6000) D.cache.clear();
  // fmt kalıbı (yalnızca düz yazıyla başlayanlar ya da hepsi)
  auto pattern = [&](bool literalStartOnly, string& r) {
    for (auto& p : D.pats) {
      if (literalStartOnly && p.lit0) continue;
      std::smatch m;
      if (!std::regex_match(s, m, p.re)) continue;
      size_t gi = 1; const string& f = p.en; r.clear();
      for (size_t j = 0; j < f.size(); j++) {
        if (f[j] == '%' && j + 1 < f.size()) {
          size_t e = j + 1; while (e < f.size() && (isdigit((unsigned char)f[e]) || f[e] == '.' || f[e] == '-' || f[e] == '+')) e++;
          char t = e < f.size() ? f[e] : 0;
          if (t == '%') { r += '%'; j = e; continue; }
          if ((t == 'd' || t == 'i' || t == 'u' || t == 'f' || t == 'g' || t == 's') && gi < m.size()) { string g = m[gi++].str(); r += t == 's' ? tr(g) : g; j = e; continue; }
        }
        r += f[j];
      }
      return true;
    }
    return false;
  };
  string out = s, r; bool done = false;
  // 2) düz yazıyla başlayan kalıplar ("Gün %d", "  — inciler %d/5")
  if (pattern(true, r)) return D.cache[s] = r;
  // 3) birleşik satırlar: baştaki boşluk/madde işareti ve "  — " ayracı ayrı ayrı çevrilir
  static const string BUL = "• ", SEP = "  — ";
  size_t lead = 0; while (lead < s.size() && s[lead] == ' ') lead++;
  if (lead && lead < s.size()) return D.cache[s] = s.substr(0, lead) + tr(s.substr(lead));
  if (s.compare(0, BUL.size(), BUL) == 0 && s.size() > BUL.size()) return D.cache[s] = BUL + tr(s.substr(BUL.size()));
  size_t sp = s.find(SEP);
  if (sp != string::npos && sp > 0 && sp + SEP.size() < s.size()) return D.cache[s] = tr(s.substr(0, sp)) + SEP + tr(s.substr(sp + SEP.size()));
  // 4) "%s ile konuş." gibi kalıplar
  if (pattern(false, r)) { out = r; done = true; }
  // 5) bilinen parçalar (kelime sınırında)
  if (!done) {
    for (auto& sg : D.segs) {
      size_t pos = 0;
      while ((pos = out.find(sg.first, pos)) != string::npos) {
        size_t end = pos + sg.first.size();
        bool okL = pos == 0 || !letter((unsigned char)out[pos - 1]) || !letter((unsigned char)sg.first[0]);
        bool okR = end >= out.size() || !letter((unsigned char)out[end]) || !letter((unsigned char)sg.first.back());
        if (okL && okR) { out.replace(pos, sg.first.size(), sg.second); pos += sg.second.size(); } else pos = end;
      }
    }
  }
  D.cache[s] = out;
  return out;
}
void Game::setLang(int l) { lang = l ? 1 : 0; textCache.clear(); storeSet("orman_dil", lang ? "en" : "tr"); }
void Game::loadLang() { lang = storeGet("orman_dil") == "en" ? 1 : 0; }
// menüdeki dil satırı (her iki dilde de anlaşılsın)
string Game::langLabel() { return lang ? "Language: English  (Dil)" : "Dil: Türkçe  (Language)"; }
