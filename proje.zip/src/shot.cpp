// ORMANIN KALBİ - geliştirme yardımcısı: belirli bir sahneyi kurup ekran görüntüsünü PNG olarak kaydeder
// kullanım: OrmaninKalbi.exe --shot cikti.png sahne
#include "game.h"
#include "oyunlar.h"
#include <SDL.h>

static uint32_t crcT[256];
static uint32_t crc(const unsigned char* d, size_t n, uint32_t c = 0xFFFFFFFFu) {
  if (!crcT[1]) for (uint32_t i = 0; i < 256; i++) { uint32_t v = i; for (int k = 0; k < 8; k++) v = v & 1 ? 0xEDB88320u ^ (v >> 1) : v >> 1; crcT[i] = v; }
  for (size_t i = 0; i < n; i++) c = crcT[(c ^ d[i]) & 255] ^ (c >> 8);
  return c;
}
// sıkıştırmasız (stored) deflate ile basit PNG yazıcı
bool writePng(const char* path, const unsigned char* rgba, int w, int h) {
  std::string raw; for (int y = 0; y < h; y++) { raw.push_back(0); raw.append((const char*)rgba + (size_t)y * w * 4, (size_t)w * 4); }
  std::string z = "\x78\x01"; uint32_t a = 1, b = 0;
  for (unsigned char c : raw) { a = (a + c) % 65521; b = (b + a) % 65521; }
  for (size_t p = 0; p < raw.size();) {
    size_t n = std::min<size_t>(65535, raw.size() - p); bool last = p + n == raw.size();
    z.push_back(last ? 1 : 0); z.push_back((char)(n & 255)); z.push_back((char)(n >> 8)); z.push_back((char)(~n & 255)); z.push_back((char)((~n >> 8) & 255));
    z.append(raw, p, n); p += n;
  }
  uint32_t ad = (b << 16) | a; for (int i = 3; i >= 0; i--) z.push_back((char)((ad >> (i * 8)) & 255));
  FILE* f = fopen(path, "wb"); if (!f) return false;
  auto be = [&](uint32_t v) { unsigned char q[4] = { (unsigned char)(v >> 24), (unsigned char)(v >> 16), (unsigned char)(v >> 8), (unsigned char)v }; fwrite(q, 1, 4, f); };
  auto chunk = [&](const char* t, const std::string& d) { be((uint32_t)d.size()); std::string td = std::string(t, 4) + d; fwrite(td.data(), 1, td.size(), f); be(crc((const unsigned char*)td.data(), td.size()) ^ 0xFFFFFFFFu); };
  fwrite("\x89PNG\r\n\x1a\n", 1, 8, f);
  std::string ih; auto put = [&](uint32_t v) { for (int i = 3; i >= 0; i--) ih.push_back((char)((v >> (i * 8)) & 255)); };
  put(w); put(h); ih += std::string("\x08\x06\x00\x00\x00", 5);
  chunk("IHDR", ih); chunk("IDAT", z); chunk("IEND", "");
  fclose(f); return true;
}
static void skipDlg(Game& g) { for (int k = 0; k < 200 && g.dlg; k++) { g.dchars = 99999; g.dlgAdvance(); } }
// sahneyi kur; kaç kare çalıştırılacağını döndürür
int shotScene(Game& g, const string& sc0) {
  // "en:sahne" -> İngilizce (kayda yazmadan)
  string sc = sc0; if (sc.rfind("en:", 0) == 0) { g.lang = 1; sc = sc.substr(3); }
  if (sc == "title") return 30;
  if (sc == "nethost") { g.netHost(); return 1500; }
  if (sc == "netjoin") { g.menuMode = "online"; return 1500; }
  if (sc == "join") { g.menuMode = "online"; g.joinOpen = true; g.joinCode = "KM"; return 10; }
  if (sc == "chapters") { g.menuMode = "chapters"; return 10; }
  if (sc == "dialog") { g.startChapter(1); return 60; }
  g.state = S_PLAY;
  if (sc == "ch1") { g.startChapter(1); skipDlg(g); g.px = 44 * 16; g.py = 58 * 16; }
  else if (sc == "night") { g.startChapter(1); skipDlg(g); g.dayT = 0.9; g.px = 46 * 16; g.py = 54 * 16; }
  else if (sc == "dungeon") { g.startChapter(1); skipDlg(g); g.hasLantern = true; g.enterDungeon(); }
  else if (sc == "interior") { g.startChapter(1); skipDlg(g); g.enterInterior(0, 38, 54); }
  else if (sc == "snow") { g.startChapter(2); skipDlg(g); g.enterSnow(36 * 16, 44 * 16); skipDlg(g); }
  else if (sc == "ice") { g.startChapter(2); skipDlg(g); g.enterIceTemple(); }
  else if (sc == "cave") { g.startChapter(1); skipDlg(g); g.mainStep = 3; g.hasLantern = true; g.enterCave(0); }
  else if (sc == "kemal") { g.startChapter(1); skipDlg(g); g.px = 52 * 16; g.py = 62 * 16; g.startKemalFight(); skipDlg(g); }
  else if (sc == "sea") { g.startChapter(3); skipDlg(g); g.mainStep = 16; g.hasCharm = true; g.enterSea(14 * 16, 30 * 16); skipDlg(g); }
  else if (sc == "palace") { g.startChapter(3); skipDlg(g); g.mainStep = 19; g.enterPalace(); }
  else if (sc == "quest") { g.startChapter(1); skipDlg(g); g.questLog = true; }
  else if (sc == "hikaye") { g.startChapter(1); skipDlg(g); g.px = 48 * 16; g.py = 51 * 16; }
  else if (sc == "hikaye2") { g.startChapter(1); skipDlg(g); for (auto& n : g.npcs) if (n->id == N_ELDER) { g.talk(*n); skipDlg(g); } g.hs[2] = 1; g.hs[4] = 1; g.hc[4] = 3; g.questLog = true; }
  else if (sc == "hikaye3") { g.startChapter(4); skipDlg(g); g.mainStep = 23; g.enterSky(36 * 16 + 8, 29 * 16 + 4); skipDlg(g); }
  else if (sc == "coop") { g.coop = "local"; g.startChapter(1); skipDlg(g); g.afterStart(); }
  else if (sc == "marsh") { g.startChapter(1); skipDlg(g); g.hasLantern = true; g.enterOverworld(118 * 16, 47 * 16); }
  else if (sc == "glacier") { g.startChapter(2); skipDlg(g); g.enterSnow(96 * 16, 22 * 16); skipDlg(g); }
  else if (sc == "storm") { g.startChapter(3); skipDlg(g); g.mainStep = 16; g.enterSea(96 * 16, 21 * 16); skipDlg(g); }
  else if (sc == "sky") { g.startChapter(4); skipDlg(g); g.mainStep = 22; g.enterSky(12 * 16 + 8, 27 * 16 + 12); skipDlg(g); }
  else if (sc == "village") { g.startChapter(4); skipDlg(g); g.mainStep = 23; g.enterSky(40 * 16 + 8, 31 * 16 + 4); skipDlg(g); }
  else if (sc == "wind") { g.startChapter(4); skipDlg(g); g.mainStep = 24; g.enterSky(44 * 16 + 8, 19 * 16 + 4); skipDlg(g); g.time = 0.5; }
  else if (sc == "eagle") { g.startChapter(4); skipDlg(g); g.mainStep = 24; g.enterSky(44 * 16 + 8, 10 * 16); skipDlg(g); for (auto& e : g.ents) if (e->type == E_EAGLE) { e->state = 2; e->z = 0; e->x = 46 * 16; e->y = 8 * 16; } }
  else if (sc == "bridge") { g.startChapter(4); skipDlg(g); g.mainStep = 25; g.hasHorn = true; g.f4 |= G4_BRIDGE0; g.enterSky(58 * 16, 29 * 16); skipDlg(g); }
  else if (sc == "tower") { g.startChapter(4); skipDlg(g); g.mainStep = 26; g.f4 |= 4 | 8 | 16; g.enterSky(149 * 16 + 8, 24 * 16); skipDlg(g); }
  else if (sc == "towerin") { g.startChapter(4); skipDlg(g); g.enterTower(); skipDlg(g); }
  else if (sc == "lord") { g.startChapter(4); skipDlg(g); g.doorMask |= 1u << 21; g.enterTower(); skipDlg(g); g.px = RW * 16 + 10 * 16; g.py = 8 * 16; g.curRoom = -1; }
  else if (sc == "twist" || sc == "twist2") { g.startChapter(4); skipDlg(g); g.mainStep = 28; g.state = S_CREDITS; g.creditsT = 30; g.twistStart(); g.twistT = sc == "twist" ? 2.9 : 5.6; return 2; }
  else if (sc == "isle") { g.startChapter(5); skipDlg(g); g.mainStep = 32; g.enterGameIsle(); skipDlg(g); g.px = 22 * 16; g.py = 15 * 16; return 60; }
  else if (sc.rfind("g_", 0) == 0) {
    static const char* K[5] = { "g_dama", "g_satranc", "g_tavla", "g_papaz", "g_okey" };
    int k = 0; for (int i = 0; i < 5; i++) if (sc == K[i]) k = i;
    g.startChapter(5); skipDlg(g); g.enterGameIsle(); skipDlg(g);
    g.mgStart(k, false, { "Dama Dedesi Şükrü", "Saadet Teyze", "Hayriye Teyze" }, nullptr);
    if (k == 4) { g.mg->names[1] = "Okeyci Nimet Teyze"; }
    g.mg->human[0] = false;
    for (int i = 0; i < (k == 3 ? 90 : k == 4 ? 300 : 420) && g.mg->winner < 0; i++) g.update(1 / 60.0);
    g.mg->human[0] = true;
    return 2;
  }
  else if (sc == "mirror") { g.startChapter(4); skipDlg(g); g.enterMirror(); skipDlg(g); }
  else if (sc == "mirror2" || sc == "mirror3") {
    g.startChapter(4); skipDlg(g); g.maxHp = 40; g.hp = 40; g.enterMirror(); skipDlg(g);
    for (auto& e : g.ents) if (e->type == E_KNIGHT) e->hp = e->maxHp * (sc == "mirror2" ? 0.6 : 0.3);
    return sc == "mirror2" ? 60 : 150;
  }
  return 90;
}
// online deneme: ev sahibi arkadaşı gelince oyunu başlatır; misafir odayı bekleyip katılır
void shotTick(Game& g, const string& sc, int frame) {
  if (sc == "nethost" && g.netLive && g.state == S_TITLE && g.fadeState == 0) g.titleChoose(0);
  if (sc == "nethost" && g.state == S_PLAY && g.dlg) skipDlg(g);
  if (sc == "netjoin" && frame == 240 && g.netRole.empty()) { const char* c = getenv("ORMAN_ODA"); g.netJoin(c ? c : ""); }
}