// ORMANIN KALBİ - 1. bölüm düşman yapay zekâsı, ganimet, parçacıklar, kamera
#include "game.h"

Ent& Game::shoot(int type, double x, double y, double vx, double vy, int room) {
  auto e = std::make_unique<Ent>();
  e->type = type; e->x = x; e->y = y; e->vx = vx; e->vy = vy; e->hp = 1; e->room = room; e->hx = x; e->hy = y;
  ents.push_back(std::move(e)); return *ents.back();
}
void Game::updateEnemies(double dt) {
  double bx = px, by = py, hw = 5, hh = 5; WorldMap& m = map; size_t n = ents.size();
  for (size_t i = 0; i < n; i++) {
    Ent& e = *ents[i];
    if (!e.alive) continue;
    bool proj = isProjT(e.type);
    if (isDg(m.kind) && e.room != curRoom && !proj) continue;
    if (isOut(m.kind) && (std::fabs(e.x - bx) > 260 || std::fabs(e.y - by) > 170) && !proj && e.type != E_CAT) continue;
    e.t += dt; if (e.flash > 0) e.flash -= dt; if (e.cd > 0) e.cd -= dt;
    // en yakın kahramanı hedef al (iki kişilik oyunda)
    double tgx = bx, tgy = by; int tg = 1;
    if (p2 && !p2->deadT) { P2& q = *p2; if ((q.px - e.x) * (q.px - e.x) + (q.py - e.y) * (q.py - e.y) < (bx - e.x) * (bx - e.x) + (by - e.y) * (by - e.y)) { tgx = q.px; tgy = q.py; tg = 2; } }
    double dx = tgx - e.x, dy = tgy - e.y, d = std::sqrt(dx * dx + dy * dy) + 0.01;
    auto jump = [&] { e.vz -= 400 * dt; e.z += e.vz * dt; moveE(e, e.vx * dt, 0, hw, hh); moveE(e, 0, e.vy * dt, hw, hh); if (e.z <= 0) { e.z = 0; e.vz = 0; } };
    if (e.kt > 0) { e.kt -= dt; moveE(e, e.kx * dt, 0, hw, hh); moveE(e, 0, e.ky * dt, hw, hh); }
    else switch (e.type) {
      case E_SLIME: case E_SLIMER: case E_ICESLIME: {
        bool red = e.type != E_SLIME;
        if (e.z <= 0 && e.vz <= 0) {
          e.z = 0;
          if (e.t > (red ? 0.6 : 1.0)) {
            e.t = rnd() * 0.3; e.vz = 95;
            double a = d < 110 ? std::atan2(dy, dx) + (rnd() - 0.5) * 0.6 : rnd() * 6.28, sp = red ? 60 : 38;
            e.vx = std::cos(a) * sp; e.vy = std::sin(a) * sp;
          } else { e.vx = e.vy = 0; }
        }
        if (e.z > 0 || e.vz > 0) jump();
        break;
      }
      case E_OCTO: {
        if (e.state == 0) {
          double vx, vy; dirVec(e.dir, vx, vy); double ox = e.x, oy = e.y;
          moveE(e, vx * 28 * dt, vy * 28 * dt, hw, hh);
          if ((std::fabs(e.x - ox) + std::fabs(e.y - oy)) < 0.1 || e.t > 1.6 || m.get((int)std::trunc((e.x + vx * 9) / 16), (int)std::trunc((e.y + vy * 9) / 16)) == T_WATER) {
            e.t = 0; e.state = 1;
            if (d < 120) e.dir = std::fabs(dx) > std::fabs(dy) ? (dx < 0 ? 2 : 3) : (dy < 0 ? 1 : 0);
          }
        } else if (e.t > 0.6) {
          if (d < 140 && e.cd <= 0) { double vx, vy; dirVec(e.dir, vx, vy); shoot(E_ROCKP, e.x + vx * 8, e.y + vy * 8, vx * 115, vy * 115, e.room); e.cd = 1.6; sfx(SFX_CLICK, 0.8); }
          e.state = 0; e.t = 0; e.dir = I(rnd() * 4);
        }
        break;
      }
      case E_BAT: case E_GHOST: case E_ICEBAT: {
        bool gh = e.type == E_GHOST; double range = gh ? 150 : 100;
        double tx = e.hx + std::cos(e.t * 0.8) * 30, ty = e.hy + std::sin(e.t * 1.3) * 18;
        if (d < range) { tx = bx + std::cos(e.t * (gh ? 1.5 : 4)) * (gh ? 6 : 14); ty = by - 6 + std::sin(e.t * (gh ? 2 : 5)) * 10; }
        double ax = tx - e.x, ay = ty - e.y, al = std::sqrt(ax * ax + ay * ay) + 0.01, sp = d < range ? (gh ? 36 : 62) : 30;
        e.x += ax / al * std::min(al, sp * dt); e.y += ay / al * std::min(al, sp * dt);
        e.z = (gh ? 6 : 8) + std::sin(e.t * (gh ? 3 : 6)) * 3;
        e.dir = dx < 0 ? 2 : 3;
        if (isDg(m.kind)) { double ox = (e.room % 3) * RW * 16, oy = (e.room / 3) * RH * 16; e.x = clampf(e.x, ox + 24, ox + RW * 16 - 24); e.y = clampf(e.y, oy + 40, oy + RH * 16 - 20); }
        break;
      }
      case E_SKEL: {
        if (e.z > 0 || e.vz > 0) { jump(); break; }
        if (attackT > 0 && d < 34 && e.cd <= 0) { e.vz = 110; e.vx = -dx / d * 70; e.vy = -dy / d * 70; e.cd = 1.2; break; }
        double a = std::atan2(dy, dx) + std::sin(e.t * 2) * 0.7;
        moveE(e, std::cos(a) * 34 * dt, 0, hw, hh); moveE(e, 0, std::sin(a) * 34 * dt, hw, hh);
        e.dir = std::fabs(dx) > std::fabs(dy) ? (dx < 0 ? 2 : 3) : (dy < 0 ? 1 : 0);
        break;
      }
      case E_WOLF: case E_SNOWWOLF: {
        if (e.state == 1) { moveE(e, e.vx * dt, 0, hw, hh); moveE(e, 0, e.vy * dt, hw, hh); if (e.t > 0.35) { e.state = 2; e.t = 0; } }
        else if (e.state == 2) { moveE(e, -dx / d * 30 * dt, 0, hw, hh); moveE(e, 0, -dy / d * 30 * dt, hw, hh); if (e.t > 0.6) { e.state = 0; e.t = 0; } }
        else if (d < 130) {
          double a = std::atan2(dy, dx) + std::sin(e.t * 3) * 0.5;
          moveE(e, std::cos(a) * 52 * dt, 0, hw, hh); moveE(e, 0, std::sin(a) * 52 * dt, hw, hh);
          if (d < 48 && e.cd <= 0) { e.state = 1; e.t = 0; e.cd = 1.4; e.vx = dx / d * 175; e.vy = dy / d * 175; sfx(SFX_GROWL, 0.5); }
        } else { double a = e.t * 0.7 + e.hx; moveE(e, std::cos(a) * 20 * dt, std::sin(a) * 20 * dt, hw, hh); }
        e.dir = dx < 0 ? 2 : 3;
        break;
      }
      case E_BOAR: {
        if (e.state == 1) {
          bool hit = moveE(e, e.vx * dt, e.vy * dt, hw, hh);
          if (hit || e.t > 1.6) { e.state = 2; e.t = 0; if (hit) { shake = 0.15; sfx(SFX_HIT, 0.6); burst(4, e.x, e.y - 6, 5, 0x9a6434); } }
        } else if (e.state == 2) { if (e.t > 1.2) { e.state = 0; e.t = 0; } }
        else {
          bool aligned = (std::fabs(dx) < 10 || std::fabs(dy) < 10) && d < 140;
          if (aligned && e.cd <= 0) {
            e.state = 1; e.t = 0; e.cd = 2.2; sfx(SFX_SNORT);
            if (std::fabs(dx) > std::fabs(dy)) { e.vx = dx > 0 ? 150 : -150; e.vy = 0; } else { e.vy = dy > 0 ? 150 : -150; e.vx = 0; }
          } else { double a = e.t * 0.5 + e.hy; moveE(e, std::cos(a) * 18 * dt, std::sin(a) * 18 * dt, hw, hh); }
          if (e.state == 0) e.dir = dx < 0 ? 2 : 3;
        }
        if (e.state == 1) e.dir = e.vx < 0 ? 2 : e.vx > 0 ? 3 : e.dir;
        break;
      }
      case E_THORN: {
        if (d < 130 && e.t > 2.4) {
          e.t = 0; e.state = 1; sfx(SFX_CLICK, 0.7);
          for (int k = 0; k < 4; k++) { double vx, vy; dirVec(k, vx, vy); shoot(E_SEED, e.x + vx * 6, e.y + vy * 4, vx * 80, vy * 80, e.room); }
        }
        if (e.t > 0.3) e.state = 0;
        break;
      }
      case E_STUMP: {
        if (d > 170) break;
        if (e.t > (e.hp < e.maxHp / 2 ? 1.8 : 2.6)) {
          e.t = 0; e.state = 1; sfx(SFX_RUMBLE, 0.4);
          int nn = e.hp < e.maxHp / 2 ? 12 : 8;
          for (int k = 0; k < nn; k++) { double a = k * 6.283 / nn + e.cd; shoot(E_SEED, e.x + std::cos(a) * 14, e.y - 4 + std::sin(a) * 10, std::cos(a) * 75, std::sin(a) * 75, -1); }
          e.cd += 0.3;
        }
        if (e.t > 0.4) e.state = 0;
        if (e.t > 1.0 && e.t < 1.5) { moveE(e, dx / d * 22 * dt, 0, 12, 8); moveE(e, 0, dy / d * 22 * dt, 12, 8); }
        break;
      }
      case E_BOSS: {
        if (e.z > 0 || e.vz > 0) {
          e.vz -= (e.state == 2 ? 260 : 420) * dt; e.z += e.vz * dt;
          moveE(e, e.vx * dt, 0, 18, 10); moveE(e, 0, e.vy * dt, 18, 10);
          if (e.z <= 0) {
            e.z = 0; e.vz = 0;
            if (e.state == 2) {
              shake = 0.5; sfx(SFX_RUMBLE); haptic("big");
              double ex = e.x, ey = e.y; int room = e.room;
              Ent& w = shoot(E_ROCKP, ex, ey, 0, 0, room); w.state = 9; w.hx = 0; w.hy = 0;
              burst(4, ex, ey, 14, 0x5a4e72);
            } else sfx(SFX_HIT, 0.5);
            ents[i]->state = 0;
          }
        } else if (e.t > 0.85) {
          e.t = 0; e.cd += 1;
          double a = std::atan2(dy, dx);
          if (I(e.cd) % 4 == 3) { e.state = 2; e.vz = 230; e.vx = dx / 1.7; e.vy = dy / 1.7; toast("Kral havaya sıçradı!"); }
          else { e.state = 1; e.vz = 120; e.vx = std::cos(a) * 46; e.vy = std::sin(a) * 46; }
        }
        break;
      }
      case E_CHICK: {
        if (e.state == 3) {
          if (e.t > 2) { e.t = 0; e.vx = (rnd() - 0.5) * 14; e.vy = (rnd() - 0.5) * 10; e.dir = e.vx < 0 ? 2 : 3; }
          double nx = e.x + e.vx * dt, ny = e.y + e.vy * dt;
          if (nx > 59 * 16 + 4 && nx < 62 * 16 - 4 && ny > 64 * 16 + 4 && ny < 67 * 16) { e.x = nx; e.y = ny; }
          break;
        }
        if (qs[Q_CHICK] == 1 && d < 46) {
          moveE(e, -dx / d * 62 * dt, 0, 4, 4); moveE(e, 0, -dy / d * 62 * dt, 4, 4);
          e.dir = dx > 0 ? 2 : 3; e.state = 1; break;
        }
        if (e.state == 2) { moveE(e, -dx / d * 70 * dt, -dy / d * 70 * dt, 4, 4); if (e.t > 1.2) e.state = 0; break; }
        if (e.t > 2) { e.t = 0; e.state = rnd() < 0.5 ? 1 : 0; e.dir = rnd() < 0.5 ? 2 : 3; e.vy = (rnd() - 0.5) * 12; }
        if (e.state == 1) moveE(e, (e.dir == 2 ? -14 : 14) * dt, e.vy * dt, 4, 4);
        if (rnd() < 0.002) sfx(SFX_SELECT, 0.25);
        break;
      }
      case E_CAT: {
        if (e.state == 1) {
          double tx = px - 14, ty = py + 4, ax = tx - e.x, ay = ty - e.y, al = std::sqrt(ax * ax + ay * ay) + 0.01;
          if (al > 200) { e.x = tx; e.y = ty; }
          else if (al > 6) { e.x += ax / al * std::min(al, 84 * dt); e.y += ay / al * std::min(al, 84 * dt); e.dir = ax < 0 ? 2 : 3; e.vx = 1; } else e.vx = 0;
        } else if (e.t > 3) { e.t = 0; e.dir = rnd() < 0.5 ? 2 : 3; }
        break;
      }
      case E_ROCKP: case E_SEED: case E_SNOWBALL: case E_SHARD: {
        if (e.state == 9) {
          double R = (e.t / 0.55) * 70;
          for (auto& h : heroes()) { double pd = std::hypot(h.x - e.x, h.y - e.y); if (std::fabs(pd - R) < 7 && e.t < 0.55) hurtAt(h, 2, e.x, e.y); }
          if (e.t > 0.6) e.alive = false;
          break;
        }
        e.x += e.vx * dt; e.y += e.vy * dt;
        if (e.type == E_SNOWBALL) { e.vz -= 260 * dt; e.z = std::max(0.0, e.z + e.vz * dt); }   // kartopu yay çizer
        int cx = (int)std::trunc(e.x / 16), cy = (int)std::trunc((e.y - 2) / 16);
        if (m.solid(cx, cy) && m.get(cx, cy) != T_WATER && m.get(cx, cy) != T_ICEWATER && e.z < 6) {
          e.alive = false; burst(e.type >= E_SNOWBALL ? 5 : 4, e.x, e.y - 4, 5, e.type == E_SEED ? 0x4cbc44 : 0x9094a4);
        }
        if (e.t > 2.5) e.alive = false;
        for (auto& h : heroes()) if (e.alive && std::fabs(h.x - e.x) < 7 && std::fabs(h.y - 6 - e.y) < 9 && e.z < 10) {
          hurtAt(h, 1, e.x, e.y); e.alive = false;
          if (e.type == E_SHARD && h.n == 1) { freezeT = 1.4; burst(5, px, py - 8, 6); }
        }
        break;
      }
      default: updateEnemy2(e, dt, dx, dy, d); break;
    }
    Ent& e2 = *ents[i];   // (yeni düşman eklenince dizi büyüyebilir; e hâlâ geçerli)
    if (e2.alive && !isTameT(e2.type) && !proj) {
      double r = isBigT(e2.type) ? 22 : 9;
      int dm = (isBigT(e2.type) || e2.type == E_SKEL || e2.type == E_BOAR) ? 2 : 1;
      if (e2.z < 10 && d < r && tg == 2) hurtP2(dm, e2.x, e2.y);
      else if (e2.z < 10 && d < r) {
        double was = invT;
        hurtPlayer(dm, e2.x, e2.y);
        if (e2.type == E_ICESLIME && was <= 0 && invT > 0) { freezeT = 1.6; burst(5, px, py - 8, 6); }
      }
    }
  }
  ents.erase(std::remove_if(ents.begin(), ents.end(), [](const std::unique_ptr<Ent>& e) { return !e->alive; }), ents.end());
}
void Game::updatePicks(double dt) {
  EACH(k, picks) {
    if (!k.alive) continue;
    k.t += dt;
    if (k.z > 0 || k.vz > 0) { k.vz -= 300 * dt; k.z += k.vz * dt; if (k.z < 0) { k.z = 0; k.vz = k.vz < -40 ? -k.vz * 0.4 : 0; } }
    if (k.t > 12 && (k.type == P_COIN || k.type == P_HEART)) { k.alive = false; continue; }
    bool near1 = std::fabs(k.x - px) < 9 && std::fabs(k.y - py) < 10;
    bool near2 = !near1 && p2 && !p2->deadT && std::fabs(k.x - p2->px) < 9 && std::fabs(k.y - p2->py) < 10;
    if ((near1 || near2) && k.t > 0.25) {
      k.alive = false;
      double kx0 = k.x, ky0 = k.y;
      switch (k.type) {
        case P_COIN: coins = std::min(999, coins + k.val); sfx(SFX_CHIME, 0.6); break;
        case P_HEART: if (near2) p2->hp = std::min(maxHp, p2->hp + 2); else hp = std::min(maxHp, hp + 2); sfx(SFX_EAT, 0.8); break;
        case P_HEARTC: giveHeartC(); saveGame(); break;
        case P_MUSH: {
          mushMask |= 1 << k.val; int n = mushCount();
          showItem(A.mush, fmt("Şifalı mantar! (%d/3)", n));
          if (n == 3) toast("Üç mantar tamam! Yaşlı bekçiye dön.");
          saveGame();
          break;
        }
        case P_GEM:
          hasGem = true; mainStep = 5; showItem(A.gem, "ORMANIN KALBİ!"); saveGame();
          say({ L("", "Taşın içinde yeşil bir ışık atıyor; sanki ormanın kendisi nefes alıyor. Ama bir kenarı kırık..."),
            L("Arda", "Ormanın Kalbi... Bunu Nine'ye götürmeliyim. Giriş merdiveninden çıkayım.") });
          break;
        default: pick2(k); break;
      }
      burst(1, kx0, ky0 - 6, 5, 0xfff4b0);
    }
  }
  picks.erase(std::remove_if(picks.begin(), picks.end(), [](const std::unique_ptr<Pick>& k) { return !k->alive; }), picks.end());
}
void Game::updateParticles(double dt) {
  for (auto& p : pts) {
    p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.kind == 0) { p.vy += 120 * dt; p.vx *= 0.96; p.rot += dt * 8; }
    if (p.kind == 4) p.vy += 200 * dt;
    if (p.kind == 1 || p.kind == 5) { p.vx *= 0.9; p.vy *= 0.9; }
  }
  pts.erase(std::remove_if(pts.begin(), pts.end(), [](const Part& p) { return p.t >= p.life; }), pts.end());
}
void Game::updateCamera(double dt) {
  WorldMap& m = map;
  if (isDg(m.kind)) {
    int r = curRoom < 0 ? roomOf(px, py) : curRoom;
    double tx = (r % 3) * RW * 16 - (VW - RW * 16) / 2.0, ty = (r / 3) * RH * 16 - (VH - RH * 16) / 2.0;
    camX += (tx - camX) * std::min(1.0, dt * 9); camY += (ty - camY) * std::min(1.0, dt * 9);
  } else if (m.kind == MAP_INTERIOR) { camX = (IW * 16 - VW) / 2.0; camY = (IH * 16 - VH) / 2.0; }
  else {
    double fx, fy; camFocus(fx, fy);
    double tx = clampf(fx - VW / 2.0, 0, m.W * 16 - VW), ty = clampf(fy - 8 - VH / 2.0, 0, m.H * 16 - VH);
    camX += (tx - camX) * std::min(1.0, dt * 10); camY += (ty - camY) * std::min(1.0, dt * 10);
  }
}
