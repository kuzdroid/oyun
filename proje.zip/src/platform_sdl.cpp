// ORMANIN KALBİ - platform katmanı (SDL2): pencere, çizim, yazı, ses, dokunmatik/klavye, kayıt dosyası
// Windows, Android ve iPhone'da aynı kod çalışır.
#include "game.h"
#include <SDL.h>
#define STB_TRUETYPE_IMPLEMENTATION
#include "../third_party/stb_truetype.h"

extern const unsigned char* FONT_DATA[2][2];
extern const unsigned ICON32[1024];

// ---------------- kayıt ----------------
static string prefDir() {
  static string d;
  if (d.empty()) { char* p = SDL_GetPrefPath("Yesilvadi", "OrmaninKalbi"); d = p ? p : "./"; SDL_free(p); }
  return d;
}
string storeGet(const string& key) {
  SDL_RWops* f = SDL_RWFromFile((prefDir() + key + ".txt").c_str(), "rb");
  if (!f) return "";
  Sint64 n = SDL_RWsize(f); string s; if (n > 0) { s.resize((size_t)n); SDL_RWread(f, &s[0], 1, (size_t)n); }
  SDL_RWclose(f); return s;
}
void storeSet(const string& key, const string& val) {
  string p = prefDir() + key + ".txt", tmp = p + ".yeni";
  SDL_RWops* f = SDL_RWFromFile(tmp.c_str(), "wb");
  if (!f) return;
  SDL_RWwrite(f, val.data(), 1, val.size()); SDL_RWclose(f);
  remove(p.c_str()); rename(tmp.c_str(), p.c_str());
}
const char* platformName() { return SDL_GetPlatform(); }

// ---------------- çizim ----------------
struct SdlGfx : Gfx {
  SDL_Renderer* R; SDL_Texture *atlas = nullptr, *lo = nullptr, *dark = nullptr, *grad = nullptr, *glowT = nullptr, *glyphs = nullptr;
  int loW = 0, loH = 0, cur = 1;
  SDL_BlendMode cutMode;
  stbtt_fontinfo font[2][2]; float ascent[2];
  struct Glyph { int x, y, w, h, xo, yo; float adv; };
  std::unordered_map<uint64_t, Glyph> gcache; int gx = 0, gy = 0, growH = 0;
  static const int GW = 2048;

  explicit SdlGfx(SDL_Renderer* r) : R(r) {
    auto px = atlasPixels();
    atlas = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, ATLAS_W, ATLAS_H);
    SDL_UpdateTexture(atlas, nullptr, px.data(), ATLAS_W * 4); SDL_SetTextureBlendMode(atlas, SDL_BLENDMODE_BLEND);
    // ışık dairesi: merkezde tam, kenarda sıfır (karanlığı oyar)
    const int GS = 128; std::vector<uint32_t> g(GS * GS), l(GS * GS);
    for (int y = 0; y < GS; y++) for (int x = 0; x < GS; x++) {
      double dx = (x + 0.5) / (GS / 2.0) - 1, dy = (y + 0.5) / (GS / 2.0) - 1, t = std::sqrt(dx * dx + dy * dy);
      double a = t >= 1 ? 0 : 1 - sstep(0.35, 1, t), b = t >= 1 ? 0 : 1 - t;
      g[y * GS + x] = 0x00FFFFFFu | ((uint32_t)(a * 255 + 0.5) << 24); l[y * GS + x] = 0x00FFFFFFu | ((uint32_t)(b * 255 + 0.5) << 24);
    }
    grad = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, GS, GS); SDL_UpdateTexture(grad, nullptr, g.data(), GS * 4);
    glowT = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, GS, GS); SDL_UpdateTexture(glowT, nullptr, l.data(), GS * 4);
    SDL_SetTextureBlendMode(glowT, SDL_BLENDMODE_ADD);
    cutMode = SDL_ComposeCustomBlendMode(SDL_BLENDFACTOR_ZERO, SDL_BLENDFACTOR_ONE, SDL_BLENDOPERATION_ADD, SDL_BLENDFACTOR_ZERO, SDL_BLENDFACTOR_ONE_MINUS_SRC_ALPHA, SDL_BLENDOPERATION_ADD);
    SDL_SetTextureBlendMode(grad, cutMode);
    for (int b = 0; b < 2; b++) {
      for (int s = 0; s < 2; s++) stbtt_InitFont(&font[b][s], FONT_DATA[b][s], stbtt_GetFontOffsetForIndex(FONT_DATA[b][s], 0));
      int a, d, lg; stbtt_GetFontVMetrics(&font[b][0], &a, &d, &lg);
      int x0, y0, x1, y1; stbtt_GetFontBoundingBox(&font[b][0], &x0, &y0, &x1, &y1);
      ascent[b] = (float)a / (float)(a - d);   // em oranı (yaklaşık)
    }
    glyphs = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STATIC, GW, GW);
    SDL_SetTextureBlendMode(glyphs, SDL_BLENDMODE_BLEND);
    clearGlyphs();
  }
  void clearGlyphs() {
    gcache.clear(); gx = gy = growH = 0;
    std::vector<uint32_t> z(GW * 64, 0x00FFFFFF); for (int y = 0; y < GW; y += 64) { SDL_Rect r{ 0, y, GW, 64 }; SDL_UpdateTexture(glyphs, &r, z.data(), GW * 4); }
  }
  void ensureLow(int w, int h) {
    if (lo && w == loW && h == loH) return;
    if (lo) SDL_DestroyTexture(lo); if (dark) SDL_DestroyTexture(dark);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    lo = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET, w, h);
    dark = SDL_CreateTexture(R, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET, w, h);
    SDL_SetTextureBlendMode(lo, SDL_BLENDMODE_BLEND); SDL_SetTextureBlendMode(dark, SDL_BLENDMODE_BLEND);
    loW = w; loH = h;
  }
  void target(int t) override { cur = t; SDL_SetRenderTarget(R, t == 0 ? lo : nullptr); }
  void setCol(Col c) { SDL_SetRenderDrawColor(R, (Uint8)(c.r * 255 + 0.5f), (Uint8)(c.g * 255 + 0.5f), (Uint8)(c.b * 255 + 0.5f), (Uint8)(clampf(c.a, 0, 1) * 255 + 0.5f)); }
  void rect(double x, double y, double w, double h, Col c) override {
    if (w <= 0 || h <= 0 || c.a <= 0) return;
    SDL_SetRenderDrawBlendMode(R, SDL_BLENDMODE_BLEND); setCol(c);
    SDL_FRect r{ (float)x, (float)y, (float)w, (float)h }; SDL_RenderFillRectF(R, &r);
  }
  void sprite(const Spr* s, double dx, double dy, double dw, double dh, bool flip, double a) override {
    if (a <= 0) return;
    SDL_Rect src{ (int)s->x, (int)s->y, (int)s->w, (int)s->h };
    SDL_FRect dst{ (float)dx, (float)dy, (float)dw, (float)dh };
    SDL_SetTextureAlphaMod(atlas, (Uint8)(a * 255 + 0.5));
    SDL_RenderCopyExF(R, atlas, &src, &dst, 0, nullptr, flip ? SDL_FLIP_HORIZONTAL : SDL_FLIP_NONE);
  }
  void spriteRot(const Spr* s, double px, double py, double ox, double oy, double ang, double sc, double a) override {
    if (a <= 0) return;
    SDL_Rect src{ (int)s->x, (int)s->y, (int)s->w, (int)s->h };
    SDL_FRect dst{ (float)(px - ox * sc), (float)(py - oy * sc), (float)(s->w * sc), (float)(s->h * sc) };
    SDL_FPoint c{ (float)(ox * sc), (float)(oy * sc) };
    SDL_SetTextureAlphaMod(atlas, (Uint8)(a * 255 + 0.5));
    SDL_RenderCopyExF(R, atlas, &src, &dst, ang * 180 / PI, &c, SDL_FLIP_NONE);
  }
  void ellipse(double cx, double cy, double rx, double ry, Col c, double lw) override {
    if (c.a <= 0) return;
    SDL_SetRenderDrawBlendMode(R, SDL_BLENDMODE_BLEND); setCol(c);
    for (int k = 0; k < (int)std::max(1.0, lw); k++) {
      SDL_FPoint p[49]; double r1 = rx - k * 0.7, r2 = ry - k * 0.7;
      for (int i = 0; i <= 48; i++) { double a = i * 2 * PI / 48; p[i] = { (float)(cx + std::cos(a) * r1), (float)(cy + std::sin(a) * r2) }; }
      SDL_RenderDrawLinesF(R, p, 49);
    }
  }
  void darkBegin(Col c) override {
    SDL_SetRenderTarget(R, dark);
    SDL_SetRenderDrawBlendMode(R, SDL_BLENDMODE_NONE); setCol(c); SDL_RenderClear(R);
  }
  void darkCut(double x, double y, double r) override { SDL_FRect d{ (float)(x - r), (float)(y - r), (float)(r * 2), (float)(r * 2) }; SDL_RenderCopyF(R, grad, nullptr, &d); }
  void darkEnd() override { SDL_SetRenderTarget(R, lo); SDL_RenderCopy(R, dark, nullptr, nullptr); }
  void glow(double x, double y, double r, double a) override {
    SDL_SetTextureColorMod(glowT, 255, 186, 84); SDL_SetTextureAlphaMod(glowT, (Uint8)(clampf(a, 0, 1) * 255));
    SDL_FRect d{ (float)(x - r), (float)(y - r), (float)(r * 2), (float)(r * 2) }; SDL_RenderCopyF(R, glowT, nullptr, &d);
  }
  void vgrad(double y0, double y1, Col top, Col bottom) override {
    int w, h; SDL_GetRendererOutputSize(R, &w, &h);
    auto col = [](Col c) { return SDL_Color{ (Uint8)(c.r * 255), (Uint8)(c.g * 255), (Uint8)(c.b * 255), (Uint8)(clampf(c.a, 0, 1) * 255) }; };
    SDL_Vertex v[4] = { { { 0, (float)y0 }, col(top), { 0, 0 } }, { { (float)w, (float)y0 }, col(top), { 0, 0 } }, { { (float)w, (float)y1 }, col(bottom), { 0, 0 } }, { { 0, (float)y1 }, col(bottom), { 0, 0 } } };
    int idx[6] = { 0, 1, 2, 0, 2, 3 };
    SDL_SetRenderDrawBlendMode(R, SDL_BLENDMODE_BLEND);
    SDL_RenderGeometry(R, nullptr, v, 4, idx, 6);
  }
  void blitLow(double x, double y, double w, double h) override { SDL_FRect d{ (float)x, (float)y, (float)w, (float)h }; SDL_RenderCopyF(R, lo, nullptr, &d); }

  // ---- yazı (Pixelify Sans, stb_truetype ile ekran çözünürlüğünde) ----
  static uint32_t nextCp(const string& s, size_t& i) {
    unsigned char c = s[i++];
    if (c < 0x80) return c;
    int n = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : 1; uint32_t cp = c & (0x3F >> n);
    while (n-- > 0 && i < s.size()) cp = (cp << 6) | (s[i++] & 0x3F);
    return cp;
  }
  stbtt_fontinfo* fontFor(uint32_t cp, bool bold, int& gi) {
    for (int s = 0; s < 2; s++) { gi = stbtt_FindGlyphIndex(&font[bold][s], (int)cp); if (gi) return &font[bold][s]; }
    gi = stbtt_FindGlyphIndex(&font[bold][0], '?'); return &font[bold][0];
  }
  Glyph& glyph(uint32_t cp, int px, bool bold) {
    uint64_t key = ((uint64_t)cp << 20) | ((uint64_t)px << 1) | (bold ? 1 : 0);
    auto it = gcache.find(key); if (it != gcache.end()) return it->second;
    int gi; stbtt_fontinfo* f = fontFor(cp, bold, gi);
    float sc = stbtt_ScaleForMappingEmToPixels(f, (float)px);
    int adv, lsb; stbtt_GetGlyphHMetrics(f, gi, &adv, &lsb);
    int x0, y0, x1, y1; stbtt_GetGlyphBitmapBox(f, gi, sc, sc, &x0, &y0, &x1, &y1);
    Glyph g{ 0, 0, x1 - x0, y1 - y0, x0, y0, adv * sc };
    if (g.w > 0 && g.h > 0) {
      if (gx + g.w + 1 > GW) { gx = 0; gy += growH + 1; growH = 0; }
      if (gy + g.h + 1 > GW) { clearGlyphs(); return glyph(cp, px, bold); }
      std::vector<unsigned char> bm(g.w * g.h); stbtt_MakeGlyphBitmap(f, bm.data(), g.w, g.h, g.w, sc, sc, gi);
      std::vector<uint32_t> rgba(g.w * g.h); for (int i = 0; i < g.w * g.h; i++) rgba[i] = 0x00FFFFFFu | ((uint32_t)bm[i] << 24);
      SDL_Rect r{ gx, gy, g.w, g.h }; SDL_UpdateTexture(glyphs, &r, rgba.data(), g.w * 4);
      g.x = gx; g.y = gy; gx += g.w + 1; growH = std::max(growH, g.h);
    }
    return gcache[key] = g;
  }
  double textW(const string& s, double px, bool bold) override {
    int p = std::max(1, (int)px); double w = 0;
    for (size_t i = 0; i < s.size();) { uint32_t cp = nextCp(s, i); w += glyph(cp, p, bold).adv; }
    return w;
  }
  void text(const string& s, double X, double Y, double px, Col c, int align, bool bold) override {
    if (c.a <= 0 || s.empty()) return;
    int p = std::max(1, (int)px);
    double w = align ? textW(s, px, bold) : 0, x = align == 1 ? X - w / 2 : align == 2 ? X - w : X;
    double base = Y + ascent[bold] * p;
    if (cur != 1) SDL_SetRenderTarget(R, nullptr);
    SDL_SetTextureColorMod(glyphs, (Uint8)(c.r * 255), (Uint8)(c.g * 255), (Uint8)(c.b * 255));
    SDL_SetTextureAlphaMod(glyphs, (Uint8)(clampf(c.a, 0, 1) * 255));
    for (size_t i = 0; i < s.size();) {
      uint32_t cp = nextCp(s, i); Glyph& g = glyph(cp, p, bold);
      if (g.w > 0) { SDL_Rect src{ g.x, g.y, g.w, g.h }; SDL_FRect dst{ (float)std::round(x + g.xo), (float)std::round(base + g.yo), (float)g.w, (float)g.h }; SDL_RenderCopyF(R, glyphs, &src, &dst); }
      x += g.adv;
    }
    if (cur != 1) SDL_SetRenderTarget(R, lo);
  }
};

// ---------------- ses ----------------
static Synth synth;
static void audioCb(void*, Uint8* stream, int len) { synth.fill((float*)stream, len / (int)sizeof(float)); }

// ---------------- dokunmatik düğmeler ----------------
struct Btn { const char* act; double x, y, r; bool down = false; SDL_FingerID fid = -1; };

#ifdef __ANDROID__
#include <jni.h>
// orijinal kopya mı: paket adı ve imza sertifikası (Google Play'den kurulan sürüm)
static bool androidOriginal() {
  JNIEnv* env = (JNIEnv*)SDL_AndroidGetJNIEnv(); jobject act = (jobject)SDL_AndroidGetActivity();
  if (!env || !act) return false;
  bool ok = false;
  jclass ac = env->GetObjectClass(act);
  jstring pkg = (jstring)env->CallObjectMethod(act, env->GetMethodID(ac, "getPackageName", "()Ljava/lang/String;"));
  const char* p = env->GetStringUTFChars(pkg, nullptr);
  ok = p && string(p) == "com.yesilvadi.ormaninkalbi";
  env->ReleaseStringUTFChars(pkg, p);
  if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
  env->DeleteLocalRef(ac); env->DeleteLocalRef(act);
  return ok;
}
#endif

bool writePng(const char* path, const unsigned char* rgba, int w, int h);
int shotScene(Game& g, const string& sc);
void shotTick(Game& g, const string& sc, int frame);

int main(int argc, char** argv) {
  string shotPath, shotSc; int shotW = 0, shotH = 0;
  for (int i = 1; i + 2 < argc + 1; i++) if (!strcmp(argv[i], "--shot") && i + 2 < argc) { shotPath = argv[i + 1]; shotSc = argv[i + 2]; if (i + 4 < argc) { shotW = atoi(argv[i + 3]); shotH = atoi(argv[i + 4]); } }
  SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
  SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
  SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "0");
  SDL_SetHint(SDL_HINT_IOS_HIDE_HOME_INDICATOR, "2");
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) { SDL_Log("SDL: %s", SDL_GetError()); return 1; }
  bool mobile = false;
#if defined(__ANDROID__) || defined(__IPHONEOS__)
  mobile = true;
#endif
  Uint32 wf = SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI | (mobile ? SDL_WINDOW_FULLSCREEN : 0);
  SDL_Window* win = SDL_CreateWindow("Ormanın Kalbi", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, shotW ? shotW : 1280, shotH ? shotH : 720, shotPath.size() ? (Uint32)SDL_WINDOW_HIDDEN : wf);
  if (!win) { SDL_Log("pencere: %s", SDL_GetError()); return 1; }
  { SDL_Surface* ic = SDL_CreateRGBSurfaceWithFormatFrom((void*)ICON32, 32, 32, 32, 128, SDL_PIXELFORMAT_ABGR8888); if (ic) { SDL_SetWindowIcon(win, ic); SDL_FreeSurface(ic); } }
  SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_TARGETTEXTURE);
  if (!ren) ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_TARGETTEXTURE);
  SdlGfx gfx(ren);
  // ses: 22050 Hz tek kanal; aygıt başka hız isterse sentez ona uyar
  SDL_AudioSpec want{}, got{};
  want.freq = 22050; want.format = AUDIO_F32SYS; want.channels = 1; want.samples = 1024; want.callback = audioCb;
  SDL_AudioDeviceID dev = SDL_OpenAudioDevice(nullptr, 0, &want, &got, SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
  if (dev) { synth.SR = got.freq; synth.ok = true; SDL_PauseAudioDevice(dev, 0); }
  if (storeGet("orman_ses") == "0") synth.muted = true;

  Game game(&gfx, &synth);
  game.desktop = !mobile;
#ifdef __ANDROID__
  game.pirate = !androidOriginal();
#endif
  int W = 1, H = 1;
  auto doResize = [&] { SDL_GetRendererOutputSize(ren, &W, &H); game.resize(W, H); gfx.ensureLow(game.VW, VH); };
  doResize();
  // dp: dokunmatik düğme boyutları için (160 dpi = 1)
  int ww, wh; SDL_GetWindowSize(win, &ww, &wh);
  double pxScale = (double)W / std::max(1, ww);   // pencere noktası -> piksel
  // dokunmatik düğmelerin birimi ekran yüksekliğinden: her telefonda aynı oran (DPI telefona göre çok değişiyor, iPhone'da iki kez sayılıyordu)
  double dp = 1;
  auto touchUnit = [&] { dp = std::min(H / 460.0, W / 900.0) / pxScale; if (dp < 0.6) dp = 0.6; };
  touchUnit();
  // ekran görüntüsünde telefon arayüzü: ORMAN_MOBIL=1
  bool touchUI = mobile || getenv("ORMAN_MOBIL") != nullptr;

  // klavye: tek oyuncu ve aynı bilgisayarda iki oyuncu
  bool keys[8] = {}, keys2[4] = {};   // sol sağ yukarı aşağı
  std::vector<Btn> btns = { { "attack", 0, 0, 0 }, { "act", 0, 0, 0 }, { "item", 0, 0, 0 }, { "log", 0, 0, 0 }, { "pause", 0, 0, 0 } };
  auto layout = [&] {
    touchUnit(); double u = dp * pxScale;
    btns[0].r = 42 * u; btns[0].x = W - (22 + 42) * u; btns[0].y = H - (26 + 42) * u;
    btns[1].r = 31 * u; btns[1].x = W - (118 + 31) * u; btns[1].y = H - (52 + 31) * u;
    btns[2].r = 25 * u; btns[2].x = W - (40 + 25) * u; btns[2].y = H - (132 + 25) * u;
    double top = ((game.dayY ? game.dayY : 16) + 14) * game.s;
    btns[3].r = 19 * u; btns[3].x = W - (8 + 38 + 8 + 19) * u; btns[3].y = top + 19 * u;
    btns[4].r = 19 * u; btns[4].x = W - (8 + 19) * u; btns[4].y = top + 19 * u;
  };
  SDL_FingerID stickId = -1; double sx = 0, sy = 0, kx = 0, ky = 0; const double SR = 52;
  bool stickOn = false;
  auto press = [&](const char* act, Input& in) {
    Press& p = in.pressed;
    if (!strcmp(act, "attack")) p.attack = true; else if (!strcmp(act, "act")) { p.act = true; p.confirm = true; } else if (!strcmp(act, "item")) p.item = true;
    else if (!strcmp(act, "log")) p.log = true; else if (!strcmp(act, "pause")) p.pause = true; else if (!strcmp(act, "confirm")) p.confirm = true;
    else if (!strcmp(act, "up")) p.up = true; else if (!strcmp(act, "down")) p.down = true; else if (!strcmp(act, "left")) p.left = true; else if (!strcmp(act, "right")) p.right = true;
  };
  auto tapAt = [&](double x, double y) { double vx, vy; game.toVirt(x, y, vx, vy); game.tap(vx, vy); };
  int shotFrames = shotPath.size() ? shotScene(game, shotSc) : -1;
  bool running = true, paused = false;
  Uint64 last = SDL_GetPerformanceCounter();
  while (running) {
    SDL_Event e;
    bool twoP = game.coop == "local" && game.state != S_TITLE;
    while (SDL_PollEvent(&e)) {
      switch (e.type) {
        case SDL_QUIT: running = false; break;
        case SDL_APP_WILLENTERBACKGROUND: case SDL_APP_DIDENTERBACKGROUND: game.pause(); paused = true; if (dev) SDL_PauseAudioDevice(dev, 1); break;
        case SDL_APP_DIDENTERFOREGROUND: paused = false; if (dev) SDL_PauseAudioDevice(dev, 0); last = SDL_GetPerformanceCounter(); break;
        case SDL_WINDOWEVENT:
          if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED || e.window.event == SDL_WINDOWEVENT_RESIZED) { doResize(); SDL_GetWindowSize(win, &ww, &wh); pxScale = (double)W / std::max(1, ww); }
          if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST && !mobile) { for (auto& k : keys) k = false; for (auto& k : keys2) k = false; }
          break;
        case SDL_TEXTINPUT:
          if (game.joinOpen) for (const char* c = e.text.text; *c; c++) game.joinKey(*c);
          else for (const char* c = e.text.text; *c; c++) game.typed(*c);   // gizli şifreler
          break;
        case SDL_KEYDOWN: case SDL_KEYUP: {
          bool dn = e.type == SDL_KEYDOWN, rep = e.key.repeat != 0; SDL_Keycode k = e.key.keysym.sym;
          if (dn && k == SDLK_F11 && !mobile) { bool fs = SDL_GetWindowFlags(win) & SDL_WINDOW_FULLSCREEN_DESKTOP; SDL_SetWindowFullscreen(win, fs ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP); break; }
          if (game.joinOpen) { if (dn && (k == SDLK_BACKSPACE || k == SDLK_RETURN || k == SDLK_ESCAPE || k == SDLK_AC_BACK)) game.joinKey(k == SDLK_BACKSPACE ? 8 : k == SDLK_RETURN ? 13 : 27); break; }
          if (dn && k == SDLK_AC_BACK) { if (game.state == S_PLAY) press("pause", game.inp); break; }
          if (twoP) {
            int i1 = -1, i2 = -1; const char* a1 = nullptr; const char* a2 = nullptr;
            switch (k) {
              case SDLK_a: i1 = 0; break; case SDLK_d: i1 = 1; break; case SDLK_w: i1 = 2; break; case SDLK_s: i1 = 3; break;
              case SDLK_f: a1 = "attack"; break; case SDLK_g: a1 = "act"; break; case SDLK_r: a1 = "item"; break; case SDLK_TAB: a1 = "log"; break;
              case SDLK_ESCAPE: a1 = "pause"; break; case SDLK_RETURN: case SDLK_SPACE: a1 = "confirm"; break;
              case SDLK_LEFT: i2 = 0; break; case SDLK_RIGHT: i2 = 1; break; case SDLK_UP: i2 = 2; break; case SDLK_DOWN: i2 = 3; break;
              case SDLK_k: a2 = "attack"; break; case SDLK_l: a2 = "act"; break; case SDLK_o: a2 = "item"; break;
            }
            static const char* DIRS[4] = { "left", "right", "up", "down" };
            if (i1 >= 0) { keys[i1] = dn; if (dn && !rep) press(DIRS[i1], game.inp); }
            if (a1 && dn && !rep) press(a1, game.inp);
            if (i2 >= 0) { keys2[i2] = dn; if (dn && !rep && game.p2) press(DIRS[i2], game.p2->inp); }
            if (a2 && dn && !rep && game.p2) press(a2, game.p2->inp);
            break;
          }
          int di = -1; const char* a = nullptr;
          switch (k) {
            case SDLK_LEFT: case SDLK_a: di = 0; break; case SDLK_RIGHT: case SDLK_d: di = 1; break; case SDLK_UP: case SDLK_w: di = 2; break; case SDLK_DOWN: case SDLK_s: di = 3; break;
            case SDLK_SPACE: case SDLK_j: a = "attack"; break; case SDLK_e: case SDLK_k: a = "act"; break; case SDLK_RETURN: a = "confirm"; break; case SDLK_q: a = "item"; break;
            case SDLK_l: case SDLK_TAB: a = "log"; break; case SDLK_ESCAPE: a = "pause"; break;
          }
          static const char* DIRS[4] = { "left", "right", "up", "down" };
          if (di >= 0) { keys[di] = dn; if (dn && !rep) press(DIRS[di], game.inp); }
          if (a && dn && !rep) press(a, game.inp);
          break;
        }
        case SDL_MOUSEBUTTONDOWN:
          if (e.button.button == SDL_BUTTON_LEFT && (game.uiMode() || game.joinOpen)) tapAt(e.button.x * pxScale, e.button.y * pxScale);
          break;
        case SDL_FINGERDOWN: {
          double x = e.tfinger.x * W, y = e.tfinger.y * H;
          if (game.uiMode() || game.joinOpen) break;   // menü ve diyalogda dokunuş bırakınca işlenir
          bool hitBtn = false;
          for (auto& b : btns) if (std::hypot(x - b.x, y - b.y) < b.r * 1.15) { b.down = true; b.fid = e.tfinger.fingerId; press(b.act, game.inp); hitBtn = true; break; }
          if (!hitBtn && x < W * 0.5 && stickId == (SDL_FingerID)-1) { stickId = e.tfinger.fingerId; sx = x; sy = y; kx = ky = 0; stickOn = true; }
          break;
        }
        case SDL_FINGERMOTION:
          if (e.tfinger.fingerId == stickId) {
            double x = e.tfinger.x * W, y = e.tfinger.y * H, R0 = SR * dp * pxScale;
            double dx = x - sx, dy = y - sy, l = std::hypot(dx, dy);
            if (l > R0) { sx += dx / l * (l - R0); sy += dy / l * (l - R0); dx = x - sx; dy = y - sy; }   // çubuk parmağı izler
            kx = dx / R0; ky = dy / R0;
          }
          break;
        case SDL_FINGERUP: {
          double x = e.tfinger.x * W, y = e.tfinger.y * H;
          for (auto& b : btns) if (b.fid == e.tfinger.fingerId) { b.down = false; b.fid = -1; }
          if (e.tfinger.fingerId == stickId) { stickId = -1; kx = ky = 0; stickOn = false; break; }
          if (game.uiMode() || game.joinOpen) tapAt(x, y);
          break;
        }
      }
    }
    Uint64 now = SDL_GetPerformanceCounter();
    double dt = std::min(0.05, (double)(now - last) / SDL_GetPerformanceFrequency()); last = now;
    if (paused) { SDL_Delay(50); continue; }
    if (game.uiMode() && stickOn) { stickId = -1; kx = ky = 0; stickOn = false; }
    if (stickOn) { game.inp.ax = kx; game.inp.ay = ky; }
    else { game.inp.ax = (keys[1] ? 1 : 0) - (keys[0] ? 1 : 0); game.inp.ay = (keys[3] ? 1 : 0) - (keys[2] ? 1 : 0); }
    if (game.p2 && game.coop == "local") { game.p2->inp.ax = (keys2[1] ? 1 : 0) - (keys2[0] ? 1 : 0); game.p2->inp.ay = (keys2[3] ? 1 : 0) - (keys2[2] ? 1 : 0); }
    if (game.joinOpen && !SDL_IsTextInputActive()) SDL_StartTextInput();
    if (!game.joinOpen && mobile && SDL_IsTextInputActive()) SDL_StopTextInput();
    if (shotFrames >= 0) { static int fr = 0; shotTick(game, shotSc, ++fr); }
    game.netPoll(dt);
    game.update(dt);
    game.render();
    // dokunmatik düğmeler (telefonda; menü ve diyalogda gizli)
    if (touchUI && !game.uiMode() && !game.joinOpen) {
      layout();
      gfx.target(1);
      bool near = game.findInteract().npc || game.findInteract().cat || game.findInteract().obj;
      auto disc = [&](double cx, double cy, double r, Col c) {
        const int N = 32; SDL_Vertex v[N + 1]; int idx[N * 3];
        SDL_Color col{ (Uint8)(c.r * 255), (Uint8)(c.g * 255), (Uint8)(c.b * 255), (Uint8)(c.a * 255) };
        v[0] = { { (float)cx, (float)cy }, col, { 0, 0 } };
        for (int i = 0; i < N; i++) { double a = i * 2 * PI / N; v[i + 1] = { { (float)(cx + std::cos(a) * r), (float)(cy + std::sin(a) * r) }, col, { 0, 0 } }; idx[i * 3] = 0; idx[i * 3 + 1] = i + 1; idx[i * 3 + 2] = (i + 1) % N + 1; }
        SDL_RenderGeometry(ren, nullptr, v, N + 1, idx, N * 3);
      };
      for (size_t i = 0; i < btns.size(); i++) {
        Btn& b = btns[i];
        Col base = i == 0 ? rgba(200, 60, 60, b.down ? 0.75 : 0.5) : i == 1 ? rgba(70, 150, 230, b.down ? 0.75 : near ? 0.62 : 0.42) : rgba(40, 34, 60, b.down ? 0.75 : 0.5);
        disc(b.x, b.y, b.r, rgba(20, 14, 30, 0.35)); disc(b.x, b.y, b.r * 0.92, base);
        double sc = b.r / 10;
        if (i == 0) gfx.spriteRot(game.A.sword, b.x, b.y, 3.5, 7, PI / 4, sc * 0.42, 1);
        else if (i == 1) gfx.text("...", b.x, b.y - b.r * 0.55, b.r * 0.9, hexc(0xffffff), 1, true);
        else if (i == 2) { const Spr* sp = game.breads > 0 && game.potions == 0 ? game.A.bread : game.A.potion; gfx.sprite(sp, b.x - sp->w * sc * 0.25, b.y - sp->h * sc * 0.25, sp->w * sc * 0.5, sp->h * sc * 0.5, false, game.potions + game.breads ? 1 : 0.45);
          int n = game.potions > 0 ? game.potions : game.breads; if (n) gfx.text(std::to_string(n), b.x + b.r * 0.75, b.y - b.r * 1.15, b.r * 0.7, hexc(0xffffff), 1, true); }
        else if (i == 3) for (int k = -1; k <= 1; k++) gfx.rect(b.x - b.r * 0.45, b.y + k * b.r * 0.32 - b.r * 0.07, b.r * 0.9, b.r * 0.14, hexc(0xffffff));
        else { gfx.rect(b.x - b.r * 0.32, b.y - b.r * 0.4, b.r * 0.22, b.r * 0.8, hexc(0xffffff)); gfx.rect(b.x + b.r * 0.1, b.y - b.r * 0.4, b.r * 0.22, b.r * 0.8, hexc(0xffffff)); }
        static const char* LBL[5] = { "Kılıç", "Konuş", "İksir", "", "" };
        if (LBL[i][0]) gfx.text(LBL[i], b.x, b.y + b.r + 3 * dp * pxScale, 11 * dp * pxScale, rgba(255, 255, 255, 0.85), 1, false);
      }
      if (stickOn) {
        double R0 = SR * dp * pxScale;
        disc(sx, sy, 56 * dp * pxScale, rgba(255, 255, 255, 0.12)); disc(sx + kx * R0, sy + ky * R0, 25 * dp * pxScale, rgba(255, 255, 255, 0.35));
      } else { disc(W * 0.12, H - 76 * dp * pxScale, 46 * dp * pxScale, rgba(255, 255, 255, 0.07)); gfx.text("Hareket", W * 0.12, H - 22 * dp * pxScale, 11 * dp * pxScale, rgba(255, 255, 255, 0.6), 1, false); }
    }
    if (shotFrames >= 0 && --shotFrames <= 0) {
      std::vector<unsigned char> px((size_t)W * H * 4);
      SDL_RenderReadPixels(ren, nullptr, SDL_PIXELFORMAT_ABGR8888, px.data(), W * 4);
      for (size_t i = 3; i < px.size(); i += 4) px[i] = 255;
      writePng(shotPath.c_str(), px.data(), W, H); running = false;
    }
    SDL_RenderPresent(ren);
  }
  game.netClose();
  if (dev) SDL_CloseAudioDevice(dev);
  SDL_DestroyRenderer(ren); SDL_DestroyWindow(win); SDL_Quit();
  return 0;
}
