// ORMANIN KALBİ - oyunun durumu (bütün bölümler). Yöntemlerin bildirimleri protos.inc'te (cpp/tools/protos.js üretir).
#pragma once
#include "core.h"
#include "audio.h"
#include "net.h"
#include <array>

// çizim katmanı: platform (SDL) ya da testlerdeki boş çizici uygular
struct Gfx {
  virtual ~Gfx() {}
  // 0: düşük çözünürlüklü dünya tuvali (VW x 180), 1: ekran (W x H)
  virtual void target(int t) = 0;
  virtual void rect(double x, double y, double w, double h, Col c) = 0;
  virtual void sprite(const Spr* src, double dx, double dy, double dw, double dh, bool flip, double a) = 0;
  virtual void spriteRot(const Spr* src, double px, double py, double ox, double oy, double ang, double sc, double a) = 0;
  virtual void ellipse(double cx, double cy, double rx, double ry, Col c, double lw) = 0;
  // karanlık katmanı: doldur, ışıkların çevresini aç, dünyanın üstüne bas
  virtual void darkBegin(Col c) = 0;
  virtual void darkCut(double x, double y, double r) = 0;
  virtual void darkEnd() = 0;
  virtual void glow(double x, double y, double r, double a) = 0;
  // ekran: yukarıdan aşağı geçişli dolgu, düşük çözünürlüklü tuvali ekrana büyütme, yazı
  virtual void vgrad(double y0, double y1, Col top, Col bottom) = 0;
  virtual void blitLow(double x, double y, double w, double h) = 0;
  virtual void text(const string& s, double X, double Y, double px, Col c, int align, bool bold) = 0;
  virtual double textW(const string& s, double px, bool bold) = 0;
};

enum { S_TITLE = 0, S_PLAY = 1, S_PAUSE = 2, S_OVER = 3, S_CREDITS = 4 };
enum {
  E_SLIME = 0, E_SLIMER = 1, E_OCTO = 2, E_BAT = 3, E_SKEL = 4, E_BOSS = 5, E_CHICK = 6, E_ROCKP = 7, E_WOLF = 8, E_BOAR = 9, E_THORN = 10, E_GHOST = 11, E_STUMP = 12, E_SEED = 13, E_CAT = 14,
  E_SNOWWOLF = 15, E_ICESLIME = 16, E_ICEBAT = 17, E_YETI = 18, E_GOLEM = 19, E_GOAT = 20, E_SNOWBALL = 21, E_SHARD = 22,
  E_KEMAL = 23, E_HAMMER = 24, E_COINP = 25, E_SYETI = 26,
  E_CRAB = 27, E_GULL = 28, E_JELLY = 29, E_CRABKING = 30, E_KRAKEN = 31, E_TENTACLE = 32, E_BUBBLE = 33, E_GCAPTAIN = 34, E_BLADE = 35,
};
enum { P_COIN = 0, P_HEART = 1, P_KEY = 2, P_BKEY = 3, P_HEARTC = 4, P_GEM = 5, P_MUSH = 6, P_FIRESTONE = 7, P_GEM2 = 8, P_PEARL = 9, P_GEM3 = 10, P_TIDEPEARL = 11 };
enum { N_ELDER = 1, N_SHOP = 2, N_KID = 3, N_HERMIT = 4, N_FISHER = 5, N_BAKER = 6, N_MUHTAR = 7, N_SMITH = 8, N_SHEPHERD = 9, N_TRAVELER = 10, N_INNKEEP = 11, N_HUNTER = 12,
  N_CAPTAIN = 13, N_PEARLMA = 14, N_COOK = 15, N_KEEPER = 16, N_INNKEEP3 = 17 };
enum { Q_CAT = 0, Q_CHICK = 1, Q_BREAD = 2, Q_OCTO = 3, Q_GHOST = 4, Q_GOAT = 5, Q_FROZEN = 6, Q_WOLVES = 7, Q_PEARLS = 8, Q_CRABS = 9, Q_LIGHT = 10, Q_COUNT = 11 };
enum { F_BLOCK = 1, F_TORCH = 2, F_STUMP = 4, F_BREADSHOP = 8, F_BASKET = 16,
  F2_BLOCK = 1 << 12, F2_TORCH = 1 << 13, F2_YETI = 1 << 14, F2_SNOWINTRO = 1 << 15, F2_TRAVELER = 1 << 16, F2_FIREWARM = 1 << 17,
  F3_BLOCK = 1 << 18, F3_CRABKING = 1 << 19, F3_LIGHT = 1 << 20, F3_GCAPTAIN = 1 << 21, F3_INTRO = 1 << 22 };
enum { SEC_MEDAL = 1, SEC_HERMIT = 2, SEC_GAVE = 4, SEC_KEMAL = 16, SEC_YCAVE = 32, SEC_LAUGH = 64 };
constexpr int VH = 180;
constexpr double PHW = 5.5, PHH = 11;
extern const char* QNAME[Q_COUNT];
extern const int MUSH_POS[3][2];
bool isProjT(int t);
bool isBigT(int t);
bool isTameT(int t);
const char* platformName();

// ikinci oyuncu (aynı bilgisayar ya da online)
struct P2 {
  double px = 0, py = 0; int pdir = 0; double attackT = 0; int attackId = 100000; double invT = 0, kT = 0, kx = 0, ky = 0, animT = 0; bool moving = false;
  double pvx = 0, pvy = 0, freezeT = 0, dustT = 0, pushT = 0; int hp = 6; double deadT = 0; Input inp; int gen = 0, tp = 0; bool remote = false, remoteMoving = false;
  const std::vector<std::vector<const Spr*>>* set = nullptr; double gx = 0, gy = 0;
};
struct Hero { double x, y; int n; };
struct Hit { double x, y, w, h; std::function<void()> fn; };
struct DarkInfo { double base; int col[3]; };
struct LightSrc { double x, y, r; };

class Game;
// eklenti kayıtları: sonraki bölümler kendi türlerini buraya ekler
struct Ext {
  std::unordered_map<int, std::function<void(Ent&, double, double, double, double)>> enemy;
  std::unordered_map<int, std::function<void(Ent&, double, double, bool)>> draw;
  std::unordered_map<int, std::function<bool(Ent&)>> kill;
  std::unordered_map<int, std::function<void(Ent&, double)>> hit;
  std::unordered_map<int, std::function<void(Pick&)>> pick;
  std::unordered_map<int, std::function<void(int)>> chest;
  std::unordered_map<int, std::function<void(int, int, int, double, double)>> tile, tileAll;
  std::unordered_map<int, std::function<void(Obj&, double, double)>> obj;
  std::unordered_map<int, std::function<void(Obj&)>> interact, cut;
  std::unordered_map<int, std::function<void(Npc&)>> talk;
  std::unordered_map<int, std::function<bool(Npc*)>> talkPre;
  std::vector<std::function<void()>> npcs;
  std::unordered_map<int, int> hp;
  std::unordered_map<int, std::function<void(int, int, bool, bool)>> trans;
  std::vector<std::function<bool(int, int, bool, bool)>> transOver;
  std::unordered_map<int, std::function<void()>> area;
  std::vector<std::function<void()>> areaOver;
  std::unordered_map<int, std::function<DarkInfo(double, double, std::vector<LightSrc>&)>> dark;
  std::unordered_map<int, std::function<void()>> enter;
  std::unordered_map<int, std::function<void(int, int)>> enterAt;   // JS: enter[yer + 100](rx, ry)
  std::unordered_map<int, std::function<int()>> saveAs;
  std::unordered_map<int, int> mood;
  struct PushX { int flag; std::function<void()> done; };
  std::unordered_map<int, PushX> push;
  struct RoomX { std::function<bool(int)> isClear; std::function<void(int, bool)> enter; std::function<void(int)> cleared; };
  std::unordered_map<int, RoomX> room;
  std::unordered_map<int, bool Game::*> bossKey;
  std::unordered_map<int, std::function<void()>> exitDg;
  std::vector<std::function<void(WorldMap&)>> overBuild;
  std::unordered_map<int, int> interiorMap;
  std::unordered_map<int, std::function<const double*(Obj&)>> light;   // [yarıçap, yükseklik] ya da nullptr
};

class Game {
 public:
  Art A; Synth* au = nullptr; Gfx* g = nullptr; Ext EXT;
  int VW = 320, W = 1, H = 1; double s = 1, ox0 = 0;
  Input inp; std::vector<Hit> hits; std::map<string, std::vector<string>> textCache;
  std::function<void(const char*)> onHaptic;
  int state = S_TITLE; WorldMap map; std::vector<Room> rooms; int interior = -1; int interiorRet[2] = { 0, 0 };
  std::vector<std::unique_ptr<Ent>> ents; std::vector<std::unique_ptr<Pick>> picks; std::vector<Part> pts; std::vector<std::unique_ptr<Npc>> npcs;
  double px = 47 * 16 + 8, py = 60 * 16, animT = 0, attackT = 0, invT = 0, kT = 0, kx = 0, ky = 0, deathT = 0, dustT = 0, pushT = 0;
  int pdir = 0, attackId = 0; bool moving = false;
  // ilerleme (kaydedilir)
  int hp = 6, maxHp = 6, coins = 0, keys = 0, potions = 0, breads = 0, swordLv = 0, hpPieces = 0;
  bool hasLantern = false, bossKey = false, hasGem = false, cured = false, bossDead = false;
  uint32_t chestMask = 0, doorMask = 0, clearMask = 0; int flags = 0, mainStep = 0, mushMask = 0;
  int qs[Q_COUNT] = {}, qc[Q_COUNT] = {}; double dayT = 0.3; int dayN = 1;
  uint32_t iceMask = 0, clear2 = 0; bool hasFireStone = false, hasFireLantern = false, hasGem2 = false, bossKey2 = false, golemDead = false;
  double pvx = 0, pvy = 0, freezeT = 0;
  int sec = 0; uint32_t c3 = 0, clear3 = 0; bool hasCharm = false, hasGem3 = false, bossKey3 = false, krakenDead = false; int tide = 0;
  // kamera, geçişler, diyalog, arayüz
  double camX = 0, camY = 0, shake = 0, time = 0, roomT = 0; int curRoom = -1, mood = -1;
  double fade = 0; int fadeState = 0; std::function<void()> fadeCb;
  int pushObj = -1; double pushAnim = 0, pushFX = 0, pushFY = 0;
  bool dlg = false, dlgClosed = false; std::vector<Line> dl; int di = 0; double dchars = 0; std::function<void()> dDone;
  std::vector<string> dChoices; std::function<void(int)> dChoice; int dSel = 0;
  double toastT = 0; string toastS; double itemShowT = 0; const Spr* itemShow = nullptr;
  int menuSel = 0; double creditsT = 0; bool questLog = false; double titleCam = 0; uint32_t rs = 12345;
  bool pirate = false, desktop = false;
  double drawOX = 0, drawOY = 0, hudRowY = 0, dayY = 18, objH = 14;
  const std::vector<std::vector<const Spr*>>* heroSet = nullptr;
  string menuNote, menuMode = "main", chapBack = "main", coop;
  std::unique_ptr<P2> p2;
  // gizli bölümler, 2. ve 3. bölüm
  string typedBuf; double laughCd = 0; int caveId = 0; double kemalWait = 0; int boatPos[2] = { 78, 50 };
  struct Flake { double x, y, s, p; }; std::vector<Flake> flakes; double lastWx = 0;
  struct Found { Npc* npc; Ent* cat; Obj* obj; };
  // online
  struct Snap { int st = 0, k = 0, i = 0, cv = 0, rr[2] = { 0, 0 }, mood = 0; double sh = 0, fd = 0; int room = 0, tp = 0; double cr = 0, dt = 0, a[10] = {}; bool hasB = false; double b[5] = {}; };
  struct SnapEnt { int nid, type; double x, y, z; int st; double t; int dir, fl; double vx, vy; int inv; };
  string netRole; bool netLive = false, netOpen = false, joinOpen = false, guestMenu = false, hostPaused = false, gDead = false;
  std::unique_ptr<NetTransport> net; string roomCode, gKey, joinCode, netLastProg, netLastObj; std::vector<string> netFx;
  double netWait = 0, netAcc = 0, gAcc = 0; int gPress = 0, gTp = 0, netId = 0, netProgN = 0, netObjN = 0;
  std::function<void()> onJoinRequest;

  explicit Game(Gfx* gfx, Synth* synth);
#include "protos.inc"
};
