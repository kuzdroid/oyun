// ORMANIN KALBİ - uzun hikâye: her bölümde iki zorunlu ana hikâye zinciri ve çok adımlı yan görevler
// Görevler veri olarak yazılır (tablo); adımlar: biriyle konuş, düşman yen, eşya topla, bir yere git.
// İlerleme hs[] (0: alınmadı, 1..: şu anki adım, 100: bitti) ve hc[] (sayaç / toplanan eşyaların bitleri) ile kaydedilir.
#include "game.h"

enum { K_TALK = 0, K_KILL = 1, K_FETCH = 2, K_GOTO = 3 };
// yeni köylüler (A.villager sırasıyla aynı)
enum { H_KAYA = 40, H_GULSUM, H_ULAS, H_RIZA, H_KEREM, H_AYSE, H_VELI, H_DURSUN, H_MELEK, H_BURAN, H_MERT, H_PUSULA, H_NAZLI, H_YILDIZ, H_CANCI, H_BULUT, H_SON };
static const int HDONE = 100;

struct HAdim {
  int kind = K_TALK, npc = 0; string hint; std::vector<Line> said;
  int map = -1, enemy = -1, count = 0; bool night = false; int r[4] = { 0, 0, 0, 0 };
  std::vector<std::pair<int, int>> at; int spr = 0;
};
struct HGorev {
  string name, where; int chap = 1; bool main = false; int giver = 0, minStep = 0, maxStep = 999, needQ = -1, needOld = -1; string gateHint, need;
  std::vector<Line> intro; std::vector<HAdim> steps; int coins = 0, potions = 0, breads = 0; bool piece = false, heartC = false;
};
struct HKisi { int id, map, interior, x, y, when, minStep; string name; bool flip; std::vector<string> idle; int spr = -1; };   // spr: A.villager sırası (-1: id'den)
// Oyun Adası'nın köylüleri (Bölüm 1-5) ve oradaki ustalar (bolum5.cpp)
enum { H_MUSTAFA = 66, H_HASAN, H_ZEYNEP, H_HUSNU, H_SULTAN };
enum { N_MASTER5 = 60, N_GDAMA5, N_GSATRANC5, N_GTAVLA5, N_GPAPAZ5, N_GOKEY5 };

static HAdim konus(int npc, const string& hint, std::vector<Line> said) { HAdim a; a.kind = K_TALK; a.npc = npc; a.hint = hint; a.said = said; return a; }
static HAdim yen(int map, int enemy, int n, std::array<int, 4> r, bool night, int npc, const string& hint, std::vector<Line> said) {
  HAdim a; a.kind = K_KILL; a.map = map; a.enemy = enemy; a.count = n; for (int i = 0; i < 4; i++) a.r[i] = r[i]; a.night = night; a.npc = npc; a.hint = hint; a.said = said; return a;
}
static HAdim topla(int map, int spr, std::vector<std::pair<int, int>> at, int npc, const string& hint, std::vector<Line> said) {
  HAdim a; a.kind = K_FETCH; a.map = map; a.spr = spr; a.at = at; a.count = (int)at.size(); a.npc = npc; a.hint = hint; a.said = said; return a;
}
static HAdim git(int map, int x, int y, const string& hint, std::vector<Line> said) { HAdim a; a.kind = K_GOTO; a.map = map; a.at = { { x, y } }; a.hint = hint; a.said = said; return a; }

static std::vector<HKisi> KISI;
static std::vector<HGorev> TAB;
static const std::map<int, string> ESKI_AD = {
  { N_ELDER, "Bilge Nine" }, { N_SHOP, "Kemal Usta" }, { N_KID, "Küçük Efe" }, { N_HERMIT, "Yaşlı Bekçi" }, { N_FISHER, "Balıkçı Çocuk" }, { N_BAKER, "Fırıncı Hatice" },
  { N_MUHTAR, "Muhtar Ayaz" }, { N_SMITH, "Demirci Bora" }, { N_SHEPHERD, "Çoban Lale" }, { N_TRAVELER, "Gezgin Rüzgâr" }, { N_INNKEEP, "Hancı Kardelen" }, { N_HUNTER, "Avcı Tolga" },
  { N_CAPTAIN, "Kaptan Deniz" }, { N_PEARLMA, "İnci Ana" }, { N_COOK, "Aşçı Ozan" }, { N_KEEPER, "Fenerci Nur" }, { N_INNKEEP3, "Hancı Dalga" },
  { N_WINDMA, "Rüzgâr Ana" }, { N_BIRDKEEPER, "Kuşçu Serçe" }, { N_MILLER, "Değirmenci Poyraz" }, { N_CLOUDGUARD, "Bulut Bekçisi Tan" }, { N_INNKEEP4, "Hancı Meltem" }, { N_FATHER, "Baba" },
  { N_MASTER5, "Oyun Ustası Bilmece" }, { N_GDAMA5, "Dama Dedesi Şükrü" }, { N_GSATRANC5, "Satranççı Vezir Hanım" }, { N_GTAVLA5, "Tavlacı Zar Ali" }, { N_GPAPAZ5, "Kartçı Papatya" }, { N_GOKEY5, "Okeyci Nimet Teyze" } };
static string adOf(int id) {
  auto it = ESKI_AD.find(id); if (it != ESKI_AD.end()) return it->second;
  for (auto& k : KISI) if (k.id == id) return k.name;
  return "";
}

// ---------------- köylüler ----------------
static void kisiler() {
  KISI = {
    { H_KAYA, MAP_OVER, -1, 49, 49, 0, 0, "Bekçi Kaya", false, { "Nöbet uzun, gece daha uzun. Ama köy uyurken biri uyanık kalmalı.", "Kuzeyden esen rüzgâr bugün daha temiz. Sis geriliyor mu ne?" } },
    { H_GULSUM, MAP_OVER, -1, 36, 60, 1, 0, "Ebe Gülsüm", false, { "Her otun bir derdi, her derdin bir otu vardır, yavrum.", "Kızım Kardelen karlı dağlarda han işletiyor. Yolun düşerse selamımı söyle." } },
    { H_ULAS, MAP_OVER, -1, 60, 60, 1, 0, "Postacı Ulaş", true, { "Mektup var, mektup! ...Yok, sana değil. Henüz.", "Yeşilvadi'nin her kapısını bilirim. Kemal Usta'nınki hep gıcırdar." } },
    { H_RIZA, MAP_OVER, -1, 78, 62, 1, 0, "Çiftçi Rıza", false, { "Toprak sabırlıdır; ekersen biçersin. Domuzlar sabırsızdır; ekersen yerler.", "Bu yıl buğday bereketli olacak. Sis olmasa daha da olurdu." } },
    { H_KEREM, MAP_OVER, -1, 104, 57, 1, 0, "Avcı Kerem", true, { "Bataklıkta iz sürmek zordur. İzler suyla birlikte kaybolur.", "Babanı tanırdım Arda. Benden iyi okçuydu, söylemesi zor ama." } },
    { H_AYSE, MAP_OVER, -1, 44, 63, 1, 0, "Minik Ayşe", false, { "Büyüyünce ben de bekçi olacağım! Tahta kılıcım bile var. ...Kırık ama.", "Tekir dün yine benim ekmeğimi çaldı!" } },
    { H_VELI, MAP_OVER, -1, 66, 55, 1, 0, "Aşık Veli", false, { "Sazım susarsa köy de susar, delikanlı.", "Bir türkü yakacağım senin için: 'Bekçinin Yolu'. Henüz bitmedi; sen bitirince biter." } },
    { H_DURSUN, MAP_SNOW, -1, 62, 30, 1, 6, "Madenci Dursun", false, { "Dağın içi de dışı gibi soğuk. Ama içinde altın var, dışında sadece kar.", "Kazmamı kaybettim sanmıştım; meğer elimdeymiş. Soğuk aklı da donduruyor." } },
    { H_MELEK, MAP_SNOW, -1, 38, 38, 1, 6, "Şifacı Melek", true, { "Dağ havası iyileştirir ama önce dondurur.", "Kardelen'in çorbası benim ilaçlarımdan iyidir; ona söyleme." } },
    { H_BURAN, MAP_SNOW, -1, 56, 47, 1, 6, "Kızakçı Buran", false, { "Bu dağlarda kızaktan hızlı tek şey çığdır!", "Köpeklerim kar kurtlarından korkmaz. Ben korkarım ama." } },
    { H_MERT, MAP_SEA, -1, 16, 33, 1, 13, "Dalgıç Mert", false, { "Denizin dibi sessizdir. Sessizlik iyidir, Kraken uyumadıkça.", "Nefesimi üç dakika tutabilirim! ...Tamam, iki." } },
    { H_PUSULA, MAP_SEA, -1, 26, 26, 1, 13, "Haritacı Pusula", true, { "Her harita bir yalandır; ama yararlı bir yalan.", "Kuzey orada. Hayır, orada. Pusulam fırtınadan beri şaşkın." } },
    { H_NAZLI, MAP_SEA, -1, 9, 35, 0, 13, "Ağcı Nazlı", false, { "İyi bir ağ sabırla örülür; kötü bir ağ, aceleyle.", "Gece ağlar parlar, yakamozdan. Gördün mü hiç?" } },
    { H_YILDIZ, MAP_SKY, -1, 44, 29, 0, 21, "Bilgin Yıldız", false, { "Gökyüzünde her yıldızın bir adı var. Bazılarını ben koydum.", "Bulutların üstünde yaşayınca yıldızlar komşu gibi oluyor." } },
    { H_CANCI, MAP_SKY, -1, 34, 27, 1, 21, "Çancı Rüzgâr", true, { "Çanlar susunca rüzgâr da susar. Rüzgâr susunca köy uyur.", "Dinle: her çanın sesi başka. En incesi, en eskisi." } },
    { H_BULUT, MAP_SKY, -1, 46, 33, 1, 21, "Bahçıvan Bulut", false, { "Gök çiçekleri yalnızca yağmurdan önce açar.", "Toprağım az, gökyüzüm çok. Bahçıvan için tuhaf bir dert." } },
    { H_MUSTAFA, MAP_GAMEISLE, -1, 15, 11, 0, 30, "Mustafa Amca", false, { "Elli yıldır bu adadayım. Kaybettiğim oyunları saymadım; kazandıklarımı hiç unutmadım.", "Tavlada zar değil, sabır kazandırır, evlat." }, 3 },
    { H_HASAN, MAP_GAMEISLE, -1, 25, 11, 1, 30, "Kahveci Hasan", true, { "Çay taze, demli! Oyun çayla oynanır.", "Bu masada kim kaybederse çaylar ondan. Hep aynı kişi kaybediyor: Mustafa Amca." }, 11 },
    { H_ZEYNEP, MAP_GAMEISLE, -1, 39, 11, 1, 30, "Küçük Zeynep", false, { "Büyüyünce okey ustası olacağım! Şimdilik taşları diziyorum.", "Kumsalda yengeçlerle yarışıyorum. Onlar yan yan, ben düz." }, 5 },
    { H_HUSNU, MAP_GAMEISLE, -1, 48, 12, 1, 30, "Balıkçı Hüsnü", true, { "Balık oltaya, oyuncu masaya. Herkes kendi işine.", "Martılar ağımı didikliyor; onlara oyun öğretsem mi?" }, 10 },
    { H_SULTAN, MAP_GAMEISLE, -1, 34, 25, 1, 30, "Sultan Teyze", false, { "Okeyci kızlar beni de çağırıyor ama ben çay dağıtırım.", "Meydanın en eski taşı benim, evladım. Her oyunu gördüm." }, 1 },
  };
}

// ---------------- görevler ----------------
static void gorevler() {
  TAB.clear();
  auto add = [](const string& name, int chap, int giver, const string& where) -> HGorev& { TAB.emplace_back(); HGorev& g = TAB.back(); g.name = name; g.chap = chap; g.giver = giver; g.where = where; return g; };
  const int O = MAP_OVER, S = MAP_SNOW, D = MAP_SEA, G = MAP_SKY;

  // ======================= BÖLÜM 1-1: KARA SİS =======================
  { HGorev& g = add("Sisin İzinde", 1, N_ELDER, "Bilge Nine (köy meydanı)"); g.main = true; g.minStep = 0; g.maxStep = 0;
    g.intro = { L("Bilge Nine", "Arda! Gel yanıma, evladım. Dün gece kuzeyden kara bir sis indi. Köyün üstünden geçti, ormana yayıldı."),
      L("Bilge Nine", "Ne olduğunu anlamadan hiçbir yere gidemeyiz. Bekçi Kaya bütün gece nöbetteydi; köyün kuzey girişinde dikilir."),
      L("Bilge Nine", "Ona git, ne gördüğünü sor. Sonra bana anlat. Acele etme; acele eden yolda kalır.") };
    g.steps = {
      konus(H_KAYA, "Köyün kuzey girişindeki Bekçi Kaya ile konuş.", { L("Bekçi Kaya", "Arda. Gördüğümü anlatsam inanmazsın. Sis tapınağın tepesinden yükseldi, bir yılan gibi kıvrılarak indi."),
        L("Bekçi Kaya", "Geçtiği yerde kara kristaller bıraktı. Dokunduğum çimen bir anda sarardı."), L("Bekçi Kaya", "Beş tanesini gördüm: köyün çevresinde, gölün kıyısında, ormanın kenarında. Topla onları, Ebe Gülsüm'e götür. O otlardan da taşlardan da anlar.") }),
      topla(O, 2, { { 40, 40 }, { 56, 36 }, { 72, 60 }, { 24, 60 }, { 88, 48 } }, H_GULSUM, "Beş kara kristali topla, köyün batısındaki Ebe Gülsüm'e götür.", {
        L("Ebe Gülsüm", "Beş tane... Elinde nasıl da soğuk duruyorlar. Bunlar sisin tohumları, yavrum. Kalbin ışığı olmadan çoğalıyorlar."),
        L("Ebe Gülsüm", "Kaynatıp zararsız hale getirebilirim ama ocağım için balçık özü lazım. Köyle göl arasındaki çayırlarda balçık çok; sekizini yen, özlerini getir.") }),
      yen(O, E_SLIME, 8, { 34, 33, 62, 52 }, false, H_GULSUM, "Köyün kuzeyindeki çayırlarda 8 balçık yen, Ebe Gülsüm'e dön.", {
        L("Ebe Gülsüm", "Oldu! Kazan kaynıyor... Bak! Kristalin içinde bir görüntü belirdi."),
        L("", "Kara kristalin yüzeyinde bir an tapınağın kapısı göründü. Kapının önünde, kahverengi saçlı bir adamın gölgesi..."),
        L("Arda", "O kim? Gölge bana el sallıyor gibiydi."), L("Ebe Gülsüm", "Bilmiyorum yavrum. Ama sis geceleri daha güçlü. Bekçi Kaya bu gece nöbette; ona yardım et.") }),
      yen(O, E_GHOST, 3, { 30, 40, 66, 66 }, true, H_KAYA, "Gece köyün çevresinde 3 hortlak kov, sonra Bekçi Kaya'ya haber ver (Kaya gündüz de nöbette).", {
        L("Bekçi Kaya", "Üç hortlak! Sen olmasan şafağı göremezdik belki. Kılıcın tahta ama yüreğin çelik."),
        L("Bekçi Kaya", "Şimdi Nine'ye git. Gördüklerini anlat. O bize ne yapacağımızı söyler.") }),
      konus(N_ELDER, "Bilge Nine'ye gördüklerini anlat.", { L("Arda", "Nine, kristalin içinde bir adamın gölgesini gördüm. Tapınağın kapısındaydı."),
        L("Bilge Nine", "...Kahverengi saçlı mı? Hmm. Gözlerin seni yanıltmış olabilir, evladım. Ya da yanıltmamış."),
        L("Bilge Nine", "Her neyse, artık eminim: sis tapınaktan geliyor ve Ormanın Kalbi yerinde değil. Dinle şimdi...") }) };
    g.coins = 30; g.potions = 1; }

  { HGorev& g = add("Bekçinin Ocağı", 1, N_HERMIT, "Yaşlı Bekçi (mağara)"); g.main = true; g.minStep = 2; g.maxStep = 2;
    g.intro = { L("Yaşlı Bekçi", "Mantarlardan önce bir şey daha, evlat. Ocağım yıllardır soğuk. Gerçek bir kılıç dövmek için demir ve iyi kömür lazım."),
      L("Yaşlı Bekçi", "Ormanın batısında eski bir maden vardı. Göçtü ama cevherleri hâlâ yerde parlar. Dördünü bul, buraya getir.") };
    g.steps = {
      topla(O, 3, { { 6, 22 }, { 20, 28 }, { 12, 42 }, { 24, 48 } }, N_HERMIT, "Batı ormanında 4 demir cevheri bul, Yaşlı Bekçi'ye götür.", {
        L("Yaşlı Bekçi", "İyi cevher bu. Ağır, dürüst demir. Şimdi kömür lazım. En iyisi Kemal Usta'nın deposundadır."),
        L("Yaşlı Bekçi", "O cimri bedava vermez... Ona benim adımı söyle. Hatırlar beni. İstemese de hatırlar.") }),
      konus(N_SHOP, "Kemal Usta'dan kömür iste.", { L("Kemal Usta", "Yaşlı bekçi mi? O adam bana otuz yıl önce bir kılıç borçluydu! Hâlâ bekliyorum!"),
        L("Kemal Usta", "...Peki peki, kömürü veririm. Ama kömür arabası Çiftçi Rıza'nın tarlasından geçemiyor; domuzlar yolu kesmiş."),
        L("Kemal Usta", "Güneydoğu tarlalarında beş yaban domuzunu kovarsan araba geçer. Sonra gel.") }),
      yen(O, E_BOAR, 5, { 66, 50, 90, 64 }, false, N_SHOP, "Güneydoğu tarlalarında 5 yaban domuzunu kov, Kemal Usta'ya dön.", {
        L("Kemal Usta", "Araba geçti! Kömür de geldi. Al bakalım, bir çuval kara elmas."), L("Kemal Usta", "Bekçiye söyle: borcu hâlâ duruyor. Faiziyle!") }),
      konus(N_HERMIT, "Kömürü Yaşlı Bekçi'ye götür.", { L("Yaşlı Bekçi", "Kemal'in kömürü! Hah, otuz yıldır borç diye diye bitiremedi. Ocak hazır."),
        L("Yaşlı Bekçi", "Şimdi tek eksik şifalı mantarlar. Onlar olmadan çelik ruh kazanmaz.") }) };
    g.coins = 20; }

  { HGorev& g = add("Kayıp Mektuplar", 1, H_ULAS, "Postacı Ulaş (pazarın güneyi)");
    g.intro = { L("Postacı Ulaş", "Arda! Felaket! Sisle gelen rüzgâr çantamı devirdi; mektuplar köyün dört bir yanına uçtu."),
      L("Postacı Ulaş", "Altı mektup! Biri Gülsüm Teyze'ye, biri Kemal Usta'ya... birinin üstünde senin adın bile vardı galiba. Bulur musun?") };
    g.steps = {
      topla(O, 0, { { 44, 52 }, { 58, 63 }, { 68, 58 }, { 52, 44 }, { 38, 66 }, { 64, 50 } }, H_ULAS, "Köyün çevresine saçılan 6 mektubu bul, Postacı Ulaş'a götür.", {
        L("Postacı Ulaş", "Altısı da! Islanmamışlar bile. Sen postacı olmalıymışsın."), L("Postacı Ulaş", "Şunu Gülsüm Teyze'ye sen götürür müsün? Karlı dağlardan, kızından geliyor.") }),
      konus(H_GULSUM, "Mektubu Ebe Gülsüm'e götür.", { L("Ebe Gülsüm", "Kardelen'den! Kızım... Dağlarda bir han işletiyor, biliyor musun? Her kış yazar."),
        L("Ebe Gülsüm", "'Anne, dağlarda bir yeti dolaşıyor, ama merak etme' yazmış. Merak etme! Hah!"), L("Arda", "Senin mektubum hangisiydi peki, Ulaş?"),
        L("Ebe Gülsüm", "Ulaş her mektupta 'senin adın vardı galiba' der. Görmüyor ki, gözlükleri kırık.") }) };
    g.coins = 25; g.potions = 1; }

  { HGorev& g = add("Şifalı Otlar", 1, H_GULSUM, "Ebe Gülsüm (köyün batısı)"); g.need = "Sisin İzinde";
    g.intro = { L("Ebe Gülsüm", "Sis köyün çocuklarını da hasta etti, yavrum. Küçük Efe sabahtan beri öksürüyor."),
      L("Ebe Gülsüm", "Batı ormanında altı şifalı ot bul. Mor çiçekli, gümüş yapraklı olanlar. Kokusunu duyunca anlarsın.") };
    g.steps = {
      topla(O, 1, { { 8, 16 }, { 16, 24 }, { 22, 34 }, { 10, 38 }, { 18, 46 }, { 26, 54 } }, H_GULSUM, "Batı ormanında 6 şifalı ot topla, Ebe Gülsüm'e götür.", {
        L("Ebe Gülsüm", "Mis gibi! Hemen şurup yapıyorum. ...Al, sıcak sıcak. Küçük Efe'ye götür.") }),
      konus(N_KID, "Şurubu Küçük Efe'ye götür.", { L("Küçük Efe", "Öhö öhö... Şurup mu? Acı mı? ...Hmm! Ballıymış!"), L("Küçük Efe", "Öksürüğüm geçti bile! Teşekkürler ağabey. Tavuklara da söyleyeyim, onlar da öksürüyordu.") }) };
    g.potions = 2; g.coins = 10; }

  { HGorev& g = add("Domuz Baskını", 1, H_RIZA, "Çiftçi Rıza (güneydoğu tarlaları)");
    g.intro = { L("Çiftçi Rıza", "Yaban domuzları! Sisten beri delirdiler. Tarlamın yarısını eşelediler."),
      L("Çiftçi Rıza", "Altısını kovarsan sana hasattan pay veririm. Dikkat et; koşarken durduramazlar kendilerini.") };
    g.steps = {
      yen(O, E_BOAR, 6, { 66, 50, 92, 66 }, false, H_RIZA, "Tarlalarda 6 yaban domuzunu kov, Çiftçi Rıza'ya dön.", { L("Çiftçi Rıza", "Altısı da kaçtı! Tarlam rahat bir nefes aldı.") }),
      topla(O, 7, { { 70, 54 }, { 84, 60 }, { 76, 66 } }, H_RIZA, "Domuzların dağıttığı 3 ayçiçeği tohumunu bul, Rıza'ya getir.", {
        L("Çiftçi Rıza", "Tohumlarım! Bunlar dedemden kalma ayçiçeği tohumları. Gelecek yaz tarlam sapsarı olacak."), L("Çiftçi Rıza", "Al, ekmek ve biraz altın. Hak ettin.") }) };
    g.coins = 40; g.breads = 2; }

  { HGorev& g = add("Ayşe'nin Tahta Atı", 1, H_AYSE, "Minik Ayşe (köyün güneyi)");
    g.intro = { L("Minik Ayşe", "Ağabey! Tahta atım! Dedemin yaptığı tahta at! Kaçtı!"), L("Arda", "Tahta at nasıl kaçar?"),
      L("Minik Ayşe", "...Tamam, ben bataklığa fırlattım. Kızgındım. Ama şimdi pişmanım! Doğudaki bataklıkta bir yerde.") };
    g.steps = {
      topla(O, 4, { { 124, 60 } }, H_AYSE, "Doğudaki Sisli Bataklık'ta Ayşe'nin tahta atını bul.", { L("Minik Ayşe", "Pırlantam! Çamur olmuş ama olsun. Bir daha asla fırlatmayacağım. ...Belki."),
        L("Minik Ayşe", "Annem bataklık çiçeklerini çok sever. Üç tane getirir misin? Ona sürpriz yapacağım!") }),
      topla(O, 7, { { 110, 30 }, { 126, 22 }, { 104, 46 } }, H_AYSE, "Bataklıktan 3 çiçek topla, Minik Ayşe'ye getir.", {
        L("Minik Ayşe", "Ne güzeller! Annem ağlayacak, mutluluktan. Al bunu; dedemin sandığında buldum, sana yakışır.") }) };
    g.piece = true; }

  { HGorev& g = add("Bataklık Işıkları", 1, H_KEREM, "Avcı Kerem (bataklığın girişi)");
    g.intro = { L("Avcı Kerem", "Geceleri bataklıkta soluk ışıklar dolaşıyor. Hortlaklar... Avcılar korkudan giremiyor."),
      L("Avcı Kerem", "Gece bataklıkta altısını kov. Sonra sabah bana gel; birlikte eski sunağa bakarız.") };
    g.steps = {
      yen(O, E_GHOST, 6, { 96, 14, 132, 66 }, true, H_KEREM, "Gece Sisli Bataklık'ta 6 hortlak kov, sabah Avcı Kerem'e dön.", {
        L("Avcı Kerem", "Altı ışık söndü, dün gece bataklık ilk kez karanlıktı. Şimdi eski sunağa git; ışıklar hep oradan çıkıyordu.") }),
      git(O, 118, 46, "Bataklığın ortasındaki Eski Sunak'a git.", { L("Arda", "Dört ateş kabı... ve taşlara kazınmış bir yıldız. Dört kollu bir yıldız."),
        L("Arda", "Babamın mektubundaki gibi: Kalp dört parçaya bölünmüş bir yıldız. Kerem'e anlatmalıyım.") }),
      konus(H_KEREM, "Avcı Kerem'e sunakta gördüklerini anlat.", { L("Avcı Kerem", "Dört kollu yıldız mı? ...Baban da bunu sormuştu bana, yıllar önce. Sonra gitti ve bir daha dönmedi."),
        L("Avcı Kerem", "Belki sen onun bulamadığını bulursun. Al bunu, yolun uzun.") }) };
    g.coins = 50; }

  { HGorev& g = add("Ozanın Telleri", 1, H_VELI, "Aşık Veli (köy meydanının doğusu)");
    g.intro = { L("Aşık Veli", "Sazımın telleri koptu, delikanlı. Sis yarasaları kaptı gitti; parlak şeylere bayılırlar."),
      L("Aşık Veli", "Batı ormanında altı yarasa yen; tellerimi geri getir. Sana bir türkü borçlu kalırım.") };
    g.steps = {
      yen(O, E_BAT, 6, { 5, 16, 29, 50 }, false, H_VELI, "Batı ormanında 6 yarasa yen, Aşık Veli'ye dön.", { L("Aşık Veli", "Tellerim! Biraz yarasa kokuyor ama ses aynı."),
        L("Aşık Veli", "Türküyü bitirmem için eski bir hikâye lazım. Bilge Nine 'Dört Kollu Yıldız' masalını bilir. Ona sor, bana anlat.") }),
      konus(N_ELDER, "Bilge Nine'ye Dört Kollu Yıldız masalını sor.", { L("Bilge Nine", "Dört Kollu Yıldız... Çocukken annem anlatırdı. Gökten bir yıldız düşmüş, dört kolu dört yere savrulmuş."),
        L("Bilge Nine", "Biri ormana, biri dağa, biri denize, biri göğe. Dördü birleşirse dünya nefes alır, ayrı kalırsa sis gelir."),
        L("Bilge Nine", "Masal bu kadar. Ama masallar hep biraz doğrudur, evladım.") }),
      konus(H_VELI, "Masalı Aşık Veli'ye anlat.", { L("Aşık Veli", "Orman, dağ, deniz, gök... İşte türkünün dört dörtlüğü! Dinle:"),
        L("Aşık Veli", "'Ormandan çıktı bir çocuk, elinde tahta kılıç; yıldızın dört kolunu, toplar ya da yorulur...' Hah, sonu sende."),
        L("Aşık Veli", "Al bunu, sazımın kutusunda saklardım. Uğur getirir.") }) };
    g.piece = true; }

  { HGorev& g = add("Kemal'in Alacakları", 1, N_SHOP, "Kemal Usta (pazar)"); g.minStep = 3; g.needOld = Q_CAT;
    g.intro = { L("Kemal Usta", "Delikanlı! Madem kahramansın, bir kahramanlık da bana yap: alacaklarımı topla."),
      L("Kemal Usta", "Fırıncı Hatice bana un parası borçlu. Balıkçı çocuk da olta parası. Git, tatlı dille iste. Tatlı dil yılanı deliğinden çıkarır, Hatice'yi fırınından.") };
    g.steps = {
      konus(N_BAKER, "Fırıncı Hatice'den Kemal Usta'nın alacağını iste (fırının içinde).", { L("Fırıncı Hatice", "Kemal mi gönderdi? O cimri! Geçen ay bana bozuk un sattı!"),
        L("Fırıncı Hatice", "...Peki, param yok ama şu kurabiye tepsisini götür. Ödeşiriz dersin.") }),
      konus(N_FISHER, "Balıkçı Çocuk'tan olta parasını iste.", { L("Balıkçı Çocuk", "Olta parası mı? Oltayı kırık sattı ki! ...Tamam, param yok ama bugün tuhaf bir balık tuttum, mor bir balık. Bunu al.") }),
      konus(N_SHOP, "Kurabiyeyle balığı Kemal Usta'ya götür.", { L("Kemal Usta", "Kurabiye... ve mor bir balık? Para nerede? Siz köylüler beni batıracaksınız!"),
        L("Kemal Usta", "...Kurabiyeler güzelmiş ama. Hmm. Balık da tuhaf bir şekilde parlıyor. Al şu 20 altını, zahmetine. Kimseye söyleme.") }) };
    g.coins = 20; g.potions = 1; }

  { HGorev& g = add("Bekçinin Nöbeti", 1, H_KAYA, "Bekçi Kaya (köyün kuzey girişi)"); g.need = "Sisin İzinde";
    g.intro = { L("Bekçi Kaya", "Geceleri batı ormanında kurtlar uluyor. Sürü köye her gece biraz daha yaklaşıyor."),
      L("Bekçi Kaya", "Bir gece batı ormanında altı kurdu dağıt. Sürü başını kaybedince geri çekilirler.") };
    g.steps = { yen(O, E_WOLF, 6, { 6, 18, 29, 56 }, true, H_KAYA, "Gece batı ormanında 6 kurt yen, Bekçi Kaya'ya dön.", {
      L("Bekçi Kaya", "Bu gece ilk kez uluma duymadım. Sağ ol, Arda. Bekçi kılıcını hak edeceksin; daha şimdiden hak ettin bile.") }) };
    g.coins = 40; g.potions = 1; }

  // ======================= BÖLÜM 1-2: KARLI DAĞLAR =======================
  { HGorev& g = add("Ayazköy'ün Ocakları", 2, N_MUHTAR, "Muhtar Ayaz (Ayazköy)"); g.main = true; g.minStep = 7; g.maxStep = 7;
    g.intro = { L("Muhtar Ayaz", "Bir yolcu! Bu karda? Gel, gel... ama ısınacak ocak yok, kusura bakma."),
      L("Muhtar Ayaz", "Köyün bütün ocakları sönük. Kömür bitti, maden göçtü. Halkım donuyor; çocuklar hasta."),
      L("Muhtar Ayaz", "Sana anlatacak çok şeyim var ama önce köyü ayakta tutmalıyız. Madenci Dursun kuzeydoğudaki madenin önünde. Ona yardım et.") };
    g.steps = {
      konus(H_DURSUN, "Kuzeydoğudaki madenin önünde Madenci Dursun'u bul.", { L("Madenci Dursun", "Kömür mü? Maden göçtü evlat; kömürler dağın her yanına saçıldı."),
        L("Madenci Dursun", "Üstüne bir de buz yarasaları madene yuva yaptı. Altısını kov; ben de kazmamı alıp toplamaya başlayayım.") }),
      yen(S, E_ICEBAT, 6, { 58, 6, 104, 32 }, false, 0, "Madenin çevresinde 6 buz yarasası kov.", { L("Arda", "Yarasalar dağıldı. Şimdi kömür taşlarını toplayalım.") }),
      topla(S, 3, { { 64, 8 }, { 72, 12 }, { 80, 8 }, { 88, 10 }, { 68, 20 }, { 84, 18 } }, H_MELEK, "Dağa saçılan 6 kömür taşını topla, köydeki Şifacı Melek'e götür.", {
        L("Şifacı Melek", "Kömür! Hasta çocukların odası ısınacak. Sen bir meleksin... hayır dur, melek benim. Sen bir kahramansın."),
        L("Şifacı Melek", "Kalanını Muhtar'a götür, köyün bütün ocaklarına dağıtsın.") }),
      konus(N_MUHTAR, "Kalan kömürü Muhtar Ayaz'a götür.", { L("Muhtar Ayaz", "Ocaklar yanıyor! Bacalardan duman yükseliyor, bak! Ayazköy yıllardır böyle tütmemişti."),
        L("Muhtar Ayaz", "Borcumuz büyük, evlat. Şimdi dinle; sana dağların derdini anlatayım...") }) };
    g.coins = 40; g.breads = 2; }

  { HGorev& g = add("Çatlak Örs", 2, N_SMITH, "Demirci Bora (Ayazköy)"); g.main = true; g.minStep = 9; g.maxStep = 9;
    g.intro = { L("Demirci Bora", "Bu... Ateş Taşı! Yeti'yi sen mi yendin? Vay be!"),
      L("Demirci Bora", "Ama dur. Örsüm Yeti'nin saldırısında çatladı. Çatlak örste bu taşı işlersem taş paramparça olur."),
      L("Demirci Bora", "Yeni bir örs için buzul demiri lazım. Doğudaki Buzul Vadisi'nde dört parça bul. Bir de körüğüm için kurt postu...") };
    g.steps = {
      topla(S, 3, { { 86, 30 }, { 96, 36 }, { 100, 50 }, { 78, 46 } }, 0, "Doğudaki Buzul Vadisi'nde 4 buzul demiri topla.", { L("Arda", "Dört parça buzul demiri. Ağır ve buz gibi soğuk. Şimdi körük için kurt postu lazım.") }),
      yen(S, E_SNOWWOLF, 5, { 60, 10, 104, 52 }, false, N_HUNTER, "Doğu yaylalarında 5 kar kurdu yen, postlar için Avcı Tolga'ya git.", {
        L("Avcı Tolga", "Beş kar kurdu! Postlarını tabakladım bile, sıcacık. Bora'nın körüğüne yeter de artar."), L("Avcı Tolga", "Bora'ya söyle, bir dahaki nal benden olsun!") }),
      konus(N_SMITH, "Demiri ve postları Demirci Bora'ya götür.", { L("Demirci Bora", "Buzul demiri ve kurt postu! Hah! Gece boyunca çalışacağım, ama sabaha örs hazır."),
        L("", "Bütün gece Ayazköy'de çekiç sesleri yankılandı. Sabah, kıpkırmızı parlayan yepyeni bir örs vardı.") }) };
    g.coins = 30; }

  { HGorev& g = add("Donmuş Posta", 2, H_BURAN, "Kızakçı Buran (Ayazköy)"); g.minStep = 7;
    g.intro = { L("Kızakçı Buran", "Kızağım devrildi! Mektup çuvalı karın içine saçıldı; köpekler çığlık atarak kaçtı."),
      L("Kızakçı Buran", "Altı mektup dağa dağıldı. Bulursan seni kızağımla bir tura çıkarırım! ...Köpekleri bulursam.") };
    g.steps = {
      topla(S, 0, { { 20, 12 }, { 10, 30 }, { 30, 24 }, { 60, 40 }, { 70, 48 }, { 52, 22 } }, H_BURAN, "Karlı Dağlar'a saçılan 6 mektubu bul, Kızakçı Buran'a götür.", {
        L("Kızakçı Buran", "Hepsi! Bir tanesi... Avcı Tolga'dan Çoban Lale'ye. Pembe zarfta! Bunu sen götür, ben utanırım.") }),
      konus(N_SHEPHERD, "Pembe zarfı Çoban Lale'ye götür.", { L("Çoban Lale", "Tolga'dan mı? ...Kızardım mı? Hayır! Soğuktan!"),
        L("Çoban Lale", "'Keçilerin kadar inatçısın' yazmış. Bu iltifat mı? ...Sanırım öyle. Ona 'evet' de. Neye evet? O bilir.") }),
      konus(N_HUNTER, "Çoban Lale'nin cevabını Avcı Tolga'ya götür.", { L("Avcı Tolga", "Ne dedi? ...Evet mi dedi? EVET Mİ DEDİ?"), L("Avcı Tolga", "Bu dağların en mutlu avcısı benim! Al, al, ne istersen al!") }) };
    g.coins = 30; g.piece = true; }

  { HGorev& g = add("Kar Çiçekleri", 2, H_MELEK, "Şifacı Melek (Ayazköy)"); g.minStep = 7;
    g.intro = { L("Şifacı Melek", "Kar çiçekleri yalnızca Buzul Vadisi'nde açar. Hastalarım için altı tane lazım."),
      L("Şifacı Melek", "Mavi taç yapraklı, buz gibi kokan çiçekler. Donmuş gölün çevresine bak.") };
    g.steps = { topla(S, 7, { { 90, 26 }, { 102, 40 }, { 80, 40 }, { 88, 52 }, { 76, 24 }, { 100, 28 } }, H_MELEK, "Buzul Vadisi'nde 6 kar çiçeği topla, Şifacı Melek'e götür.", {
      L("Şifacı Melek", "Altısı da taze! Al, bunlardan iki iksir yaptım. Biri senin, biri de... yine senin. Sen daha çok yaralanıyorsun.") }) };
    g.potions = 2; g.coins = 15; }

  { HGorev& g = add("Buz Balçıkları", 2, H_DURSUN, "Madenci Dursun (maden)"); g.need = "Ayazköy'ün Ocakları";
    g.intro = { L("Madenci Dursun", "Maden yeniden açıldı ama içi buz balçıklarıyla doldu. Kaygan, inatçı, soğuk şeyler."),
      L("Madenci Dursun", "Dağda on tanesini temizlersen kazdığım ilk altınlar senin.") };
    g.steps = { yen(S, E_ICESLIME, 10, { 58, 6, 104, 52 }, false, H_DURSUN, "Dağın doğusunda 10 buz balçığı yen, Madenci Dursun'a dön.", {
      L("Madenci Dursun", "On tane! Maden pırıl pırıl. İşte ilk altınlar, söz verdiğim gibi.") }) };
    g.coins = 50; }

  { HGorev& g = add("Kızak Yolu", 2, H_BURAN, "Kızakçı Buran (Ayazköy)"); g.need = "Donmuş Posta";
    g.intro = { L("Kızakçı Buran", "Köpeklerim döndü! Şimdi yeni bir kızak yolu çizmem lazım. Ama yolu görmeden çizemem."),
      L("Kızakçı Buran", "Üç yere git: donmuş gölün ortasına, buz halkasının yanına ve Yeti'nin mağarasının önüne. Yollar güvenli mi, gör.") };
    g.steps = {
      git(S, 92, 44, "Buzul Vadisi'ndeki donmuş gölün ortasına git.", { L("Arda", "Buz kalın ve sağlam. Kızak burada uçar gider.") }),
      git(S, 96, 22, "Buz halkasının yanına git.", { L("Arda", "Halkanın çevresi düz. Dönemeç keskin ama köpekler alışır.") }),
      git(S, 14, 15, "Kuzeybatıda Yeti'nin mağarasının önüne git.", { L("Arda", "Mağaranın önü sessiz. Yeti'den eser yok... şimdilik.") }),
      konus(H_BURAN, "Kızakçı Buran'a yolları anlat.", { L("Kızakçı Buran", "Göl, halka, mağara! Ayazköy'ün ilk kızak yarışını yapacağız. Adını 'Arda Yolu' koyacağım!") }) };
    g.coins = 40; }

  { HGorev& g = add("Madenin Derinliği", 2, H_DURSUN, "Madenci Dursun (maden)"); g.need = "Buz Balçıkları";
    g.intro = { L("Madenci Dursun", "Madenin derininde tuhaf mor kristaller buldum. Yeşilvadi'deki kara kristallere benziyor, ama daha soğuk."),
      L("Madenci Dursun", "Beşi dağa saçıldı. Topla, bakalım nereden geliyorlar.") };
    g.steps = {
      topla(S, 2, { { 66, 30 }, { 74, 40 }, { 92, 22 }, { 102, 14 }, { 58, 50 } }, H_DURSUN, "Dağa saçılan 5 mor kristali topla, Madenci Dursun'a götür.", {
        L("Madenci Dursun", "Bak, hepsi aynı yöne dönüyor... kuzeye, Buz Tapınağı'na. Sis buraya da ulaşmış."),
        L("Madenci Dursun", "Kristallerin çevresinde geceleri kar kurtları toplanıyor. Bir gece altısını dağıt.") }),
      yen(S, E_SNOWWOLF, 6, { 4, 10, 68, 52 }, true, H_DURSUN, "Gece 6 kar kurdu yen, Madenci Dursun'a dön.", { L("Madenci Dursun", "Kurtlar dağıldı, kristaller de söndü. Al bunu; maden ruhu sana teşekkür ediyor.") }) };
    g.piece = true; }

  { HGorev& g = add("Annemin Tarifi", 2, N_INNKEEP, "Hancı Kardelen (Ayazköy hanı)"); g.minStep = 7;
    g.intro = { L("Hancı Kardelen", "Yeşilvadi'den misin? Annem Ebe Gülsüm'ü tanır mısın? ...Tanıyorsun! Ah, ne güzel."),
      L("Hancı Kardelen", "Annemin çorba tarifi için dağ kekiği lazım; dört tane. Batıdaki yamaçlarda olur.") };
    g.steps = {
      topla(S, 1, { { 8, 44 }, { 16, 50 }, { 6, 20 }, { 22, 8 } }, N_INNKEEP, "Batı yamaçlarında 4 dağ kekiği topla, Hancı Kardelen'e götür.", {
        L("Hancı Kardelen", "Kokusu! Tıpkı annemin mutfağı. Çorba kaynarken Şifacı Melek'e bir kâse götürür müsün? Hep tadına bakar.") }),
      konus(H_MELEK, "Çorbayı Şifacı Melek'e götür.", { L("Şifacı Melek", "Ebe Gülsüm'ün tarifi mi bu? ...Benim ilaçlarımdan iyi. Bunu Kardelen'e söyleme.") }) };
    g.breads = 3; g.coins = 20; }

  { HGorev& g = add("Gezginin Haritası", 2, N_TRAVELER, "Gezgin Rüzgâr (kurtarıldıktan sonra)"); g.minStep = 7;
    g.intro = { L("Gezgin Rüzgâr", "Buzun içinde kalınca haritamın sayfaları dağıldı. Dört sayfa; hepsi bir ömrün yolları."),
      L("Gezgin Rüzgâr", "Bulursan sana dağların en gizli köşesini anlatırım.") };
    g.steps = { topla(S, 8, { { 14, 14 }, { 42, 28 }, { 56, 14 }, { 26, 40 } }, N_TRAVELER, "Dağa dağılan 4 harita sayfasını bul, Gezgin Rüzgâr'a götür.", {
      L("Gezgin Rüzgâr", "Sayfalarım! Bak, burada yazıyor: 'Göklerde bir kule var; yıldız kuyusundan çıkılır.' Bu yazı benim değil..."),
      L("Gezgin Rüzgâr", "Kahverengi mürekkep, eğri harfler. Biri yıllar önce haritama not düşmüş. Al bakalım, ödülün.") }) };
    g.coins = 40; g.potions = 1; }

  // ======================= BÖLÜM 1-3: BATIK ŞEHİR =======================
  { HGorev& g = add("Fırtınanın Ardından", 3, N_CAPTAIN, "Kaptan Deniz (Mercanköy)"); g.main = true; g.minStep = 14; g.maxStep = 15;
    g.intro = { L("Kaptan Deniz", "Ahoy! Hoş geldin, ama kötü bir zamanda geldin. Dün gece fırtına üç teknemizi devirdi."),
      L("Kaptan Deniz", "Ağlar, şamandıralar adalara saçıldı. Balıkçılar denize açılamıyor; açılamazsak aç kalırız."),
      L("Kaptan Deniz", "Dalgıç Mert'e yardım et. Sonra sana Batık Şehir'i anlatırım; söz.") };
    g.steps = {
      konus(H_MERT, "Dalgıç Mert'i bul (Mercanköy iskelesinin güneyi).", { L("Dalgıç Mert", "Şamandıralar dağıldı! Altısı adaların kıyılarına vurmuş. Onlarsız ağlar dibe çöker."),
        L("Dalgıç Mert", "Bir de martılar kalan ağları didikliyor. Önce şamandıraları bul.") }),
      topla(D, 5, { { 8, 16 }, { 20, 14 }, { 28, 24 }, { 6, 40 }, { 24, 44 }, { 40, 48 } }, H_MERT, "Adalara saçılan 6 şamandırayı bul, Dalgıç Mert'e götür.", {
        L("Dalgıç Mert", "Altısı da! Şimdi martılar... Gökten pike yapıyorlar; yana kaç ve vur!") }),
      yen(D, E_GULL, 5, { 4, 14, 60, 50 }, false, H_NAZLI, "5 martıyı kov, sonra ağları Ağcı Nazlı'ya götür.", {
        L("Ağcı Nazlı", "Ağlar paramparça ama ben onarırım. Gece boyunca örerim; sabaha balıkçılar denizde olur."),
        L("Ağcı Nazlı", "Kaptan'a söyle, Mercanköy ayakta.") }),
      konus(N_CAPTAIN, "Kaptan Deniz'e haber ver.", { L("Kaptan Deniz", "Tekneler denizde! Hah! Bu köy batmaz, evlat; olsa olsa ıslanır."), L("Kaptan Deniz", "Şimdi oturalım. Sana Batık Şehir'i anlatacağım...") }) };
    g.coins = 40; g.potions = 1; }

  { HGorev& g = add("Asanın Dümeni", 3, N_CAPTAIN, "Kaptan Deniz (Mercanköy)"); g.main = true; g.minStep = 17; g.maxStep = 17;
    g.intro = { L("Kaptan Deniz", "Gelgit İncisi! Mavi mavi parlıyor... Ama dur."),
      L("Kaptan Deniz", "Asayı oymak için özel bir tahta lazım: güneydeki batık geminin dümen tahtası. O tahta yüz yıl denizi dinledi."),
      L("Kaptan Deniz", "Haritacı Pusula batık geminin yerini bilir. Ama son zamanlarda kendi yerini bile bilmiyor.") };
    g.steps = {
      konus(H_PUSULA, "Haritacı Pusula ile konuş (Mercanköy'ün doğusu).", { L("Haritacı Pusula", "Batık gemi mi? Biliyorum! ...Biliyordum. Haritamın sayfaları rüzgârla dağıldı."),
        L("Haritacı Pusula", "Dört sayfayı bul. Sonra sana yolu çizerim; hatta yürürüm de!") }),
      topla(D, 8, { { 14, 22 }, { 26, 36 }, { 44, 46 }, { 50, 14 } }, H_PUSULA, "Dört harita sayfasını bul, Haritacı Pusula'ya götür.", {
        L("Haritacı Pusula", "İşte! Batık gemi güneydeki adada, kıyıya vurmuş. Kıç tarafındaki dümen tahtası hâlâ sağlam olmalı.") }),
      git(D, 38, 50, "Güneydeki adada batık gemiyi bul.", { L("Arda", "Geminin kıçında, yosun tutmuş bir dümen tahtası... Yüz yıl denizi dinlemiş. Kulağımı dayayınca dalga sesi geliyor.") }),
      konus(N_CAPTAIN, "Dümen tahtasını Kaptan Deniz'e götür.", { L("Kaptan Deniz", "Bu o tahta! Elim titriyor... Bu gemide ben de çalıştım, gençken."), L("Kaptan Deniz", "Şimdi asayı yapabilirim.") }) };
    g.coins = 30; }

  { HGorev& g = add("Şarkı Söyleyen Kabuklar", 3, H_NAZLI, "Ağcı Nazlı (Mercanköy)"); g.need = "Fırtınanın Ardından";
    g.intro = { L("Ağcı Nazlı", "Bu denizde şarkı söyleyen kabuklar var. Kulağına tutunca annemin ninnisini duyarım."),
      L("Ağcı Nazlı", "Altı tane bul. Adalara dağılmışlardır; biri Martı Adası'nda bile olabilir.") };
    g.steps = { topla(D, 6, { { 10, 20 }, { 22, 40 }, { 48, 14 }, { 56, 20 }, { 100, 18 }, { 36, 50 } }, H_NAZLI, "Adalarda 6 şarkı söyleyen kabuk bul, Ağcı Nazlı'ya götür.", {
      L("Ağcı Nazlı", "Altısı farklı şarkı söylüyor! Bak bu... annemin ninnisi. Al bunu evlat, ağımın dibinden çıktı.") }) };
    g.piece = true; }

  { HGorev& g = add("Martı Hırsızlar", 3, N_COOK, "Aşçı Ozan (Mercanköy)"); g.needOld = Q_CRABS;
    g.intro = { L("Aşçı Ozan", "Yengeçler gitti, şimdi martılar! Tezgâhımdan balık çalıyorlar, hem de gözümün önünde!"),
      L("Aşçı Ozan", "Sekizini kov. Gerisi kendini bilir.") };
    g.steps = { yen(D, E_GULL, 8, { 4, 10, 110, 50 }, false, N_COOK, "8 martıyı kov, Aşçı Ozan'a dön.", { L("Aşçı Ozan", "Tezgâhım güvende! Al, üç sıcak balık ekmeği. Bir de bahşiş.") }) };
    g.breads = 3; g.coins = 30; }

  { HGorev& g = add("Derin Dalış", 3, H_MERT, "Dalgıç Mert (Mercanköy)"); g.need = "Fırtınanın Ardından"; g.minStep = 18;
    g.intro = { L("Dalgıç Mert", "Gelgit Asası'n var mı? Harika! Kayalık Ada'ya giden yol ancak su çekilince açılır."),
      L("Dalgıç Mert", "Orada denizanaları kaynıyor. Altısını temizle, sonra adanın ucuna git; orada eski bir dalış çanı var.") };
    g.steps = {
      yen(D, E_JELLY, 6, { 97, 38, 114, 52 }, false, 0, "Kayalık Ada'da 6 denizanası temizle.", { L("Arda", "Denizanaları dağıldı. Şimdi adanın ucuna...") }),
      git(D, 106, 46, "Kayalık Ada'nın ortasına git.", { L("Arda", "Kumların arasında yarı gömülü bir dalış çanı... Üstünde bir isim kazılı: 'Mert'in babası'.") }),
      konus(H_MERT, "Dalgıç Mert'e çanı anlat.", { L("Dalgıç Mert", "Babamın çanı! Yıllar önce fırtınada kaybolmuştu. ...Teşekkür ederim. Bunu sana vermem gerek; babam da öyle isterdi.") }) };
    g.piece = true; }

  { HGorev& g = add("Fenerin Yağı", 3, N_KEEPER, "Fenerci Nur (deniz feneri)"); g.needOld = Q_LIGHT;
    g.intro = { L("Fenerci Nur", "Fener yanıyor ama yağı azalıyor. Yağlı mor balıklardan beş tane lazım; kıyılarda çırpınıp dururlar."),
      L("Fenerci Nur", "Getirirsen fener bütün kış yanar.") };
    g.steps = { topla(D, 9, { { 4, 26 }, { 28, 18 }, { 42, 44 }, { 58, 14 }, { 96, 24 } }, N_KEEPER, "Kıyılarda 5 yağlı mor balık bul, Fenerci Nur'a götür.", {
      L("Fenerci Nur", "Beşi de! Fener bütün kış yanacak. Tekneler eve dönecek. Al bakalım.") }) };
    g.coins = 40; }

  { HGorev& g = add("Pusula'nın Haritası", 3, H_PUSULA, "Haritacı Pusula (Mercanköy)"); g.need = "Asanın Dümeni";
    g.intro = { L("Haritacı Pusula", "Yeni bir harita çiziyorum: bütün adalar! Ama yerinde görmeden çizmem. Dört yere git benim için."),
      L("Haritacı Pusula", "Martı Adası, Mercan Resifi, deniz feneri ve Kayalık Ada. Sırayla.") };
    g.steps = {
      git(D, 99, 20, "Doğudaki Martı Adası'na git.", { L("Arda", "Martılar her yerde. Adanın ortasında yeşil bir çayır var.") }),
      git(D, 50, 18, "Kuzeydeki Mercan Resifi'ne git.", { L("Arda", "Resifin mercanları gün ışığında pembe parlıyor.") }),
      git(D, 18, 19, "Deniz fenerinin dibine git.", { L("Arda", "Fener... Buradan bütün adalar görünüyor.") }),
      git(D, 106, 46, "Kayalık Ada'ya git (su çekilince).", { L("Arda", "Kayalık Ada. Haritanın en uzak köşesi.") }),
      konus(H_PUSULA, "Haritacı Pusula'ya gördüklerini anlat.", { L("Haritacı Pusula", "Harika! Harita tamam. Bu haritanın adı 'Arda'nın Denizi' olacak. Ödülün de burada.") }) };
    g.coins = 50; g.potions = 1; }

  { HGorev& g = add("Gece Yengeçleri", 3, H_NAZLI, "Ağcı Nazlı (Mercanköy)"); g.need = "Şarkı Söyleyen Kabuklar";
    g.intro = { L("Ağcı Nazlı", "Geceleri batı kıyısında yengeçler ağlarımı kesiyor. Gündüz saklanıyorlar, gece çıkıyorlar."),
      L("Ağcı Nazlı", "Bir gece altısını kov. Gündüz bana gel, ödülün hazır olur.") };
    g.steps = { yen(D, E_CRAB, 6, { 3, 14, 30, 46 }, true, H_NAZLI, "Gece batı kıyısında 6 yengeç kov, Ağcı Nazlı'ya dön.", { L("Ağcı Nazlı", "Ağlarım sabaha kadar sağlam kaldı! Al, iki iksir. Gece nöbeti yorar.") }) };
    g.potions = 2; }

  { HGorev& g = add("İnci Ana'nın Sırrı", 3, N_PEARLMA, "İnci Ana (Mercanköy)"); g.needOld = Q_PEARLS;
    g.intro = { L("İnci Ana", "Kolyem tamamlandı ama bir sırrım var, evladım. Batık Şehir'in son kraliçesi... benim büyük annemdi."),
      L("İnci Ana", "Kaptan Deniz'e sor; o bilir. Bana anlatmaya hiç cesareti olmadı.") };
    g.steps = {
      konus(N_CAPTAIN, "Kaptan Deniz'e İnci Ana'nın sırrını sor.", { L("Kaptan Deniz", "Sana mı söyledi? ...Evet. Kraliçe şehri sudan korumak için kırmızı yıldızı kullandı."),
        L("Kaptan Deniz", "Yıldız şehri kurtaramadı ama halkı kurtardı. Mercanköy o halkın köyüdür. İnci Ana'ya söyle: kraliçe kahramandı.") }),
      konus(N_PEARLMA, "Kaptan Deniz'in sözlerini İnci Ana'ya götür.", { L("İnci Ana", "Kahramandı... Yetmiş yıldır bunu duymayı bekledim. Al bunu, kraliçenin kolyesinden kalan son parça.") }) };
    g.piece = true; }

  // ======================= BÖLÜM 1-4: GÖKLERDEKİ KULE =======================
  { HGorev& g = add("Susan Çanlar", 4, N_WINDMA, "Rüzgâr Ana (Rüzgârköy)"); g.main = true; g.minStep = 23; g.maxStep = 23;
    g.intro = { L("Rüzgâr Ana", "Bir yeryüzü çocuğu! Yıldız kuyusundan mı geldin? Dur, nefeslen... Ah, kusura bakma, aklım başka yerde."),
      L("Rüzgâr Ana", "Rüzgâr çanlarımız sustu. Çanlar susunca köyün rüzgârı da durur; değirmenler durur, kuşlar uçamaz."),
      L("Rüzgâr Ana", "Çancı Rüzgâr köyün batısında. Ona yardım et; sonra sana anlatacak çok şeyim var. Çok.") };
    g.steps = {
      konus(H_CANCI, "Köyün batısındaki Çancı Rüzgâr ile konuş.", { L("Çancı Rüzgâr", "Fırtına çanların dillerini kopardı, adalara saçtı. Beş çan dili! Onlarsız çanlar sadece... metal."),
        L("Çancı Rüzgâr", "Biri kuzeydeki yuvanın yakınında, ikisi batı adasında... gerisi bulutlar arasında.") }),
      topla(G, 5, { { 12, 23 }, { 8, 30 }, { 30, 31 }, { 50, 25 }, { 40, 6 } }, H_CANCI, "Adalara saçılan 5 çan dilini bul, Çancı Rüzgâr'a götür.", {
        L("Çancı Rüzgâr", "Beşi de! Ama çan iplerini bulutçuklar kemiriyor. Altısını kovmazsan çanları asamam.") }),
      yen(G, E_CLOUDLING, 6, { 4, 18, 56, 40 }, false, H_CANCI, "Köyün çevresinde 6 bulutçuk kov, Çancı Rüzgâr'a dön.", {
        L("", "Çancı Rüzgâr çanları bir bir astı. İlk çan çaldığında köyün üstünden ılık bir rüzgâr esti; değirmenin kanatları dönmeye başladı."),
        L("Çancı Rüzgâr", "Duyuyor musun? Gökyüzü yeniden nefes alıyor. Rüzgâr Ana'ya git; seni bekliyor.") }),
      konus(N_WINDMA, "Rüzgâr Ana'ya dön.", { L("Rüzgâr Ana", "Çanlar! Yıllardır bu kadar güzel çalmamışlardı. Sağ ol, çocuğum. Şimdi otur ve dinle...") }) };
    g.coins = 40; }

  { HGorev& g = add("Yıldızların Haritası", 4, N_WINDMA, "Rüzgâr Ana (Rüzgârköy)"); g.main = true; g.minStep = 25; g.maxStep = 25;
    g.gateHint = "Köprüleri örmeden önce Rüzgâr Ana ile konuş.";
    g.intro = { L("Rüzgâr Ana", "Rüzgâr Borusu! Kartalı yendin demek. Ama dinle: köprüler yıldızların yerine göre örülür."),
      L("Rüzgâr Ana", "Yıldızların haritası olmadan boruyu üflersen köprü seni boşluğa bırakır. Bilgin Yıldız haritayı çiziyordu; ona yardım et.") };
    g.steps = {
      konus(H_YILDIZ, "Köydeki Bilgin Yıldız ile konuş.", { L("Bilgin Yıldız", "Harita mı? Neredeyse bitti! Ama rüzgâr dört sayfamı uçurdu. Hepsi köyün çevresinde olmalı."),
        L("Bilgin Yıldız", "Sonra bir gece gökyüzüne bakmamız gerekecek. Ama önce sayfalar.") }),
      topla(G, 8, { { 12, 30 }, { 36, 22 }, { 52, 34 }, { 46, 4 } }, H_YILDIZ, "Rüzgârın uçurduğu 4 sayfayı bul, Bilgin Yıldız'a götür.", {
        L("Bilgin Yıldız", "Sayfalar tamam. Ama son yıldızları fırtına ruhları örtüyor. Bir gece dördünü söndürürsen gökyüzü açılır.") }),
      yen(G, E_WISP, 4, { 4, 18, 56, 40 }, true, H_YILDIZ, "Gece köyün çevresinde 4 fırtına ruhu söndür, Bilgin Yıldız'a dön.", {
        L("Bilgin Yıldız", "Gökyüzü açıldı! Bak... dört kollu bir yıldız. Kule tam onun ortasında."),
        L("Bilgin Yıldız", "Köprü taşlarının şarkısı bu yıldızın kollarını izler. Artık boruyu güvenle üflersin. Rüzgâr Ana'ya söyle.") }),
      konus(N_WINDMA, "Rüzgâr Ana'ya haritayı götür.", { L("Rüzgâr Ana", "Harita tamam mı? O zaman yol açık. Rüzgâr seninle olsun, çocuğum.") }) };
    g.piece = true; }

  { HGorev& g = add("Bulut Bahçesi", 4, H_BULUT, "Bahçıvan Bulut (Rüzgârköy)"); g.minStep = 23;
    g.intro = { L("Bahçıvan Bulut", "Gök çiçeklerim fırtınada savruldu. Altısı adalara dağıldı; köklerini bulutlara salmadan bulmalıyım."),
      L("Bahçıvan Bulut", "Yaprakları kırmızı, sapları ince. Görünce tanırsın.") };
    g.steps = { topla(G, 7, { { 6, 28 }, { 16, 25 }, { 24, 34 }, { 48, 30 }, { 54, 22 }, { 38, 8 } }, H_BULUT, "Adalarda 6 gök çiçeği bul, Bahçıvan Bulut'a götür.", {
      L("Bahçıvan Bulut", "Hepsi kök salmadan gelmiş! Bahçem yeniden kıpkırmızı olacak. Al, çiçeklerden iki iksir.") }) };
    g.potions = 2; g.coins = 15; }

  { HGorev& g = add("Gök Kuşları", 4, H_BULUT, "Bahçıvan Bulut (Rüzgârköy)"); g.need = "Bulut Bahçesi"; g.minStep = 26;
    g.intro = { L("Bahçıvan Bulut", "Doğu adalarındaki gök kuşları tohumlarımı yiyor. Köprüler açıldıysa altısını kov, olur mu?") };
    g.steps = { yen(G, E_SKYBIRD, 6, { 60, 4, 166, 48 }, false, H_BULUT, "Doğu adalarında 6 gök kuşu kov, Bahçıvan Bulut'a dön.", { L("Bahçıvan Bulut", "Tohumlarım güvende. Al bakalım!") }) };
    g.coins = 40; }

  { HGorev& g = add("Bilginin Dürbünü", 4, H_YILDIZ, "Bilgin Yıldız (Rüzgârköy)"); g.need = "Yıldızların Haritası"; g.minStep = 26;
    g.intro = { L("Bilgin Yıldız", "Köprüler açıldı! Doğu adalarından gökyüzüne bakmak istiyorum ama ben yükseklikten korkarım. ...Evet, gökte yaşarken."),
      L("Bilgin Yıldız", "Üç gözlem noktasına git: köprünün ötesindeki bahçe, Yıldırım Adası ve kulenin batısı.") };
    g.steps = {
      git(G, 72, 28, "Doğudaki bahçe adasına git.", { L("Arda", "Buradan gökyüzü kocaman. Yıldız Işığı aşağıya, yeryüzüne akıyor.") }),
      git(G, 98, 22, "Yıldırım Adası'na git.", { L("Arda", "Bulutların arasında şimşekler... Ama yıldızlar sakin.") }),
      git(G, 120, 32, "Kulenin batısındaki adaya git.", { L("Arda", "Kule buradan çok yakın. Tepesinde kara bir sis dönüyor.") }),
      konus(H_YILDIZ, "Bilgin Yıldız'a gördüklerini anlat.", { L("Bilgin Yıldız", "Şimşekler, sis, yıldız ışığı... Hepsini yazdım. Bu kitabın adı 'Gökyüzünün Tanığı' olacak. Al bunu.") }) };
    g.piece = true; }

  { HGorev& g = add("Değirmenin Unu", 4, N_MILLER, "Değirmenci Poyraz (Rüzgârköy)"); g.needOld = Q_BIRDS;
    g.intro = { L("Değirmenci Poyraz", "Değirmen yine dönüyor; ilk unu öğüttüm! Bir çuval Hancı Meltem'e götür, bir çuval Kuşçu Serçe'ye.") };
    g.steps = {
      konus(N_INNKEEP4, "Un çuvalını Hancı Meltem'e götür (Rüzgârköy hanı).", { L("Hancı Meltem", "Gökyüzünün ilk unu! Bu akşam han ekmek kokacak.") }),
      konus(N_BIRDKEEPER, "Un çuvalını Kuşçu Serçe'ye götür.", { L("Kuşçu Serçe", "Un mu? Kuşlarım un yemez ki! ...Ama ben yerim. Teşekkürler!") }),
      konus(N_MILLER, "Değirmenci Poyraz'a dön.", { L("Değirmenci Poyraz", "İkisi de sevindi mi? Güzel. Al, ilk ekmekler senin.") }) };
    g.breads = 3; g.coins = 30; }

  { HGorev& g = add("Çancının Şarkısı", 4, H_CANCI, "Çancı Rüzgâr (Rüzgârköy)"); g.need = "Susan Çanlar";
    g.intro = { L("Çancı Rüzgâr", "Çanlar çalıyor ama geceleri fırtına ruhları seslerini yutuyor. Bir gece altısını söndür.") };
    g.steps = { yen(G, E_WISP, 6, { 4, 4, 166, 48 }, true, H_CANCI, "Gece 6 fırtına ruhu söndür, Çancı Rüzgâr'a dön.", {
      L("Çancı Rüzgâr", "Dün gece çanlar sabaha kadar çaldı. Rüzgârköy'ün en uzun şarkısıydı. Senin şarkın.") }) };
    g.coins = 50; }

  { HGorev& g = add("Babanın Günlüğü", 4, N_FATHER, "Baba (Yeşilvadi, yolculuk bitince)"); g.minStep = 28;
    g.intro = { L("Baba", "Arda... Kuleye çıkarken günlüğümün sayfalarını gökyüzüne saçmışım. Yıllarımın hikâyesi o sayfalarda."),
      L("Baba", "Dördünü bulursan sana hiç anlatmadıklarımı okursun. Gökyüzünün doğusundalar, köprülerin ötesinde.") };
    g.steps = { topla(G, 8, { { 64, 30 }, { 92, 20 }, { 122, 30 }, { 146, 24 } }, N_FATHER, "Gökyüzünün doğusunda babanın 4 günlük sayfasını bul, babana götür.", {
      L("Baba", "Hepsi... 'Bugün Arda ilk adımını attı. Yarın kuleye gidiyorum. Dönmezsem, o beni bulur.'"),
      L("Baba", "Ve buldun. Bu benden sana, oğlum. Annemin, Nine'nin bana verdiği kalp kabı.") }) };
    g.heartC = true; }

  { HGorev& g = add("İki Eski Dost", 4, N_WINDMA, "Rüzgâr Ana (yolculuk bitince)"); g.minStep = 28;
    g.intro = { L("Rüzgâr Ana", "Sis dağıldı, çocuğum. Şimdi bir iyilik isteyeceğim: Yeşilvadi'deki Bilge Nine'ye selamımı götür."),
      L("Rüzgâr Ana", "Ona 'Kuyunun kızı hâlâ ıslık çalıyor' de. Anlar.") };
    g.steps = {
      konus(N_ELDER, "Rüzgâr Ana'nın selamını Bilge Nine'ye götür.", { L("Bilge Nine", "'Kuyunun kızı'... Yüce gökler! O hâlâ yaşıyor mu? Çocukken kuyunun başında ıslık çalardı, rüzgâr gelirdi."),
        L("Bilge Nine", "Bir gün kuyuya düştü sandık. Meğer yukarı düşmüş! Ona söyle: 'Nine artık ıslık çalamıyor ama hâlâ dinliyor.'") }),
      konus(N_WINDMA, "Nine'nin cevabını Rüzgâr Ana'ya götür.", { L("Rüzgâr Ana", "Hâlâ dinliyor... Hah! Çocukken de hep o dinlerdi, ben çalardım."), L("Rüzgâr Ana", "Al bunu. Yıllardır saklıyordum, birine vermek için.") }) };
    g.piece = true; }
  // ======================= BÖLÜM 1-5: OYUN ADASI =======================
  const int A5 = MAP_GAMEISLE;
  { HGorev& g = add("Fırtınanın Dağıttığı Taşlar", 5, N_MASTER5, "Oyun Ustası Bilmece (adanın ortası)"); g.main = true; g.minStep = 31; g.maxStep = 31;
    g.intro = { L("Oyun Ustası Bilmece", "Hoş geldin, bekçi. Ama kötü bir günde geldin: dün geceki fırtına masaları darmadağın etti."),
      L("Oyun Ustası Bilmece", "Taşlar, zarlar adaya saçıldı. Eksik taşla oyun oynanmaz; eksik oyunla da kıvılcım verilmez."),
      L("Oyun Ustası Bilmece", "Önce köydeki Mustafa Amca'ya git. Adanın en yaşlısı odur; her taşın yerini bilir.") };
    g.steps = {
      konus(H_MUSTAFA, "Kuzeydeki köyde Mustafa Amca ile konuş.", { L("Mustafa Amca", "Fırtına mı? Elli yıldır böylesini görmedim. Oyun taşları palmiyelerin dibine, evlerin arkasına uçtu."),
        L("Mustafa Amca", "Altı tane eksik. Bul getir; ben de tahtaları silip hazırlayayım.") }),
      topla(A5, 11, { { 8, 15 }, { 52, 17 }, { 18, 34 }, { 44, 34 }, { 10, 24 }, { 50, 24 } }, H_MUSTAFA, "Adaya saçılan 6 oyun taşını bul, Mustafa Amca'ya götür.", {
        L("Mustafa Amca", "Altısı da burada! Ama zarlar eksik. Küçük Zeynep görmüş olmalı; o kız gözünden hiçbir şey kaçırmaz.") }),
      konus(H_ZEYNEP, "Küçük Zeynep'e zarları sor.", { L("Küçük Zeynep", "Zarlar mı? Kumsaldaki yengeçler kaptı! Parlak şeylere bayılıyorlar."),
        L("Küçük Zeynep", "Altısını kovarsan zarları bırakırlar. Ben de seninle gelirdim ama annem kumsala yalnız inme diyor.") }),
      yen(A5, E_CRAB, 6, { 12, 31, 48, 37 }, false, H_ZEYNEP, "Güney kumsalında 6 yengeç kov, Küçük Zeynep'e dön.", {
        L("Küçük Zeynep", "Zarlar geri geldi! Hepsi kumlu ama olsun. Al, Kahveci Hasan'a götür; o yıkar, masalara dağıtır.") }),
      konus(H_HASAN, "Zarları kahvehanenin önündeki Kahveci Hasan'a götür.", { L("Kahveci Hasan", "Taşlar tamam, zarlar tamam! Ben de çayları demledim."),
        L("Kahveci Hasan", "Masalar hazır. Usta'ya haber ver: Oyun Adası yeniden açıldı!") }),
      konus(N_MASTER5, "Oyun Ustası Bilmece'ye masaların hazır olduğunu söyle.", { L("Oyun Ustası Bilmece", "Taşlar yerinde, zarlar yerinde, çaylar demlenmiş. Sen bu adanın gönlünü kazandın, bekçi."),
        L("Oyun Ustası Bilmece", "Şimdi asıl işe gelelim...") }) };
    g.coins = 40; g.potions = 1; }

  { HGorev& g = add("Martı Belası", 5, H_HUSNU, "Balıkçı Hüsnü (köyün doğusu)"); g.minStep = 31;
    g.intro = { L("Balıkçı Hüsnü", "Martılar ağlarımı didik didik ediyor. Beşini kovarsan akşama sana balık ekmek yaparım.") };
    g.steps = { yen(A5, E_GULL, 5, { 6, 6, 54, 36 }, false, H_HUSNU, "Adanın üstünde 5 martı kov, Balıkçı Hüsnü'ye dön.", {
      L("Balıkçı Hüsnü", "Ağlarım rahat bir nefes aldı. Al, iki balık ekmek; biri senin, biri de... yine senin.") }) };
    g.breads = 2; g.coins = 20; }

  { HGorev& g = add("Çay Servisi", 5, H_SULTAN, "Sultan Teyze (meydanın güneyi)"); g.minStep = 32;
    g.intro = { L("Sultan Teyze", "Ustalar oynarken çayları soğuyor. Şu tepsiyi dama, tavla ve okey masasına götürür müsün? Ayaklarım eskisi gibi değil.") };
    g.steps = {
      konus(N_GDAMA5, "Çayı Dama Dedesi Şükrü'ye götür.", { L("Dama Dedesi Şükrü", "Çay! Sultan'ın çayı oyunun yarısıdır. Öteki yarısı da benim taşlarım.") }),
      konus(N_GTAVLA5, "Çayı Tavlacı Zar Ali'ye götür.", { L("Tavlacı Zar Ali", "Çay mı? Şeş beş gibi geldi! Sağ ol, delikanlı.") }),
      konus(N_GOKEY5, "Çayı Okeyci Nimet Teyze'ye götür.", { L("Okeyci Nimet Teyze", "Ah, tam vaktinde! Teyzeler çaysız okey oynamaz, bilirsin.") }),
      konus(H_SULTAN, "Sultan Teyze'ye dön.", { L("Sultan Teyze", "Hepsi içti mi? Maşallah. Al bakalım, çay parası; bir de iksir, yorgunsundur.") }) };
    g.coins = 30; g.potions = 1; }

  { HGorev& g = add("Kumsalın Kabukları", 5, H_ZEYNEP, "Küçük Zeynep (köy)"); g.need = "Fırtınanın Dağıttığı Taşlar";
    g.intro = { L("Küçük Zeynep", "Penceremdeki kabuklara beş tane daha lazım! Okey taşı gibi dizeceğim: renk renk, sıra sıra.") };
    g.steps = { topla(A5, 6, { { 16, 35 }, { 24, 36 }, { 36, 36 }, { 45, 35 }, { 7, 20 } }, H_ZEYNEP, "Kumsalda 5 deniz kabuğu bul, Küçük Zeynep'e götür.", {
      L("Küçük Zeynep", "Beşi de! Bak, kırmızı, sarı, mavi, siyah... Bir de okey! Al, bu da senin; kumsalda buldum, parlıyordu.") }) };
    g.piece = true; }

  { HGorev& g = add("Mustafa Amca'nın Sırrı", 5, H_MUSTAFA, "Mustafa Amca (köy)"); g.minStep = 34;
    g.intro = { L("Mustafa Amca", "Kıvılcımı aldın demek. Sana bir şey söyleyeyim mi? Bu adanın ilk oyun ustası bendim."),
      L("Mustafa Amca", "Bilmece'ye bir el tavla kaybettim, ustalığı ona verdim. Kırk yıl oldu. Gidip ona sor: o oyunu hâlâ hatırlıyor mu?") };
    g.steps = {
      konus(N_MASTER5, "Oyun Ustası Bilmece'ye Mustafa Amca'nın tavlasını sor.", { L("Oyun Ustası Bilmece", "Hatırlamaz mıyım! Son zarda düşeş attı, sonra bilerek kırık bir taş bıraktı. Ustalığı bana o verdi, kazanmadım ben."),
        L("Oyun Ustası Bilmece", "Ona söyle: borcumu ödeyeceğim. Bir gün o masada yine karşı karşıya oturacağız.") }),
      konus(H_MUSTAFA, "Mustafa Amca'ya Usta'nın cevabını götür.", { L("Mustafa Amca", "Bilerek mi bıraktım? ...Hah! Kırk yıldır kimse fark etmemişti. Al bunu, evlat; o günden beri cebimde taşıdım.") }) };
    g.piece = true; }

  // önce bitmesi gereken görevler adla yazıldı; sıra numarasına çevir
  for (auto& g : TAB) if (g.need.size()) for (size_t q = 0; q < TAB.size(); q++) if (TAB[q].name == g.need) g.needQ = (int)q;
}

// ---------------- motor ----------------
static const HGorev* G0(int q) { return q >= 0 && q < (int)TAB.size() ? &TAB[q] : nullptr; }
int Game::hikayeSay() { return (int)TAB.size(); }
const HAdim* adimOf(const HGorev& g, int st) { return st >= 1 && st <= (int)g.steps.size() ? &g.steps[st - 1] : nullptr; }
// (x, y) yakınında boş, yürünebilir bir kare (köylü, eşya ve hedef yerleri için)
void Game::hikayeBos(int& x, int& y) {
  WorldMap& m = map;
  auto ok = [&](int X, int Y) {
    if (X < 1 || Y < 1 || X >= m.W - 1 || Y >= m.H - 1 || m.solid(X, Y) || m.blk[Y * m.W + X]) return false;
    int t = m.get(X, Y);
    if (t == T_WATER || t == T_ICEWATER || t == T_BRIDGEH || t == T_VOID || t == T_CLOUDGAP || t == T_TIDE || isWindT(t)) return false;
    for (auto& o : m.objs) if (o->alive && o->tx <= X && X < o->tx + std::max(1, o->tw) && o->ty <= Y && Y < o->ty + std::max(1, o->th)) return false;
    return true;
  };
  for (int r = 0; r < 8; r++) for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) {
    if (std::max(std::abs(dx), std::abs(dy)) != r) continue;
    if (ok(x + dx, y + dy)) { x += dx; y += dy; return; }
  }
}
bool Game::hikayeBitti(int q) { return q >= 0 && q < 64 && hs[q] >= HDONE; }
int Game::hikayeAdimSay(int q) { const HGorev* g = G0(q); return g ? (int)g->steps.size() : 0; }
// adım tamam mı (öldürme ve toplama adımları için)
bool Game::hikayeTamam(int q) {
  const HGorev* g = G0(q); if (!g) return false; const HAdim* a = adimOf(*g, hs[q]); if (!a) return false;
  if (a->kind == K_KILL) return hc[q] >= a->count;
  if (a->kind == K_FETCH) { int n = 0; for (int i = 0; i < a->count; i++) n += (hc[q] >> i) & 1; return n >= a->count; }
  return false;
}
string Game::hikayeIpucu(int q) {
  const HGorev* g = G0(q); if (!g) return ""; const HAdim* a = adimOf(*g, hs[q]); if (!a) return "";
  string s = a->hint;
  if (a->kind == K_KILL) s += fmt(" (%d/%d)", std::min(hc[q], a->count), a->count);
  if (a->kind == K_FETCH) { int n = 0; for (int i = 0; i < a->count; i++) n += (hc[q] >> i) & 1; s += fmt(" (%d/%d)", n, a->count); }
  if (hikayeTamam(q) && a->npc) s = fmt("%s ile konuş.", adOf(a->npc).c_str());
  return s;
}
void Game::hikayeOnce(int chap) { for (size_t q = 0; q < TAB.size() && q < 64; q++) if (TAB[q].main && TAB[q].chap < chap) hs[q] = HDONE; }
// ana görev ekranı: kapı adımında süren zincir varsa onun ipucu
string Game::hikayeHedef() {
  for (size_t q = 0; q < TAB.size() && q < 64; q++) {
    const HGorev& g = TAB[q]; if (!g.main || mainStep < g.minStep || mainStep > g.maxStep) continue;
    if (hs[q] > 0 && hs[q] < HDONE) return hikayeIpucu((int)q);
    if (hs[q] == 0 && g.gateHint.size()) return g.gateHint;
  }
  return "";
}
void Game::hikayeOdul(int q) {
  const HGorev& g = TAB[q];
  coins += g.coins; potions += g.potions; breads += g.breads;
  string t = "Görev tamamlandı: " + g.name;
  if (g.coins) t += fmt("  +%d altın", g.coins);
  if (g.potions) t += fmt("  +%d iksir", g.potions);
  if (g.breads) t += fmt("  +%d ekmek", g.breads);
  if (g.heartC) giveHeartC(); else if (g.piece) givePiece();
  if (!g.heartC && !g.piece) showItem(g.coins ? A.coin[0] : g.potions ? A.potion : A.bread, t); else toast(t);
}
void Game::hikayeIlerle(int q) {
  const HGorev& g = TAB[q];
  if (hs[q] >= (int)g.steps.size()) {
    hs[q] = HDONE; hc[q] = 0; hikayeOdul(q); saveGame();
    // ana zincir verenin yanında bittiyse asıl hikâye kaldığı yerden sürsün
    if (g.main && g.steps.back().kind == K_TALK && g.steps.back().npc == g.giver) {
      for (auto& n : npcs) if (n->id == g.giver) { talk(*n); break; }
    }
    return;
  }
  hs[q]++; hc[q] = 0;
  toast("Görev: " + hikayeIpucu(q));
  hikayeKur(q, true);
  saveGame();
}
// bir adımı haritaya kur: düşmanları çıkar, eşyaları yerleştir
void Game::hikayeKur(int q, bool fresh) {
  const HGorev* g = G0(q); if (!g) return; const HAdim* a = adimOf(*g, hs[q]); if (!a || a->map != map.kind || interior >= 0) return;
  if (a->kind == K_KILL && fresh && (!a->night || night())) {
    int n = std::min(8, a->count - hc[q]);
    if (n > 0) scatterEnemies(a->enemy, n, a->r[0], a->r[1], a->r[2], a->r[3]);
  }
  if (a->kind == K_FETCH) {
    for (int i = 0; i < a->count; i++) {
      if ((hc[q] >> i) & 1) continue;
      bool has = false; for (auto& k : picks) if (k->alive && k->type == P_QITEM && k->val == q * 32 + i) has = true;
      if (has) continue;
      int x = a->at[i].first, y = a->at[i].second; hikayeBos(x, y);
      addPick(P_QITEM, x * 16 + 8, y * 16 + 12, 0, q * 32 + i);
    }
  }
}
bool Game::hikayeAktif(int q) { const HGorev* g = G0(q); return g && hs[q] >= 1 && hs[q] <= (int)g->steps.size(); }
// konuşma: true dönerse köylünün kendi konuşması atlanır
bool Game::hikayeKonus(int id) {
  if (dlg) return false;
  int n = (int)std::min<size_t>(TAB.size(), 64);
  // 1) sürmekte olan bir adımı bu kişi bitiriyor mu
  for (int q = 0; q < n; q++) {
    if (!hikayeAktif(q)) continue; const HAdim* a = adimOf(TAB[q], hs[q]);
    if (a->npc != id) continue;
    if (a->kind == K_TALK || ((a->kind == K_KILL || a->kind == K_FETCH) && hikayeTamam(q))) {
      if (a->kind == K_FETCH) { for (auto& k : picks) if (k->type == P_QITEM && k->val / 32 == q) k->alive = false; }
      say(a->said, [this, q] { hikayeIlerle(q); });
      return true;
    }
  }
  // 2) ana hikâyenin kapısı: zincir bitmeden asıl hikâye ilerlemez
  for (int q = 0; q < n; q++) {
    const HGorev& g = TAB[q]; if (!g.main || g.giver != id || mainStep < g.minStep || mainStep > g.maxStep || hikayeBitti(q)) continue;
    if (hs[q] == 0) { say(g.intro, [this, q] { hs[q] = 1; hc[q] = 0; toast("Yeni hikâye: " + TAB[q].name); hikayeKur(q, true); saveGame(); }); return true; }
    say({ L(adOf(id), fmt("Önce şunu halledelim: %s", hikayeIpucu(q).c_str())) });
    return true;
  }
  // 3) yeni bir yan görev
  for (int q = 0; q < n; q++) {
    const HGorev& g = TAB[q]; if (g.main || g.giver != id || hs[q] != 0 || mainStep < g.minStep) continue;
    if (g.needQ >= 0 && !hikayeBitti(g.needQ)) continue;
    if (g.needOld >= 0 && qs[g.needOld] != 2) continue;
    say(g.intro, [this, q] { hs[q] = 1; hc[q] = 0; toast("Yeni görev: " + TAB[q].name); hikayeKur(q, true); saveGame(); });
    return true;
  }
  // 4) yeni köylüler süren işlerini hatırlatır
  if (id >= H_KAYA) for (int q = 0; q < n; q++) {
    if (!hikayeAktif(q)) continue; const HAdim* a = adimOf(TAB[q], hs[q]);
    if (a->npc == id || (TAB[q].giver == id && a->npc == 0)) { say({ L(adOf(id), hikayeIpucu(q)) }); return true; }
  }
  return false;
}
void Game::hikayeOldu(Ent& e) {
  int n = (int)std::min<size_t>(TAB.size(), 64);
  for (int q = 0; q < n; q++) {
    if (!hikayeAktif(q)) continue; const HAdim* a = adimOf(TAB[q], hs[q]);
    if (a->kind != K_KILL || a->enemy != e.type || a->map != map.kind || interior >= 0 || hc[q] >= a->count) continue;
    if (a->night && !night()) continue;
    int tx = (int)(e.x / 16), ty = (int)(e.y / 16);
    if (a->r[2] > 0 && (tx < a->r[0] - 2 || tx > a->r[2] + 2 || ty < a->r[1] - 2 || ty > a->r[3] + 2)) continue;
    hc[q]++;
    if (hc[q] >= a->count) {
      if (a->npc) toast(fmt("%s tamam! %s ile konuş.", TAB[q].name.c_str(), adOf(a->npc).c_str()));
      else { say(a->said, [this, q] { hikayeIlerle(q); }); }
    } else toast(fmt("%s: %d/%d", TAB[q].name.c_str(), hc[q], a->count));
  }
}
void Game::hikayeTick(double) {
  if (state != S_PLAY || netRole == "guest") return;
  int key = map.gen * 2 + (night() ? 1 : 0);
  if (map.gen != hGen || key != hNight) {
    bool fresh = map.gen != hGen, nightTurn = !fresh && key != hNight && night();
    hGen = map.gen; hNight = key;
    int n = (int)std::min<size_t>(TAB.size(), 64);
    for (int q = 0; q < n; q++) {
      if (!hikayeAktif(q)) continue; const HAdim* a = adimOf(TAB[q], hs[q]);
      if (fresh || (nightTurn && a->kind == K_KILL && a->night)) hikayeKur(q, true);
    }
  }
  if (dlg || fadeState) return;
  int n = (int)std::min<size_t>(TAB.size(), 64);
  for (int q = 0; q < n; q++) {
    if (!hikayeAktif(q)) continue; const HAdim* a = adimOf(TAB[q], hs[q]);
    if (a->kind != K_GOTO || a->map != map.kind || interior >= 0) continue;
    int x = a->at[0].first, y = a->at[0].second; hikayeBos(x, y);
    if (std::hypot(px - (x * 16 + 8), py - (y * 16 + 10)) < 30) { say(a->said, [this, q] { hikayeIlerle(q); }); return; }
  }
}
// görev günlüğü satırları: (yazı, renk türü 0 süren, 1 alınmamış, 2 biten)
std::vector<std::pair<string, int>> Game::hikayeGunluk(int chap) {
  std::vector<std::pair<string, int>> out; int done = 0;
  int n = (int)std::min<size_t>(TAB.size(), 64);
  for (int q = 0; q < n; q++) {
    const HGorev& g = TAB[q];
    if (hikayeAktif(q)) { out.push_back({ (g.main ? "[HİKÂYE] " : "") + g.name + "  — " + hikayeIpucu(q), 0 }); continue; }
    if (g.chap != chap) continue;
    if (hikayeBitti(q)) { done++; continue; }
    if (g.main) continue;
    if (mainStep < g.minStep || (g.needQ >= 0 && !hikayeBitti(g.needQ)) || (g.needOld >= 0 && qs[g.needOld] != 2)) continue;
    out.push_back({ "? ? ?  — " + g.where, 1 });
  }
  if (done) out.push_back({ fmt("Bu bölümde biten hikâye görevleri: %d", done), 2 });
  return out;
}
void Game::initHikaye() {
  kisiler(); gorevler();
  EXT.npcs.push_back([this] {
    WorldMap& m = map; bool nt = night();
    for (auto& k : KISI) {
      if (k.map != m.kind || (m.kind == MAP_INTERIOR && interior != k.interior) || mainStep < k.minStep) continue;
      if ((k.when == 1 && nt) || (k.when == 2 && !nt)) continue;
      int x = k.x, y = k.y; hikayeBos(x, y);
      addNPC(k.id, x, y, A.villager[k.spr >= 0 ? k.spr : k.id - H_KAYA], k.name, k.flip);
    }
  });
  for (auto& k : KISI) {
    int id = k.id; std::vector<string> idle = k.idle; string name = k.name;
    EXT.talk[id] = [this, idle, name](Npc&) { say({ L(name, idle[(dayN + (int)(time / 9)) % idle.size()]) }); };
  }
  // bütün köylüler (eskiler de) önce hikâyeye sorulur
  std::vector<int> ids; for (auto& k : KISI) ids.push_back(k.id);
  for (auto& kv : ESKI_AD) ids.push_back(kv.first);
  for (int id : ids) {
    auto old = EXT.talkPre.count(id) ? EXT.talkPre[id] : nullptr;
    EXT.talkPre[id] = [this, id, old](Npc* n) { if (n && hikayeKonus(id)) return true; return old ? old(n) : false; };
  }
  EXT.pick[P_QITEM] = [this](Pick& k) {
    int q = k.val / 32, i = k.val % 32; const HGorev* g = G0(q); if (!g) return;
    const HAdim* a = adimOf(*g, hs[q]); if (!a || a->kind != K_FETCH || i >= a->count) return;
    hc[q] |= 1 << i; int n = 0; for (int j = 0; j < a->count; j++) n += (hc[q] >> j) & 1;
    static const char* AD[12] = { "Mektup", "Şifalı ot", "Kristal", "Cevher", "Tahta at", "Çan dili", "Kabuk", "Çiçek", "Sayfa", "Balık", "Zar", "Oyun taşı" };
    showItem(A.qitem[a->spr], fmt("%s (%d/%d)", AD[a->spr], n, a->count));
    if (n >= a->count) {
      if (a->npc) toast(fmt("%s: hepsi toplandı! %s ile konuş.", g->name.c_str(), adOf(a->npc).c_str()));
      else say(a->said, [this, q] { hikayeIlerle(q); });
    }
    saveGame();
  };
  EXT.tick.push_back([this](double dt) { hikayeTick(dt); });
  // 4. bölüm: harita bitmeden bulut taşları köprü örmez
  auto oldStone = EXT.interact[O_CLOUDSTONE];
  EXT.interact[O_CLOUDSTONE] = [this, oldStone](Obj& o) {
    for (size_t q = 0; q < TAB.size() && q < 64; q++) {
      const HGorev& g = TAB[q];
      if (g.main && g.chap == 4 && g.minStep == 25 && mainStep == 25 && !hikayeBitti((int)q)) {
        say({ L("Arda", "Rüzgâr Ana'nın sözü aklıma geldi: yıldızların haritası olmadan köprü beni boşluğa bırakabilir. Önce onunla konuşmalıyım.") });
        return;
      }
    }
    if (oldStone) oldStone(o);
  };
}
// görev eşyası çizimi (drawPick2 çağırır); misafirde de hs[] bilindiği için doğru resim çıkar
const Spr* Game::hikayeEsya(int val) {
  int q = val / 32; const HGorev* g = G0(q); if (!g) return A.qitem[0];
  const HAdim* a = adimOf(*g, hs[q]); return A.qitem[a && a->kind == K_FETCH ? a->spr : 0];
}
// testler için: görev tablosunu dışarıya aç
std::vector<Game::HBilgi> Game::hikayeBilgi() {
  std::vector<HBilgi> out;
  for (size_t q = 0; q < TAB.size(); q++) {
    const HGorev& g = TAB[q]; HBilgi b; b.name = g.name; b.chap = g.chap; b.main = g.main; b.giver = g.giver; b.minStep = g.minStep;
    for (auto& a : g.steps) { HBilgi::Adim s; s.kind = a.kind; s.map = a.map; s.npc = a.npc; s.enemy = a.enemy; s.count = a.count; s.night = a.night; s.at = a.at; for (int i = 0; i < 4; i++) s.r[i] = a.r[i]; b.steps.push_back(s); }
    out.push_back(b);
  }
  return out;
}
std::vector<Game::HKisiB> Game::hikayeKisiler() { std::vector<HKisiB> out; for (auto& k : KISI) out.push_back({ k.id, k.map, k.x, k.y, k.when, k.minStep }); return out; }
