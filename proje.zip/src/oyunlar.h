// ORMANIN KALBİ - Oyun Adası'nın masa oyunları (oyunlar.cpp)
#pragma once
#include "game.h"

enum { MG_DAMA = 0, MG_SATRANC = 1, MG_TAVLA = 2, MG_PAPAZ = 3, MG_OKEY = 4 };
const char* mgName(int kind);
const char* okeyModeName(int mode);
std::vector<string> okeyRuleTest(Game& g);

// bir masa oyunu: sıradaki oyuncu, kazanan (-1 sürüyor, 99 berabere), imleç ve seçim
struct MiniGame {
  int np = 2, turn = 0, winner = -1; bool human[4] = { true, false, false, false };
  string names[4]; string msg; int cur = 0, sel = -1;
  // who[s]: s. sandalyede kim oturuyor (0: 1. oyuncu, 1-3: ortaklar, -1: bot); tbl: hangi masa (0/1)
  int who[4] = { 0, -1, -1, -1 }, tbl = 0;
  int opt = 0;   // okey: tür (0 klasik, 1 düşmeli, 2 101) | 16: eşli
  virtual ~MiniGame() {}
  virtual int kind() const = 0;
  virtual void key(Game& g, int k) = 0;   // 0 sol, 1 sağ, 2 yukarı, 3 aşağı, 4 seç, 5 vazgeç
  virtual void tap(Game& g, int cell) = 0;
  virtual void ai(Game& g) = 0;           // sıradaki bilgisayar oyuncusunun hamlesi
  virtual void draw(Game& g, int viewer) = 0;
  virtual void tick(Game&, double) {}
  // sıra başkasındayken de yapılabilen dokunuş (okeyde ıstakayı dizmek)
  virtual bool anyTime(int) const { return false; }
  virtual void tapAs(Game&, int, int) {}
  virtual void save(WBuf& w) = 0;
  virtual void load(RBuf& r) = 0;
  void saveBase(WBuf& w);
  void loadBase(RBuf& r);
};
