// ORMANIN KALBİ - Oyun Adası'nın masa oyunları (oyunlar.cpp)
#pragma once
#include "game.h"

enum { MG_DAMA = 0, MG_SATRANC = 1, MG_TAVLA = 2, MG_PAPAZ = 3, MG_OKEY = 4 };
const char* mgName(int kind);

// bir masa oyunu: sıradaki oyuncu, kazanan (-1 sürüyor, 99 berabere), imleç ve seçim
struct MiniGame {
  int np = 2, turn = 0, winner = -1; bool human[4] = { true, false, false, false };
  string names[4]; string msg; int cur = 0, sel = -1;
  virtual ~MiniGame() {}
  virtual int kind() const = 0;
  virtual void key(Game& g, int k) = 0;   // 0 sol, 1 sağ, 2 yukarı, 3 aşağı, 4 seç, 5 vazgeç
  virtual void tap(Game& g, int cell) = 0;
  virtual void ai(Game& g) = 0;           // sıradaki bilgisayar oyuncusunun hamlesi
  virtual void draw(Game& g, int viewer) = 0;
  virtual void tick(Game&, double) {}
  virtual void save(WBuf& w) = 0;
  virtual void load(RBuf& r) = 0;
  void saveBase(WBuf& w);
  void loadBase(RBuf& r);
};
