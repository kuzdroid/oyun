// ORMANIN KALBİ - online bağlantı katmanı (oda koduyla, ücretsiz PeerJS aracı servisi üzerinden WebRTC)
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>

// bağlantı olayları ana iş parçacığında poll() ile alınır
struct NetEvent { enum Kind { OPEN, PEER, DATA, CLOSE, ERR } kind; std::string data; };
struct NetTransport {
  virtual ~NetTransport() {}
  virtual bool host(const std::string& id) = 0;      // bu kimlikle oda aç
  virtual bool join(const std::string& id) = 0;      // bu kimlikteki odaya bağlan
  virtual void send(const std::string& bytes) = 0;
  virtual bool poll(NetEvent& ev) = 0;
  virtual void close() = 0;
};
NetTransport* makeTransport();   // platform: libdatachannel; yoksa nullptr

// küçük ikili yazıcı/okuyucu (anlık görüntüler için)
struct WBuf {
  std::string b;
  void u8(int v) { b.push_back((char)(uint8_t)v); }
  void i32(int32_t v) { b.append((const char*)&v, 4); }
  void f32(double v) { float f = (float)v; b.append((const char*)&f, 4); }
  void f64(double v) { b.append((const char*)&v, 8); }
  void str(const std::string& s) { i32((int32_t)s.size()); b += s; }
};
struct RBuf {
  const std::string& b; size_t p = 0; bool bad = false;
  explicit RBuf(const std::string& s) : b(s) {}
  bool need(size_t n) { if (p + n > b.size()) { bad = true; return false; } return true; }
  int u8() { if (!need(1)) return 0; return (uint8_t)b[p++]; }
  int32_t i32() { int32_t v = 0; if (!need(4)) return 0; memcpy(&v, b.data() + p, 4); p += 4; return v; }
  double f32() { float f = 0; if (!need(4)) return 0; memcpy(&f, b.data() + p, 4); p += 4; return f; }
  double f64() { double f = 0; if (!need(8)) return 0; memcpy(&f, b.data() + p, 8); p += 8; return f; }
  std::string str() { int32_t n = i32(); if (n < 0 || !need((size_t)n)) return ""; std::string s = b.substr(p, n); p += n; return s; }
};
