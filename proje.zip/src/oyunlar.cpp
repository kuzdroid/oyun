// ORMANIN KALBİ - Oyun Adası'nın masa oyunları: dama, satranç, tavla, papaz kimde, 101 okey
// Arkadaşın varsa (aynı bilgisayar ya da online) onunla, yoksa adadaki ustayla (bilgisayar) oynanır.
// Ortak arayüz: imleç (oklar), seç (Kılıç/Konuş), vazgeç (İksir); dokunmatikte hücreye dokunmak yeter.
#include "game.h"
#include "oyunlar.h"
#include <algorithm>
#include <random>

static Col H(uint32_t c, double a = 1) { Col k = hexc(c); k.a = a; return k; }
static void frame(Game& g, double x, double y, double w, double h, Col c) { g.rectV(x, y, w, 1, c); g.rectV(x, y + h - 1, w, 1, c); g.rectV(x, y, 1, h, c); g.rectV(x + w - 1, y, 1, h, c); }
static void sprV(Game& g, const Spr* sp, double x, double y, double sc) { g.g->sprite(sp, g.vx(x), y * g.s, sp->w * g.s * sc, sp->h * g.s * sc, false, 1); }
// yan bilgi: oyuncular, sıra, ileti
static void sideInfo(Game& g, MiniGame& m, double x, double w, const char* title) {
  g.text(title, x + w / 2, 8, 0.36, H(0xf8d878), 1, true);
  double y = 24;
  for (int i = 0; i < m.np; i++) {
    bool t = m.turn == i && m.winner < 0;
    g.text(fmt("%s%s", t ? "> " : "  ", g.tr(m.names[i]).c_str()), x + 4, y, 0.27, t ? H(0x9af0a0) : H(0xd0d0e0)); y += 10;
  }
  y += 4;
  string s = m.winner >= 0 ? (m.winner == 99 ? string("Berabere!") : fmt("%s kazandı!", g.tr(m.names[m.winner]).c_str())) : m.msg;
  for (auto& l : g.wrap(s, 0.26, w - 6)) { g.text(l, x + 4, y, 0.26, H(0xf8e8c0)); y += 9; }
  g.text(g.desktop ? "Oklar: seç  •  Boşluk: onayla  •  Q: vazgeç  •  Esc: çık" : "Dokun: seç  •  Durdur: çık", g.VW / 2.0, 172, 0.22, H(0xa0a0b8), 1);
}
void MiniGame::saveBase(WBuf& w) { w.u8(np); w.u8(turn); w.i32(winner); for (int i = 0; i < 4; i++) { w.u8(human[i]); w.str(names[i]); } w.str(msg); w.i32(cur); w.i32(sel); }
void MiniGame::loadBase(RBuf& r) { np = r.u8(); turn = r.u8(); winner = r.i32(); for (int i = 0; i < 4; i++) { human[i] = r.u8() != 0; names[i] = r.str(); } msg = r.str(); cur = r.i32(); sel = r.i32(); }

// ======================================================================= DAMA
// Türk daması: taşlar ileri ve yana gider, çapraz yok; alma zorunlu ve en çok alan hamle seçilir; son sıraya varan dama olur, dama uzağa gider.
struct Dama : MiniGame {
  int b[64] = {}; int ply = 0;   // 1 beyaz, 2 beyaz dama (0. oyuncu, aşağıda) ; 3 siyah, 4 siyah dama
  struct Mv { std::vector<int> path, cap; };
  static int side(int v) { return v == 1 || v == 2 ? 0 : v == 3 || v == 4 ? 1 : -1; }
  static bool king(int v) { return v == 2 || v == 4; }
  Dama() { for (int x = 0; x < 8; x++) { b[8 + x] = b[16 + x] = 3; b[40 + x] = b[48 + x] = 1; } msg = "Taşlar ileri ve yana gider. Alma zorunlu!"; cur = 52; }
  int kind() const override { return MG_DAMA; }
  void capDfs(std::array<int, 64> bd, int at, int s, bool kg, Mv m, std::vector<Mv>& out) {
    static const int DX[4] = { 0, 0, -1, 1 }, DY[4] = { -1, 1, 0, 0 };
    bool more = false; int x = at % 8, y = at / 8;
    for (int d = 0; d < 4; d++) {
      if (!kg && DY[d] == (s == 0 ? 1 : -1)) continue;   // taş geri alamaz
      if (!kg) {
        int nx = x + DX[d], ny = y + DY[d], mx = x + 2 * DX[d], my = y + 2 * DY[d];
        if (mx < 0 || my < 0 || mx > 7 || my > 7) continue;
        int n = ny * 8 + nx, t = my * 8 + mx;
        if (side(bd[n]) == 1 - s && bd[t] == 0) { auto b2 = bd; b2[n] = 0; b2[t] = b2[at]; b2[at] = 0; Mv m2 = m; m2.path.push_back(t); m2.cap.push_back(n); more = true; capDfs(b2, t, s, false, m2, out); }
      } else {
        int cx = x + DX[d], cy = y + DY[d];
        while (cx >= 0 && cy >= 0 && cx < 8 && cy < 8 && bd[cy * 8 + cx] == 0) { cx += DX[d]; cy += DY[d]; }
        if (cx < 0 || cy < 0 || cx > 7 || cy > 7 || side(bd[cy * 8 + cx]) != 1 - s) continue;
        int n = cy * 8 + cx, lx = cx + DX[d], ly = cy + DY[d];
        while (lx >= 0 && ly >= 0 && lx < 8 && ly < 8 && bd[ly * 8 + lx] == 0) {
          int t = ly * 8 + lx; auto b2 = bd; b2[n] = 0; b2[t] = b2[at]; b2[at] = 0; Mv m2 = m; m2.path.push_back(t); m2.cap.push_back(n); more = true; capDfs(b2, t, s, true, m2, out);
          lx += DX[d]; ly += DY[d];
        }
      }
    }
    if (!more && m.cap.size()) out.push_back(m);
  }
  std::vector<Mv> moves(const int* bd0, int s) {
    std::array<int, 64> bd; for (int i = 0; i < 64; i++) bd[i] = bd0[i];
    std::vector<Mv> caps, simple;
    for (int i = 0; i < 64; i++) if (side(bd[i]) == s) { Mv m; m.path.push_back(i); capDfs(bd, i, s, king(bd[i]), m, caps); }
    if (caps.size()) {
      size_t best = 0; for (auto& m : caps) best = std::max(best, m.cap.size());
      std::vector<Mv> r; for (auto& m : caps) if (m.cap.size() == best) r.push_back(m);
      return r;
    }
    static const int DX[4] = { 0, 0, -1, 1 }, DY[4] = { -1, 1, 0, 0 };
    for (int i = 0; i < 64; i++) if (side(bd[i]) == s) {
      int x = i % 8, y = i / 8; bool kg = king(bd[i]);
      for (int d = 0; d < 4; d++) {
        if (!kg && DY[d] == (s == 0 ? 1 : -1)) continue;
        int cx = x + DX[d], cy = y + DY[d];
        while (cx >= 0 && cy >= 0 && cx < 8 && cy < 8 && bd[cy * 8 + cx] == 0) { simple.push_back({ { i, cy * 8 + cx }, {} }); if (!kg) break; cx += DX[d]; cy += DY[d]; }
      }
    }
    return simple;
  }
  static void apply(int* bd, const Mv& m) {
    int v = bd[m.path.front()]; bd[m.path.front()] = 0;
    for (int c : m.cap) bd[c] = 0;
    int t = m.path.back(); bd[t] = v;
    if (v == 1 && t < 8) bd[t] = 2; if (v == 3 && t >= 56) bd[t] = 4;
  }
  static int eval(const int* bd, int s) {
    int e = 0;
    for (int i = 0; i < 64; i++) { int v = bd[i]; if (!v) continue; int sc = king(v) ? 32 : 10 + (side(v) == 0 ? (7 - i / 8) : i / 8); e += side(v) == s ? sc : -sc; }
    return e;
  }
  int search(int* bd, int s, int depth, int a, int bt) {
    auto mv = moves(bd, s);
    if (mv.empty()) return -10000;
    if (!depth) return eval(bd, s);
    for (auto& m : mv) { int b2[64]; memcpy(b2, bd, sizeof b2); apply(b2, m); int v = -search(b2, 1 - s, depth - 1, -bt, -a); if (v > a) a = v; if (a >= bt) break; }
    return a;
  }
  void after(Game& g) {
    ply++; turn = 1 - turn; sel = -1;
    if (moves(b, turn).empty()) winner = 1 - turn;
    else if (ply > 240) winner = 99;
    else msg = moves(b, turn)[0].cap.size() ? "Alma zorunlu!" : "";
    g.sfx(SFX_CLICK);
  }
  void ai(Game& g) override {
    auto mv = moves(b, turn); if (mv.empty()) return;
    int best = -100000; std::vector<int> idx;
    for (size_t i = 0; i < mv.size(); i++) { int b2[64]; memcpy(b2, b, sizeof b2); apply(b2, mv[i]); int v = -search(b2, 1 - turn, 2, -100000, 100000); if (v > best) { best = v; idx.clear(); } if (v == best) idx.push_back((int)i); }
    apply(b, mv[idx[(int)(g.rnd() * idx.size()) % idx.size()]]); after(g);
  }
  void key(Game& g, int k) override {
    if (k < 4) { int x = cur % 8 + (k == 0 ? -1 : k == 1 ? 1 : 0), y = cur / 8 + (k == 2 ? -1 : k == 3 ? 1 : 0); cur = std::max(0, std::min(7, y)) * 8 + std::max(0, std::min(7, x)); return; }
    if (k == 5) { sel = -1; return; }
    auto mv = moves(b, turn);
    if (sel >= 0) for (auto& m : mv) if (m.path.front() == sel && m.path.back() == cur) { apply(b, m); after(g); return; }
    bool can = false; for (auto& m : mv) if (m.path.front() == cur) can = true;
    if (can) sel = cur; else if (sel >= 0) msg = "Oraya gidemez."; else if (side(b[cur]) == turn) msg = mv.size() && mv[0].cap.size() ? "Alma zorunlu! Başka bir taşla al." : "Bu taş oynayamaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cs = 19, bx = std::floor((g.VW - cs * 8) / 2), by = 14;
    for (int i = 0; i < 64; i++) {
      double x = bx + (i % 8) * cs, y = by + (i / 8) * cs;
      g.rectV(x, y, cs, cs, ((i % 8 + i / 8) & 1) ? H(0xb88850) : H(0xe8cc90));
      if (b[i]) { sprV(g, g.A.disc[side(b[i]) == 0 ? 0 : 1], x + 2, y + 2, 1.5); if (king(b[i])) { g.rectV(x + 7, y + 7, 5, 5, H(0xf8d848)); } }
      g.hit(x, y, cs, cs, [&g, i] { g.mgTap(i); });
    }
    if (winner < 0) {
      auto mv = moves(b, turn);
      if (sel >= 0) for (auto& m : mv) if (m.path.front() == sel) { int t = m.path.back(); g.rectV(bx + (t % 8) * cs + 7, by + (t / 8) * cs + 7, 5, 5, H(0x60e070, 0.9)); }
      if (sel >= 0) frame(g, bx + (sel % 8) * cs, by + (sel / 8) * cs, cs, cs, H(0x60e070));
      if (human[turn]) frame(g, bx + (cur % 8) * cs + 1, by + (cur / 8) * cs + 1, cs - 2, cs - 2, H(0xf8d848));
    }
    sideInfo(g, *this, 4, bx - 8, "DAMA");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : b) w.u8(v); w.i32(ply); }
  void load(RBuf& r) override { loadBase(r); for (int& v : b) v = r.u8(); ply = r.i32(); }
};

// ======================================================================= SATRANÇ
struct Satranc : MiniGame {
  struct Pos { int b[64]; int castle, ep; };
  struct Mv { int f, t, promo; };
  Pos p; int ply = 0, lastF = -1, lastT = -1;
  // taş = tip (1 piyon 2 at 3 fil 4 kale 5 vezir 6 şah) + 8 * renk (0 beyaz/aşağıda, 1 siyah)
  Satranc() {
    static const int R[8] = { 4, 2, 3, 5, 6, 3, 2, 4 };
    memset(p.b, 0, sizeof p.b);
    for (int x = 0; x < 8; x++) { p.b[x] = R[x] + 8; p.b[8 + x] = 1 + 8; p.b[48 + x] = 1; p.b[56 + x] = R[x]; }
    p.castle = 15; p.ep = -1; cur = 52; msg = "Beyazlar başlar.";
  }
  int kind() const override { return MG_SATRANC; }
  static int col(int v) { return v ? v >> 3 : -1; }
  static int typ(int v) { return v & 7; }
  static bool attacked(const Pos& q, int sq, int by) {
    int x = sq % 8, y = sq / 8;
    int pd = by == 0 ? 1 : -1;   // beyaz piyon aşağıdan saldırır
    for (int dx = -1; dx <= 1; dx += 2) { int px = x + dx, py = y + pd; if (px >= 0 && px < 8 && py >= 0 && py < 8 && q.b[py * 8 + px] == 1 + by * 8) return true; }
    static const int KN[8][2] = { {1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1} };
    for (auto& k : KN) { int nx = x + k[0], ny = y + k[1]; if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && q.b[ny * 8 + nx] == 2 + by * 8) return true; }
    for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) { if (!dx && !dy) continue; int nx = x + dx, ny = y + dy; if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && q.b[ny * 8 + nx] == 6 + by * 8) return true; }
    static const int D[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
    for (int d = 0; d < 8; d++) {
      int nx = x + D[d][0], ny = y + D[d][1];
      while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        int v = q.b[ny * 8 + nx];
        if (v) { if (col(v) == by) { int t = typ(v); if (t == 5 || (d < 4 && t == 4) || (d >= 4 && t == 3)) return true; } break; }
        nx += D[d][0]; ny += D[d][1];
      }
    }
    return false;
  }
  static int kingSq(const Pos& q, int c) { for (int i = 0; i < 64; i++) if (q.b[i] == 6 + c * 8) return i; return -1; }
  static void doMove(Pos& q, const Mv& m) {
    int v = q.b[m.f], c = col(v), t = typ(v);
    if (t == 1 && m.t == q.ep) q.b[m.t + (c == 0 ? 8 : -8)] = 0;   // geçerken alma
    if (t == 6 && std::abs(m.t - m.f) == 2) { if (m.t > m.f) { q.b[m.f + 1] = q.b[m.f + 3]; q.b[m.f + 3] = 0; } else { q.b[m.f - 1] = q.b[m.f - 4]; q.b[m.f - 4] = 0; } }
    q.b[m.t] = v; q.b[m.f] = 0;
    if (m.promo) q.b[m.t] = m.promo + c * 8;
    q.ep = (t == 1 && std::abs(m.t - m.f) == 16) ? (m.f + m.t) / 2 : -1;
    if (t == 6) q.castle &= c == 0 ? ~3 : ~12;
    for (int s : { m.f, m.t }) { if (s == 63) q.castle &= ~1; if (s == 56) q.castle &= ~2; if (s == 7) q.castle &= ~4; if (s == 0) q.castle &= ~8; }
  }
  static void gen(const Pos& q, int c, std::vector<Mv>& out) {
    out.clear();
    for (int i = 0; i < 64; i++) {
      int v = q.b[i]; if (col(v) != c) continue;
      int x = i % 8, y = i / 8, t = typ(v);
      auto add = [&](int to) { int ty = to / 8; if (t == 1 && (ty == 0 || ty == 7)) out.push_back({ i, to, 5 }); else out.push_back({ i, to, 0 }); };
      if (t == 1) {
        int d = c == 0 ? -1 : 1, ny = y + d;
        if (ny >= 0 && ny < 8 && !q.b[ny * 8 + x]) { add(ny * 8 + x); int sy = c == 0 ? 6 : 1; if (y == sy && !q.b[(y + 2 * d) * 8 + x]) add((y + 2 * d) * 8 + x); }
        for (int dx = -1; dx <= 1; dx += 2) { int nx = x + dx; if (nx < 0 || nx > 7 || ny < 0 || ny > 7) continue; int to = ny * 8 + nx; if ((q.b[to] && col(q.b[to]) != c) || to == q.ep) add(to); }
      } else if (t == 2 || t == 6) {
        static const int KN[8][2] = { {1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1} }, KG[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
        for (auto& k : (t == 2 ? KN : KG)) { int nx = x + k[0], ny = y + k[1]; if (nx < 0 || nx > 7 || ny < 0 || ny > 7) continue; int to = ny * 8 + nx; if (!q.b[to] || col(q.b[to]) != c) add(to); }
        if (t == 6) {
          int base = c == 0 ? 60 : 4, ks = c == 0 ? 1 : 4, qs = c == 0 ? 2 : 8;
          if (i == base && !attacked(q, i, 1 - c)) {
            if ((q.castle & ks) && !q.b[i + 1] && !q.b[i + 2] && !attacked(q, i + 1, 1 - c) && !attacked(q, i + 2, 1 - c)) add(i + 2);
            if ((q.castle & qs) && !q.b[i - 1] && !q.b[i - 2] && !q.b[i - 3] && !attacked(q, i - 1, 1 - c) && !attacked(q, i - 2, 1 - c)) add(i - 2);
          }
        }
      } else {
        static const int D[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
        for (int d = (t == 3 ? 4 : 0); d < (t == 4 ? 4 : 8); d++) {
          int nx = x + D[d][0], ny = y + D[d][1];
          while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) { int to = ny * 8 + nx; if (q.b[to]) { if (col(q.b[to]) != c) add(to); break; } add(to); nx += D[d][0]; ny += D[d][1]; }
        }
      }
    }
  }
  static void legal(const Pos& q, int c, std::vector<Mv>& out) {
    std::vector<Mv> ps; gen(q, c, ps); out.clear();
    for (auto& m : ps) { Pos q2 = q; doMove(q2, m); if (!attacked(q2, kingSq(q2, c), 1 - c)) out.push_back(m); }
  }
  static int eval(const Pos& q, int c) {
    static const int V[7] = { 0, 100, 310, 330, 500, 900, 0 };
    int e = 0;
    for (int i = 0; i < 64; i++) {
      int v = q.b[i]; if (!v) continue; int t = typ(v), x = i % 8, y = i / 8;
      int s = V[t];
      if (t == 1) s += (col(v) == 0 ? 6 - y : y - 1) * 6 + ((x == 3 || x == 4) ? 6 : 0);
      if (t == 2 || t == 3) s += 12 - (std::abs(2 * x - 7) + std::abs(2 * y - 7));
      e += col(v) == c ? s : -s;
    }
    return e;
  }
  int search(const Pos& q, int c, int depth, int a, int bt) {
    std::vector<Mv> mv; legal(q, c, mv);
    if (mv.empty()) return attacked(q, kingSq(q, c), 1 - c) ? -50000 - depth : 0;
    if (!depth) return eval(q, c);
    std::stable_sort(mv.begin(), mv.end(), [&](const Mv& x, const Mv& y) { return q.b[x.t] > q.b[y.t]; });
    for (auto& m : mv) { Pos q2 = q; doMove(q2, m); int v = -search(q2, 1 - c, depth - 1, -bt, -a); if (v > a) a = v; if (a >= bt) break; }
    return a;
  }
  void after(Game& g, const Mv& m) {
    lastF = m.f; lastT = m.t; ply++; turn = 1 - turn; sel = -1; g.sfx(SFX_CLICK);
    std::vector<Mv> mv; legal(p, turn, mv);
    bool chk = attacked(p, kingSq(p, turn), 1 - turn);
    if (mv.empty()) { winner = chk ? 1 - turn : 99; msg = chk ? "Şah mat!" : "Pat: hamle yok."; }
    else if (ply > 300) winner = 99;
    else msg = chk ? "Şah!" : "";
  }
  void ai(Game& g) override {
    std::vector<Mv> mv; legal(p, turn, mv); if (mv.empty()) return;
    int best = -1000000; std::vector<int> idx;
    for (size_t i = 0; i < mv.size(); i++) { Pos q2 = p; doMove(q2, mv[i]); int v = -search(q2, 1 - turn, 2, -1000000, 1000000) + (int)(g.rnd() * 8); if (v > best) { best = v; idx.clear(); } if (v == best) idx.push_back((int)i); }
    Mv m = mv[idx[0]]; doMove(p, m); after(g, m);
  }
  void key(Game& g, int k) override {
    if (k < 4) { int x = cur % 8 + (k == 0 ? -1 : k == 1 ? 1 : 0), y = cur / 8 + (k == 2 ? -1 : k == 3 ? 1 : 0); cur = std::max(0, std::min(7, y)) * 8 + std::max(0, std::min(7, x)); return; }
    if (k == 5) { sel = -1; return; }
    std::vector<Mv> mv; legal(p, turn, mv);
    if (sel >= 0) for (auto& m : mv) if (m.f == sel && m.t == cur) { doMove(p, m); after(g, m); return; }
    bool can = false; for (auto& m : mv) if (m.f == cur) can = true;
    if (can) sel = cur; else if (sel >= 0) msg = "Bu hamle olmaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cs = 19, bx = std::floor((g.VW - cs * 8) / 2), by = 14;
    std::vector<Mv> mv; if (winner < 0) legal(p, turn, mv);
    for (int i = 0; i < 64; i++) {
      double x = bx + (i % 8) * cs, y = by + (i / 8) * cs;
      Col c = ((i % 8 + i / 8) & 1) ? H(0x7a9a58) : H(0xe8e0c0);
      if (i == lastF || i == lastT) c = ((i % 8 + i / 8) & 1) ? H(0xa8a848) : H(0xf0e890);
      g.rectV(x, y, cs, cs, c);
      int v = p.b[i]; if (v) sprV(g, g.A.chess[(typ(v) - 1) + col(v) * 6], x + 3, y + 1, 2);
      g.hit(x, y, cs, cs, [&g, i] { g.mgTap(i); });
    }
    if (winner < 0) {
      if (sel >= 0) { frame(g, bx + (sel % 8) * cs, by + (sel / 8) * cs, cs, cs, H(0x60e070)); for (auto& m : mv) if (m.f == sel) g.rectV(bx + (m.t % 8) * cs + 7, by + (m.t / 8) * cs + 7, 5, 5, H(0x40c050, 0.85)); }
      if (human[turn]) frame(g, bx + (cur % 8) * cs + 1, by + (cur / 8) * cs + 1, cs - 2, cs - 2, H(0xf8d848));
    }
    sideInfo(g, *this, 4, bx - 8, "SATRANÇ");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : p.b) w.u8(v); w.u8(p.castle); w.i32(p.ep); w.i32(ply); w.i32(lastF); w.i32(lastT); }
  void load(RBuf& r) override { loadBase(r); for (int& v : p.b) v = r.u8(); p.castle = r.u8(); p.ep = r.i32(); ply = r.i32(); lastF = r.i32(); lastT = r.i32(); }
};

// ======================================================================= TAVLA
// 0. oyuncu (beyaz) 23'ten 0'a gider, evi 0-5; 1. oyuncu (siyah) 0'dan 23'e, evi 18-23. Çift zar dört hamle; olabildiğince çok zar oynanır.
struct Tavla : MiniGame {
  struct St { int pt[24]; int bar[2], off[2]; };
  struct Mv { int f, t, d; };   // f: -1 kırık (bar); t: -2 toplandı
  St s; std::vector<int> dice; bool rolled = false; int d0 = 0, d1 = 0; double passT = 0;
  Tavla() {
    memset(&s, 0, sizeof s);
    s.pt[23] = 2; s.pt[12] = 5; s.pt[7] = 3; s.pt[5] = 5;
    s.pt[0] = -2; s.pt[11] = -5; s.pt[16] = -3; s.pt[18] = -5;
    cur = 26; sel = -9; msg = "Zar at!";
  }
  int kind() const override { return MG_TAVLA; }
  static int own(const St& q, int i, int p) { return p == 0 ? std::max(0, q.pt[i]) : std::max(0, -q.pt[i]); }
  static int opp(const St& q, int i, int p) { return own(q, i, 1 - p); }
  static bool home(const St& q, int p) {
    if (q.bar[p]) return false;
    for (int i = 0; i < 24; i++) if (own(q, i, p) && (p == 0 ? i > 5 : i < 18)) return false;
    return true;
  }
  static int target(const St& q, int p, int f, int d) {
    if (q.bar[p] && f != -1) return -9;
    if (f == -1) { if (!q.bar[p]) return -9; int t = p == 0 ? 24 - d : d - 1; return opp(q, t, p) >= 2 ? -9 : t; }
    if (!own(q, f, p)) return -9;
    int t = p == 0 ? f - d : f + d;
    if (t >= 0 && t < 24) return opp(q, t, p) >= 2 ? -9 : t;
    if (!home(q, p)) return -9;
    int dist = p == 0 ? f + 1 : 24 - f;
    if (dist == d) return -2;
    // büyük zarla toplama: daha geride taş yoksa
    for (int i = 0; i < 24; i++) if (own(q, i, p) && (p == 0 ? i > f : i < f)) return -9;
    return -2;
  }
  static void apply(St& q, int p, const Mv& m) {
    int sg = p == 0 ? 1 : -1;
    if (m.f == -1) q.bar[p]--; else q.pt[m.f] -= sg;
    if (m.t == -2) { q.off[p]++; return; }
    if (opp(q, m.t, p) == 1) { q.pt[m.t] = 0; q.bar[1 - p]++; }
    q.pt[m.t] += sg;
  }
  static void seqs(const St& q, int p, std::vector<int> ds, std::vector<Mv>& cur, std::vector<std::vector<Mv>>& out, int& budget) {
    if (--budget < 0) return;
    bool any = false; std::vector<int> tried;
    for (size_t k = 0; k < ds.size(); k++) {
      int d = ds[k]; if (std::find(tried.begin(), tried.end(), d) != tried.end()) continue; tried.push_back(d);
      for (int f = -1; f < 24; f++) {
        int t = target(q, p, f, d); if (t == -9) continue;
        any = true; St q2 = q; Mv m{ f, t, d }; apply(q2, p, m);
        auto ds2 = ds; ds2.erase(ds2.begin() + k); cur.push_back(m);
        seqs(q2, p, ds2, cur, out, budget); cur.pop_back();
      }
    }
    if (!any) out.push_back(cur);
  }
  std::vector<std::vector<Mv>> legalSeqs(const St& q, int p, const std::vector<int>& ds) {
    std::vector<std::vector<Mv>> all; std::vector<Mv> c; int budget = 60000; seqs(q, p, ds, c, all, budget);
    size_t mx = 0; for (auto& a : all) mx = std::max(mx, a.size());
    std::vector<std::vector<Mv>> r; for (auto& a : all) if (a.size() == mx) r.push_back(a);
    if (mx == 1 && ds.size() == 2 && ds[0] != ds[1]) {
      int big = std::max(ds[0], ds[1]); std::vector<std::vector<Mv>> r2; for (auto& a : r) if (a[0].d == big) r2.push_back(a);
      if (r2.size()) r = r2;
    }
    if (mx == 0) r.clear();
    return r;
  }
  static int pip(const St& q, int p) { int n = q.bar[p] * 25; for (int i = 0; i < 24; i++) n += own(q, i, p) * (p == 0 ? i + 1 : 24 - i); return n; }
  static int evalSt(const St& q, int p) {
    int e = (pip(q, 1 - p) - pip(q, p)) * 2 + q.off[p] * 12 + q.bar[1 - p] * 14;
    for (int i = 0; i < 24; i++) {
      int n = own(q, i, p);
      if (n >= 2) e += (p == 0 ? i <= 5 : i >= 18) ? 7 : 3;
      if (n == 1) {   // açık taş: arkasında rakip var mı
        bool risk = false;
        for (int j = 0; j < 24; j++) if (own(q, j, 1 - p)) { int dd = p == 0 ? i - j : j - i; if (dd > 0 && dd <= 12) risk = true; }
        if (q.bar[1 - p]) risk = true;
        if (risk) e -= 9;
      }
    }
    return e;
  }
  void roll(Game& g) {
    d0 = 1 + (int)(g.rnd() * 6) % 6; d1 = 1 + (int)(g.rnd() * 6) % 6; rolled = true;
    dice = d0 == d1 ? std::vector<int>{ d0, d0, d0, d0 } : std::vector<int>{ d0, d1 };
    g.sfx(SFX_CLICK);
    if (legalSeqs(s, turn, dice).empty()) { msg = fmt("%d-%d: oynayacak hamle yok.", d0, d1); passT = 1.4; }
    else msg = fmt("Zar: %d-%d", d0, d1);
  }
  void endTurn(Game& g) {
    if (s.off[turn] >= 15) { winner = turn; return; }
    turn = 1 - turn; rolled = false; dice.clear(); sel = -9; cur = 26; msg = "Zar at!"; g.sfx(SFX_SELECT);
  }
  void tick(Game& g, double dt) override { if (passT > 0) { passT -= dt; if (passT <= 0) endTurn(g); } }
  // tek hamle: sıradaki oyuncu f'den t'ye (uygun zarla)
  bool single(Game& g, int f, int t) {
    auto L = legalSeqs(s, turn, dice);
    for (auto& sq : L) if (sq[0].f == f && sq[0].t == t) {
      apply(s, turn, sq[0]); dice.erase(std::find(dice.begin(), dice.end(), sq[0].d)); sel = -9; g.sfx(SFX_CLICK);
      if (s.off[turn] >= 15) { winner = turn; return true; }
      if (dice.empty() || legalSeqs(s, turn, dice).empty()) endTurn(g);
      return true;
    }
    return false;
  }
  void ai(Game& g) override {
    if (passT > 0) return;
    if (!rolled) { roll(g); return; }
    auto L = legalSeqs(s, turn, dice); if (L.empty()) { endTurn(g); return; }
    int best = -1000000; size_t bi = 0;
    for (size_t i = 0; i < L.size(); i++) { St q = s; for (auto& m : L[i]) apply(q, turn, m); int v = evalSt(q, turn); if (v > best) { best = v; bi = i; } }
    for (auto& m : L[bi]) apply(s, turn, m);
    dice.clear(); endTurn(g);
  }
  // imleç sırası: alt sıra soldan sağa (11..0), kırık, toplanan; üst sıra (12..23), zar düğmesi
  static int vis(int i, int& row) { if (i < 12) { row = 1; return 11 - i; } if (i < 24) { row = 0; return i - 12; } row = 2; return i == 24 ? 0 : i == 25 ? 1 : 2; }
  void key(Game& g, int k) override {
    if (passT > 0) return;
    if (k == 0 || k == 1) {
      static const int ORD[27] = { 12,13,14,15,16,17,18,19,20,21,22,23, 11,10,9,8,7,6,5,4,3,2,1,0, 24, 25, 26 };
      int at = 0; for (int i = 0; i < 27; i++) if (ORD[i] == cur) at = i;
      at = (at + (k == 0 ? -1 : 1) + 27) % 27; cur = ORD[at]; return;
    }
    if (k == 2 || k == 3) { if (cur < 12) cur = 23 - cur; else if (cur < 24) cur = 23 - cur; else cur = k == 2 ? 23 : 0; return; }
    if (k == 5) { sel = -9; return; }
    if (!rolled) { roll(g); return; }
    if (cur == 26) return;
    int c = cur == 24 ? -1 : cur == 25 ? -2 : cur;
    if (sel != -9 && c != sel && single(g, sel, c)) return;
    auto L = legalSeqs(s, turn, dice); bool can = false; for (auto& sq : L) if (sq[0].f == c) can = true;
    if (can) sel = c; else msg = "Oradan oynanmaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cw = 14, bx = std::floor((g.VW - cw * 14) / 2) + 20, by = 12, bh = 150, ph = 62;
    g.rectV(bx - 4, by - 2, cw * 13 + 8 + 20, bh + 4, H(0x5a3a1e));
    g.rectV(bx, by, cw * 13, bh, H(0xd8b880));
    auto colX = [&](int c) { return bx + (c < 6 ? c : c + 1) * cw; };
    auto ptX = [&](int i) { int row; int c = vis(i, row); return colX(c); };
    g.rectV(bx + 6 * cw, by, cw, bh, H(0x7a5030));   // kırık bölmesi
    std::vector<std::vector<Mv>> L; if (winner < 0 && rolled && passT <= 0) L = legalSeqs(s, turn, dice);
    for (int i = 0; i < 24; i++) {
      int row; vis(i, row); double x = ptX(i);
      Col pc = (i & 1) ? H(0x8a3a2a) : H(0x3a5a3a);
      for (int k = 0; k < 10; k++) { double w = cw * (1 - k / 10.0); double yy = row == 0 ? by + k * (ph / 10) : by + bh - (k + 1) * (ph / 10); g.rectV(x + (cw - w) / 2, yy, w, ph / 10 + 0.5, pc); }
      int n = std::abs(s.pt[i]); int who = s.pt[i] > 0 ? 0 : 1;
      for (int k = 0; k < std::min(n, 5); k++) { double yy = row == 0 ? by + 1 + k * 12 : by + bh - 13 - k * 12; sprV(g, g.A.disc[who == 0 ? 0 : 1], x + 1, yy, 1.2); }
      if (n > 5) g.text(fmt("%d", n), x + cw / 2, row == 0 ? by + 62 : by + bh - 72, 0.26, H(0xffffff), 1, true);
      g.hit(x, row == 0 ? by : by + bh - ph, cw, ph, [&g, i] { g.mgTap(i); });
      bool tgt = false; for (auto& sq : L) if (sel != -9 && sq[0].f == sel && sq[0].t == i) tgt = true;
      if (tgt) g.rectV(x + 4, row == 0 ? by + ph + 2 : by + bh - ph - 7, 6, 5, H(0x40e050));
    }
    for (int p = 0; p < 2; p++) for (int k = 0; k < s.bar[p]; k++) sprV(g, g.A.disc[p], bx + 6 * cw + 1, p == 0 ? by + bh / 2 + 4 + k * 8 : by + bh / 2 - 16 - k * 8, 1.2);
    g.hit(bx + 6 * cw, by + ph, cw, bh - 2 * ph, [&g] { g.mgTap(24); });
    // toplananlar
    double ox = bx + cw * 13 + 4;
    g.rectV(ox, by, 16, bh, H(0x4a2e18));
    g.text(fmt("%d", s.off[1]), ox + 8, by + 4, 0.26, H(0xffffff), 1, true); g.text(fmt("%d", s.off[0]), ox + 8, by + bh - 12, 0.26, H(0xffffff), 1, true);
    g.hit(ox, by, 16, bh, [&g] { g.mgTap(25); });
    bool tgtOff = false; for (auto& sq : L) if (sel != -9 && sq[0].f == sel && sq[0].t == -2) tgtOff = true;
    if (tgtOff) g.rectV(ox + 5, by + bh / 2 - 3, 6, 6, H(0x40e050));
    // zarlar
    double dx = bx + 2 * cw, dy = by + bh / 2 - 7;
    if (rolled) for (int k = 0; k < 2; k++) { g.rectV(dx + k * 18, dy, 14, 14, H(0xfaf6ea)); frame(g, dx + k * 18, dy, 14, 14, H(0x302020)); g.text(fmt("%d", k ? d1 : d0), dx + k * 18 + 7, dy + 2.5, 0.32, H(0x201010), 1, true); }
    else if (winner < 0) { g.rectV(dx, dy, 44, 14, H(0x3a6ad0)); g.text("ZAR AT", dx + 22, dy + 3, 0.26, H(0xffffff), 1, true); g.hit(dx, dy, 44, 14, [&g] { g.mgTap(26); }); }
    if (rolled && dice.size()) { string ds; for (int d : dice) ds += fmt("%d ", d); g.text(ds, bx + 9.5 * cw, dy + 2, 0.26, H(0x302010), 1, true); }
    // imleç
    if (winner < 0 && human[turn]) {
      double x, y, w = cw, h = ph;
      if (cur < 24) { int row; vis(cur, row); x = ptX(cur); y = row == 0 ? by : by + bh - ph; }
      else if (cur == 24) { x = bx + 6 * cw; y = by + ph; h = bh - 2 * ph; }
      else if (cur == 25) { x = ox; y = by; w = 16; h = bh; }
      else { x = dx; y = dy; w = 44; h = 14; }
      frame(g, x, y, w, h, H(0xf8d848));
      if (sel >= 0 && rolled) { int row; vis(sel, row); frame(g, ptX(sel) + 1, row == 0 ? by + 1 : by + bh - ph + 1, cw - 2, ph - 2, H(0x60e070)); }
    }
    sideInfo(g, *this, 2, bx - 26, "TAVLA");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : s.pt) w.i32(v); for (int i = 0; i < 2; i++) { w.u8(s.bar[i]); w.u8(s.off[i]); } w.u8(rolled); w.u8(d0); w.u8(d1); w.u8((int)dice.size()); for (int d : dice) w.u8(d); }
  void load(RBuf& r) override { loadBase(r); for (int& v : s.pt) v = r.i32(); for (int i = 0; i < 2; i++) { s.bar[i] = r.u8(); s.off[i] = r.u8(); } rolled = r.u8() != 0; d0 = r.u8(); d1 = r.u8(); int n = r.u8(); dice.clear(); for (int i = 0; i < n; i++) dice.push_back(r.u8()); }
};

// ======================================================================= PAPAZ KİMDE
// 3 papaz (kral) çıkarılır; aynı sayıdaki iki kart atılır. Rakibin elinden sırayla kart çekilir; son papazı elinde tutan kaybeder.
struct Papaz : MiniGame {
  std::vector<int> hand[2]; int lastA = -1, lastB = -1;   // kart = renk * 16 + sayı (1-13)
  int kind() const override { return MG_PAPAZ; }
  void deal(Game& g) {
    std::vector<int> deck; for (int c = 0; c < 4; c++) for (int n = 1; n <= 13; n++) if (n != 13 || c == 0) deck.push_back(c * 16 + n);
    for (int i = (int)deck.size() - 1; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(deck[i], deck[j]); }
    for (size_t i = 0; i < deck.size(); i++) hand[i & 1].push_back(deck[i]);
    for (int p = 0; p < 2; p++) prune(p);
    msg = "Rakibinin kapalı kartlarından birini seç."; cur = 0;
  }
  void prune(int p) {
    auto& h = hand[p];
    for (size_t i = 0; i < h.size(); i++) for (size_t j = i + 1; j < h.size(); j++) if (h[i] % 16 == h[j] % 16) { h.erase(h.begin() + j); h.erase(h.begin() + i); i = (size_t)-1; break; }
  }
  void take(Game& g, int idx) {
    auto& o = hand[1 - turn]; if (o.empty()) return;
    idx = std::max(0, std::min((int)o.size() - 1, idx));
    int c = o[idx]; o.erase(o.begin() + idx);
    auto& h = hand[turn]; bool pair = false;
    for (size_t i = 0; i < h.size(); i++) if (h[i] % 16 == c % 16) { lastA = h[i]; lastB = c; h.erase(h.begin() + i); pair = true; break; }
    if (!pair) { h.push_back(c); for (int i = (int)h.size() - 1; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(h[i], h[j]); } }
    msg = pair ? "Çift! İkisi de atıldı." : (c % 16 == 13 ? "Papaz geldi..." : "Çift olmadı.");
    g.sfx(SFX_CLICK);
    for (int p = 0; p < 2; p++) if (hand[p].empty()) { winner = p; msg = "Papaz kimde? Papaz onda!"; return; }
    turn = 1 - turn; cur = 0;
    std::shuffle(hand[1 - turn].begin(), hand[1 - turn].end(), std::minstd_rand((unsigned)(g.rnd() * 99999)));
  }
  void ai(Game& g) override { take(g, (int)(g.rnd() * hand[1 - turn].size())); }
  void key(Game& g, int k) override {
    int n = (int)hand[1 - turn].size();
    if (k == 0) cur = (cur + n - 1) % std::max(1, n); else if (k == 1) cur = (cur + 1) % std::max(1, n); else if (k == 4) take(g, cur);
  }
  void tap(Game& g, int c) override { cur = c; take(g, c); }
  static string rankName(Game& g, int n) { static const char* TR[14] = { "", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "V", "K", "P" }, *EN[14] = { "", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" }; return (g.lang ? EN : TR)[n]; }
  static void card(Game& g, double x, double y, int c, bool open) {
    g.rectV(x, y, 18, 26, open ? H(0xfaf8f0) : H(0x2a4a9a)); frame(g, x, y, 18, 26, H(0x202030));
    if (!open) { g.rectV(x + 3, y + 3, 12, 20, H(0x3a62c0)); return; }
    bool red = (c / 16) & 1; Col k = red ? H(0xd02828) : H(0x202020);
    g.text(rankName(g, c % 16), x + 9, y + 3, 0.3, k, 1, true);
    static const char* PIP[4] = { "01110111111111100100", "01010111111111001110", "00100011101111100100", "00100011100111000100" };   // maça kupa sinek karo (5x4)
    const char* pp = PIP[c / 16];
    for (int i = 0; i < 20; i++) if (pp[i] == '1') g.rectV(x + 6.5 + (i % 5), y + 14 + i / 5, 1, 1, k);
  }
  void draw(Game& g, int viewer) override {
    int me = human[turn] ? turn : viewer, op = 1 - me;
    double cw = 20, top = 22, bot = 136;
    int no = (int)hand[op].size(), nm = (int)hand[me].size();
    double ox = std::floor((g.VW - std::min(no, 14) * cw) / 2), mx = std::floor((g.VW - std::min(nm, 14) * cw) / 2);
    g.text(g.tr(names[op]), g.VW / 2.0, 10, 0.28, H(0xd0d0e0), 1);
    for (int i = 0; i < no; i++) {
      double x = ox + (i % 14) * cw, y = top + (i / 14) * 10;
      card(g, x, y, hand[op][i], winner >= 0);
      if (winner < 0 && turn == me) { g.hit(x, y, cw, 26, [&g, i] { g.mgTap(i); }); if (human[turn] && i == cur) frame(g, x - 1, y - 1, 20, 28, H(0xf8d848)); }
    }
    for (int i = 0; i < nm; i++) card(g, mx + (i % 14) * cw, bot + (i / 14) * 10, hand[me][i], true);
    g.text(g.tr(names[me]), g.VW / 2.0, bot - 10, 0.28, H(0xd0d0e0), 1);
    if (lastA >= 0) { card(g, g.VW / 2.0 - 20, 72, lastA, true); card(g, g.VW / 2.0 + 2, 72, lastB, true); }
    string s = winner >= 0 ? fmt("%s kazandı! Papaz %s elinde kaldı.", g.tr(names[winner]).c_str(), g.tr(names[1 - winner]).c_str()) : msg;
    if (winner < 0 && turn != me) s = fmt("%s kart çekiyor...", g.tr(names[turn]).c_str());
    g.text("PAPAZ KİMDE", 6, 72, 0.32, H(0xf8d878), 0, true);
    int ln = 0; for (auto& l : g.wrap(s, 0.26, g.VW / 2.0 - 34)) g.text(l, 6, 84 + 9 * ln++, 0.26, H(0xf8e8c0));
    g.text(g.desktop ? "Oklar: seç  •  Boşluk: çek  •  Esc: çık" : "Bir karta dokun  •  Durdur: çık", g.VW / 2.0, 172, 0.22, H(0xa0a0b8), 1);
  }
  void save(WBuf& w) override { saveBase(w); for (int p = 0; p < 2; p++) { w.u8((int)hand[p].size()); for (int c : hand[p]) w.u8(c); } w.i32(lastA); w.i32(lastB); }
  void load(RBuf& r) override { loadBase(r); for (int p = 0; p < 2; p++) { int n = r.u8(); hand[p].clear(); for (int i = 0; i < n; i++) hand[p].push_back(r.u8()); } lastA = r.i32(); lastB = r.i32(); }
};

// ======================================================================= 101 OKEY
// 106 taş (4 renk x 1-13 x 2 + 2 sahte okey). Gösterge taşının bir fazlası okeydir (her şeyin yerine geçer).
// Amaç: 101 puanlık per (seri ya da aynı sayı) açmak, sonra elindeki taşları perlere işleyip eli bitirmek.
struct Okey : MiniGame {
  std::vector<int> hand[4], pile; struct Meld { std::vector<int> t; int type, c, n, len; };   // type 0 seri (renk c, n'den len taş), 1 grup (sayı n)
  std::vector<Meld> table; int lastDis[4] = { -1, -1, -1, -1 }; bool opened[4] = {}; int phase = 0, indicator = 0, okC = 0, okN = 1; bool firstTurn = true;
  int kind() const override { return MG_OKEY; }
  static int colOf(int id) { return id / 26; }
  static int numOf(int id) { return (id % 26) / 2 + 1; }
  bool wild(int id) const { return id < 104 && colOf(id) == okC && numOf(id) == okN; }
  void tileCN(int id, int& c, int& n) const { if (id >= 104) { c = okC; n = okN; } else { c = colOf(id); n = numOf(id); } }
  void deal(Game& g) {
    for (int i = 0; i < 106; i++) pile.push_back(i);
    for (int i = 105; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(pile[i], pile[j]); }
    for (size_t i = 0; i < pile.size(); i++) if (pile[i] < 104) { indicator = pile[i]; pile.erase(pile.begin() + i); break; }
    okC = colOf(indicator); okN = numOf(indicator) % 13 + 1;
    for (int p = 0; p < np; p++) for (int k = 0; k < (p == 0 ? 22 : 21); k++) { hand[p].push_back(pile.back()); pile.pop_back(); }
    for (int p = 0; p < np; p++) sortHand(p);
    phase = 1; msg = "İlk sen oynuyorsun: 101 puanlık per açabiliyorsan aç, sonra bir taş at."; cur = 0;
  }
  void sortHand(int p) { std::sort(hand[p].begin(), hand[p].end(), [&](int a, int b) { int ca, na, cb, nb; tileCN(a, ca, na); tileCN(b, cb, nb); if (wild(a) != wild(b)) return wild(b); return ca != cb ? ca < cb : na < nb; }); }
  // ---- per bulucu: en çok puanlı ayrık perler (sayılar üzerinden, okeyler joker)
  struct Cand { int type, c, n, len, need, pts; };
  void bestMelds(const std::vector<int>& h, std::vector<Meld>& out, int& pts) const {
    int cnt[4][14] = {}; int J = 0; std::vector<int> ids[4][14], wl;
    for (int id : h) { if (wild(id)) { J++; wl.push_back(id); continue; } int c, n; tileCN(id, c, n); cnt[c][n]++; ids[c][n].push_back(id); }
    std::vector<Cand> cs;
    for (int n = 1; n <= 13; n++) for (int mask = 0; mask < 16; mask++) {
      int sz = __builtin_popcount(mask); if (sz < 3) continue;
      int need = 0; for (int c = 0; c < 4; c++) if ((mask >> c) & 1 && !cnt[c][n]) need++;
      if (need <= J && need < sz) cs.push_back({ 1, mask, n, sz, need, n * sz });
    }
    for (int c = 0; c < 4; c++) for (int s = 1; s <= 11; s++) for (int len = 3; s + len - 1 <= 13; len++) {
      int need = 0, pt = 0; for (int k = s; k < s + len; k++) { if (!cnt[c][k]) need++; pt += k; }
      if (need > J) break;
      if (need < len) cs.push_back({ 0, c, s, len, need, pt });
    }
    std::sort(cs.begin(), cs.end(), [](const Cand& a, const Cand& b) { return a.pts > b.pts; });
    int best = 0, nodes = 0; std::vector<int> pick, bestPick;
    std::function<void(size_t, int, int)> dfs = [&](size_t i, int jl, int cur) {
      if (++nodes > 30000) return;
      if (cur > best) { best = cur; bestPick = pick; }
      for (size_t k = i; k < cs.size(); k++) {
        const Cand& m = cs[k]; bool ok = true; int need = 0;
        if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1) { if (cnt[c][m.n]) continue; need++; } }
        else for (int x = m.n; x < m.n + m.len; x++) if (!cnt[m.c][x]) need++;
        if (need > jl || need >= m.len) ok = false;
        if (!ok) continue;
        int dec[13][2]; int nd = 0;   // azaltılan sayaçlar (geri almak için)
        if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1 && cnt[c][m.n]) { cnt[c][m.n]--; dec[nd][0] = c; dec[nd++][1] = m.n; } }
        else for (int x = m.n; x < m.n + m.len; x++) if (cnt[m.c][x]) { cnt[m.c][x]--; dec[nd][0] = m.c; dec[nd++][1] = x; }
        pick.push_back((int)k); dfs(k, jl - need, cur + m.pts); pick.pop_back();
        for (int i = 0; i < nd; i++) cnt[dec[i][0]][dec[i][1]]++;
      }
    };
    dfs(0, J, 0);
    pts = best; out.clear();
    // seçilen perleri gerçek taşlara çevir
    int used[4][14] = {}; size_t wi = 0;
    for (int k : bestPick) {
      const Cand& m = cs[k]; Meld md; md.type = m.type; md.c = m.type == 0 ? m.c : 0; md.n = m.n; md.len = m.len;
      auto take = [&](int c, int n) { if (used[c][n] < (int)ids[c][n].size()) md.t.push_back(ids[c][n][used[c][n]++]); else if (wi < wl.size()) md.t.push_back(wl[wi++]); };
      if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1) take(c, m.n); md.c = m.c; }
      else for (int x = m.n; x < m.n + m.len; x++) take(m.c, x);
      if ((int)md.t.size() == m.len) out.push_back(md);
    }
  }
  static void removeTiles(std::vector<int>& h, const std::vector<int>& t) { for (int id : t) { auto it = std::find(h.begin(), h.end(), id); if (it != h.end()) h.erase(it); } }
  int handPts(int p) const { int s = 0; for (int id : hand[p]) { if (wild(id)) continue; int c, n; tileCN(id, c, n); s += n; } return opened[p] ? s : s * 2; }
  // per açma (101 puan) ya da açtıktan sonra per atma
  bool layDown(Game& g, int p) {
    std::vector<Meld> ms; int pts; bestMelds(hand[p], ms, pts);
    if (!opened[p] && pts < 101) { msg = fmt("Açmak için 101 puan lazım (elindeki perler: %d).", pts); return false; }
    if (ms.empty()) { msg = "Atacak per yok."; return false; }
    for (auto& m : ms) { removeTiles(hand[p], m.t); table.push_back(m); }
    if (!opened[p]) { opened[p] = true; msg = fmt("%s %d puanla açtı!", g.tr(names[p]).c_str(), pts); } else msg = "Perler masaya atıldı.";
    g.sfx(SFX_CHIME); checkWin(p); return true;
  }
  // masadaki perlere taş işle
  bool workIn(Game& g, int p) {
    if (!opened[p]) { msg = "Önce per açmalısın."; return false; }
    bool any = false, ch = true;
    while (ch) {
      ch = false;
      for (size_t i = 0; i < hand[p].size() && !ch; i++) {
        int id = hand[p][i]; int c, n; tileCN(id, c, n); bool w = wild(id);
        for (auto& m : table) {
          if (m.type == 0 && (w || c == m.c)) {
            if (m.n + m.len <= 13 && (w || n == m.n + m.len)) { m.t.push_back(id); m.len++; ch = true; break; }
            if (m.n > 1 && (w || n == m.n - 1)) { m.t.insert(m.t.begin(), id); m.n--; m.len++; ch = true; break; }
          } else if (m.type == 1 && m.len < 4 && !w && n == m.n && !((m.c >> c) & 1)) { m.t.push_back(id); m.c |= 1 << c; m.len++; ch = true; break; }
        }
        if (ch) { hand[p].erase(hand[p].begin() + i); any = true; }
      }
    }
    msg = any ? "Taşlar işlendi." : "İşlenecek taş yok.";
    if (any) { g.sfx(SFX_CLICK); checkWin(p); }
    return any;
  }
  void checkWin(int p) { if (hand[p].empty()) { winner = p; msg = "Elini bitirdi!"; } }
  void endByPile() {
    int best = 99999, w = 0; for (int p = 0; p < np; p++) { int s = handPts(p); if (s < best) { best = s; w = p; } }
    winner = w; msg = "Deste bitti: en az cezası olan kazandı.";
  }
  int prev() const { return (turn + np - 1) % np; }
  void draw1(Game& g, bool fromDiscard) {
    int p = turn;
    if (fromDiscard) { int t = lastDis[prev()]; if (t < 0) return; hand[p].push_back(t); lastDis[prev()] = -1; }
    else { if (pile.empty()) { endByPile(); return; } hand[p].push_back(pile.back()); pile.pop_back(); }
    sortHand(p); phase = 1; cur = 0; g.sfx(SFX_CLICK);
    msg = opened[p] ? "Per at, taş işle ya da bir taş at." : "101 puanlık per açabiliyorsan aç, sonra bir taş at.";
  }
  void discard(Game& g, int idx) {
    int p = turn; if (idx < 0 || idx >= (int)hand[p].size()) return;
    lastDis[p] = hand[p][idx]; hand[p].erase(hand[p].begin() + idx);
    g.sfx(SFX_CLICK);
    if (hand[p].empty()) { winner = p; return; }
    turn = (turn + 1) % np; phase = 0; cur = 0; firstTurn = false;
    msg = human[turn] ? "Desteden çek ya da soldakinin attığı taşı al." : "";
  }
  void ai(Game& g) override {
    int p = turn;
    if (phase == 0) {
      int t = lastDis[prev()]; bool take = false;
      if (t >= 0) { std::vector<Meld> m; int a, b; bestMelds(hand[p], m, a); auto h2 = hand[p]; h2.push_back(t); bestMelds(h2, m, b); int c, n; tileCN(t, c, n); take = wild(t) || b - a >= n + 3; }
      draw1(g, take); if (winner >= 0) return;
    }
    std::vector<Meld> ms; int pts; bestMelds(hand[p], ms, pts);
    if ((!opened[p] && pts >= 101) || (opened[p] && ms.size())) layDown(g, p);
    if (winner >= 0) return;
    if (opened[p]) workIn(g, p);
    if (winner >= 0) return;
    // atılacak taş: perlere girmeyen en büyük sayı (okey atılmaz)
    bestMelds(hand[p], ms, pts); std::vector<int> inM; for (auto& m : ms) for (int id : m.t) inM.push_back(id);
    int bi = -1, bn = -1;
    for (size_t i = 0; i < hand[p].size(); i++) { int id = hand[p][i]; if (wild(id)) continue; int c, n; tileCN(id, c, n); bool used = std::find(inM.begin(), inM.end(), id) != inM.end(); int sc = n + (used ? -40 : 0); if (sc > bn) { bn = sc; bi = (int)i; } }
    if (bi < 0) bi = 0;
    discard(g, bi);
  }
  // imleç: 0: desteden çek, 1: yerden al (çekme sırası) | elde taşlar, sonra "Per Aç/At" ve "İşle" düğmeleri
  void key(Game& g, int k) override {
    int n = phase == 0 ? 2 : (int)hand[turn].size() + 2;
    if (k == 0) cur = (cur + n - 1) % n; else if (k == 1) cur = (cur + 1) % n;
    else if (k == 2 || k == 3) { if (phase == 1) { int hs = (int)hand[turn].size(); if (cur < hs) cur = std::min(hs - 1, std::max(0, cur + (k == 2 ? -12 : 12))); } }
    else if (k == 4) act(g, cur);
  }
  void act(Game& g, int c) {
    if (phase == 0) { if (c == 1 && lastDis[prev()] < 0) { msg = "Yerde taş yok."; return; } draw1(g, c == 1); return; }
    int hs = (int)hand[turn].size();
    if (c < hs) discard(g, c); else if (c == hs) layDown(g, turn); else workIn(g, turn);
  }
  void tap(Game& g, int c) override { cur = c; act(g, c); }
  void tile(Game& g, double x, double y, int id, double w = 13, double h = 18) const {
    g.rectV(x, y, w, h, H(0xf6f0dc)); frame(g, x, y, w, h, wild(id) ? H(0xf8c020) : H(0x807060));
    static const uint32_t TC[4] = { 0xd02828, 0xd08a00, 0x2050c8, 0x202020 };
    if (id >= 104) { g.text("OK", x + w / 2, y + h / 2 - 4, 0.22, H(0x208040), 1, true); return; }
    g.text(fmt("%d", numOf(id)), x + w / 2, y + 3, w > 11 ? 0.3 : 0.24, H(TC[colOf(id)]), 1, true);
    g.rectV(x + w / 2 - 1.5, y + h - 5, 3, 3, H(TC[colOf(id)]));
  }
  void btn(Game& g, double x, double y, double w, const string& t, int idx, bool on) {
    g.rectV(x, y, w, 13, on ? H(0x3a6ad0) : H(0x3a3a5a)); g.text(t, x + w / 2, y + 2.5, 0.24, H(0xffffff), 1, true);
    g.hit(x, y, w, 13, [&g, idx] { g.mgTap(idx); });
    if (human[turn] && cur == idx && winner < 0) frame(g, x - 1, y - 1, w + 2, 15, H(0xf8d848));
  }
  void draw(Game& g, int viewer) override {
    int me = human[turn] ? turn : viewer;
    // rakipler
    for (int k = 1; k < np; k++) {
      int p = (me + k) % np; double x = 4 + (k - 1) * (g.VW - 8) / 3.0;
      g.rectV(x, 2, (g.VW - 8) / 3.0 - 4, 24, turn == p && winner < 0 ? H(0x2a5a3a) : H(0x2a2a40));
      g.text(fmt("%s (%d)", g.tr(names[p]).c_str(), (int)hand[p].size()), x + 3, 4, 0.24, H(0xe0e0f0));
      if (lastDis[p] >= 0) tile(g, x + 3, 13, lastDis[p], 9, 12); g.text(opened[p] ? "açtı" : "", x + 16, 14, 0.22, H(0x9af0a0));
    }
    // gösterge, deste, masadaki perler
    g.text("Gösterge", 6, 30, 0.22, H(0xc0c0d0)); tile(g, 6, 38, indicator, 11, 15);
    g.text(fmt("Deste: %d", (int)pile.size()), 6, 56, 0.22, H(0xc0c0d0));
    double tx = 48, ty = 30;
    for (auto& m : table) {
      double w = m.t.size() * 9 + 3; if (tx + w > g.VW - 4) { tx = 48; ty += 14; } if (ty > 82) break;
      for (size_t i = 0; i < m.t.size(); i++) tile(g, tx + i * 9, ty, m.t[i], 8.5, 12);
      tx += w;
    }
    // elim
    auto& h = hand[me]; int hs = (int)h.size();
    double hw = 14, hx = std::floor((g.VW - std::min(hs, 12) * hw) / 2), hy = 116;
    for (int i = 0; i < hs; i++) {
      double x = hx + (i % 12) * hw, y = hy + (i / 12) * 20;
      tile(g, x, y, h[i]);
      if (winner < 0 && turn == me && human[me] && phase == 1) { g.hit(x, y, hw, 19, [&g, i] { g.mgTap(i); }); if (cur == i) frame(g, x - 1, y - 1, 15, 20, H(0x40e050)); }
    }
    if (winner < 0 && turn == me && human[me]) {
      if (phase == 0) { btn(g, g.VW / 2.0 - 70, 98, 66, "Desteden çek", 0, true); btn(g, g.VW / 2.0 + 4, 98, 66, "Yerdekini al", 1, lastDis[prev()] >= 0); }
      else { btn(g, g.VW / 2.0 - 70, 98, 66, opened[me] ? "Per at" : "Per aç (101)", hs, true); btn(g, g.VW / 2.0 + 4, 98, 66, "İşle", hs + 1, opened[me]); }
      if (phase == 0 && lastDis[prev()] >= 0) tile(g, g.VW / 2.0 + 74, 96, lastDis[prev()], 11, 15);
    }
    string s = winner >= 0 ? (fmt("%s kazandı!", g.tr(names[winner]).c_str())) : (turn != me || !human[me]) ? fmt("%s oynuyor...", g.tr(names[turn]).c_str()) : msg;
    double ly = 86; for (auto& l : g.wrap(s, 0.24, g.VW - 40)) { g.text(l, g.VW / 2.0, ly, 0.24, H(0xf8e8c0), 1); ly += 8; }
    std::vector<Meld> ms; int pts; if (winner < 0 && human[me]) { bestMelds(h, ms, pts); g.text(fmt("Elindeki perler: %d puan", pts), 6, 70, 0.22, pts >= 101 || opened[me] ? H(0x9af0a0) : H(0xc0c0d0)); }
    g.text(g.desktop ? "Oklar: seç  •  Boşluk: onayla (taş seçince atar)  •  Esc: çık" : "Taşa dokun: at  •  Durdur: çık", g.VW / 2.0, 172, 0.22, H(0xa0a0b8), 1);
  }
  void save(WBuf& w) override {
    saveBase(w);
    for (int p = 0; p < 4; p++) { w.u8((int)hand[p].size()); for (int id : hand[p]) w.u8(id); w.i32(lastDis[p]); w.u8(opened[p]); }
    w.u8((int)pile.size()); w.u8(indicator); w.u8(okC); w.u8(okN); w.u8(phase);
    w.u8((int)table.size()); for (auto& m : table) { w.u8(m.type); w.u8(m.c); w.u8(m.n); w.u8(m.len); w.u8((int)m.t.size()); for (int id : m.t) w.u8(id); }
  }
  void load(RBuf& r) override {
    loadBase(r);
    for (int p = 0; p < 4; p++) { int n = r.u8(); hand[p].clear(); for (int i = 0; i < n; i++) hand[p].push_back(r.u8()); lastDis[p] = r.i32(); opened[p] = r.u8() != 0; }
    int pn = r.u8(); pile.assign(pn, 0); indicator = r.u8(); okC = r.u8(); okN = r.u8(); phase = r.u8();
    int tn = r.u8(); table.clear(); for (int i = 0; i < tn && !r.bad; i++) { Meld m; m.type = r.u8(); m.c = r.u8(); m.n = r.u8(); m.len = r.u8(); int k = r.u8(); for (int j = 0; j < k; j++) m.t.push_back(r.u8()); table.push_back(m); }
  }
};

// ======================================================================= Game tarafı
static std::shared_ptr<MiniGame> makeGame(int kind) {
  switch (kind) {
    case MG_DAMA: return std::make_shared<Dama>();
    case MG_SATRANC: return std::make_shared<Satranc>();
    case MG_TAVLA: return std::make_shared<Tavla>();
    case MG_PAPAZ: return std::make_shared<Papaz>();
    case MG_OKEY: return std::make_shared<Okey>();
  }
  return nullptr;
}
const char* mgName(int kind) { static const char* N[5] = { "Dama", "Satranç", "Tavla", "Papaz Kimde", "101 Okey" }; return kind >= 0 && kind < 5 ? N[kind] : ""; }
// friendPlays: arkadaş 1. oyuncu olur; değilse rakipler bilgisayar
void Game::mgStart(int kind, bool friendPlays, const std::vector<string>& rivals, std::function<void(int)> done) {
  mg = makeGame(kind); if (!mg) return;
  MiniGame& m = *mg;
  if (kind == MG_OKEY) m.np = 4;
  m.names[0] = "Arda";
  for (int i = 1; i < m.np; i++) m.names[i] = i - 1 < (int)rivals.size() ? rivals[i - 1] : fmt("Oyuncu %d", i + 1);
  if (friendPlays) { m.human[1] = true; m.names[1] = netRole == "host" ? "Arkadaşın" : "2. Oyuncu"; }
  if (kind == MG_PAPAZ) static_cast<Papaz&>(m).deal(*this);
  if (kind == MG_OKEY) static_cast<Okey&>(m).deal(*this);
  mgDone = done; mgEndT = 0; mgAiT = 0; sfx(SFX_CHIME);
}
// sıradaki insan oyuncu kim: 0 bu cihazın oyuncusu, 1 arkadaş (aynı bilgisayarda 2. oyuncu ya da online misafir)
void Game::mgUpdate(double dt) {
  MiniGame& m = *mg;
  Press& I = inp.pressed;
  if (I.pause) { ask({ L("", "Oyundan çıkmak istiyor musun? (Kaybetmiş sayılırsın.)") }, { "Çık", "Devam" }, [this](int c) { if (c == 0) mgFinish(1); }); return; }
  if (m.winner >= 0) {
    mgEndT += dt;
    if (mgEndT > 2.2 && (I.act || I.attack || I.confirm || mgEndT > 6)) mgFinish(m.winner);
    return;
  }
  m.tick(*this, dt);
  int t = m.turn;
  if (!m.human[t]) { mgAiT += dt; if (mgAiT > (m.kind() == MG_OKEY ? 0.9 : 0.6)) { mgAiT = 0; m.ai(*this); } return; }
  Press* src = &I;
  if (t == 1 && p2) src = &p2->inp.pressed;
  Press& P = *src;
  if (P.left) m.key(*this, 0); if (P.right) m.key(*this, 1); if (P.up) m.key(*this, 2); if (P.down) m.key(*this, 3);
  if (P.attack || P.act || P.confirm) m.key(*this, 4);
  if (P.item) m.key(*this, 5);
  if (t == 1 && p2) p2->inp.pressed = Press();
}
// dokunmatik: misafirde ev sahibine gönderilir; aynı cihazda sırası gelen insan oynar
void Game::mgTap(int cell) {
  if (netRole == "guest") { if (net && netLive) { WBuf w; w.u8('m'); w.i32(cell); net->send(w.b); } return; }
  if (!mg || mg->winner >= 0) return;
  if (!mg->human[mg->turn]) return;
  if (mg->turn == 1 && p2 && p2->remote) return;   // online arkadaşın sırası: o oynar
  mg->tap(*this, cell);
}
void Game::mgRemoteTap(int cell) { if (mg && mg->winner < 0 && mg->turn == 1 && mg->human[1]) mg->tap(*this, cell); }
void Game::mgFinish(int winner) {
  auto cb = mgDone; mg.reset(); mgDone = nullptr;
  if (cb) cb(winner);
}
void Game::mgDraw() {
  g->rect(0, 0, W, H, rgba(10, 20, 14, 0.94));
  int viewer = netRole == "guest" ? 1 : 0;
  mg->draw(*this, viewer);
  if (mg->winner >= 0) text(desktop ? "Devam etmek için Boşluk" : "Devam etmek için dokun", VW / 2.0, 160, 0.28, hexc(0xffffff), 1, true);
}
void Game::mgSave(WBuf& w) { w.u8(mg ? 1 : 0); if (mg) { w.u8(mg->kind()); WBuf s; mg->save(s); w.str(s.b); } }
void Game::mgLoad(RBuf& r) {
  int has = r.u8(); if (r.bad) return;
  if (!has) { mg.reset(); return; }
  int k = r.u8(); string s = r.str(); if (r.bad) return;
  if (!mg || mg->kind() != k) mg = makeGame(k);
  if (mg) { RBuf rr(s); mg->load(rr); }
}
