// ORMANIN KALBİ - Oyun Adası'nın masa oyunları: dama, satranç, tavla, papaz kimde, 101 okey
// Arkadaşın varsa (aynı bilgisayar ya da online) onunla, yoksa adadaki ustayla (bilgisayar) oynanır.
// Ortak arayüz: imleç (oklar), seç (Kılıç/Konuş), vazgeç (İksir); dokunmatikte hücreye dokunmak yeter.
#include "game.h"
#include "oyunlar.h"
#include <algorithm>
#include <random>

static Col H(uint32_t c, double a = 1) { Col k = hexc(c); k.a = a; return k; }
static void frame(Game& g, double x, double y, double w, double h, Col c) { g.rectV(x, y, w, 1, c); g.rectV(x, y + h - 1, w, 1, c); g.rectV(x, y, 1, h, c); g.rectV(x + w - 1, y, 1, h, c); }
static void sprV(Game& g, const Spr* sp, double x, double y, double sc) { g.g->sprite(sp, g.vx(x), y * g.s, sp->w * g.s * sc, sp->h * g.s * sc, false, 1); }
// yan bilgi: oyuncular, sıra, ileti
static void sideInfo(Game& g, MiniGame& m, double x, double w, const char* title) {
  g.text(title, x + w / 2, 8, 0.36, H(0xf8d878), 1, true);
  double y = 24;
  for (int i = 0; i < m.np; i++) {
    bool t = m.turn == i && m.winner < 0;
    g.text(fmt("%s%s", t ? "> " : "  ", g.tr(m.names[i]).c_str()), x + 4, y, 0.27, t ? H(0x9af0a0) : H(0xd0d0e0)); y += 10;
  }
  y += 4;
  string s = m.winner >= 0 ? (m.winner == 99 ? string("Berabere!") : fmt("%s kazandı!", g.tr(m.names[m.winner]).c_str())) : m.msg;
  for (auto& l : g.wrap(s, 0.26, w - 6)) { g.text(l, x + 4, y, 0.26, H(0xf8e8c0)); y += 9; }
  g.text(g.desktop ? "Oklar: seç  •  Boşluk: onayla  •  Q: vazgeç  •  Esc: çık" : "Dokun: seç  •  Durdur: çık", g.VW / 2.0, 172, 0.22, H(0xa0a0b8), 1);
}
void MiniGame::saveBase(WBuf& w) { w.u8(np); w.u8(turn); w.i32(winner); for (int i = 0; i < 4; i++) { w.u8(human[i]); w.str(names[i]); w.i32(who[i]); } w.str(msg); w.i32(cur); w.i32(sel); w.u8(tbl); w.u8(opt); }
void MiniGame::loadBase(RBuf& r) { np = r.u8(); turn = r.u8(); winner = r.i32(); for (int i = 0; i < 4; i++) { human[i] = r.u8() != 0; names[i] = r.str(); who[i] = r.i32(); } msg = r.str(); cur = r.i32(); sel = r.i32(); tbl = r.u8(); opt = r.u8(); }

// ======================================================================= DAMA
// Türk daması: taşlar ileri ve yana gider, çapraz yok; alma zorunlu ve en çok alan hamle seçilir; son sıraya varan dama olur, dama uzağa gider.
struct Dama : MiniGame {
  int b[64] = {}; int ply = 0;   // 1 beyaz, 2 beyaz dama (0. oyuncu, aşağıda) ; 3 siyah, 4 siyah dama
  struct Mv { std::vector<int> path, cap; };
  static int side(int v) { return v == 1 || v == 2 ? 0 : v == 3 || v == 4 ? 1 : -1; }
  static bool king(int v) { return v == 2 || v == 4; }
  Dama() { for (int x = 0; x < 8; x++) { b[8 + x] = b[16 + x] = 3; b[40 + x] = b[48 + x] = 1; } msg = "Taşlar ileri ve yana gider. Alma zorunlu!"; cur = 52; }
  int kind() const override { return MG_DAMA; }
  void capDfs(std::array<int, 64> bd, int at, int s, bool kg, Mv m, std::vector<Mv>& out) {
    static const int DX[4] = { 0, 0, -1, 1 }, DY[4] = { -1, 1, 0, 0 };
    bool more = false; int x = at % 8, y = at / 8;
    for (int d = 0; d < 4; d++) {
      if (!kg && DY[d] == (s == 0 ? 1 : -1)) continue;   // taş geri alamaz
      if (!kg) {
        int nx = x + DX[d], ny = y + DY[d], mx = x + 2 * DX[d], my = y + 2 * DY[d];
        if (mx < 0 || my < 0 || mx > 7 || my > 7) continue;
        int n = ny * 8 + nx, t = my * 8 + mx;
        if (side(bd[n]) == 1 - s && bd[t] == 0) { auto b2 = bd; b2[n] = 0; b2[t] = b2[at]; b2[at] = 0; Mv m2 = m; m2.path.push_back(t); m2.cap.push_back(n); more = true; capDfs(b2, t, s, false, m2, out); }
      } else {
        int cx = x + DX[d], cy = y + DY[d];
        while (cx >= 0 && cy >= 0 && cx < 8 && cy < 8 && bd[cy * 8 + cx] == 0) { cx += DX[d]; cy += DY[d]; }
        if (cx < 0 || cy < 0 || cx > 7 || cy > 7 || side(bd[cy * 8 + cx]) != 1 - s) continue;
        int n = cy * 8 + cx, lx = cx + DX[d], ly = cy + DY[d];
        while (lx >= 0 && ly >= 0 && lx < 8 && ly < 8 && bd[ly * 8 + lx] == 0) {
          int t = ly * 8 + lx; auto b2 = bd; b2[n] = 0; b2[t] = b2[at]; b2[at] = 0; Mv m2 = m; m2.path.push_back(t); m2.cap.push_back(n); more = true; capDfs(b2, t, s, true, m2, out);
          lx += DX[d]; ly += DY[d];
        }
      }
    }
    if (!more && m.cap.size()) out.push_back(m);
  }
  std::vector<Mv> moves(const int* bd0, int s) {
    std::array<int, 64> bd; for (int i = 0; i < 64; i++) bd[i] = bd0[i];
    std::vector<Mv> caps, simple;
    for (int i = 0; i < 64; i++) if (side(bd[i]) == s) { Mv m; m.path.push_back(i); capDfs(bd, i, s, king(bd[i]), m, caps); }
    if (caps.size()) {
      size_t best = 0; for (auto& m : caps) best = std::max(best, m.cap.size());
      std::vector<Mv> r; for (auto& m : caps) if (m.cap.size() == best) r.push_back(m);
      return r;
    }
    static const int DX[4] = { 0, 0, -1, 1 }, DY[4] = { -1, 1, 0, 0 };
    for (int i = 0; i < 64; i++) if (side(bd[i]) == s) {
      int x = i % 8, y = i / 8; bool kg = king(bd[i]);
      for (int d = 0; d < 4; d++) {
        if (!kg && DY[d] == (s == 0 ? 1 : -1)) continue;
        int cx = x + DX[d], cy = y + DY[d];
        while (cx >= 0 && cy >= 0 && cx < 8 && cy < 8 && bd[cy * 8 + cx] == 0) { simple.push_back({ { i, cy * 8 + cx }, {} }); if (!kg) break; cx += DX[d]; cy += DY[d]; }
      }
    }
    return simple;
  }
  static void apply(int* bd, const Mv& m) {
    int v = bd[m.path.front()]; bd[m.path.front()] = 0;
    for (int c : m.cap) bd[c] = 0;
    int t = m.path.back(); bd[t] = v;
    if (v == 1 && t < 8) bd[t] = 2; if (v == 3 && t >= 56) bd[t] = 4;
  }
  static int eval(const int* bd, int s) {
    int e = 0;
    for (int i = 0; i < 64; i++) { int v = bd[i]; if (!v) continue; int sc = king(v) ? 32 : 10 + (side(v) == 0 ? (7 - i / 8) : i / 8); e += side(v) == s ? sc : -sc; }
    return e;
  }
  int search(int* bd, int s, int depth, int a, int bt) {
    auto mv = moves(bd, s);
    if (mv.empty()) return -10000;
    if (!depth) return eval(bd, s);
    for (auto& m : mv) { int b2[64]; memcpy(b2, bd, sizeof b2); apply(b2, m); int v = -search(b2, 1 - s, depth - 1, -bt, -a); if (v > a) a = v; if (a >= bt) break; }
    return a;
  }
  void after(Game& g) {
    ply++; turn = 1 - turn; sel = -1;
    if (moves(b, turn).empty()) winner = 1 - turn;
    else if (ply > 240) winner = 99;
    else msg = moves(b, turn)[0].cap.size() ? "Alma zorunlu!" : "";
    g.sfx(SFX_CLICK);
  }
  void ai(Game& g) override {
    auto mv = moves(b, turn); if (mv.empty()) return;
    int best = -100000; std::vector<int> idx;
    for (size_t i = 0; i < mv.size(); i++) { int b2[64]; memcpy(b2, b, sizeof b2); apply(b2, mv[i]); int v = -search(b2, 1 - turn, 2, -100000, 100000); if (v > best) { best = v; idx.clear(); } if (v == best) idx.push_back((int)i); }
    apply(b, mv[idx[(int)(g.rnd() * idx.size()) % idx.size()]]); after(g);
  }
  void key(Game& g, int k) override {
    if (k < 4) { int x = cur % 8 + (k == 0 ? -1 : k == 1 ? 1 : 0), y = cur / 8 + (k == 2 ? -1 : k == 3 ? 1 : 0); cur = std::max(0, std::min(7, y)) * 8 + std::max(0, std::min(7, x)); return; }
    if (k == 5) { sel = -1; return; }
    auto mv = moves(b, turn);
    if (sel >= 0) for (auto& m : mv) if (m.path.front() == sel && m.path.back() == cur) { apply(b, m); after(g); return; }
    bool can = false; for (auto& m : mv) if (m.path.front() == cur) can = true;
    if (can) sel = cur; else if (sel >= 0) msg = "Oraya gidemez."; else if (side(b[cur]) == turn) msg = mv.size() && mv[0].cap.size() ? "Alma zorunlu! Başka bir taşla al." : "Bu taş oynayamaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cs = 19, bx = std::floor((g.VW - cs * 8) / 2), by = 14;
    for (int i = 0; i < 64; i++) {
      double x = bx + (i % 8) * cs, y = by + (i / 8) * cs;
      g.rectV(x, y, cs, cs, ((i % 8 + i / 8) & 1) ? H(0xb88850) : H(0xe8cc90));
      if (b[i]) { sprV(g, g.A.disc[side(b[i]) == 0 ? 0 : 1], x + 2, y + 2, 1.5); if (king(b[i])) { g.rectV(x + 7, y + 7, 5, 5, H(0xf8d848)); } }
      g.hit(x, y, cs, cs, [&g, tb = tbl, i] { g.mgTap(tb, i); });
    }
    if (winner < 0) {
      auto mv = moves(b, turn);
      if (sel >= 0) for (auto& m : mv) if (m.path.front() == sel) { int t = m.path.back(); g.rectV(bx + (t % 8) * cs + 7, by + (t / 8) * cs + 7, 5, 5, H(0x60e070, 0.9)); }
      if (sel >= 0) frame(g, bx + (sel % 8) * cs, by + (sel / 8) * cs, cs, cs, H(0x60e070));
      if (human[turn]) frame(g, bx + (cur % 8) * cs + 1, by + (cur / 8) * cs + 1, cs - 2, cs - 2, H(0xf8d848));
    }
    sideInfo(g, *this, 4, bx - 8, "DAMA");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : b) w.u8(v); w.i32(ply); }
  void load(RBuf& r) override { loadBase(r); for (int& v : b) v = r.u8(); ply = r.i32(); }
};

// ======================================================================= SATRANÇ
struct Satranc : MiniGame {
  struct Pos { int b[64]; int castle, ep; };
  struct Mv { int f, t, promo; };
  Pos p; int ply = 0, lastF = -1, lastT = -1;
  // taş = tip (1 piyon 2 at 3 fil 4 kale 5 vezir 6 şah) + 8 * renk (0 beyaz/aşağıda, 1 siyah)
  Satranc() {
    static const int R[8] = { 4, 2, 3, 5, 6, 3, 2, 4 };
    memset(p.b, 0, sizeof p.b);
    for (int x = 0; x < 8; x++) { p.b[x] = R[x] + 8; p.b[8 + x] = 1 + 8; p.b[48 + x] = 1; p.b[56 + x] = R[x]; }
    p.castle = 15; p.ep = -1; cur = 52; msg = "Beyazlar başlar.";
  }
  int kind() const override { return MG_SATRANC; }
  static int col(int v) { return v ? v >> 3 : -1; }
  static int typ(int v) { return v & 7; }
  static bool attacked(const Pos& q, int sq, int by) {
    int x = sq % 8, y = sq / 8;
    int pd = by == 0 ? 1 : -1;   // beyaz piyon aşağıdan saldırır
    for (int dx = -1; dx <= 1; dx += 2) { int px = x + dx, py = y + pd; if (px >= 0 && px < 8 && py >= 0 && py < 8 && q.b[py * 8 + px] == 1 + by * 8) return true; }
    static const int KN[8][2] = { {1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1} };
    for (auto& k : KN) { int nx = x + k[0], ny = y + k[1]; if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && q.b[ny * 8 + nx] == 2 + by * 8) return true; }
    for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) { if (!dx && !dy) continue; int nx = x + dx, ny = y + dy; if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8 && q.b[ny * 8 + nx] == 6 + by * 8) return true; }
    static const int D[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
    for (int d = 0; d < 8; d++) {
      int nx = x + D[d][0], ny = y + D[d][1];
      while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        int v = q.b[ny * 8 + nx];
        if (v) { if (col(v) == by) { int t = typ(v); if (t == 5 || (d < 4 && t == 4) || (d >= 4 && t == 3)) return true; } break; }
        nx += D[d][0]; ny += D[d][1];
      }
    }
    return false;
  }
  static int kingSq(const Pos& q, int c) { for (int i = 0; i < 64; i++) if (q.b[i] == 6 + c * 8) return i; return -1; }
  static void doMove(Pos& q, const Mv& m) {
    int v = q.b[m.f], c = col(v), t = typ(v);
    if (t == 1 && m.t == q.ep) q.b[m.t + (c == 0 ? 8 : -8)] = 0;   // geçerken alma
    if (t == 6 && std::abs(m.t - m.f) == 2) { if (m.t > m.f) { q.b[m.f + 1] = q.b[m.f + 3]; q.b[m.f + 3] = 0; } else { q.b[m.f - 1] = q.b[m.f - 4]; q.b[m.f - 4] = 0; } }
    q.b[m.t] = v; q.b[m.f] = 0;
    if (m.promo) q.b[m.t] = m.promo + c * 8;
    q.ep = (t == 1 && std::abs(m.t - m.f) == 16) ? (m.f + m.t) / 2 : -1;
    if (t == 6) q.castle &= c == 0 ? ~3 : ~12;
    for (int s : { m.f, m.t }) { if (s == 63) q.castle &= ~1; if (s == 56) q.castle &= ~2; if (s == 7) q.castle &= ~4; if (s == 0) q.castle &= ~8; }
  }
  static void gen(const Pos& q, int c, std::vector<Mv>& out) {
    out.clear();
    for (int i = 0; i < 64; i++) {
      int v = q.b[i]; if (col(v) != c) continue;
      int x = i % 8, y = i / 8, t = typ(v);
      auto add = [&](int to) { int ty = to / 8; if (t == 1 && (ty == 0 || ty == 7)) out.push_back({ i, to, 5 }); else out.push_back({ i, to, 0 }); };
      if (t == 1) {
        int d = c == 0 ? -1 : 1, ny = y + d;
        if (ny >= 0 && ny < 8 && !q.b[ny * 8 + x]) { add(ny * 8 + x); int sy = c == 0 ? 6 : 1; if (y == sy && !q.b[(y + 2 * d) * 8 + x]) add((y + 2 * d) * 8 + x); }
        for (int dx = -1; dx <= 1; dx += 2) { int nx = x + dx; if (nx < 0 || nx > 7 || ny < 0 || ny > 7) continue; int to = ny * 8 + nx; if ((q.b[to] && col(q.b[to]) != c) || to == q.ep) add(to); }
      } else if (t == 2 || t == 6) {
        static const int KN[8][2] = { {1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1} }, KG[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
        for (auto& k : (t == 2 ? KN : KG)) { int nx = x + k[0], ny = y + k[1]; if (nx < 0 || nx > 7 || ny < 0 || ny > 7) continue; int to = ny * 8 + nx; if (!q.b[to] || col(q.b[to]) != c) add(to); }
        if (t == 6) {
          int base = c == 0 ? 60 : 4, ks = c == 0 ? 1 : 4, qs = c == 0 ? 2 : 8;
          if (i == base && !attacked(q, i, 1 - c)) {
            if ((q.castle & ks) && !q.b[i + 1] && !q.b[i + 2] && !attacked(q, i + 1, 1 - c) && !attacked(q, i + 2, 1 - c)) add(i + 2);
            if ((q.castle & qs) && !q.b[i - 1] && !q.b[i - 2] && !q.b[i - 3] && !attacked(q, i - 1, 1 - c) && !attacked(q, i - 2, 1 - c)) add(i - 2);
          }
        }
      } else {
        static const int D[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
        for (int d = (t == 3 ? 4 : 0); d < (t == 4 ? 4 : 8); d++) {
          int nx = x + D[d][0], ny = y + D[d][1];
          while (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) { int to = ny * 8 + nx; if (q.b[to]) { if (col(q.b[to]) != c) add(to); break; } add(to); nx += D[d][0]; ny += D[d][1]; }
        }
      }
    }
  }
  static void legal(const Pos& q, int c, std::vector<Mv>& out) {
    std::vector<Mv> ps; gen(q, c, ps); out.clear();
    for (auto& m : ps) { Pos q2 = q; doMove(q2, m); if (!attacked(q2, kingSq(q2, c), 1 - c)) out.push_back(m); }
  }
  static int eval(const Pos& q, int c) {
    static const int V[7] = { 0, 100, 310, 330, 500, 900, 0 };
    int e = 0;
    for (int i = 0; i < 64; i++) {
      int v = q.b[i]; if (!v) continue; int t = typ(v), x = i % 8, y = i / 8;
      int s = V[t];
      if (t == 1) s += (col(v) == 0 ? 6 - y : y - 1) * 6 + ((x == 3 || x == 4) ? 6 : 0);
      if (t == 2 || t == 3) s += 12 - (std::abs(2 * x - 7) + std::abs(2 * y - 7));
      e += col(v) == c ? s : -s;
    }
    return e;
  }
  int search(const Pos& q, int c, int depth, int a, int bt) {
    std::vector<Mv> mv; legal(q, c, mv);
    if (mv.empty()) return attacked(q, kingSq(q, c), 1 - c) ? -50000 - depth : 0;
    if (!depth) return eval(q, c);
    std::stable_sort(mv.begin(), mv.end(), [&](const Mv& x, const Mv& y) { return q.b[x.t] > q.b[y.t]; });
    for (auto& m : mv) { Pos q2 = q; doMove(q2, m); int v = -search(q2, 1 - c, depth - 1, -bt, -a); if (v > a) a = v; if (a >= bt) break; }
    return a;
  }
  void after(Game& g, const Mv& m) {
    lastF = m.f; lastT = m.t; ply++; turn = 1 - turn; sel = -1; g.sfx(SFX_CLICK);
    std::vector<Mv> mv; legal(p, turn, mv);
    bool chk = attacked(p, kingSq(p, turn), 1 - turn);
    if (mv.empty()) { winner = chk ? 1 - turn : 99; msg = chk ? "Şah mat!" : "Pat: hamle yok."; }
    else if (ply > 300) winner = 99;
    else msg = chk ? "Şah!" : "";
  }
  void ai(Game& g) override {
    std::vector<Mv> mv; legal(p, turn, mv); if (mv.empty()) return;
    int best = -1000000; std::vector<int> idx;
    for (size_t i = 0; i < mv.size(); i++) { Pos q2 = p; doMove(q2, mv[i]); int v = -search(q2, 1 - turn, 2, -1000000, 1000000) + (int)(g.rnd() * 8); if (v > best) { best = v; idx.clear(); } if (v == best) idx.push_back((int)i); }
    Mv m = mv[idx[0]]; doMove(p, m); after(g, m);
  }
  void key(Game& g, int k) override {
    if (k < 4) { int x = cur % 8 + (k == 0 ? -1 : k == 1 ? 1 : 0), y = cur / 8 + (k == 2 ? -1 : k == 3 ? 1 : 0); cur = std::max(0, std::min(7, y)) * 8 + std::max(0, std::min(7, x)); return; }
    if (k == 5) { sel = -1; return; }
    std::vector<Mv> mv; legal(p, turn, mv);
    if (sel >= 0) for (auto& m : mv) if (m.f == sel && m.t == cur) { doMove(p, m); after(g, m); return; }
    bool can = false; for (auto& m : mv) if (m.f == cur) can = true;
    if (can) sel = cur; else if (sel >= 0) msg = "Bu hamle olmaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cs = 19, bx = std::floor((g.VW - cs * 8) / 2), by = 14;
    std::vector<Mv> mv; if (winner < 0) legal(p, turn, mv);
    for (int i = 0; i < 64; i++) {
      double x = bx + (i % 8) * cs, y = by + (i / 8) * cs;
      Col c = ((i % 8 + i / 8) & 1) ? H(0x7a9a58) : H(0xe8e0c0);
      if (i == lastF || i == lastT) c = ((i % 8 + i / 8) & 1) ? H(0xa8a848) : H(0xf0e890);
      g.rectV(x, y, cs, cs, c);
      int v = p.b[i]; if (v) sprV(g, g.A.chess[(typ(v) - 1) + col(v) * 6], x + 3, y + 1, 2);
      g.hit(x, y, cs, cs, [&g, tb = tbl, i] { g.mgTap(tb, i); });
    }
    if (winner < 0) {
      if (sel >= 0) { frame(g, bx + (sel % 8) * cs, by + (sel / 8) * cs, cs, cs, H(0x60e070)); for (auto& m : mv) if (m.f == sel) g.rectV(bx + (m.t % 8) * cs + 7, by + (m.t / 8) * cs + 7, 5, 5, H(0x40c050, 0.85)); }
      if (human[turn]) frame(g, bx + (cur % 8) * cs + 1, by + (cur / 8) * cs + 1, cs - 2, cs - 2, H(0xf8d848));
    }
    sideInfo(g, *this, 4, bx - 8, "SATRANÇ");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : p.b) w.u8(v); w.u8(p.castle); w.i32(p.ep); w.i32(ply); w.i32(lastF); w.i32(lastT); }
  void load(RBuf& r) override { loadBase(r); for (int& v : p.b) v = r.u8(); p.castle = r.u8(); p.ep = r.i32(); ply = r.i32(); lastF = r.i32(); lastT = r.i32(); }
};

// ======================================================================= TAVLA
// 0. oyuncu (beyaz) 23'ten 0'a gider, evi 0-5; 1. oyuncu (siyah) 0'dan 23'e, evi 18-23. Çift zar dört hamle; olabildiğince çok zar oynanır.
struct Tavla : MiniGame {
  struct St { int pt[24]; int bar[2], off[2]; };
  struct Mv { int f, t, d; };   // f: -1 kırık (bar); t: -2 toplandı
  St s; std::vector<int> dice; bool rolled = false; int d0 = 0, d1 = 0; double passT = 0;
  Tavla() {
    memset(&s, 0, sizeof s);
    s.pt[23] = 2; s.pt[12] = 5; s.pt[7] = 3; s.pt[5] = 5;
    s.pt[0] = -2; s.pt[11] = -5; s.pt[16] = -3; s.pt[18] = -5;
    cur = 26; sel = -9; msg = "Zar at!";
  }
  int kind() const override { return MG_TAVLA; }
  static int own(const St& q, int i, int p) { return p == 0 ? std::max(0, q.pt[i]) : std::max(0, -q.pt[i]); }
  static int opp(const St& q, int i, int p) { return own(q, i, 1 - p); }
  static bool home(const St& q, int p) {
    if (q.bar[p]) return false;
    for (int i = 0; i < 24; i++) if (own(q, i, p) && (p == 0 ? i > 5 : i < 18)) return false;
    return true;
  }
  static int target(const St& q, int p, int f, int d) {
    if (q.bar[p] && f != -1) return -9;
    if (f == -1) { if (!q.bar[p]) return -9; int t = p == 0 ? 24 - d : d - 1; return opp(q, t, p) >= 2 ? -9 : t; }
    if (!own(q, f, p)) return -9;
    int t = p == 0 ? f - d : f + d;
    if (t >= 0 && t < 24) return opp(q, t, p) >= 2 ? -9 : t;
    if (!home(q, p)) return -9;
    int dist = p == 0 ? f + 1 : 24 - f;
    if (dist == d) return -2;
    // büyük zarla toplama: daha geride taş yoksa
    for (int i = 0; i < 24; i++) if (own(q, i, p) && (p == 0 ? i > f : i < f)) return -9;
    return -2;
  }
  static void apply(St& q, int p, const Mv& m) {
    int sg = p == 0 ? 1 : -1;
    if (m.f == -1) q.bar[p]--; else q.pt[m.f] -= sg;
    if (m.t == -2) { q.off[p]++; return; }
    if (opp(q, m.t, p) == 1) { q.pt[m.t] = 0; q.bar[1 - p]++; }
    q.pt[m.t] += sg;
  }
  static void seqs(const St& q, int p, std::vector<int> ds, std::vector<Mv>& cur, std::vector<std::vector<Mv>>& out, int& budget) {
    if (--budget < 0) return;
    bool any = false; std::vector<int> tried;
    for (size_t k = 0; k < ds.size(); k++) {
      int d = ds[k]; if (std::find(tried.begin(), tried.end(), d) != tried.end()) continue; tried.push_back(d);
      for (int f = -1; f < 24; f++) {
        int t = target(q, p, f, d); if (t == -9) continue;
        any = true; St q2 = q; Mv m{ f, t, d }; apply(q2, p, m);
        auto ds2 = ds; ds2.erase(ds2.begin() + k); cur.push_back(m);
        seqs(q2, p, ds2, cur, out, budget); cur.pop_back();
      }
    }
    if (!any) out.push_back(cur);
  }
  std::vector<std::vector<Mv>> legalSeqs(const St& q, int p, const std::vector<int>& ds) {
    std::vector<std::vector<Mv>> all; std::vector<Mv> c; int budget = 60000; seqs(q, p, ds, c, all, budget);
    size_t mx = 0; for (auto& a : all) mx = std::max(mx, a.size());
    std::vector<std::vector<Mv>> r; for (auto& a : all) if (a.size() == mx) r.push_back(a);
    if (mx == 1 && ds.size() == 2 && ds[0] != ds[1]) {
      int big = std::max(ds[0], ds[1]); std::vector<std::vector<Mv>> r2; for (auto& a : r) if (a[0].d == big) r2.push_back(a);
      if (r2.size()) r = r2;
    }
    if (mx == 0) r.clear();
    return r;
  }
  static int pip(const St& q, int p) { int n = q.bar[p] * 25; for (int i = 0; i < 24; i++) n += own(q, i, p) * (p == 0 ? i + 1 : 24 - i); return n; }
  static int evalSt(const St& q, int p) {
    int e = (pip(q, 1 - p) - pip(q, p)) * 2 + q.off[p] * 12 + q.bar[1 - p] * 14;
    for (int i = 0; i < 24; i++) {
      int n = own(q, i, p);
      if (n >= 2) e += (p == 0 ? i <= 5 : i >= 18) ? 7 : 3;
      if (n == 1) {   // açık taş: arkasında rakip var mı
        bool risk = false;
        for (int j = 0; j < 24; j++) if (own(q, j, 1 - p)) { int dd = p == 0 ? i - j : j - i; if (dd > 0 && dd <= 12) risk = true; }
        if (q.bar[1 - p]) risk = true;
        if (risk) e -= 9;
      }
    }
    return e;
  }
  void roll(Game& g) {
    d0 = 1 + (int)(g.rnd() * 6) % 6; d1 = 1 + (int)(g.rnd() * 6) % 6; rolled = true;
    dice = d0 == d1 ? std::vector<int>{ d0, d0, d0, d0 } : std::vector<int>{ d0, d1 };
    g.sfx(SFX_CLICK);
    if (legalSeqs(s, turn, dice).empty()) { msg = fmt("%d-%d: oynayacak hamle yok.", d0, d1); passT = 1.4; }
    else msg = fmt("Zar: %d-%d", d0, d1);
  }
  void endTurn(Game& g) {
    if (s.off[turn] >= 15) { winner = turn; return; }
    turn = 1 - turn; rolled = false; dice.clear(); sel = -9; cur = 26; msg = "Zar at!"; g.sfx(SFX_SELECT);
  }
  void tick(Game& g, double dt) override { if (passT > 0) { passT -= dt; if (passT <= 0) endTurn(g); } }
  // tek hamle: sıradaki oyuncu f'den t'ye (uygun zarla)
  bool single(Game& g, int f, int t) {
    auto L = legalSeqs(s, turn, dice);
    for (auto& sq : L) if (sq[0].f == f && sq[0].t == t) {
      apply(s, turn, sq[0]); dice.erase(std::find(dice.begin(), dice.end(), sq[0].d)); sel = -9; g.sfx(SFX_CLICK);
      if (s.off[turn] >= 15) { winner = turn; return true; }
      if (dice.empty() || legalSeqs(s, turn, dice).empty()) endTurn(g);
      return true;
    }
    return false;
  }
  void ai(Game& g) override {
    if (passT > 0) return;
    if (!rolled) { roll(g); return; }
    auto L = legalSeqs(s, turn, dice); if (L.empty()) { endTurn(g); return; }
    int best = -1000000; size_t bi = 0;
    for (size_t i = 0; i < L.size(); i++) { St q = s; for (auto& m : L[i]) apply(q, turn, m); int v = evalSt(q, turn); if (v > best) { best = v; bi = i; } }
    for (auto& m : L[bi]) apply(s, turn, m);
    dice.clear(); endTurn(g);
  }
  // imleç sırası: alt sıra soldan sağa (11..0), kırık, toplanan; üst sıra (12..23), zar düğmesi
  static int vis(int i, int& row) { if (i < 12) { row = 1; return 11 - i; } if (i < 24) { row = 0; return i - 12; } row = 2; return i == 24 ? 0 : i == 25 ? 1 : 2; }
  void key(Game& g, int k) override {
    if (passT > 0) return;
    if (k == 0 || k == 1) {
      static const int ORD[27] = { 12,13,14,15,16,17,18,19,20,21,22,23, 11,10,9,8,7,6,5,4,3,2,1,0, 24, 25, 26 };
      int at = 0; for (int i = 0; i < 27; i++) if (ORD[i] == cur) at = i;
      at = (at + (k == 0 ? -1 : 1) + 27) % 27; cur = ORD[at]; return;
    }
    if (k == 2 || k == 3) { if (cur < 12) cur = 23 - cur; else if (cur < 24) cur = 23 - cur; else cur = k == 2 ? 23 : 0; return; }
    if (k == 5) { sel = -9; return; }
    if (!rolled) { roll(g); return; }
    if (cur == 26) return;
    int c = cur == 24 ? -1 : cur == 25 ? -2 : cur;
    if (sel != -9 && c != sel && single(g, sel, c)) return;
    auto L = legalSeqs(s, turn, dice); bool can = false; for (auto& sq : L) if (sq[0].f == c) can = true;
    if (can) sel = c; else msg = "Oradan oynanmaz.";
  }
  void tap(Game& g, int c) override { cur = c; key(g, 4); }
  void draw(Game& g, int) override {
    double cw = 14, bx = std::floor((g.VW - cw * 14) / 2) + 20, by = 12, bh = 150, ph = 62;
    g.rectV(bx - 4, by - 2, cw * 13 + 8 + 20, bh + 4, H(0x5a3a1e));
    g.rectV(bx, by, cw * 13, bh, H(0xd8b880));
    auto colX = [&](int c) { return bx + (c < 6 ? c : c + 1) * cw; };
    auto ptX = [&](int i) { int row; int c = vis(i, row); return colX(c); };
    g.rectV(bx + 6 * cw, by, cw, bh, H(0x7a5030));   // kırık bölmesi
    std::vector<std::vector<Mv>> L; if (winner < 0 && rolled && passT <= 0) L = legalSeqs(s, turn, dice);
    for (int i = 0; i < 24; i++) {
      int row; vis(i, row); double x = ptX(i);
      Col pc = (i & 1) ? H(0x8a3a2a) : H(0x3a5a3a);
      for (int k = 0; k < 10; k++) { double w = cw * (1 - k / 10.0); double yy = row == 0 ? by + k * (ph / 10) : by + bh - (k + 1) * (ph / 10); g.rectV(x + (cw - w) / 2, yy, w, ph / 10 + 0.5, pc); }
      int n = std::abs(s.pt[i]); int who = s.pt[i] > 0 ? 0 : 1;
      for (int k = 0; k < std::min(n, 5); k++) { double yy = row == 0 ? by + 1 + k * 12 : by + bh - 13 - k * 12; sprV(g, g.A.disc[who == 0 ? 0 : 1], x + 1, yy, 1.2); }
      if (n > 5) g.text(fmt("%d", n), x + cw / 2, row == 0 ? by + 62 : by + bh - 72, 0.26, H(0xffffff), 1, true);
      g.hit(x, row == 0 ? by : by + bh - ph, cw, ph, [&g, tb = tbl, i] { g.mgTap(tb, i); });
      bool tgt = false; for (auto& sq : L) if (sel != -9 && sq[0].f == sel && sq[0].t == i) tgt = true;
      if (tgt) g.rectV(x + 4, row == 0 ? by + ph + 2 : by + bh - ph - 7, 6, 5, H(0x40e050));
    }
    for (int p = 0; p < 2; p++) for (int k = 0; k < s.bar[p]; k++) sprV(g, g.A.disc[p], bx + 6 * cw + 1, p == 0 ? by + bh / 2 + 4 + k * 8 : by + bh / 2 - 16 - k * 8, 1.2);
    g.hit(bx + 6 * cw, by + ph, cw, bh - 2 * ph, [&g, tb = tbl] { g.mgTap(tb, 24); });
    // toplananlar
    double ox = bx + cw * 13 + 4;
    g.rectV(ox, by, 16, bh, H(0x4a2e18));
    g.text(fmt("%d", s.off[1]), ox + 8, by + 4, 0.26, H(0xffffff), 1, true); g.text(fmt("%d", s.off[0]), ox + 8, by + bh - 12, 0.26, H(0xffffff), 1, true);
    g.hit(ox, by, 16, bh, [&g, tb = tbl] { g.mgTap(tb, 25); });
    bool tgtOff = false; for (auto& sq : L) if (sel != -9 && sq[0].f == sel && sq[0].t == -2) tgtOff = true;
    if (tgtOff) g.rectV(ox + 5, by + bh / 2 - 3, 6, 6, H(0x40e050));
    // zarlar
    double dx = bx + 2 * cw, dy = by + bh / 2 - 7;
    if (rolled) for (int k = 0; k < 2; k++) { g.rectV(dx + k * 18, dy, 14, 14, H(0xfaf6ea)); frame(g, dx + k * 18, dy, 14, 14, H(0x302020)); g.text(fmt("%d", k ? d1 : d0), dx + k * 18 + 7, dy + 2.5, 0.32, H(0x201010), 1, true); }
    else if (winner < 0) { g.rectV(dx, dy, 44, 14, H(0x3a6ad0)); g.text("ZAR AT", dx + 22, dy + 3, 0.26, H(0xffffff), 1, true); g.hit(dx, dy, 44, 14, [&g, tb = tbl] { g.mgTap(tb, 26); }); }
    if (rolled && dice.size()) { string ds; for (int d : dice) ds += fmt("%d ", d); g.text(ds, bx + 9.5 * cw, dy + 2, 0.26, H(0x302010), 1, true); }
    // imleç
    if (winner < 0 && human[turn]) {
      double x, y, w = cw, h = ph;
      if (cur < 24) { int row; vis(cur, row); x = ptX(cur); y = row == 0 ? by : by + bh - ph; }
      else if (cur == 24) { x = bx + 6 * cw; y = by + ph; h = bh - 2 * ph; }
      else if (cur == 25) { x = ox; y = by; w = 16; h = bh; }
      else { x = dx; y = dy; w = 44; h = 14; }
      frame(g, x, y, w, h, H(0xf8d848));
      if (sel >= 0 && rolled) { int row; vis(sel, row); frame(g, ptX(sel) + 1, row == 0 ? by + 1 : by + bh - ph + 1, cw - 2, ph - 2, H(0x60e070)); }
    }
    sideInfo(g, *this, 2, bx - 26, "TAVLA");
  }
  void save(WBuf& w) override { saveBase(w); for (int v : s.pt) w.i32(v); for (int i = 0; i < 2; i++) { w.u8(s.bar[i]); w.u8(s.off[i]); } w.u8(rolled); w.u8(d0); w.u8(d1); w.u8((int)dice.size()); for (int d : dice) w.u8(d); }
  void load(RBuf& r) override { loadBase(r); for (int& v : s.pt) v = r.i32(); for (int i = 0; i < 2; i++) { s.bar[i] = r.u8(); s.off[i] = r.u8(); } rolled = r.u8() != 0; d0 = r.u8(); d1 = r.u8(); int n = r.u8(); dice.clear(); for (int i = 0; i < n; i++) dice.push_back(r.u8()); }
};

// ======================================================================= PAPAZ KİMDE
// 2-4 kişi. 3 papaz (kral) çıkarılır; aynı sayıdaki iki kart atılır. Sırası gelen, kartı olan bir sonraki oyuncudan kart çeker.
// Elini bitiren kalkar; son papazı elinde tutan kaybeder.
struct Papaz : MiniGame {
  std::vector<int> hand[4]; int lastA = -1, lastB = -1, loser = -1;   // kart = renk * 16 + sayı (1-13)
  int kind() const override { return MG_PAPAZ; }
  void deal(Game& g) {
    std::vector<int> deck; for (int c = 0; c < 4; c++) for (int n = 1; n <= 13; n++) if (n != 13 || c == 0) deck.push_back(c * 16 + n);
    for (int i = (int)deck.size() - 1; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(deck[i], deck[j]); }
    for (size_t i = 0; i < deck.size(); i++) hand[i % np].push_back(deck[i]);
    for (int p = 0; p < np; p++) prune(p);
    turn = 0; skipOut(); msg = "Sağındakinin kapalı kartlarından birini seç."; cur = 0;
  }
  void prune(int p) {
    auto& h = hand[p];
    for (size_t i = 0; i < h.size(); i++) for (size_t j = i + 1; j < h.size(); j++) if (h[i] % 16 == h[j] % 16) { h.erase(h.begin() + j); h.erase(h.begin() + i); i = (size_t)-1; break; }
  }
  int active() const { int n = 0; for (int p = 0; p < np; p++) if (hand[p].size()) n++; return n; }
  int src() const { for (int k = 1; k < np; k++) { int p = (turn + k) % np; if (hand[p].size()) return p; } return turn; }
  void skipOut() { for (int k = 0; k < np && hand[turn].empty(); k++) turn = (turn + 1) % np; }
  void finish() {
    for (int p = 0; p < np; p++) if (hand[p].size()) loser = p;
    // kazanan: Arda kaybetmediyse onun yeri (sonucu Arda'nın gözünden vermek için), değilse ilk kalkan
    winner = -1; for (int p = 0; p < np; p++) if (p != loser && who[p] == 0) winner = p;
    if (winner < 0) winner = loser == 0 ? 1 : 0;
    msg = "Papaz kimde? Papaz onda!";
  }
  void take(Game& g, int idx) {
    int sp = src(); auto& o = hand[sp]; if (o.empty() || sp == turn) return;
    idx = std::max(0, std::min((int)o.size() - 1, idx));
    int c = o[idx]; o.erase(o.begin() + idx);
    auto& h = hand[turn]; bool pair = false;
    for (size_t i = 0; i < h.size(); i++) if (h[i] % 16 == c % 16) { lastA = h[i]; lastB = c; h.erase(h.begin() + i); pair = true; break; }
    if (!pair) { h.push_back(c); for (int i = (int)h.size() - 1; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(h[i], h[j]); } }
    msg = pair ? "Çift! İkisi de atıldı." : (c % 16 == 13 ? "Papaz geldi..." : "Çift olmadı.");
    g.sfx(SFX_CLICK);
    if (active() <= 1) { finish(); return; }
    turn = (turn + 1) % np; skipOut(); cur = 0;
    int s2 = src(); std::shuffle(hand[s2].begin(), hand[s2].end(), std::minstd_rand((unsigned)(g.rnd() * 99999)));
  }
  void ai(Game& g) override { take(g, (int)(g.rnd() * hand[src()].size())); }
  void key(Game& g, int k) override {
    int n = (int)hand[src()].size();
    if (k == 0) cur = (cur + n - 1) % std::max(1, n); else if (k == 1) cur = (cur + 1) % std::max(1, n); else if (k == 4) take(g, cur);
  }
  void tap(Game& g, int c) override { cur = c; take(g, c); }
  static string rankName(Game& g, int n) { static const char* TR[14] = { "", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "V", "K", "P" }, *EN[14] = { "", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" }; return (g.lang ? EN : TR)[n]; }
  static void card(Game& g, double x, double y, int c, bool open, double w = 18, double h = 26) {
    g.rectV(x, y, w, h, open ? H(0xfaf8f0) : H(0x2a4a9a)); frame(g, x, y, w, h, H(0x202030));
    if (!open) { g.rectV(x + 3, y + 3, w - 6, h - 6, H(0x3a62c0)); return; }
    bool red = (c / 16) & 1; Col k = red ? H(0xd02828) : H(0x202020);
    g.text(rankName(g, c % 16), x + w / 2, y + 3, 0.3, k, 1, true);
    static const char* PIP[4] = { "01110111111111100100", "01010111111111001110", "00100011101111100100", "00100011100111000100" };   // maça kupa sinek karo (5x4)
    const char* pp = PIP[c / 16];
    for (int i = 0; i < 20; i++) if (pp[i] == '1') g.rectV(x + w / 2 - 2.5 + (i % 5), y + 14 + i / 5, 1, 1, k);
  }
  void draw(Game& g, int viewer) override {
    int me = viewer, sp = src();
    // ötekiler üstte: her biri kendi kapalı kart sırası
    int others = np - 1; double colW = (g.VW - 8) / std::max(1, others);
    for (int k = 1; k < np; k++) {
      int p = (me + k) % np; double x0 = 4 + (k - 1) * colW, cw = std::min(16.0, (colW - 8) / std::max(1, (int)hand[p].size()));
      bool isSrc = p == sp && winner < 0;
      g.rectV(x0, 6, colW - 4, 46, isSrc ? H(0x2a5a3a, 0.6) : H(0x101018, 0.4));
      g.text(fmt("%s (%d)", g.tr(names[p]).c_str(), (int)hand[p].size()), x0 + colW / 2 - 2, 8, 0.24, turn == p && winner < 0 ? H(0xb8ffb8) : H(0xd0d0e0), 1);
      for (int i = 0; i < (int)hand[p].size(); i++) {
        double x = x0 + 4 + i * cw, y = 20;
        card(g, x, y, hand[p][i], winner >= 0, 16, 24);
        if (isSrc && turn == me && human[me]) { g.hit(x, y, cw, 24, [&g, tb = tbl, i] { g.mgTap(tb, i); }); if (i == cur) frame(g, x - 1, y - 1, 18, 26, H(0xf8d848)); }
      }
    }
    int nm = (int)hand[me].size(); double mx = std::floor((g.VW - std::min(nm, 14) * 20) / 2);
    for (int i = 0; i < nm; i++) card(g, mx + (i % 14) * 20, 136 + (i / 14) * 10, hand[me][i], true);
    g.text(g.tr(names[me]), g.VW / 2.0, 126, 0.28, H(0xd0d0e0), 1);
    if (lastA >= 0) { card(g, g.VW / 2.0 - 20, 70, lastA, true); card(g, g.VW / 2.0 + 2, 70, lastB, true); }
    string s = winner >= 0 ? fmt("Papaz %s elinde kaldı!", g.tr(names[loser]).c_str()) : msg;
    if (winner < 0 && turn != me) s = fmt("%s kart çekiyor...", g.tr(names[turn]).c_str());
    g.text("PAPAZ KİMDE", 6, 62, 0.32, H(0xf8d878), 0, true);
    int ln = 0; for (auto& l : g.wrap(s, 0.26, g.VW / 2.0 - 34)) g.text(l, 6, 74 + 9 * ln++, 0.26, H(0xf8e8c0));
    g.text(g.desktop ? "Oklar: seç  •  Boşluk: çek  •  Esc: çık" : "Bir karta dokun  •  Durdur: çık", g.VW / 2.0, 172, 0.22, H(0xa0a0b8), 1);
  }
  void save(WBuf& w) override { saveBase(w); for (int p = 0; p < 4; p++) { w.u8((int)hand[p].size()); for (int c : hand[p]) w.u8(c); } w.i32(lastA); w.i32(lastB); w.i32(loser); }
  void load(RBuf& r) override { loadBase(r); for (int p = 0; p < 4; p++) { int n = r.u8(); hand[p].clear(); for (int i = 0; i < n; i++) hand[p].push_back(r.u8()); } lastA = r.i32(); lastB = r.i32(); loser = r.i32(); }
};
// ======================================================================= 101 OKEY
// 106 taş (4 renk x 1-13 x 2 + 2 sahte okey). Gösterge taşının bir fazlası okeydir (her şeyin yerine geçer).
// Amaç: 101 puanlık per (seri ya da aynı sayı) açmak, sonra elindeki taşları perlere işleyip eli bitirmek.
const char* okeyModeName(int mode);
struct Okey : MiniGame {
  // ıstaka: 2 sıra x 13 yer (-1 boş). Taşları oyuncu dizer; yan yana duranlar bir dizi sayılır, boşluk ya da sıra sonu ayırır.
  // Oyun dizilişe karışmaz: yanlış dizilen per geçersizdir, öyle kalır.
  enum { RW = 13, RS = 26, C_DECK = 26, C_PILE = 27, C_DROP = 28, C_OPEN = 29, C_WORK = 30 };
  int rk[4][RS]; int ss[4] = { -1, -1, -1, -1 };   // ss: her oyuncunun ıstakada seçtiği yer
  std::vector<int> pile; struct Meld { std::vector<int> t; int type, c, n, len, owner = 0; };   // type 0 seri (renk c, n'den len taş), 1 grup (sayı n, renkler c), 2 çift
  std::vector<Meld> table; int lastDis[4] = { -1, -1, -1, -1 }; bool opened[4] = {}, byPairs[4] = {}; int phase = 0, indicator = 0, okC = 0, okN = 1;
  Okey() { for (auto& r : rk) for (int& x : r) x = -1; }
  int kind() const override { return MG_OKEY; }
  static int colOf(int id) { return id / 26; }
  static int numOf(int id) { return (id % 26) / 2 + 1; }
  int mode() const { return opt & 3; }          // 0 klasik, 1 düşmeli, 2 101
  bool team() const { return (opt & 16) != 0; }  // eşli: karşılıklı oturanlar takım
  int need() const { return mode() == 2 ? 101 : 51; }
  bool wild(int id) const { return id < 104 && colOf(id) == okC && numOf(id) == okN; }
  void tileCN(int id, int& c, int& n) const { if (id >= 104) { c = okC; n = okN; } else { c = colOf(id); n = numOf(id); } }
  int count(int p) const { int n = 0; for (int x : rk[p]) if (x >= 0) n++; return n; }
  std::vector<int> tiles(int p) const { std::vector<int> v; for (int x : rk[p]) if (x >= 0) v.push_back(x); return v; }
  int slotOf(int p, int id) const { for (int i = 0; i < RS; i++) if (rk[p][i] == id) return i; return -1; }
  // yeni taşın yeri: sağdan, mümkünse iki yanı boş bir yer (dizilmiş perlere yapışmasın)
  int freeSlot(int p) const {
    for (int i = RS - 1; i >= 0; i--) if (rk[p][i] < 0 && (i % RW == 0 || rk[p][i - 1] < 0) && (i % RW == RW - 1 || rk[p][i + 1] < 0)) return i;
    for (int i = RS - 1; i >= 0; i--) if (rk[p][i] < 0) return i;
    return -1;
  }
  void deal(Game& g) {
    for (int i = 0; i < 106; i++) pile.push_back(i);
    for (int i = 105; i > 0; i--) { int j = (int)(g.rnd() * (i + 1)) % (i + 1); std::swap(pile[i], pile[j]); }
    for (size_t i = 0; i < pile.size(); i++) if (pile[i] < 104) { indicator = pile[i]; pile.erase(pile.begin() + i); break; }
    okC = colOf(indicator); okN = numOf(indicator) % 13 + 1;
    int base = mode() == 2 ? 21 : 14;   // ilk başlayan bir fazla alır (sırası gelince 15 taş, değilken 14)
    for (int p = 0; p < np; p++) for (int k = 0; k < (p == 0 ? base + 1 : base); k++) { rk[p][k] = pile.back(); pile.pop_back(); }
    for (int p = 0; p < np; p++) if (!human[p]) arrange(p);
    phase = 1; cur = 0;
    msg = mode() == 0 ? string("İlk sen oynuyorsun. Taşlarını ıstakada diz (taşa dokun, sonra gideceği yere), sonra birini seçip at. Kalan 14 taşın hepsi per ya da 7 çift olunca kazanırsın.")
                      : fmt("İlk sen oynuyorsun. Taşlarını diz; %d puanlık per ya da 5 çift dizdiysen yere aç, sonra bir taş seçip at.", need());
  }
  // ıstakadaki diziler (sıra sıra, soldan sağa)
  std::vector<std::vector<int>> segs(int p) const {
    std::vector<std::vector<int>> out;
    for (int r = 0; r < 2; r++) {
      std::vector<int> cur;
      for (int i = 0; i < RW; i++) { int id = rk[p][r * RW + i]; if (id >= 0) cur.push_back(id); else if (!cur.empty()) { out.push_back(cur); cur.clear(); } }
      if (!cur.empty()) out.push_back(cur);
    }
    return out;
  }
  // dizi per mi: 0 seri (hepsi aynı renk, sıra sıra; 12-13-1 olur), 1 grup (aynı sayı, hepsi ayrı renk, 3-4 taş), -1 değil. Okey her taşın yerine geçer.
  int meldOf(const std::vector<int>& s, int& pts, int& c0, int& n0) const {
    int L = (int)s.size(); pts = 0; if (L < 3) return -1;
    if (L <= 4) {
      int n = -1, mask = 0; bool ok = true;
      for (int id : s) { if (wild(id)) continue; int c, k; tileCN(id, c, k); if (n < 0) n = k; if (k != n || ((mask >> c) & 1)) { ok = false; break; } mask |= 1 << c; }
      if (ok) {
        if (n < 0) n = okN;
        for (int id : s) if (wild(id)) for (int c = 0; c < 4; c++) if (!((mask >> c) & 1)) { mask |= 1 << c; break; }
        pts = n * L; c0 = mask; n0 = n; return 1;
      }
    }
    int col = -1, start = -99; bool ok = true;
    for (int i = 0; i < L && ok; i++) {
      int id = s[i]; if (wild(id)) continue; int c, k; tileCN(id, c, k);
      if (col < 0) col = c; else if (c != col) ok = false;
      int st = (k == 1 && i > 0) ? 14 - i : k - i;   // 13'ten sonra gelen 1
      if (start == -99) start = st; else if (st != start) ok = false;
    }
    if (start == -99) start = 1;
    if (col < 0) col = okC;
    if (!ok || start < 1 || start + L - 1 > 14) return -1;
    for (int i = 0; i < L; i++) pts += start + i == 14 ? 1 : start + i;
    c0 = col; n0 = start; return 0;
  }
  // dizi çiftlerden mi oluşuyor (yan yana ikişer aynı taş; okey her taşın eşi olur): çift sayısı, değilse 0
  int pairsIn(const std::vector<int>& s) const {
    if (s.empty() || s.size() % 2) return 0;
    for (size_t i = 0; i < s.size(); i += 2) {
      if (wild(s[i]) || wild(s[i + 1])) continue;
      int c1, n1, c2, n2; tileCN(s[i], c1, n1); tileCN(s[i + 1], c2, n2); if (c1 != c2 || n1 != n2) return 0;
    }
    return (int)s.size() / 2;
  }
  int pairPts(const std::vector<int>& s, size_t i) const { int c, n; tileCN(wild(s[i]) ? s[i + 1] : s[i], c, n); return 2 * n; }
  // klasik bitiş: 1 hepsi per, 2 yedi çift, 0 değil
  int finishType(int p) const {
    auto sg = segs(p); if (count(p) != 14) return 0;
    bool allM = true; int pr = 0, pts, c, n;
    for (auto& s : sg) { if (meldOf(s, pts, c, n) < 0) allM = false; int k = pairsIn(s); if (!k) pr = -99; else pr += k; }
    return allM ? 1 : pr == 7 ? 2 : 0;
  }
  // dizilmiş geçerli perlerin puanı ve çift sayısı
  void arranged(int p, int& pts, int& prs) const {
    pts = 0; prs = 0; int pt, c, n;
    for (auto& s : segs(p)) { if (meldOf(s, pt, c, n) >= 0) pts += pt; else prs += pairsIn(s); }
  }
  // ---- per bulucu (yalnızca bilgisayar oyuncuları kendi ıstakasını dizerken kullanır)
  struct Cand { int type, c, n, len, need, pts; };
  // byCount: puan yerine pere giren taş sayısını en çoğa çıkarır (klasik okeyde el bitti mi)
  void bestMelds(const std::vector<int>& h, std::vector<Meld>& out, int& pts, bool byCount = false) const {
    int cnt[4][14] = {}; int J = 0; std::vector<int> ids[4][14], wl;
    for (int id : h) { if (wild(id)) { J++; wl.push_back(id); continue; } int c, n; tileCN(id, c, n); cnt[c][n]++; ids[c][n].push_back(id); }
    std::vector<Cand> cs;
    for (int n = 1; n <= 13; n++) for (int mask = 0; mask < 16; mask++) {
      int sz = __builtin_popcount(mask); if (sz < 3) continue;
      int need = 0; for (int c = 0; c < 4; c++) if ((mask >> c) & 1 && !cnt[c][n]) need++;
      if (need <= J && need < sz) cs.push_back({ 1, mask, n, sz, need, byCount ? sz : n * sz });
    }
    for (int c = 0; c < 4; c++) for (int s = 1; s <= 11; s++) for (int len = 3; s + len - 1 <= 13; len++) {
      int need = 0, pt = 0; for (int k = s; k < s + len; k++) { if (!cnt[c][k]) need++; pt += k; }
      if (need > J) break;
      if (need < len) cs.push_back({ 0, c, s, len, need, byCount ? len : pt });
    }
    std::sort(cs.begin(), cs.end(), [](const Cand& a, const Cand& b) { return a.pts > b.pts; });
    int best = 0, nodes = 0; std::vector<int> pick, bestPick;
    std::function<void(size_t, int, int)> dfs = [&](size_t i, int jl, int cur) {
      if (++nodes > 30000) return;
      if (cur > best) { best = cur; bestPick = pick; }
      for (size_t k = i; k < cs.size(); k++) {
        const Cand& m = cs[k]; int need = 0;
        if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1) { if (cnt[c][m.n]) continue; need++; } }
        else for (int x = m.n; x < m.n + m.len; x++) if (!cnt[m.c][x]) need++;
        if (need > jl || need >= m.len) continue;
        int dec[13][2]; int nd = 0;   // azaltılan sayaçlar (geri almak için)
        if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1 && cnt[c][m.n]) { cnt[c][m.n]--; dec[nd][0] = c; dec[nd++][1] = m.n; } }
        else for (int x = m.n; x < m.n + m.len; x++) if (cnt[m.c][x]) { cnt[m.c][x]--; dec[nd][0] = m.c; dec[nd++][1] = x; }
        pick.push_back((int)k); dfs(k, jl - need, cur + m.pts); pick.pop_back();
        for (int i = 0; i < nd; i++) cnt[dec[i][0]][dec[i][1]]++;
      }
    };
    dfs(0, J, 0);
    pts = best; out.clear();
    int used[4][14] = {}; size_t wi = 0;
    for (int k : bestPick) {
      const Cand& m = cs[k]; Meld md; md.type = m.type; md.c = m.type == 0 ? m.c : 0; md.n = m.n; md.len = m.len;
      auto take = [&](int c, int n) { if (used[c][n] < (int)ids[c][n].size()) md.t.push_back(ids[c][n][used[c][n]++]); else if (wi < wl.size()) md.t.push_back(wl[wi++]); };
      if (m.type == 1) { for (int c = 0; c < 4; c++) if ((m.c >> c) & 1) take(c, m.n); md.c = m.c; }
      else for (int x = m.n; x < m.n + m.len; x++) take(m.c, x);
      if ((int)md.t.size() == m.len) out.push_back(md);
    }
  }
  // aynı taşlardan çiftler (okeyler tek kalanların eşi olur)
  std::vector<std::vector<int>> pairUp(const std::vector<int>& h) const {
    std::vector<std::vector<int>> out; std::vector<int> ids[4][14], wl, single;
    for (int id : h) { if (wild(id)) { wl.push_back(id); continue; } int c, n; tileCN(id, c, n); ids[c][n].push_back(id); }
    for (int c = 0; c < 4; c++) for (int n = 1; n <= 13; n++) { auto& v = ids[c][n]; size_t i = 0; for (; i + 1 < v.size(); i += 2) out.push_back({ v[i], v[i + 1] }); if (i < v.size()) single.push_back(v[i]); }
    size_t w = 0; for (int s : single) { if (w >= wl.size()) break; out.push_back({ s, wl[w++] }); }
    if (w + 1 < wl.size()) out.push_back({ wl[w], wl[w + 1] });
    return out;
  }
  static void removeTiles(std::vector<int>& h, const std::vector<int>& t) { for (int id : t) { auto it = std::find(h.begin(), h.end(), id); if (it != h.end()) h.erase(it); } }
  bool complete(const std::vector<int>& h) const { std::vector<Meld> ms; int n; bestMelds(h, ms, n, true); return n >= (int)h.size(); }
  // bilgisayar kendi ıstakasını dizer: perler (ya da çiftler) aralarında boşlukla, kalanlar tek tek; out taşı en sona
  void arrange(int p, int out = -1, bool pairsWay = false) {
    auto h = tiles(p); if (out >= 0) removeTiles(h, { out });
    std::vector<std::vector<int>> grp;
    if (pairsWay) grp = pairUp(h);
    else { std::vector<Meld> ms; int pts; bestMelds(h, ms, pts, mode() == 0); for (auto& m : ms) grp.push_back(m.t); }
    for (int& x : rk[p]) x = -1;
    int r = 0, i = 0; std::vector<int> rest = h;
    for (auto& gv : grp) {
      int L = (int)gv.size(); if (i + L > RW) { r++; i = 0; } if (r > 1) break;
      for (int id : gv) rk[p][r * RW + i++] = id;
      i++; removeTiles(rest, gv);
    }
    if (out >= 0) rest.push_back(out);
    for (int id : rest) { int s = freeSlot(p); if (s >= 0) rk[p][s] = id; }
  }
  int handPts(int p) const { int s = 0; for (int id : tiles(p)) { if (wild(id)) continue; int c, n; tileCN(id, c, n); s += n; } return opened[p] ? s : s * 2; }
  // yere açma ya da açtıktan sonra per atma: yalnızca oyuncunun dizdiği geçerli perler (ve çiftle açtıysa çiftler)
  bool layDown(Game& g, int p) {
    if (mode() == 0) { msg = "Klasik okeyde yere açılmaz: elini ıstakada perlere ya da 7 çifte diz, sonra taş at."; return false; }
    std::vector<Meld> mel, prs; int pts = 0, pp = 0;
    for (auto& s : segs(p)) {
      Meld m; int pt; m.t = s; m.len = (int)s.size(); m.owner = p;
      if ((m.type = meldOf(s, pt, m.c, m.n)) >= 0) { mel.push_back(m); pts += pt; continue; }
      if (pairsIn(s)) for (size_t i = 0; i < s.size(); i += 2) { Meld q; q.t = { s[i], s[i + 1] }; q.type = 2; q.len = 2; q.c = 0; q.n = pairPts(s, i) / 2; q.owner = p; prs.push_back(q); pp++; }
    }
    std::vector<Meld>* put = nullptr;
    if (!opened[p]) {
      if (pts >= need()) put = &mel; else if (pp >= 5) { put = &prs; byPairs[p] = true; }
      else { msg = fmt("Açmak için %d puanlık per ya da 5 çift dizmelisin (dizdiğin perler: %d puan, %d çift).", need(), pts, pp); return false; }
    } else put = byPairs[p] ? &prs : &mel;
    if (put->empty()) { msg = byPairs[p] ? "Atacak çift yok." : "Atacak per yok: perlerini aralarında boşluk bırakarak diz."; return false; }
    if (put->size() + table.size() > 60) { msg = "Masada yer kalmadı."; return false; }
    for (auto& m : *put) { for (int id : m.t) { int s = slotOf(p, id); if (s >= 0) rk[p][s] = -1; } table.push_back(m); }
    ss[p] = -1;
    if (!opened[p]) { opened[p] = true; msg = byPairs[p] ? fmt("%s %d çiftle açtı!", g.tr(names[p]).c_str(), pp) : fmt("%s %d puanla açtı!", g.tr(names[p]).c_str(), pts); }
    else msg = "Perler masaya atıldı.";
    g.sfx(SFX_CHIME); checkWin(p); return true;
  }
  // seçili taşı masadaki bir pere işle (oyuncu hangi taşı seçtiyse)
  bool workIn(Game& g, int p, bool quiet = false) {
    if (mode() == 0) { msg = "Klasik okeyde taş işlenmez."; return false; }
    if (!opened[p]) { msg = "Önce yere açmalısın."; return false; }
    int s = ss[p]; if (s < 0 || rk[p][s] < 0) { if (!quiet) msg = "Önce işleyeceğin taşı seç."; return false; }
    int id = rk[p][s]; int c, n; tileCN(id, c, n); bool w = wild(id), ok = false;
    for (auto& m : table) {
      if (m.type == 0 && (w || c == m.c)) {
        int e = m.n + m.len;
        if (e <= 14 && (w || n == e || (n == 1 && e == 14))) { m.t.push_back(id); m.len++; ok = true; break; }
        if (m.n > 1 && (w || n == m.n - 1)) { m.t.insert(m.t.begin(), id); m.n--; m.len++; ok = true; break; }
      } else if (m.type == 1 && m.len < 4 && (w || (n == m.n && !((m.c >> c) & 1)))) {
        if (w) { for (int k = 0; k < 4; k++) if (!((m.c >> k) & 1)) { m.c |= 1 << k; break; } } else m.c |= 1 << c;
        m.t.push_back(id); m.len++; ok = true; break;
      }
    }
    if (!ok) { if (!quiet) msg = "Bu taş masadaki hiçbir pere uymuyor."; return false; }
    rk[p][s] = -1; ss[p] = -1; msg = "Taş işlendi."; g.sfx(SFX_CLICK); checkWin(p); return true;
  }
  void checkWin(int p) { if (count(p) == 0) { winner = p; msg = "Elini bitirdi!"; } }
  void endByPile() {
    int best = 99999, w = 0; for (int p = 0; p < np; p++) { int s = handPts(p); if (s < best) { best = s; w = p; } }
    winner = w; msg = "Deste bitti: en az cezası olan kazandı.";
  }
  int prev() const { return (turn + np - 1) % np; }
  void draw1(Game& g, bool fromDiscard) {
    int p = turn, t;
    if (fromDiscard) { t = lastDis[prev()]; if (t < 0) return; lastDis[prev()] = -1; }
    else { if (pile.empty()) { endByPile(); return; } t = pile.back(); pile.pop_back(); }
    int s = freeSlot(p); if (s >= 0) rk[p][s] = t;
    phase = 1; cur = s >= 0 ? s : 0; g.sfx(SFX_CLICK);
    msg = mode() == 0 ? string("Taşlarını diz, sonra birini seçip at. Kalan 14 taşın hepsi per ya da 7 çift olursa kazanırsın!")
        : opened[p] ? string("Per at, taş işle ya da bir taş seçip at.") : fmt("%d puanlık per ya da 5 çift dizdiysen aç, sonra bir taş seçip at.", need());
  }
  void discard(Game& g, int slot) {
    int p = turn; if (slot < 0 || slot >= RS || rk[p][slot] < 0) return;
    lastDis[p] = rk[p][slot]; rk[p][slot] = -1; ss[p] = -1;
    g.sfx(SFX_CLICK);
    if (count(p) == 0) { winner = p; msg = "Elini bitirdi!"; return; }
    if (mode() == 0) { int f = finishType(p); if (f) { winner = p; msg = f == 2 ? "Çifte gitti! Yedi çiftle bitirdi." : "Okey! Elini bitirdi."; return; } }
    turn = (turn + 1) % np; phase = 0; cur = C_DECK;
    msg = human[turn] ? "Desteden çek ya da soldakinin attığı taşı al." : "";
  }
  void ai(Game& g) override {
    int p = turn; ss[p] = -1;
    if (phase == 0) {
      int t = lastDis[prev()]; bool take = false;
      if (t >= 0) { std::vector<Meld> m; int a, b; auto h = tiles(p); bestMelds(h, m, a); h.push_back(t); bestMelds(h, m, b); int c, n; tileCN(t, c, n); take = wild(t) || b - a >= n + 3; }
      draw1(g, take); if (winner >= 0) return;
    }
    auto h = tiles(p); std::vector<Meld> ms; int pts;
    if (mode() == 0) {   // klasik: bitirebiliyorsa (per ya da 7 çift) dizip bitir, değilse pere girmeyen taşı at
      for (int id : h) {
        auto h2 = h; removeTiles(h2, { id });
        bool per = complete(h2), cift = !per && pairUp(h2).size() >= 7;
        if (per || cift) { arrange(p, id, cift); discard(g, slotOf(p, id)); if (winner >= 0) return; arrange(p); break; }
      }
      if (turn != p) return;
      bestMelds(h, ms, pts, true); std::vector<int> inM; for (auto& m : ms) for (int id : m.t) inM.push_back(id);
      int bi = h[0], bn = -999; for (int id : h) { if (wild(id)) continue; int c, n; tileCN(id, c, n); int sc = (std::find(inM.begin(), inM.end(), id) != inM.end() ? -40 : 0) + n; if (sc > bn) { bn = sc; bi = id; } }
      arrange(p, bi); discard(g, slotOf(p, bi)); return;
    }
    // düşmeli / 101: perleri diz, açabiliyorsa aç, taş işle, sonra pere girmeyen en büyük taşı at (okey atılmaz)
    bestMelds(h, ms, pts);
    bool pairsWay = !opened[p] ? (pts < need() && pairUp(h).size() >= 5) : byPairs[p];
    arrange(p, -1, pairsWay);
    int ap, apr; arranged(p, ap, apr);
    if (opened[p] || ap >= need() || apr >= 5) layDown(g, p);
    if (winner >= 0) return;
    if (opened[p]) for (bool any = true; any && winner < 0;) { any = false; for (int s = 0; s < RS && winner < 0; s++) if (rk[p][s] >= 0) { ss[p] = s; if (workIn(g, p, true)) any = true; } ss[p] = -1; }
    if (winner >= 0) return;
    h = tiles(p); bestMelds(h, ms, pts); std::vector<int> inM; for (auto& m : ms) for (int id : m.t) inM.push_back(id);
    int bi = -1, bn = -1;
    for (int id : h) { if (wild(id)) continue; int c, n; tileCN(id, c, n); bool used = std::find(inM.begin(), inM.end(), id) != inM.end(); int sc = n + (used ? -40 : 0); if (sc > bn) { bn = sc; bi = id; } }
    if (bi < 0) bi = h[0];
    discard(g, slotOf(p, bi));
  }
  // ıstakada taş taşıma: taşa dokun (seçilir), sonra başka yere dokun (oraya gider; doluysa yer değiştirir)
  void rackTap(Game& g, int p, int c) {
    int& s = ss[p];
    if (s < 0) { if (rk[p][c] >= 0) s = c; }
    else if (s == c) s = -1;
    else { std::swap(rk[p][s], rk[p][c]); s = -1; g.sfx(SFX_CLICK); }
  }
  bool anyTime(int cell) const override { return cell >= 0 && cell < RS; }
  void tapAs(Game& g, int seat, int cell) override { if (anyTime(cell) && winner < 0) rackTap(g, seat, cell); }
  std::vector<int> buttons() const { if (phase == 0) return { C_DECK, C_PILE }; if (mode() == 0) return { C_DROP }; return { C_DROP, C_OPEN, C_WORK }; }
  // imleç: 0-25 ıstaka yerleri, sonra düğmeler
  void key(Game& g, int k) override {
    auto bs = buttons(); auto bi = std::find(bs.begin(), bs.end(), cur);
    if (cur >= RS && bi == bs.end()) { cur = bs[0]; bi = bs.begin(); }
    if (k == 0 || k == 1) {
      if (cur < RS) { int r = cur / RW, i = cur % RW; cur = r * RW + (i + (k ? 1 : RW - 1)) % RW; }
      else { int j = (int)(bi - bs.begin()), n = (int)bs.size(); cur = bs[(j + (k ? 1 : n - 1)) % n]; }
    } else if (k == 2) { if (cur >= RS) cur = RW + 6; else if (cur >= RW) cur -= RW; }
    else if (k == 3) { if (cur < RW) cur += RW; else if (cur < RS) cur = bs[0]; }
    else if (k == 4) act(g, cur);
    else if (k == 5) ss[turn] = -1;
  }
  void act(Game& g, int c) {
    int p = turn;
    if (c >= 0 && c < RS) { rackTap(g, p, c); return; }
    if (c == C_DECK || c == C_PILE) {
      if (phase != 0) return;
      if (c == C_PILE && lastDis[prev()] < 0) { msg = "Yerde taş yok."; return; }
      draw1(g, c == C_PILE); return;
    }
    if (phase != 1) { msg = "Önce desteden çek ya da yerdekini al."; return; }
    if (c == C_DROP) { if (ss[p] < 0) { msg = "Atmak için önce ıstakadan bir taş seç."; return; } discard(g, ss[p]); }
    else if (c == C_OPEN) layDown(g, p);
    else if (c == C_WORK) workIn(g, p);
  }
  void tap(Game& g, int c) override { cur = c; act(g, c); }
  // ---------------- 3B okey masası: kendi küçük perspektif kameramız ----------------
  struct V3 { double x, y, z; };
  struct Cam { V3 pos, r, u, f; double F, cx, cy; };
  static Cam camera(Game& g) {
    Cam c; c.pos = { 0, -1.82, 1.5 }; V3 t = { 0, 0.02, 0 };
    V3 f = { t.x - c.pos.x, t.y - c.pos.y, t.z - c.pos.z }; double l = std::sqrt(f.x * f.x + f.y * f.y + f.z * f.z); f = { f.x / l, f.y / l, f.z / l };
    V3 r = { f.y, -f.x, 0 }; l = std::sqrt(r.x * r.x + r.y * r.y); r = { r.x / l, r.y / l, 0 };
    V3 u = { r.y * f.z - r.z * f.y, r.z * f.x - r.x * f.z, r.x * f.y - r.y * f.x };
    c.r = r; c.u = u; c.f = f; c.F = 190; c.cx = g.VW / 2.0; c.cy = 70; return c;
  }
  static bool proj(const Cam& c, V3 p, double& sx, double& sy) {
    V3 q = { p.x - c.pos.x, p.y - c.pos.y, p.z - c.pos.z };
    double d = q.x * c.f.x + q.y * c.f.y + q.z * c.f.z; if (d < 0.05) return false;
    sx = c.cx + c.F * (q.x * c.r.x + q.y * c.r.y + q.z * c.r.z) / d; sy = c.cy - c.F * (q.x * c.u.x + q.y * c.u.y + q.z * c.u.z) / d; return true;
  }
  static void quad3(Game& g, const Cam& c, V3 a, V3 b, V3 cc, V3 d, Col col) {
    V3 v[4] = { a, b, cc, d }; double xs[4], ys[4];
    for (int i = 0; i < 4; i++) { double x, y; if (!proj(c, v[i], x, y)) return; xs[i] = g.vx(x); ys[i] = y * g.s; }
    g.g->quad(xs, ys, col);
  }
  static Col shade(Col c, double k) { return rgba(I(c.r * 255 * k), I(c.g * 255 * k), I(c.b * 255 * k), c.a); }
  // eksene hizalı kutu: görünen yüzleri (dışbükey olduğu için sırasız) çizer
  static void box(Game& g, const Cam& c, double x0, double y0, double z0, double x1, double y1, double z1, Col col) {
    if (c.pos.y < y0) quad3(g, c, { x0, y0, z0 }, { x1, y0, z0 }, { x1, y0, z1 }, { x0, y0, z1 }, shade(col, 0.78));
    if (c.pos.y > y1) quad3(g, c, { x0, y1, z0 }, { x1, y1, z0 }, { x1, y1, z1 }, { x0, y1, z1 }, shade(col, 0.7));
    if (c.pos.x < x0) quad3(g, c, { x0, y0, z0 }, { x0, y1, z0 }, { x0, y1, z1 }, { x0, y0, z1 }, shade(col, 0.62));
    if (c.pos.x > x1) quad3(g, c, { x1, y0, z0 }, { x1, y1, z0 }, { x1, y1, z1 }, { x1, y0, z1 }, shade(col, 0.62));
    if (c.pos.z > z1) quad3(g, c, { x0, y0, z1 }, { x1, y0, z1 }, { x1, y1, z1 }, { x0, y1, z1 }, col);
  }
  // oturma yeri k (0 ben/önde, 1 sağ, 2 karşı, 3 sol): yerel (x: ıstaka boyunca, y: masaya doğru) -> dünya
  static V3 seatXY(int k, double lx, double ly, double z) {
    switch (k & 3) { case 1: return { -ly, lx, z }; case 2: return { -lx, -ly, z }; case 3: return { ly, -lx, z }; }
    return { lx, ly, z };
  }
  static void sbox(Game& g, const Cam& c, int k, double lx0, double ly0, double lx1, double ly1, double z0, double z1, Col col) {
    V3 a = seatXY(k, lx0, ly0, 0), b = seatXY(k, lx1, ly1, 0);
    box(g, c, std::min(a.x, b.x), std::min(a.y, b.y), z0, std::max(a.x, b.x), std::max(a.y, b.y), z1, col);
  }
  static Col tileCol(int cl) { static const uint32_t TC[4] = { 0xd02828, 0xd08a00, 0x2050c8, 0x202020 }; return hexc(TC[cl & 3]); }
  // ıstakada yer i'nin ortası (yerel x)
  static double slotX(int i) { return -0.793 + i * 0.122 + 0.061; }
  // masaya yatık taş (yüzü yukarı), üstüne sayısı
  void flatTile(Game& g, const Cam& c, int k, double lx, double ly, int id) const {
    sbox(g, c, k, lx - 0.045, ly - 0.062, lx + 0.045, ly + 0.062, 0.0, 0.018, wild(id) ? hexc(0xfbe8a8) : hexc(0xf4eedc));
    V3 m = seatXY(k, lx, ly, 0.018); V3 m2 = seatXY(k, lx, ly + 0.05, 0.018); double x, y, x2, y2;
    if (!proj(c, m, x, y) || !proj(c, m2, x2, y2)) return;
    double sz = std::max(0.13, std::min(0.34, std::hypot(x2 - x, y2 - y) * 2.2 / 29));
    if (id >= 104) g.text("OK", x, y - sz * 13, sz * 0.8, hexc(0x208040), 1, true);
    else g.text(fmt("%d", numOf(id)), x, y - sz * 14, sz, tileCol(colOf(id)), 1, true);
  }
  void btn(Game& g, double x, double y, double w, const string& t, int idx, bool on) {
    g.rectV(x, y, w, 12, on ? H(0x3a6ad0) : H(0x3a3a5a)); g.text(t, x + w / 2, y + 2, 0.24, H(0xffffff), 1, true);
    g.hit(x, y, w, 12, [&g, tb = tbl, idx] { g.mgTap(tb, idx); });
    if (human[turn] && cur == idx && winner < 0 && g.desktop) frame(g, x - 1, y - 1, w + 2, 14, H(0xf8d848));
  }
  void draw(Game& g, int viewer) override {
    int me = viewer;
    Cam c = camera(g);
    g.g->vgrad(0, g.H, rgba(24, 16, 12, 1), rgba(58, 40, 26, 1));
    // masa: ahşap çerçeve ve yeşil çuha
    box(g, c, -1.18, -1.18, -0.08, 1.18, 1.18, 0, hexc(0x7a4a26));
    quad3(g, c, { -1.04, -1.04, 0.001 }, { 1.04, -1.04, 0.001 }, { 1.04, 1.04, 0.001 }, { -1.04, 1.04, 0.001 }, hexc(0x2e7a46));
    quad3(g, c, { -0.3, -0.3, 0.002 }, { 0.3, -0.3, 0.002 }, { 0.3, 0.3, 0.002 }, { -0.3, 0.3, 0.002 }, hexc(0x2a7042));
    // ıstakalar: önce karşı ve yanlar, sonra masadaki yatık taşlar, en son benimki
    auto rack = [&](int k) {
      sbox(g, c, k, -0.86, -1.0, 0.86, -0.80, 0, 0.06, hexc(0x8a5430));
      sbox(g, c, k, -0.86, -0.88, 0.86, -0.80, 0.06, 0.12, hexc(0x7a4826));
    };
    auto backTiles = [&](int k, int seat) {   // rakibin taşları: arkaları görünür (ıstakada dizdiği yerlerde)
      for (int idx = 0; idx < RS; idx++) {
        if (rk[seat][idx] < 0) continue; int row = idx / RW, i = idx % RW;
        double lx = slotX(i), ly = row == 0 ? -0.86 : -0.95, z0 = row == 0 ? 0.12 : 0.06;
        sbox(g, c, k, lx - 0.054, ly, lx + 0.054, ly + 0.034, z0, z0 + 0.16, hexc(0xe8e0c8));
      }
    };
    for (int k : { 2, 3, 1 }) { int seat = (me + k) % 4; if (seat < np) { rack(k); backTiles(k, seat); } }
    // orta: deste ve gösterge
    double ph = 0.012 + 0.0016 * pile.size();
    box(g, c, -0.2, -0.07, 0, -0.06, 0.07, ph, hexc(0xe8e0c8));
    flatTile(g, c, 0, 0.1, 0.0, indicator);
    // perler ve atılan taşlar (sahiplerinin önünde)
    for (int k = 0; k < 4; k++) {
      int seat = (me + k) % 4; if (seat >= np) continue;
      double lx = -0.6, ly = -0.46;
      for (auto& m : table) {
        if (m.owner != seat) continue;
        double w = m.t.size() * 0.095; if (lx + w > 0.5) { lx = -0.6; ly += 0.135; } if (ly > -0.18) break;
        for (size_t i = 0; i < m.t.size(); i++) flatTile(g, c, k, lx + i * 0.095 + 0.047, ly, m.t[i]);
        lx += w + 0.05;
      }
      if (lastDis[seat] >= 0) flatTile(g, c, k, 0.68, -0.6, lastDis[seat]);
    }
    // benim ıstakam: 2 sıra x 13 yer; taşlar dik, yüzleri bana dönük. Boş yerlere de dokunulur (taş oraya taşınır).
    rack(0);
    bool mine = winner < 0 && human[me];
    bool myTurn = mine && turn == me;
    for (int row = 0; row < 2; row++) {
      // ortaya yakın olanlar en son: kenar yüzleri komşusunun önünde kalmasın
      std::vector<int> ord; for (int i = 0; i < RW; i++) ord.push_back(i);
      std::sort(ord.begin(), ord.end(), [](int a, int b) { return std::fabs(a - 6.0) > std::fabs(b - 6.0); });
      for (int i : ord) {
        int idx = row * RW + i, id = rk[me][idx];
        bool picked = mine && ss[me] == idx;
        double lx = slotX(i), ly = row == 0 ? -0.86 : -0.95, z0 = (row == 0 ? 0.12 : 0.06) + (picked ? 0.05 : 0);
        if (id >= 0) box(g, c, lx - 0.054, ly, z0, lx + 0.054, ly + 0.034, z0 + 0.16, picked ? hexc(0xfff4b0) : wild(id) ? hexc(0xfbe8a8) : hexc(0xf6f0dc));
        double x0, y0, x1, y1;
        if (!proj(c, { lx - 0.054, ly, z0 + 0.16 }, x0, y0) || !proj(c, { lx + 0.054, ly, z0 }, x1, y1)) continue;
        double fh = y1 - y0, sz = fh * 0.52 / 29;
        if (id >= 104) g.text("OK", (x0 + x1) / 2, y0 + fh * 0.22, sz * 0.8, hexc(0x208040), 1, true);
        else if (id >= 0) { g.text(fmt("%d", numOf(id)), (x0 + x1) / 2, y0 + fh * 0.12, sz, tileCol(colOf(id)), 1, true); g.rectV((x0 + x1) / 2 - 1.2, y0 + fh * 0.72, 2.4, 2.4, tileCol(colOf(id))); }
        if (mine) g.hit(x0, y0, x1 - x0, fh, [&g, tb = tbl, idx] { g.mgTap(tb, idx); });
        if (picked) frame(g, x0 - 1, y0 - 1, x1 - x0 + 2, fh + 2, H(0xf8d848));
        else if (myTurn && g.desktop && cur == idx) frame(g, x0 - 1, y0 - 1, x1 - x0 + 2, fh + 2, H(0x40e050));
      }
    }
    // isimler: herkesin ıstakasının üstünde
    for (int k = 0; k < 4; k++) {
      int seat = (me + k) % 4; if (seat >= np) continue;
      V3 p = seatXY(k, 0, k == 0 ? -1.08 : -0.9, k == 0 ? 0 : 0.42); double x, y; if (!proj(c, p, x, y)) continue;
      string nm = fmt("%s (%d)%s", g.tr(names[seat]).c_str(), count(seat), opened[seat] ? " *" : "");
      if (k == 0) { x = 6 + (g.textW(nm, 0.24) + 8) / 2; y = 156; }
      double w = g.textW(nm, 0.24) + 8; bool t = turn == seat && winner < 0;
      g.rectV(x - w / 2, y - 1, w, 10, t ? H(0x2a6a3a, 0.9) : H(0x101018, 0.75));
      g.text(nm, x, y, 0.24, t ? H(0xb8ffb8) : H(0xe8e0d0), 1, true);
    }
    // 2B bilgiler ve düğmeler
    g.text("Gösterge", 4, 3, 0.22, H(0xc0c0d0)); g.text(fmt("Deste: %d", (int)pile.size()), 4, 11, 0.22, H(0xc0c0d0));
    if (mine && mode() != 0) { int pts, prs; arranged(me, pts, prs); g.text(fmt("Dizdiğin perler: %d puan, %d çift", pts, prs), 4, 19, 0.22, pts >= need() || prs >= 5 || opened[me] ? H(0x9af0a0) : H(0xc0c0d0)); }
    g.text(fmt("%s%s", okeyModeName(mode()), team() ? "  •  Eşli" : ""), 4, 27, 0.22, H(0xf8d878));
    string s = winner >= 0 ? (team() ? fmt("%s ve %s kazandı!", g.tr(names[winner]).c_str(), g.tr(names[(winner + 2) % 4]).c_str()) : fmt("%s kazandı!", g.tr(names[winner]).c_str())) : !myTurn ? fmt("%s oynuyor...", g.tr(names[turn]).c_str()) : msg;
    if (winner >= 0 && !msg.empty()) s = g.tr(msg) + " " + g.tr(s);
    double ly = 3; for (auto& l : g.wrap(s, 0.24, g.VW - 150)) { g.text(l, g.VW - 4, ly, 0.24, H(0xf8e8c0), 2); ly += 8; }
    if (myTurn) {
      double bx = g.VW / 2.0;
      if (phase == 0) { btn(g, bx - 34, 158, 66, "Desteden çek", C_DECK, true); btn(g, bx + 40, 158, 66, "Yerdekini al", C_PILE, lastDis[prev()] >= 0); }
      else {
        btn(g, bx - 34, 158, 66, "Taşı at", C_DROP, ss[me] >= 0);
        if (mode() != 0) { btn(g, bx + 40, 158, 66, opened[me] ? string("Per at") : fmt("Yere aç (%d)", need()), C_OPEN, true); btn(g, bx + 114, 158, 46, "İşle", C_WORK, opened[me] && ss[me] >= 0); }
      }
    }
    g.text(g.desktop ? "Oklar: gez  •  Boşluk: taşı al / bırak, düğmeye bas  •  Esc: çık" : "Taşa dokun, sonra yerine dokun: taşınır  •  Seçip \"Taşı at\"", g.VW / 2.0, 173, 0.2, H(0xa0a0b8), 1);
  }
  void save(WBuf& w) override {
    saveBase(w);
    for (int p = 0; p < 4; p++) { for (int i = 0; i < RS; i++) w.u8(rk[p][i] < 0 ? 255 : rk[p][i]); w.i32(lastDis[p]); w.u8(opened[p] | (byPairs[p] ? 2 : 0)); w.i32(ss[p]); }
    w.u8((int)pile.size()); w.u8(indicator); w.u8(okC); w.u8(okN); w.u8(phase);
    w.u8((int)table.size()); for (auto& m : table) { w.u8(m.type); w.u8(m.c); w.u8(m.n); w.u8(m.len); w.u8(m.owner); w.u8((int)m.t.size()); for (int id : m.t) w.u8(id); }
  }
  void load(RBuf& r) override {
    loadBase(r);
    for (int p = 0; p < 4; p++) { for (int i = 0; i < RS; i++) { int v = r.u8(); rk[p][i] = v == 255 ? -1 : v; } lastDis[p] = r.i32(); int o = r.u8(); opened[p] = o & 1; byPairs[p] = (o & 2) != 0; ss[p] = r.i32(); }
    int pn = r.u8(); pile.assign(pn, 0); indicator = r.u8(); okC = r.u8(); okN = r.u8(); phase = r.u8();
    int tn = r.u8(); table.clear(); for (int i = 0; i < tn && !r.bad; i++) { Meld m; m.type = r.u8(); m.c = r.u8(); m.n = r.u8(); m.len = r.u8(); m.owner = r.u8(); int k = r.u8(); for (int j = 0; j < k; j++) m.t.push_back(r.u8()); table.push_back(m); }
  }
};

// okey kuralları için sınama (test.cpp): hatalı durumların listesi, boşsa hepsi doğru
std::vector<string> okeyRuleTest(Game& g) {
  std::vector<string> bad; Okey o; o.np = 4; o.okC = 3; o.okN = 1;   // okey: siyah 1
  auto T = [](int c, int n, int k = 0) { return c * 26 + (n - 1) * 2 + k; };
  const int R = 0, Y = 1, B = 2, K = 3; int W = T(K, 1);
  auto kindIs = [&](std::vector<int> s, int want, const char* nm) { int p, c, n; if (o.meldOf(s, p, c, n) != want) bad.push_back(nm); };
  kindIs({ T(Y, 1), T(Y, 2), T(Y, 3) }, 0, "sarı 1-2-3 seri");
  kindIs({ T(R, 1), T(Y, 2), T(B, 3) }, -1, "karışık renk sıra geçersiz");
  kindIs({ T(R, 5), T(Y, 5), T(K, 5), T(B, 5) }, 1, "4 ayrı renk 5 grup");
  kindIs({ T(R, 1), T(B, 1), T(R, 1, 1) }, -1, "kırmızı 1 iki kez: grup geçersiz");
  kindIs({ T(R, 12), T(R, 13), T(R, 1) }, 0, "12-13-1 seri");
  kindIs({ T(R, 13), T(R, 1), T(R, 2) }, -1, "13-1-2 geçersiz");
  kindIs({ T(R, 4), W, T(R, 6) }, 0, "okey araya girer");
  kindIs({ T(R, 4), T(R, 6), T(R, 5) }, -1, "sırası bozuk seri geçersiz (düzeltilmez)");
  if (o.pairsIn({ T(R, 5), T(R, 5, 1) }) != 1 || o.pairsIn({ T(R, 5), T(B, 5) }) != 0) bad.push_back("çift");
  // ıstaka: 1. sıra kırmızı 1-2-3, dört renk 5, kırmızı 7-8-9 (aralarında boşluk); 2. sıra mavi 10-11-12(-13)
  auto put = [&](std::vector<int> row0, std::vector<int> row1) { for (int& x : o.rk[0]) x = -1; for (size_t i = 0; i < row0.size(); i++) o.rk[0][i] = row0[i]; for (size_t i = 0; i < row1.size(); i++) o.rk[0][13 + i] = row1[i]; };
  put({ T(R, 1), T(R, 2), T(R, 3), -1, T(Y, 5), T(B, 5), T(K, 5), T(R, 5), -1, T(R, 7), T(R, 8), T(R, 9) }, { T(B, 10), T(B, 11), T(B, 12) });
  if (o.finishType(0) != 0) bad.push_back("13 taşla bitmez");
  o.rk[0][16] = T(B, 13); if (o.finishType(0) != 1) bad.push_back("14 taş, hepsi per: biter");
  for (int i = 3; i < 7; i++) o.rk[0][i] = o.rk[0][i + 1]; o.rk[0][7] = -1;   // 5'ler boşluksuz seriye yapıştı
  if (o.finishType(0) != 0) bad.push_back("boşluksuz dizilen per sayılmaz");
  put({ T(R, 2), T(R, 2, 1), -1, T(Y, 4), T(Y, 4, 1), -1, T(B, 9), T(B, 9, 1), -1, T(R, 11), W }, { T(K, 3), T(K, 3, 1), T(K, 7), T(K, 7, 1), -1, T(Y, 13), T(Y, 13, 1) });
  if (o.finishType(0) != 2) bad.push_back("7 çift: çifte gider");
  // düşmeli: 51 puan dizilmeden açılmaz, dizilince açılır ve dizilmeyen taşlar ıstakada kalır
  o.opt = 1; o.names[0] = "A";
  put({ T(R, 10), T(R, 11), T(R, 12), -1, T(Y, 2), T(B, 2), T(R, 2) }, { T(K, 9), T(Y, 9), T(B, 9), T(R, 5) });
  if (o.layDown(g, 0)) bad.push_back("51 puan yokken açtı");
  put({ T(R, 10), T(R, 11), T(R, 12), -1, T(Y, 2), T(B, 2), T(R, 2) }, { T(K, 9), T(Y, 9), T(B, 9), T(R, 9), -1, T(R, 5) });
  if (!o.layDown(g, 0) || !o.opened[0] || o.count(0) != 1 || o.table.size() != 3) bad.push_back("33+6+36=75 puanla açılmalıydı");
  return bad;
}
// ======================================================================= Game tarafı
static std::shared_ptr<MiniGame> makeGame(int kind) {
  switch (kind) {
    case MG_DAMA: return std::make_shared<Dama>();
    case MG_SATRANC: return std::make_shared<Satranc>();
    case MG_TAVLA: return std::make_shared<Tavla>();
    case MG_PAPAZ: return std::make_shared<Papaz>();
    case MG_OKEY: return std::make_shared<Okey>();
  }
  return nullptr;
}
const char* mgName(int kind) { static const char* N[5] = { "Dama", "Satranç", "Tavla", "Papaz Kimde", "Okey" }; return kind >= 0 && kind < 5 ? N[kind] : ""; }
const char* okeyModeName(int mode) { static const char* N[3] = { "Klasik Okey", "Düşmeli Okey", "101 Okey" }; return N[mode % 3]; }
// bu cihazdan oynanan oyuncu mu (0: 1. oyuncu, 1-3: ortaklar)
bool Game::mgLocal(int player) {
  if (player < 0) return false;
  if (netRole == "guest") return player == gSeat;
  if (player == 0) return true;
  return player <= 3 && pp[player - 1] && !pp[player - 1]->remote;
}
string Game::mgPlayerName(int player) { return player == 0 ? string("Arda") : netRole == "host" ? fmt("%d. Oyuncu", player + 1) : partnerName(player - 1); }
// opt: okeyde tür ve eşli (16), papazda oyuncu sayısı. Satranç/dama/tavlada 3-4 kişi varsa ikinci masa kurulur.
void Game::mgStart(int kind, bool friendPlays, const std::vector<string>& rivals, std::function<void(int)> done, int opt /*= 0*/) {
  mgT[0].reset(); mgT[1].reset();
  std::vector<int> P{ 0 }; if (friendPlays) for (int i = 0; i < 3; i++) if (pp[i]) P.push_back(i + 1);
  size_t bot = 0;
  auto seat = [&](MiniGame& m, const std::vector<int>& ps) {
    for (int s = 0; s < m.np; s++) {
      int p = s < (int)ps.size() ? ps[s] : -1;
      m.who[s] = p; m.human[s] = p >= 0;
      m.names[s] = p >= 0 ? mgPlayerName(p) : bot < rivals.size() ? rivals[bot++] : fmt("Oyuncu %d", s + 1);
    }
  };
  bool two = kind == MG_DAMA || kind == MG_SATRANC || kind == MG_TAVLA;
  mgT[0] = makeGame(kind); if (!mg) return;
  MiniGame& m = *mg; m.opt = opt;
  if (kind == MG_OKEY) {
    m.np = 4;
    std::vector<int> ps = P;
    if ((opt & 16) && P.size() == 2) ps = { P[0], -1, P[1], -1 };   // eşli: iki arkadaş karşılıklı oturur, takım olur
    if ((opt & 16) && P.size() == 3) ps = { P[0], P[1], P[2], -1 };
    std::vector<int> fill; for (int s = 0; s < 4; s++) fill.push_back(s < (int)ps.size() ? ps[s] : -1);
    seat(m, fill);
  } else if (kind == MG_PAPAZ) {
    m.np = std::max(2, std::min(4, std::max((int)P.size(), opt >= 2 ? opt : 2)));
    seat(m, P);
  } else seat(m, { P[0], P.size() > 1 ? P[1] : -1 });
  if (two && P.size() >= 3) {   // ikinci masa: 3. ve 4. oyuncu (3 kişide 3. oyuncunun karşısına ada halkından biri)
    mgT[1] = makeGame(kind); mgT[1]->tbl = 1;
    seat(*mgT[1], { P[2], P.size() > 3 ? P[3] : -1 });
  }
  for (auto& t : mgT) if (t) {
    if (kind == MG_PAPAZ) static_cast<Papaz&>(*t).deal(*this);
    if (kind == MG_OKEY) static_cast<Okey&>(*t).deal(*this);
  }
  mgDone = done; mgEndT = 0; mgAiT = mgAiT2 = 0; mgView = 0; sfx(SFX_CHIME);
}
void Game::mgUpdate(double dt) {
  Press& I = inp.pressed;
  if (I.pause) { ask({ L("", "Oyundan çıkmak istiyor musun? (Kaybetmiş sayılırsın.)") }, { "Çık", "Devam" }, [this](int c) { if (c == 0) { auto cb = mgDone; mgT[0].reset(); mgT[1].reset(); mgDone = nullptr; if (cb) cb(98); } }); return; }
  bool allDone = true; for (auto& t : mgT) if (t && t->winner < 0) allDone = false;
  if (allDone) {
    mgEndT += dt;
    bool any = I.act || I.attack || I.confirm; for (auto& q : pp) if (q && (q->inp.pressed.act || q->inp.pressed.attack)) any = true;
    for (auto& q : pp) if (q) q->inp.pressed = Press();
    if (mgEndT > 2.2 && (any || mgEndT > 6)) mgFinish();
    return;
  }
  bool needHere[2] = { false, false };
  for (int t = 0; t < 2; t++) {
    if (!mgT[t]) continue; MiniGame& m = *mgT[t];
    if (m.winner >= 0) continue;
    m.tick(*this, dt); if (m.winner >= 0) continue;
    int s = m.turn, p = m.who[s];
    if (p < 0 || !m.human[s]) { double& at = t ? mgAiT2 : mgAiT; at += dt; if (at > (m.kind() == MG_OKEY ? 0.9 : 0.6)) { at = 0; m.ai(*this); } continue; }
    if (mgLocal(p)) needHere[t] = true;
    Press P = p == 0 ? I : (p <= 3 && pp[p - 1] ? pp[p - 1]->inp.pressed : Press());
    bool used = false;
    if (P.left) { m.key(*this, 0); used = true; } if (P.right) { m.key(*this, 1); used = true; } if (P.up) { m.key(*this, 2); used = true; } if (P.down) { m.key(*this, 3); used = true; }
    if (P.attack || P.act || P.confirm) { m.key(*this, 4); used = true; }
    if (P.item) { m.key(*this, 5); used = true; }
    if (used && mgLocal(p)) mgView = t;
  }
  for (auto& q : pp) if (q) q->inp.pressed = Press();
  // aynı ekranda iki masa: görünen masada sıra buradaki birinde değilse ötekine geç
  if (mgT[1] && !needHere[mgView] && needHere[1 - mgView]) mgView = 1 - mgView;
}
// dokunmatik ve fare: misafirde ev sahibine gönderilir; ev sahibinde sırası gelen bu cihazın oyuncusuysa oynar
void Game::mgTap(int table, int cell) {
  if (netRole == "guest") { if (net && netLive) { WBuf w; w.u8('m'); w.u8(table); w.i32(cell); net->send(w.b); } return; }
  if (table < 0 || table > 1 || !mgT[table] || mgT[table]->winner >= 0) return;
  MiniGame& m = *mgT[table]; int p = m.who[m.turn];
  if (m.human[m.turn] && mgLocal(p)) { m.tap(*this, cell); return; }
  // sıra başkasında: bu cihazdaki ilk oyuncu (ekranda gözünden bakılan) ıstakasını dizebilir
  if (m.anyTime(cell)) for (int s = 0; s < m.np; s++) if (m.human[s] && mgLocal(m.who[s])) { m.tapAs(*this, s, cell); return; }
}
void Game::mgRemoteTap(int table, int cell, int player) {
  if (table < 0 || table > 1 || !mgT[table]) return; MiniGame& m = *mgT[table];
  if (m.winner >= 0) return;
  if (m.who[m.turn] == player && m.human[m.turn]) { m.tap(*this, cell); return; }
  if (m.anyTime(cell)) for (int s = 0; s < m.np; s++) if (m.who[s] == player && m.human[s]) m.tapAs(*this, s, cell);
}
// online oyuncu ayrıldı: yerine ada halkından biri (bilgisayar) oynar
void Game::mgSeatLeft(int player) {
  for (auto& t : mgT) if (t) for (int s = 0; s < t->np; s++) if (t->who[s] == player) { t->who[s] = -1; t->human[s] = false; t->names[s] += " (bilgisayar)"; }
}
// sonuç (Arda'nın gözünden): 0 Arda kazandı, 1-3 o arkadaş kazandı, 50 ada halkı kazandı, 99 berabere, 98 vazgeçti
int Game::mgResult() {
  for (auto& t : mgT) {
    if (!t) continue; MiniGame& m = *t; bool arda = false; for (int s = 0; s < m.np; s++) if (m.who[s] == 0) arda = true;
    if (!arda && mgT[1]) continue;
    if (m.winner == 99) return 99;
    if (m.winner < 0) return 98;
    if ((m.opt & 16) && m.kind() == MG_OKEY && m.who[(m.winner + 2) % 4] == 0) return 0;
    int p = m.who[m.winner]; return p >= 0 ? p : 50;
  }
  return 98;
}
void Game::mgFinish() {
  int res = mgResult();
  auto cb = mgDone; mgT[0].reset(); mgT[1].reset(); mgDone = nullptr;
  if (cb) cb(res);
}
void Game::mgDraw() {
  g->rect(0, 0, W, H, rgba(10, 20, 14, 0.94));
  int tv = mgView;
  if (netRole == "guest") { tv = 0; for (int t = 0; t < 2; t++) if (mgT[t]) for (int s = 0; s < mgT[t]->np; s++) if (mgT[t]->who[s] == gSeat) tv = t; }
  if (!mgT[tv]) tv = 0;
  MiniGame& m = *mgT[tv];
  // kimin gözünden: sırası gelen bu cihazdaysa o, değilse bu cihazdaki ilk oyuncu
  int vs = 0; bool found = false;
  if (m.winner < 0 && mgLocal(m.who[m.turn])) { vs = m.turn; found = true; }
  for (int s = 0; s < m.np && !found; s++) if (mgLocal(m.who[s])) { vs = s; found = true; }
  m.draw(*this, vs);
  if (mgT[1]) {   // iki masa: üstte sekmeler
    for (int t = 0; t < 2; t++) {
      double x = VW / 2.0 - 52 + t * 54; bool on = t == tv;
      rectV(x, 1, 50, 10, on ? hexc(0x3a6ad0) : rgba(40, 40, 60, 0.85));
      text(fmt("Masa %d", t + 1), x + 25, 2, 0.24, hexc(0xffffff), 1, true);
      if (netRole != "guest") hit(x, 1, 50, 10, [this, t] { mgView = t; });
    }
  }
  bool allDone = true; for (auto& t : mgT) if (t && t->winner < 0) allDone = false;
  if (allDone) text(desktop ? "Devam etmek için Boşluk" : "Devam etmek için dokun", VW / 2.0, 160, 0.28, hexc(0xffffff), 1, true);
  else if (m.winner >= 0) text("Öteki masanın bitmesi bekleniyor...", VW / 2.0, 160, 0.26, hexc(0xf8e8c0), 1, true);
}
void Game::mgSave(WBuf& w) {
  w.u8(mg ? 1 : 0); if (!mg) return;
  for (auto& t : mgT) { w.u8(t ? 1 : 0); if (t) { w.u8(t->kind()); WBuf s; t->save(s); w.str(s.b); } }
}
void Game::mgLoad(RBuf& r) {
  int has = r.u8(); if (r.bad) return;
  if (!has) { mgT[0].reset(); mgT[1].reset(); return; }
  for (auto& t : mgT) {
    int on = r.u8(); if (r.bad) return;
    if (!on) { t.reset(); continue; }
    int k = r.u8(); string s = r.str(); if (r.bad) return;
    if (!t || t->kind() != k) t = makeGame(k);
    if (t) { RBuf rr(s); t->load(rr); }
  }
}
