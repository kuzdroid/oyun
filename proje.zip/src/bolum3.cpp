// ORMANIN KALBİ - Bölüm 1-3: Batık Şehir
// Kayıkla doğuya, Mercanköy, Dev Yengeç, Gelgit İncisi, Gelgit Asası (suyu çekip yükseltir), Batık Saray, Derin Kraken
// yan görevler: Kayıp İnciler, Yengeç Avı, Deniz Feneri; gizli boss: Hayalet Kaptan (gece, batık gemide)
#include "game.h"

static const double WRECK_POS[2] = { 39 * 16, 48 * 16 };
void dgDoorV(WorldMap& m, int rx, int ry, int type, int lock);
void dgDoorH(WorldMap& m, int rx, int ry, int type, int lock);

// ---------------- deniz haritası ----------------
void buildSea(WorldMap& m) {
  m.init(SEA_W, SEA_H, MAP_SEA, T_WATER);
  auto isl = [&](double cx, double cy, double rx, double ry, int inner, double innerR) {
    for (int y = 0; y < SEA_H; y++) for (int x = 0; x < SEA_W; x++) {
      double dx = (x - cx) / rx, dy = (y - cy) / ry, d = dx * dx + dy * dy, wob = 0.07 * std::sin(x * 0.9 + y * 0.6);
      if (d < 1 + wob) m.set(x, y, d < innerR ? inner : T_SAND);
      else if (d < 1.45 + wob && m.get(x, y) == T_WATER) m.set(x, y, T_SHALLOW);
    }
  };
  isl(16, 30, 14, 16, T_GRASS, 0.55);   // Mercanköy adası
  isl(50, 17, 9, 6, T_SAND, 0);          // Mercan Resifi
  isl(40, 48, 7, 5, T_SAND, 0);          // batık gemi adası
  isl(68, 40, 7, 6, T_RUIN, 0.6);        // saray adası
  for (int x = 27; x <= 42; x++) if (m.get(x, 20) == T_WATER || m.get(x, 20) == T_SHALLOW) m.set(x, 20, T_BRIDGEH);
  for (int x = 23; x <= 36; x++) if (m.get(x, 44) == T_WATER || m.get(x, 44) == T_SHALLOW) m.set(x, 44, T_BRIDGEH);
  // gelgit yolu: batık gemi adasından saray adasına (su çekilince yürünür)
  mline(m, 45, 47, 62, 41, 99, 2);
  for (auto& v : m.t) if (v == 99) v = T_TIDE;
  for (int x = 0; x <= 3; x++) { m.set(x, 30, T_BRIDGEH); m.set(x, 31, T_BRIDGEH); }   // iskele
  extendSea(m);
  Rng r(55);
  for (int i = 0; i < 70; i++) { int x = I(r.range(2, SEA_W - 2)), y = I(r.range(2, SEA_H - 2)); if (m.get(x, y) == T_WATER && m.get(x + 1, y) == T_WATER && m.get(x, y + 1) == T_WATER && m.get(x - 1, y) == T_WATER && m.get(x, y - 1) == T_WATER) m.set(x, y, T_REEF); }
}
void populateSea(WorldMap& m, int shells) {
  Rng r(808);
  auto sand = [&](int x, int y) { return m.get(x, y) == T_SAND || m.get(x, y) == T_GRASS; };
  m.add(O_BOAT, 0, 32, 2, 1).text = "sea";
  { Obj& h = m.add(O_HUT, 9, 22, 3, 3); h.text = "4"; h.var = 0; }
  { Obj& h = m.add(O_HUT, 19, 22, 3, 3); h.text = "K"; h.var = 1; }
  { Obj& h = m.add(O_HUT, 8, 33, 3, 3); h.text = "D"; h.var = 2; }
  m.add(O_LIGHTHOUSE, 16, 15, 2, 2).text = "fener";
  m.add(O_SIGN, 14, 28, 1, 1).text = "MERCANKÖY\nDoğuda Mercan Resifi, güneyde batık gemi.";
  m.add(O_SIGN, 26, 21, 1, 1).text = "MERCAN RESİFİ\nDev Yengeç'in yuvası. Yaklaşmayın!";
  m.add(O_SIGN, 37, 45, 1, 1).text = "BATIK GEMİ\nGeceleri buradan şarkı sesleri gelir...";
  m.add(O_WRECK, 37, 47, 3, 2).text = "wreck";
  m.add(O_PILLAR, 43, 46, 1, 1); m.add(O_PILLAR, 64, 42, 1, 1);
  m.add(O_PALACE, 67, 35, 3, 2).text = "palace";
  m.add(O_SIGN, 65, 38, 1, 1).text = "BATIK SARAY\nMercan halkının son sarayı. Su çekilince kapı görünür.";
  m.add(O_CHEST, 55, 15).var = 38; m.add(O_CHEST, 44, 50).var = 39;
  const int SH_POS[5][2] = { {6, 27}, {25, 31}, {47, 20}, {36, 50}, {71, 44} };
  for (int i = 0; i < 5; i++) { Obj& o = m.add(O_SHELL, SH_POS[i][0], SH_POS[i][1], 1, 1); o.var = i; if ((shells >> i) & 1) o.text = "open"; }
  for (auto p : { std::pair{13, 31}, {21, 30}, {12, 38} }) m.add(O_BARREL, p.first, p.second);
  extendSeaObjs(m);
  for (int i = 0; i < 260; i++) {
    int x = I(r.range(1, SEA_W - 2)), y = I(r.range(1, SEA_H - 2));
    if (!sand(x, y) || m.blk[y * SEA_W + x]) continue;
    if (x > 6 && x < 25 && y > 20 && y < 40 && r.f() < 0.7) continue;   // köy içi açık
    double k = r.f();
    if (k < 0.35 && sand(x, y - 1) && !m.blk[(y - 1) * SEA_W + x]) m.add(O_PALM, x, y).var = r.f() < 0.5 ? 1 : 0;
    else if (k < 0.5) { Obj& o = m.add(O_FLOWER, x, y, 1, 1, false); o.var = I(r.f() * 2); }
    else if (k < 0.6) m.add(O_CORAL, x, y);
    else if (k < 0.66) m.add(O_ROCK, x, y);
  }
}
// ---------------- batık saray ----------------
void buildPalace(WorldMap& m, std::vector<Room>& rooms) {
  m.init(RW * 3, RH * 3, MAP_DUNGEON3, T_DTOP);
  rooms.clear();
  const int used[9][2] = { {1, 2}, {1, 1}, {2, 1}, {0, 1}, {0, 0}, {2, 0}, {1, 0}, {0, 2}, {2, 2} };
  for (auto& u : used) {
    int ox = u[0] * RW, oy = u[1] * RH;
    for (int y = 0; y < RH; y++) for (int x = 0; x < RW; x++) m.set(ox + x, oy + y, (y == 0 || y == RH - 1 || x == 0 || x == RW - 1) ? T_DTOP : y == 1 ? T_DWALL : T_DFLOOR);
    rooms.push_back({ u[0], u[1], u[0] == 0 && u[1] == 0, false });
  }
  dgDoorV(m, 1, 2, T_DOOR_OPEN, 0); dgDoorH(m, 0, 2, T_DOOR_OPEN, 0); dgDoorH(m, 1, 2, T_DOOR_OPEN, 0);
  dgDoorH(m, 0, 1, T_DOOR_SHUT, 12); dgDoorH(m, 1, 1, T_DOOR_SHUT, 12);
  dgDoorV(m, 0, 1, T_DOOR_LOCK, 7); dgDoorV(m, 2, 1, T_DOOR_LOCK, 8); dgDoorV(m, 1, 1, T_DOOR_BOSS, 9);
  for (int x = 9; x <= 10; x++) m.set(RW + x, 2 * RH + RH - 2, T_STAIRS);
  for (int y = 2; y < RH - 2; y++) for (int x = 9; x <= 10; x++) m.set(RW + x, RH * 2 + y, T_CARPET);
  m.add(O_PILLAR, RW + 15, RH * 2 + 4, 1, 1);
  m.add(O_SIGN, RW + 3, RH * 2 + 3, 1, 1).text = "Gelgit sütunu sarayın suyunu da yönetir.\nSu çekilince saklı yollar açılır.";
  for (int y = 2; y < RH - 1; y++) for (int x = 1; x < 17; x++) { bool isle = x >= 8 && x <= 11 && y >= 4 && y <= 6; if (!isle) m.set(x, RH * 2 + y, T_TIDE); }
  m.add(O_CHEST, 10, RH * 2 + 5).var = 32;
  for (int y = 2; y < RH - 1; y++) for (int x = 3; x < 17; x++) { bool ring = !(x >= 8 && x <= 11 && y >= 4 && y <= 6); if (ring && !(x <= 3)) m.set(RW * 2 + x, RH + y, T_TIDE); }
  m.add(O_CHEST, RW * 2 + 10, RH + 5).var = 35;
  m.set(3, RH + 3, T_PLATE); m.add(O_BLOCK, 10, RH + 6).var = 0;
  m.add(O_SIGN, 16, RH + 2, 1, 1).text = "Taş, mercan tahtının anahtarını uyandırır.";
  for (int y = 2; y <= 4; y++) for (int x = 5; x <= 14; x++) m.set(RW + x, y, T_WATER);
  for (auto p : { std::pair{RW + 4, RH + 4}, {RW + 15, RH + 4}, {RW + 4, RH + 7}, {RW + 15, RH + 7}, {RW + 3, 7}, {RW + 16, 7}, {4, 4}, {15, 8}, {RW * 2 + 4, 4}, {RW * 2 + 15, 8}, {RW * 2 + 3, RH * 2 + 3}, {RW * 2 + 16, RH * 2 + 8} }) m.add(O_CRYSTAL, p.first, p.second);
  for (auto p : { std::pair{RW + 2, RH * 2 + 8}, {RW + 17, RH * 2 + 8}, {RW * 2 + 2, 3}, {17, RH + 8} }) m.add(O_BARREL, p.first, p.second);
  m.add(O_CHEST, 10, 5).var = 36; m.add(O_CHEST, RW * 2 + 10, 5).var = 37;
  for (auto p : { std::pair{5, 4}, {14, 4}, {5, 7}, {14, 7} }) m.add(O_ROCK, p.first, p.second).var = 1;
}

// ---------------- oyun mantığı ----------------
string Game::objective3() {
  switch (mainStep) {
    case 13: return "Bilge Nine ile konuş: Kalbin üçüncü parçası.";
    case 14: return "Ayna Gölü'nün güneyindeki kayıkla doğuya, denize açıl.";
    case 15: return "Mercanköy'de Kaptan Deniz'i bul.";
    case 16: return "Kuzeydoğudaki Mercan Resifi'nde Dev Yengeç'i yen, Gelgit İncisi'ni al.";
    case 17: return "Gelgit İncisi'ni Kaptan Deniz'e götür.";
    case 18: return "Gelgit Asası ile suyu çekip güneydoğudaki Batık Saray'a gir.";
    case 19: return "Batık Saray'da Kalbin üçüncü parçasını bul.";
    case 20: return "Üçüncü parçayı Yeşilvadi'deki Bilge Nine'ye götür.";
  }
  return objective4();
}
std::vector<string> Game::credits3() {
  return { "BÖLÜM 1-3 SONU", "", "Derin Kraken denizin dibine çekildi, Batık Saray yeniden ışıdı.", "Mercanköy'ün tekneleri yine balığa çıkıyor.",
    "Kalbin üç parçası birleşti. Sonuncusu göklerdeki kulede...", "", "Kaptan Deniz yeni bir şarkı besteledi: 'Arda'nın Gelgiti'.", "Yengeçler hâlâ yan yan yürüyor.", "", "",
    "BÖLÜM 1-4 YAKINDA", "", "Oynadığın için teşekkürler!" };
}
void Game::setTide(int v) { tide = v; SOLID_X[T_TIDE] = !v; }
void Game::placeBoat(WorldMap& m) {
  if (mainStep < 14) return;
  for (auto& o : m.objs) if (o->type == O_BOAT && o->alive) return;
  for (int y = 48; y <= 55; y++) for (int x = 68; x <= 88; x++)
    if (m.get(x, y) == T_SAND && m.get(x + 1, y) == T_SAND && !m.blk[y * m.W + x] && !m.blk[y * m.W + x + 1] && (m.get(x, y - 1) == T_WATER || m.get(x + 1, y - 1) == T_WATER)) {
      m.add(O_BOAT, x, y, 2, 1).text = "over"; boatPos[0] = x; boatPos[1] = y; return;
    }
}
void Game::enterSea(double x, double y) {
  WorldMap& m = map;
  buildSea(m); populateSea(m, (c3 >> 24) & 31);
  setTide(tide);
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); rooms.clear(); curRoom = -1; pvx = pvy = 0;
  markChests();
  px = x; py = y;
  placeNPCs();
  if (mainStep < 21) {
    scatterEnemies(E_CRAB, 6, 3, 14, 30, 46); scatterEnemies(E_CRAB, 4, 42, 11, 58, 23); scatterEnemies(E_CRAB, 3, 34, 44, 47, 52);
    scatterEnemies(E_GULL, 4, 4, 14, 60, 50); scatterEnemies(E_JELLY, 3, 60, 34, 76, 46); extEnemies(false);
    if (mainStep >= 16 && !(flags & F3_CRABKING)) { Ent& k = spawn(E_CRABKING, 50 * 16, 16 * 16); k.hx = k.x; k.hy = k.y; }
  }
  camX = clampf(px - VW / 2.0, 0, m.W * 16 - VW); camY = clampf(py - VH / 2.0, 0, m.H * 16 - VH);
  if (mainStep == 14) mainStep = 15;
  if (!(flags & F3_INTRO)) {
    flags |= F3_INTRO;
    say({ L("", "BÖLÜM 1-3: BATIK ŞEHİR"),
      L("", "Kayık günlerce dalgalarla boğuştu. Sonunda ufukta palmiyeler ve sazdan damlar belirdi."),
      L("Arda", "Mercanköy! Balıkçı çocuğun dedesi Kaptan Deniz burada yaşıyormuş. Onu bulmalıyım.") });
  }
  saveGame();
}
void Game::enterPalace() {
  WorldMap& m = map;
  buildPalace(m, rooms);
  setTide(tide);
  interior = -1; ents.clear(); picks.clear(); pts.clear(); npcs.clear(); pvx = pvy = 0;
  markChests();
  for (int i = 0; i < m.W * m.H; i++) { int lid = m.lockId[i]; if (lid && ((doorMask >> lid) & 1)) m.t[i] = T_DOOR_OPEN; }
  if ((clear3 >> 8) & 1) addRoomChest(8, 33);
  if (flags & F3_BLOCK) { EACH(o, m.objs) if (o.type == O_BLOCK) moveBlockTo(o, 3, RH + 3); addRoomChest(3, 34, 10, 4); }
  markChests();
  px = RW * 16 + RW * 8; py = (RH * 2 + RH - 3) * 16; pdir = 1; curRoom = -1;
  enterRoom(roomOf(px, py), true);
  camX = (curRoom % 3) * RW * 16 - (VW - RW * 16) / 2.0; camY = (curRoom / 3) * RH * 16 - (VH - RH * 16) / 2.0;
  if (mainStep < 19) mainStep = 19;
  saveGame();
}
void Game::toggleTide() {
  if (!hasCharm) { say({ L("", "Taş bir sütun. Tepesinde dalga biçimli bir oyuk var; içine bir şey takılacak gibi.") }); return; }
  if (tide == 1) {   // suyu yükseltmeden önce kimse gelgit yolunda olmasın
    for (auto& h : heroes()) if (map.get((int)std::trunc(h.x / 16), (int)std::trunc((h.y - 3) / 16)) == T_TIDE) { toast("Önce kuru yere çık, yoksa su seni de yutar!"); return; }
  }
  setTide(1 - tide); sfx(SFX_SPLASH); sfx(SFX_RUMBLE, 0.5); shake = 0.3;
  for (int i = 0; i < 6; i++) burst(5, px + (rnd() - 0.5) * 120, py + (rnd() - 0.5) * 80, 3);
  toast(tide ? "Gelgit Asası parladı: su çekildi!" : "Su yeniden yükseldi.");
  saveGame();
}
void Game::talkElder3() {
  int s0 = mainStep;
  if (s0 >= 21) { talkElder4(); return; }
  if (s0 == 13) {
    say({ L("Bilge Nine", "İki parça birleşti ama ışık hâlâ eksik. Üçüncü parça doğuda, denizin dibinde: Batık Şehir Mercan."),
      L("Bilge Nine", "Ayna Gölü'nün suyu denize akar. Balıkçı çocuğun kayığı seni oraya götürür. Kayık gölün güney kıyısında."),
      L("Bilge Nine", "Çocuğun dedesi Kaptan Deniz, Mercanköy'de yaşar. Denizin bütün sırlarını bilir."),
      L("Arda", "Kar, buz, şimdi de deniz... Bir sonraki parça herhalde volkanın içindedir."),
      L("Bilge Nine", "Hah! Göklerde, evladım. Göklerde. Ama önce deniz.") },
      [this] { mainStep = 14; if (map.kind == MAP_OVER) placeBoat(map); toast("BÖLÜM 1-3: BATIK ŞEHİR"); saveGame(); });
    return;
  }
  if (s0 == 20) {
    mainStep = 21; saveGame();
    say({ L("Bilge Nine", "Kırmızı bir ışık... Mercan'ın parçası! Üç parça, Arda. Üç!"),
      L("", "Üç parça birbirine kenetlendi. Yeşil, mavi ve kırmızı ışık iç içe döndü; gökyüzüne ince bir ışın yükseldi."),
      L("", "Işın bulutların arasında bir şeye çarptı. Bulutların üstünde, belli belirsiz bir kule göründü."),
      L("Bilge Nine", "Göklerdeki Kule... Son parça orada. Ama oraya nasıl çıkılır, ben de bilmiyorum."),
      L("Arda", "Babam biliyordur. Mektubunda 'zamanı gelince öğreneceksin' demişti."),
      L("Bilge Nine", "O zaman o vakit yakındır. Şimdi dinlen. Kaptan Deniz'den sana bir şarkı bile gelmiş, çok utanç verici.") },
      [this] { fadeTo([this] { state = S_CREDITS; creditsT = 0; setMood(5); }); });
    return;
  }
  say({ L("Bilge Nine", s0 == 14 ? "Kayık gölün güney kıyısında. Balıkçı çocuk yolu biliyor." : s0 < 20 ? "Denizin kokusu buraya kadar geliyor. Kendine dikkat et, Arda." : "Göklerdeki Kule... Zamanı gelince.") });
}
// eklenti nesneleri için etkileşim yarıçapı
double Game::interactR(Obj& o, double& cy) {
  switch (o.type) {
    case O_BOAT: cy = o.y - 6; return 22;
    case O_LIGHTHOUSE: cy = o.y - 8; return 24;
    case O_WRECK: cy = o.y - 10; return 28;
    case O_PILLAR: cy = o.y - 8; return 15;
    case O_CLOUDSTONE: case O_PEDESTAL: cy = o.y - 8; return 16;
    case O_STARBEAM: cy = o.y - 8; return 18;
    case O_WINDMILL: cy = o.y - 10; return 22;
    case O_NEST: cy = o.y - 6; return 24;
    default: return 13;
  }
}

static const double LIGHT_ON[2] = { 130, 56 }, LIGHT_OFF[2] = { 30, 56 }, LIGHT_HUT[2] = { 30, 14 };
void Game::initBolum3() {
  EXT.hp[E_CRAB] = 3; EXT.hp[E_GULL] = 2; EXT.hp[E_JELLY] = 3; EXT.hp[E_CRABKING] = 26; EXT.hp[E_KRAKEN] = 40; EXT.hp[E_TENTACLE] = 99; EXT.hp[E_GCAPTAIN] = 34;
  EXT.bossKey[MAP_DUNGEON3] = &Game::bossKey3;
  EXT.interiorMap[4] = MAP_SEA;
  // ---------------- kayık ----------------
  EXT.overBuild.push_back([this](WorldMap& m) { placeBoat(m); });
  EXT.interact[O_BOAT] = [this](Obj& o) {
    if (mainStep < 14) { say({ L("", "Balıkçı çocuğun kayığı. Kürekleri ıslak.") }); return; }
    if (fadeState) return;
    if (o.text == "sea") ask({ L("", "Kayıkla Yeşilvadi'ye, Ayna Gölü'ne dönmek ister misin?") }, { "Dön", "Kal" }, [this](int c) {
      if (!c) fadeTo([this] { enterOverworld(boatPos[0] * 16 + 8, (boatPos[1] + 1) * 16 + 12); pdir = 1; }); });
    else ask({ L("", "Kayıkla doğuya, denize açılmak ister misin?") }, { "Açıl", "Kal" }, [this](int c) {
      if (!c) fadeTo([this] { enterSea(3 * 16 + 8, 30 * 16 + 12); pdir = 3; }); });
  };
  EXT.talkPre[N_FISHER] = [this](Npc*) {
    if (mainStep != 14) return false;
    say({ L("Balıkçı Çocuk", "Mercanköy'e mi gidiyorsun? Dedem Kaptan Deniz orada! Kayığımı al, gölün güney kıyısında."),
      L("Balıkçı Çocuk", "Dedeme söyle: torunu artık taş tükürenlerden korkmuyor!") });
    return true;
  };
  // ---------------- harita olayları ----------------
  EXT.enter[MAP_SEA] = [this] { enterSea(10 * 16 + 8, 26 * 16 + 12); };
  EXT.enter[MAP_DUNGEON3] = [this] { enterPalace(); };
  EXT.enterAt[MAP_SEA] = [this](int rx, int ry) { enterSea(rx * 16 + 8, ry * 16 + 12); };
  EXT.exitDg[MAP_DUNGEON3] = [this] { enterSea(68 * 16 + 8, 38 * 16 + 4); };
  EXT.trans[MAP_SEA] = [this](int tx, int ty, bool up, bool) {
    WorldMap& m = map;
    EACH(o, m.objs) if (o.alive && o.type == O_HUT && up && tx == o.tx + 1 && std::fabs(py - o.y) < 14 + PHH) {
      if (o.text == "4") { if (fadeState == 0) { int rx = o.tx + 1, ry = o.ty + 3; sfx(SFX_CLICK); fadeTo([this, rx, ry] { enterInterior(4, rx, ry); }); } }
      else if (toastT <= 0) toast(o.text == "K" ? "Kaptan Deniz'in kulübesi. Kaptan dışarıda, iskelenin orada." : "Kapı kilitli. İçeriden balık kokusu geliyor.");
      return;
    }
    if (tx >= 67 && tx <= 69 && ty <= 37 && up && py < 37 * 16 + 14) {
      if (mainStep < 18) { if (toastT <= 0) toast("Sarayın kapısı mühürlü. Üstünde dalga biçimli bir oyuk var."); }
      else if (mainStep >= 21) { if (toastT <= 0) toast("Batık Saray artık huzurlu."); }
      else if (fadeState == 0) fadeTo([this] { enterPalace(); toast("BATIK SARAY"); });
    }
  };
  EXT.area[MAP_SEA] = [this] {
    int tx = (int)std::trunc(px / 16), ty = (int)std::trunc(py / 16); bool nt = night();
    bool cap = false, boss = false; for (auto& e : ents) { if (e->alive && e->type == E_GCAPTAIN) cap = true; if (e->alive && e->type == E_CRABKING) boss = true; }
    if (cap) setMood(17); else if (boss && std::fabs(px - 50 * 16) < 200) setMood(4);
    else if (mainStep >= 21) setMood(5); else if (nt) setMood(6);
    else if (tx < 30 && ty > 14 && ty < 46) setMood(13); else setMood(14);
    // gizli boss: gece, batık geminin yanında
    if (nt && nightAmt() > 0.6 && mainStep >= 16 && !(flags & F3_GCAPTAIN) && !cap && !dlg
      && std::fabs(px - WRECK_POS[0]) < 70 && std::fabs(py - WRECK_POS[1]) < 60) {
      Ent& c = spawn(E_GCAPTAIN, WRECK_POS[0] + 30, WRECK_POS[1] - 10); c.hx = c.x; c.hy = c.y;
      say({ L("Hayalet Kaptan", "Hooo-ho-hooo... Kim uyandırır beni? Gemimin hazinesine kim el uzatır?!"),
        L("Hayalet Kaptan", "Yüz yıl önce bu sularda batırıldım. Yüz yıl! Bir canlıyla kılıç kılıca vuruşmayı özledim!") },
        [this] { toast("GİZLİ BOSS: HAYALET KAPTAN"); sfx(SFX_GROWL); });
    }
    if (!nt && cap) EACH(e, ents) if (e.type == E_GCAPTAIN && e.alive) { e.alive = false; poof(e.x, e.y - 10); toast("Güneş doğdu; Hayalet Kaptan kayboldu..."); }
  };
  EXT.room[MAP_DUNGEON3] = Ext::RoomX{
    [this](int r) { return ((clear3 >> r) & 1) != 0; },
    [this](int r, bool instant) {
      curRoom = r; roomT = instant ? 0 : 0.5; ents.clear();
      bool boss = r == 1 && !krakenDead;
      if ((clear3 >> r) & 1) { setMood(boss ? 16 : 15); return; }
      double ox = (r % 3) * RW * 16, oy = (r / 3) * RH * 16;
      auto at = [&](int t, double x, double y) { spawn(t, ox + x * 16 + 8, oy + y * 16 + 12).room = r; };
      switch (r) {
        case 7: at(E_CRAB, 5, 5); at(E_CRAB, 14, 6); break;
        case 6: at(E_JELLY, 13, 4); break;
        case 8: at(E_JELLY, 6, 4); at(E_JELLY, 13, 6); at(E_CRAB, 10, 8); at(E_SKEL, 10, 5); break;
        case 4: at(E_CRAB, 5, 4); at(E_CRAB, 14, 4); at(E_JELLY, 10, 6); at(E_SKEL, 6, 8); at(E_SKEL, 13, 8); at(E_JELLY, 8, 3); break;
        case 3: at(E_SKEL, 13, 4); at(E_CRAB, 6, 8); at(E_JELLY, 12, 8); break;
        case 5: at(E_JELLY, 6, 3); at(E_JELLY, 15, 8); break;
        case 0: at(E_SKEL, 7, 6); at(E_SKEL, 13, 6); at(E_JELLY, 10, 3); at(E_CRAB, 10, 8); break;
        case 2: at(E_CRAB, 5, 6); at(E_CRAB, 14, 6); at(E_JELLY, 10, 8); at(E_SKEL, 10, 4); break;
        case 1: if (!krakenDead) { Ent& k = spawn(E_KRAKEN, ox + 10 * 16, oy + 4 * 16 + 8); k.room = r; k.z = 12; k.inv = true; k.invMsg = "Kraken su altında! Kollarını vur!"; toast("DERİN KRAKEN"); sfx(SFX_RUMBLE); shake = 0.5; } break;
      }
      if (ents.empty()) clear3 |= 1u << r;
      setMood(boss ? 16 : 15);
      if (r == 0) toast("Zifiri karanlık... Kristaller hafifçe parlıyor.");
    },
    [this](int r) {
      clear3 |= 1u << r; sfx(SFX_MAGIC);
      if (r == 4) { openLock(12); toast("Mercan kapılar açıldı!"); shake = 0.3; sfx(SFX_RUMBLE); }
      if (r == 8) { addRoomChest(8, 33); toast("Bir sandık belirdi!"); }
      saveGame();
    } };
  EXT.push[MAP_DUNGEON3] = Ext::PushX{ F3_BLOCK, [this] { addRoomChest(3, 34, 10, 4); } };
  EXT.dark[MAP_DUNGEON3] = [this](double ox, double oy, std::vector<LightSrc>& Ls) {
    int r = curRoom < 0 ? roomOf(px, py) : curRoom;
    EACH(o, map.objs) if (o.alive && o.type == O_CRYSTAL) Ls.push_back({ o.x - ox, o.y - 10 - oy, 40 + std::sin(time * 2 + o.x) * 3 });
    return DarkInfo{ r == 0 ? 0.93 : 0.42, { 2, 14, 22 } };
  };
  EXT.saveAs[MAP_DUNGEON3] = [] { return (int)MAP_DUNGEON3; };
  // saray zemini (deniz yeşili)
  EXT.tileAll[MAP_DUNGEON3] = [this](int t, int x, int y, double sx, double sy) {
    switch (t) {
      case T_DFLOOR: case T_DOOR_OPEN: spr(A.dfloor3[(x + y) & 1], sx, sy); break;
      case T_CARPET: spr(A.carpet3, sx, sy); break;
      case T_STAIRS: spr(A.stairs3, sx, sy); break;
      case T_DWALL: spr(A.dwall3, sx, sy); break;
      case T_DTOP: spr(A.dwallTop3, sx, sy); break;
      case T_DOOR_SHUT: spr(A.doorShut3, sx, sy); break;
      case T_DOOR_LOCK: spr(A.doorLock3, sx, sy); break;
      case T_DOOR_BOSS: spr(A.doorBoss3, sx, sy); break;
      case T_PLATE: spr(A.plate3[(flags & F3_BLOCK) ? 1 : 0], sx, sy); break;
      case T_WATER: spr(A.water[(I(time * 3) + ((x + y * 3) & 3)) & 3], sx, sy); break;
      case T_TIDE: EXT.tile[T_TIDE](t, x, y, sx, sy); break;
    }
  };
  EXT.tile[T_SHALLOW] = [this](int, int x, int y, double sx, double sy) { spr(A.shallow[(I(time * 2) + ((x + y) & 3)) & 3], sx, sy); };
  EXT.tile[T_TIDE] = [this](int, int x, int y, double sx, double sy) { if (tide) spr(A.wetSand, sx, sy); else spr(A.water[(I(time * 3) + ((x + y * 3) & 3)) & 3], sx, sy); };
  EXT.tile[T_REEF] = [this](int, int, int, double sx, double sy) { spr(A.reef, sx, sy); };
  EXT.tile[T_RUIN] = [this](int, int x, int y, double sx, double sy) { spr(A.ruin[(x + y) & 1], sx, sy); };
  EXT.tile[T_RUINWALL] = [this](int, int, int, double sx, double sy) { spr(A.ruinWall, sx, sy); };
  // nesneler
  EXT.obj[O_HUT] = [this](Obj& o, double x, double y) { spr(A.hut[o.var % 3], x - 26, y - 53); };
  EXT.obj[O_PALM] = [this](Obj& o, double x, double y) { spr(A.shadow, x - 10, y - 4, false, 1, 1.3, 1.1); spr(A.palm[o.var & 1], x - 15, y - 39 + std::sin(time + o.tx) * 0.5); };
  EXT.obj[O_BOAT] = [this](Obj&, double x, double y) { spr(A.boat, x - 17, y - 14 + std::sin(time * 2) * 1); };
  EXT.obj[O_PILLAR] = [this](Obj&, double x, double y) { spr(A.shadow, x - 7, y - 4, false, 1, 0.9); spr(A.pillar[tide ? 1 : 0], x - 7, y - 29); };
  EXT.obj[O_SHELL] = [this](Obj& o, double x, double y) { spr(A.shell[o.text == "open" ? 1 : 0], x - 7, y - 10); };
  EXT.obj[O_LIGHTHOUSE] = [this](Obj&, double x, double y) { spr(A.lighthouse, x - 13, y - 63); if (flags & F3_LIGHT) spr(A.spark, x - 9, y - 62, false, 0.6 + 0.4 * std::sin(time * 4), 2.6, 2.6); };
  EXT.obj[O_WRECK] = [this](Obj&, double x, double y) { spr(A.wreck, x - 27, y - 33); };
  EXT.obj[O_PALACE] = [this](Obj&, double x, double y) { spr(A.palace, x - 25, y - 43); };
  EXT.obj[O_CORAL] = [this](Obj&, double x, double y) { spr(A.coral, x - 8, y - 17); };
  EXT.obj[O_BARREL] = [this](Obj&, double x, double y) { spr(A.shadow, x - 6, y - 4, false, 1, 0.8); spr(A.barrel, x - 6, y - 14); };
  EXT.light[O_LIGHTHOUSE] = [this](Obj&) { return (flags & F3_LIGHT) ? LIGHT_ON : LIGHT_OFF; };
  EXT.light[O_HUT] = [](Obj&) { return LIGHT_HUT; };
  EXT.cut[O_BARREL] = [this](Obj& o) { map.removeObj(o); burst(4, o.x, o.y - 6, 8, 0x9a6434); sfx(SFX_HIT, 0.6); drop(o.x, o.y - 4, 0.85, 0.15); };
  EXT.cut[O_SHELL] = [this](Obj& o) {
    if (o.text == "open") return;
    o.text = "open"; c3 |= 1u << (24 + o.var); sfx(SFX_CHIME, 0.6); burst(1, o.x, o.y - 6, 5, 0xffffff);
    addPick(P_PEARL, o.x, o.y + 2, 80); saveGame();
  };
  EXT.interact[O_SHELL] = [this](Obj& o) { if (o.text != "open") EXT.cut[O_SHELL](o); };
  EXT.interact[O_PILLAR] = [this](Obj&) { toggleTide(); };
  EXT.interact[O_WRECK] = [this](Obj&) { say({ L("", (flags & F3_GCAPTAIN) ? "Geminin enkazı sessiz. Kaptan sonunda huzura kavuştu." : "Batık bir geminin enkazı. Gece yarısı güvertede bir fener yanıp sönüyor gibi...") }); };
  EXT.interact[O_LIGHTHOUSE] = [this](Obj&) {
    if (flags & F3_LIGHT) { say({ L("", "Fenerin ışığı denizin üstünde dönüp duruyor.") }); return; }
    if (!night()) { say({ L("", "Deniz feneri sönük. Gece yakmak gerek.") }); return; }
    if (!hasFireLantern) { say({ L("", "Feneri yakmak için sönmeyen bir alev lazım.") }); return; }
    flags |= F3_LIGHT; sfx(SFX_FIRE); shake = 0.2;
    say({ L("", "Alev Feneri'nin ateşini kulenin lambasına aktardın. Dev ışık dönmeye başladı; uzaklardaki teknelerin düdükleri duyuldu.") },
      [this] { if (qs[Q_LIGHT] == 1) { qs[Q_LIGHT] = 2; givePiece(); } saveGame(); });
  };
  // köylüler
  EXT.npcs.push_back([this] {
    WorldMap& m = map;
    if (m.kind == MAP_SEA) {
      if (!night()) {
        addNPC(N_CAPTAIN, 6, 30, A.captain, "Kaptan Deniz");
        addNPC(N_PEARLMA, 12, 30, A.pearlMa, "İnci Ana");
        addNPC(N_COOK, 22, 30, A.cook, "Aşçı Ozan", true);
      }
      addNPC(N_KEEPER, 19, 17, A.keeper, "Fenerci Nur");
    } else if (m.kind == MAP_INTERIOR && interior == 4) addNPC(N_INNKEEP3, 10, 3, A.innkeep, "Hancı Dalga");
  });
  EXT.talk[N_INNKEEP3] = [this](Npc&) { innShop(); };
  EXT.talk[N_CAPTAIN] = [this](Npc&) {
    int s0 = mainStep;
    if (s0 <= 15) {
      say({ L("Kaptan Deniz", "Ahoy! Yeşilvadi'den bir delikanlı, hem de torunumun kayığıyla! Demek o haylaz seni yolladı."),
        L("Kaptan Deniz", "Batık Şehir mi? Mercan... Benim çocukluğumda kuleleri hâlâ sudan görünürdü. Sonra gökten kırmızı bir yıldız düştü."),
        L("Kaptan Deniz", "Saray dibe çöktü ve kapısı yalnızca gelgit çekilince açılır oldu. Ama gelgiti yöneten İnci kayıp."),
        L("Kaptan Deniz", "Dev Yengeç çaldı onu! Kuzeydoğudaki Mercan Resifi'nde, köprüden geçince. Kabuğu zırh gibidir; yorulmasını bekle."),
        L("Kaptan Deniz", "İnciyi getir, sana Gelgit Asası'nı yapayım. Bir de... torunum taş tükürenlerden korkmuyormuş, öyle mi? Hah!") },
        [this] {
          mainStep = std::max(mainStep, 16);
          if (!(flags & F3_CRABKING) && !firstEnt(E_CRABKING)) { Ent& k = spawn(E_CRABKING, 50 * 16, 16 * 16); k.hx = k.x; k.hy = k.y; }
          toast("Dev Yengeç'i yen, Gelgit İncisi'ni al."); saveGame();
        });
      return;
    }
    if (s0 == 17) {
      say({ L("Kaptan Deniz", "Gelgit İncisi! Mavi mavi parlıyor... Ver bakalım şunu."),
        L("", "Kaptan inciyi eski bir dümen tahtasından oyduğu asanın ucuna taktı. Asa denizin sesiyle uğuldamaya başladı."),
        L("Kaptan Deniz", "Gelgit Asası. Taş sütunlara dokundur; su çekilir ya da yükselir. Batık Saray'ın yolu güneydoğuda, batık geminin ötesinde."),
        L("Kaptan Deniz", "Sarayın içinde de sütunlar vardır. Su bazen yolu kapatır, bazen açar. Aklını kullan, evlat.") },
        [this] { hasCharm = true; mainStep = 18; showItem(A.staff, "GELGİT ASASI! Taş sütunlarda suyu çeker ve yükseltir."); saveGame(); });
      return;
    }
    say({ L("Kaptan Deniz", s0 == 16 ? "Dev Yengeç Mercan Resifi'nde. Hücum edip duvara çarpınca sersemler; o zaman vur!" : s0 <= 20 ? "Denizin derinliklerinde bir şey uyanmış. Kraken... Dikkatli ol." : "Torunuma söyle, gelecek yaz balığa beraber çıkacağız!") });
  };
  EXT.talk[N_PEARLMA] = [this](Npc&) {
    int q = qs[Q_PEARLS], n = qc[Q_PEARLS];
    if (q == 0) { say({ L("İnci Ana", "Fırtınada inci kolyem koptu evladım. Beş inci adalara saçıldı, kabukların içine saklandı."), L("İnci Ana", "Kabukları kılıcınla açarsın. Beşini getirirsen sana güzel bir hediye veririm.") }, [this] { qs[Q_PEARLS] = 1; toast("Yeni görev: Kayıp İnciler"); saveGame(); }); return; }
    if (q == 1 && n >= 5) { say({ L("İnci Ana", "Beşi de! Kolyem tamamlandı. Al bakalım: denizin kalbinden bir parça.") }, [this] { qs[Q_PEARLS] = 2; coins += 50; givePiece(); saveGame(); }); return; }
    say({ L("İnci Ana", q == 1 ? fmt("%d inci buldun. Beşi lazım. Biri saray adasında, su çekilince...", n) : string("Kolyem çok güzel oldu, değil mi?")) });
  };
  EXT.talk[N_COOK] = [this](Npc&) {
    int q = qs[Q_CRABS];
    if (q == 0) { say({ L("Aşçı Ozan", "Yengeçler mutfağımı bastı! Sekiz tanesini temizlersen sana bedava balık çorbası... ve daha iyisini veririm.") }, [this] { qs[Q_CRABS] = 1; qc[Q_CRABS] = 0; toast("Yeni görev: Yengeç Avı"); saveGame(); }); return; }
    if (q == 1 && qc[Q_CRABS] >= 8) { say({ L("Aşçı Ozan", "Sekiz yengeç! Mutfağım kurtuldu. Al, iki kâse çorba ve şu parlak şey.") }, [this] { qs[Q_CRABS] = 2; breads += 2; givePiece(); saveGame(); }); return; }
    ask({ L("Aşçı Ozan", q == 1 ? fmt("Yengeçler: %d/8. Bu arada, balık çorbası ister misin? 8 altın.", qc[Q_CRABS]) : string("Balık çorbası ister misin? 8 altın, deniz kadar taze!")) }, { "Çorba al (8 altın)", "Sonra" }, [this](int c) {
      if (c == 0) { if (coins >= 8) { coins -= 8; breads++; showItem(A.soup, "Balık çorbası! (+2 kalp)"); saveGame(); } else say({ L("Aşçı Ozan", "8 altın, kaptan. Yengeçler bedava ama çorba değil.") }); }
    });
  };
  EXT.talk[N_KEEPER] = [this](Npc&) {
    int q = qs[Q_LIGHT];
    if (q == 0) { say({ L("Fenerci Nur", "Fener söndü! Fitili Kraken'in dalgaları ıslattı. Geceleri tekneler kayalara çarpacak."), L("Fenerci Nur", "Sönmeyen bir alevin varsa, gece kulenin dibindeki lambaya dokundur. Lütfen!") }, [this] { qs[Q_LIGHT] = 1; toast("Yeni görev: Deniz Feneri"); saveGame(); }); return; }
    say({ L("Fenerci Nur", q == 2 ? "Fener yine dönüyor! Teknelerin düdüklerini duyuyor musun? Sağ ol!" : "Gece olunca lambaya dokun. Ateşin yeter!") });
  };
  // ---------------- eşyalar, sandıklar ----------------
  EXT.pick[P_PEARL] = [this](Pick&) { qc[Q_PEARLS]++; showItem(A.pearl, fmt("İnci! (%d/5)", std::min(5, qc[Q_PEARLS]))); saveGame(); };
  EXT.pick[P_TIDEPEARL] = [this](Pick&) { mainStep = std::max(mainStep, 17); showItem(A.tidePearl, "GELGİT İNCİSİ! Kaptan Deniz'e götür."); saveGame(); };
  EXT.pick[P_GEM3] = [this](Pick&) {
    hasGem3 = true; mainStep = 20; showItem(A.gem3, "KALBİN ÜÇÜNCÜ PARÇASI!");
    say({ L("", "Kırmızı ışık suyu yardı. Sarayın duvarlarındaki mercanlar bir bir yeniden renklendi."), L("Arda", "Üçüncü parça! Nine'ye götürmeliyim. Kayık Mercanköy'ün iskelesinde.") });
    saveGame();
  };
  EXT.chest[32] = [this](int) { keys++; showItem(A.key, "Küçük anahtar buldun."); };
  EXT.chest[33] = [this](int) { keys++; showItem(A.key, "Küçük anahtar buldun."); };
  EXT.chest[34] = [this](int) { bossKey3 = true; showItem(A.bossKey, "BÜYÜK MERCAN ANAHTARI! Kraken'in kapısını açar."); };
  EXT.chest[35] = [this](int) { giveHeartC(); };
  EXT.chest[36] = [this](int) { coins += 80; showItem(A.coin[0], "80 altın buldun!"); };
  EXT.chest[37] = [this](int) { potions += 2; coins += 40; showItem(A.potion, "2 can iksiri ve 40 altın!"); };
  EXT.chest[38] = [this](int) { coins += 40; showItem(A.coin[0], "40 altın buldun!"); };
  EXT.chest[39] = [this](int) { givePiece(); };
  // ---------------- düşmanlar ----------------
  EXT.enemy[E_CRAB] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (d < 120) { double sx = sgn(dx) * 46; moveE(e, sx * dt, sgn(dy) * 14 * dt, 6, 4); if (e.cd <= 0 && d < 40) { e.cd = 1.6; e.kx = dx / d * 160; e.ky = dy / d * 160; e.kt = 0.18; sfx(SFX_CLICK, 0.5); } }
    else { double a = e.t * 0.9 + e.hx; moveE(e, std::cos(a) * 20 * dt, 0, 6, 4); }
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.enemy[E_GULL] = [this](Ent& e, double dt, double dx, double dy, double d) {
    if (e.state == 1) { e.x += e.vx * dt; e.y += e.vy * dt; e.z = std::max(0.0, e.z - 60 * dt); if (e.t > 0.7) { e.state = 0; e.t = 0; } }
    else {
      double tx = (d < 110 ? px : e.hx) + std::cos(e.t * 2) * 40, ty = (d < 110 ? py : e.hy) - 20 + std::sin(e.t * 2) * 20, ax = tx - e.x, ay = ty - e.y, al = std::hypot(ax, ay) + 0.01;
      e.x += ax / al * std::min(al, 60 * dt); e.y += ay / al * std::min(al, 60 * dt); e.z = std::min(16.0, e.z + 30 * dt);
      if (d < 70 && e.cd <= 0) { e.state = 1; e.t = 0; e.cd = 2.2; e.vx = dx / d * 150; e.vy = dy / d * 150; sfx(SFX_SELECT, 0.4); }
    }
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.enemy[E_JELLY] = [this](Ent& e, double dt, double dx, double dy, double d) {
    double pulse = (std::sin(e.t * 3) + 1) / 2;
    if (d < 140) { moveE(e, dx / d * 18 * pulse * dt, 0, 5, 4); moveE(e, 0, dy / d * 18 * pulse * dt, 5, 4); }
    e.z = 3 + pulse * 3;
    if (d < 11 && invT <= 0) freezeT = 0.8;   // çarpılınca kısa süre uyuşur
  };
  EXT.enemy[E_BUBBLE] = [this](Ent& e, double dt, double, double, double) { e.x += e.vx * dt; e.y += e.vy * dt + std::sin(e.t * 6) * 10 * dt; if (e.t > 3.2) e.alive = false; projHit(e, 1, 8); };
  EXT.enemy[E_BLADE] = [this](Ent& e, double dt, double, double, double) { e.x += e.vx * dt; e.y += e.vy * dt; if (e.t > 1.6) e.alive = false; projHit(e, 2, 9); };
  EXT.enemy[E_CRABKING] = [this](Ent& e, double dt, double dx, double dy, double) {
    if (dlg) return;
    e.inv = e.state == 4; e.invMsg = "Dev Yengeç kabuğuna çekildi!";
    double hx = e.hx, hy = e.hy;
    auto home = [&] { e.x = clampf(e.x, hx - 120, hx + 120); e.y = clampf(e.y, hy - 70, hy + 60); };
    if (e.state == 1) { bool hit = moveE(e, e.vx * dt, 0, 14, 8); home(); if (hit || e.t > 1.0 || std::fabs(e.x - hx) >= 119) { e.state = 2; e.t = 0; shake = 0.3; sfx(SFX_HIT); toast("Dev Yengeç sersemledi!"); } }
    else if (e.state == 2) { if (e.t > 1.8) { e.state = 0; e.t = 0; } }
    else if (e.state == 4) { if (e.t > 1.6) { e.state = 0; e.t = 0; double ex = e.x, ey = e.y; int room = e.room; for (int k = 0; k < 10; k++) { double a = k * PI / 5; shoot(E_BUBBLE, ex, ey - 8, std::cos(a) * 60, std::sin(a) * 60, room); } sfx(SFX_SPLASH); } }
    else {
      moveE(e, sgn(dx) * 30 * dt, sgn(dy) * 10 * dt, 14, 8); home();
      if (e.t > (e.hp < e.maxHp / 2 ? 1.0 : 1.4)) {
        e.t = 0; e.cd += 1;
        if (I(e.cd) % 3 == 0) { double ex = e.x, ey = e.y; int room = e.room; for (int k = -2; k <= 2; k++) { double a = std::atan2(dy, dx) + k * 0.25; shoot(E_BUBBLE, ex, ey - 8, std::cos(a) * 70, std::sin(a) * 70, room); } sfx(SFX_SPLASH, 0.6); }
        else { e.state = 1; e.vx = sgn(dx) * 170; sfx(SFX_SNORT, 0.6); }
      }
    }
    if (e.hits >= 4) { e.hits = 0; e.state = 4; e.t = 0; }
  };
  EXT.hit[E_CRABKING] = [](Ent& e, double) { e.hits++; };
  EXT.enemy[E_KRAKEN] = [this](Ent& e, double dt, double dx, double dy, double) {
    if (dlg) return;
    bool fast = e.hp < e.maxHp / 2;
    if (e.state == 2) {   // su üstünde: savunmasız, kabarcık tükürür
      e.inv = false; e.z = std::max(0.0, e.z - 40 * dt);
      if (e.cd <= 0) { e.cd = 0.7; double a0 = std::atan2(dy, dx), ex = e.x, ey = e.y; int room = e.room; for (int k = -1; k <= 1; k++) shoot(E_BUBBLE, ex, ey, std::cos(a0 + k * 0.3) * 80, std::sin(a0 + k * 0.3) * 80, room); sfx(SFX_SPLASH, 0.5); }
      if (e.t > 3.6) { e.state = 0; e.t = 0; e.hits = 0; toast("Kraken suya daldı!"); }
      return;
    }
    e.inv = true; e.z = std::min(12.0, e.z + 40 * dt);
    int tent = 0; for (auto& t : ents) if (t->alive && t->type == E_TENTACLE) tent++;
    if (e.t > (fast ? 1.1 : 1.6) && tent < (fast ? 4 : 3)) {
      e.t = 0;
      double ox = (e.room % 3) * RW * 16, oy = (e.room / 3) * RH * 16;
      double tx = clampf(px + (rnd() - 0.5) * 30, ox + 24, ox + RW * 16 - 24), ty = clampf(py + (rnd() - 0.5) * 20, oy + 6 * 16, oy + RH * 16 - 24);
      int room = e.room, uid = e.uid;
      Ent& t = spawn(E_TENTACLE, tx, ty); t.room = room; t.own = uid; t.inv = true; t.z = 12;
    }
    if (e.hits >= 3) { e.state = 2; e.t = 0; e.cd = 0.4; toast("Kraken su yüzüne çıktı! Şimdi vur!"); sfx(SFX_SPLASH); shake = 0.3; }
  };
  EXT.enemy[E_TENTACLE] = [this](Ent& e, double, double, double, double) {
    if (e.state == 0) { e.inv = true; e.z = 12; if (e.t > 0.9) { e.state = 1; e.t = 0; sfx(SFX_SPLASH, 0.8); burst(5, e.x, e.y, 8); for (auto& h : heroes()) if (std::fabs(h.x - e.x) < 14 && std::fabs(h.y - e.y) < 12) hurtAt(h, 2, e.x, e.y); } }
    else if (e.state == 1) { e.inv = false; e.z = 0; if (e.t > 0.15) { e.state = 2; e.t = 0; } }
    else { e.inv = false; if (e.t > 2.4) { e.alive = false; burst(5, e.x, e.y, 6); } }
  };
  EXT.hit[E_TENTACLE] = [this](Ent& e, double) {
    e.alive = false; burst(5, e.x, e.y - 10, 8); sfx(SFX_SPLASH, 0.6);
    Ent* k = findEnt(e.own); if (k && !k->alive) k = nullptr;
    if (k) { k->hits++; k->hp -= 2; k->flash = 0.2; if (k->hp <= 0) killEnemy(*k); }
  };
  EXT.enemy[E_GCAPTAIN] = [this](Ent& e, double, double dx, double dy, double) {
    if (dlg) return;
    e.z = 6 + std::sin(e.t * 3) * 3;
    if (e.state == 1) {
      if (e.t > 0.45) {
        e.state = 0; e.t = 0; double a0 = std::atan2(dy, dx); int n = e.hp < e.maxHp / 2 ? 5 : 3; double ex = e.x, ey = e.y; int room = e.room;
        for (int k = 0; k < n; k++) { double a = a0 + (k - (n - 1) / 2.0) * 0.3; shoot(E_BLADE, ex, ey - 10, std::cos(a) * 150, std::sin(a) * 150, room); }
        sfx(SFX_SWING);
      }
      return;
    }
    if (e.t > 1.7) {
      e.t = 0; e.cd += 1; poof(e.x, e.y - 10);
      double a = rnd() * PI * 2; e.x = px + std::cos(a) * 60; e.y = py + std::sin(a) * 40; poof(e.x, e.y - 10); e.state = 1;
      if (e.hp < e.maxHp / 2 && I(e.cd) % 4 == 0) { double ex = e.x, ey = e.y; for (int sg = -1; sg <= 1; sg += 2) spawn(E_GHOST, ex + sg * 24, ey); toast("Hayalet tayfalar!"); }
    }
    e.dir = dx < 0 ? 2 : 3;
  };
  EXT.kill[E_CRAB] = [this](Ent&) { if (qs[Q_CRABS] == 1) { qc[Q_CRABS]++; toast(fmt("Yengeçler: %d/8", std::min(8, qc[Q_CRABS]))); } return false; };
  EXT.kill[E_CRABKING] = [this](Ent& e) {
    flags |= F3_CRABKING; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 5; i++) poof(ex + (rnd() - 0.5) * 40, ey - 10 - rnd() * 24);
    EACH(o, ents) if (o.alive && o.type == E_BUBBLE) o.alive = false;
    addPick(P_TIDEPEARL, ex, ey, 100);
    for (int i = 0; i < 8; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 34, ey + (rnd() - 0.5) * 22, 80 + rnd() * 40);
    toast("Dev Yengeç yenildi!"); setMood(5); saveGame();
    return true;
  };
  EXT.kill[E_KRAKEN] = [this](Ent& e) {
    krakenDead = true; shake = 1.0; haptic("big");
    double ex = e.x, ey = e.y; int room = e.room;
    for (int i = 0; i < 8; i++) poof(ex + (rnd() - 0.5) * 60, ey - 10 - rnd() * 30);
    EACH(o, ents) if (o.alive && &o != &e && o.room == room) { o.alive = false; poof(o.x, o.y - 6); }
    addPick(P_GEM3, ex, ey + 34, 90); addPick(P_HEARTC, ex + 30, ey + 34, 90);
    setMood(5); saveGame();
    return true;
  };
  EXT.kill[E_GCAPTAIN] = [this](Ent& e) {
    flags |= F3_GCAPTAIN; shake = 0.8; haptic("big");
    double ex = e.x, ey = e.y;
    for (int i = 0; i < 6; i++) poof(ex + (rnd() - 0.5) * 40, ey - 10 - rnd() * 26);
    EACH(o, ents) if (o.alive && (o.type == E_BLADE || o.type == E_GHOST)) { o.alive = false; poof(o.x, o.y - 6); }
    addPick(P_HEARTC, ex, ey, 90);
    for (int i = 0; i < 15; i++) addPick(P_COIN, ex + (rnd() - 0.5) * 50, ey + (rnd() - 0.5) * 30, 80 + rnd() * 40, 5);
    say({ L("Hayalet Kaptan", "Hooo... Yüz yıl sonra güzel bir düello. Artık huzur içinde uyuyabilirim. Hazinem senin, genç kaptan...") });
    toast("GİZLİ BOSS YENİLDİ: HAYALET KAPTAN"); setMood(5); saveGame();
    return true;
  };
  // çizimler
  EXT.draw[E_CRAB] = [this](Ent& e, double x, double y, bool fl) { spr(A.shadow, x - 7, y - 3, false, 1, 0.8); spr(A.crab[I(e.t * 8) & 1], x - 8, y - 11, e.dir == 2, 1, 1, 1, fl); };
  EXT.draw[E_GULL] = [this](Ent& e, double x, double y, bool fl) { spr(A.shadow, x - 5, y - 3, false, 0.6, 0.6); spr(A.gull[I(e.t * 8) & 1], x - 7, y - 10 - e.z, e.dir == 3, 1, 1, 1, fl); };
  EXT.draw[E_JELLY] = [this](Ent& e, double x, double y, bool fl) { spr(A.shadow, x - 6, y - 3, false, 0.5, 0.7); spr(A.jelly[I(e.t * 4) & 1], x - 7, y - 18 - e.z, false, 0.85, 1, 1, fl); };
  EXT.draw[E_BUBBLE] = [this](Ent&, double x, double y, bool) { spr(A.bubble, x - 5, y - 10); };
  EXT.draw[E_BLADE] = [this](Ent& e, double x, double y, bool) { rot(A.blade, x, y - 8, 7, 2, std::atan2(e.vy, e.vx)); };
  EXT.draw[E_CRABKING] = [this](Ent& e, double x, double y, bool fl) {
    const Spr* s0 = A.crabKing[e.state == 1 ? I(e.t * 14) & 1 : I(e.t * 5) & 1];
    spr(A.shadow, x - 18, y - 6, false, 1, 2.3, 1.8);
    spr(s0, x - s0->w / 2, y - s0->h + 4 + (e.state == 4 ? 4 : 0), e.dir == 2, e.state == 2 ? 0.75 + 0.25 * std::sin(e.t * 20) : 1, 1, 1, fl);
    if (e.state == 4) spr(A.shell[0], x - 7, y - s0->h + 2, false, 0.9, 2, 2);
  };
  EXT.draw[E_KRAKEN] = [this](Ent& e, double x, double y, bool fl) {
    const Spr* s0 = A.kraken[I(e.t * 2) & 1]; bool sub = e.state != 2;
    if (sub) { spr(s0, x - s0->w / 2, y - 26, false, 0.35 + 0.1 * std::sin(e.t * 2), 1, 0.55); burst(5, x + drawOX + (rnd() - 0.5) * 50, y + drawOY - 4, 1); }
    else spr(s0, x - s0->w / 2, y - s0->h + 14 - e.z, false, 1, 1, 1, fl);
  };
  EXT.draw[E_TENTACLE] = [this](Ent& e, double x, double y, bool fl) {
    if (e.state == 0) { double k = e.t / 0.9; g->ellipse(x, y - 2, 4 + 6 * k, 2 + 3 * k, rgba(255, 255, 255, 0.3 + 0.5 * k), 1); return; }
    const Spr* s0 = A.tentacle[I(e.t * 4) & 1]; double rise = e.state == 1 ? e.t / 0.15 : 1;
    spr(A.shadow, x - 7, y - 3, false, 1, 0.9);
    spr(s0, x - 8, y - s0->h * rise + 2, false, 1, 1, rise, fl);
  };
  EXT.draw[E_GCAPTAIN] = [this](Ent& e, double x, double y, bool fl) { const Spr* s0 = A.gcaptain[I(e.t * 4) & 1]; spr(s0, x - s0->w * 0.75, y - s0->h * 1.5 - e.z, e.dir == 2, fl ? 1 : 0.8, 1.5, 1.5, fl); };
}
// 3. bölüm eşyaları
void Game::drawPick2(Pick& k, double x, double y, double bob) {
  switch (k.type) {
    case P_PEARL: spr(A.pearl, x - 4, y - 12 - bob); break;
    case P_TIDEPEARL: spr(A.spark, x - 9, y - 22 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 2.2, 2.2); spr(A.tidePearl, x - 7, y - 18 - bob); break;
    case P_GEM3: spr(A.spark, x - 9, y - 22 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 2.2, 2.2); spr(A.gem3, x - 7, y - 18 - bob); break;
    case P_GEM4: spr(A.spark, x - 9, y - 22 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 2.2, 2.2); spr(A.gem4, x - 7, y - 18 - bob); break;
    case P_FEATHER: spr(A.spark, x - 6, y - 18 - bob, false, 0.4 + 0.4 * std::sin(k.t * 5), 1.6, 1.6); spr(A.feather, x - 4, y - 15 - bob); break;
    case P_HORN: spr(A.spark, x - 9, y - 20 - bob, false, 0.5 + 0.4 * std::sin(k.t * 5), 2.2, 2.2); spr(A.horn, x - 8, y - 14 - bob); break;
    case P_QITEM: spr(A.spark, x - 7, y - 19 - bob, false, 0.35 + 0.35 * std::sin(k.t * 4), 1.8, 1.8); spr(hikayeEsya(k.val), x - 5, y - 15 - bob); break;
  }
}
