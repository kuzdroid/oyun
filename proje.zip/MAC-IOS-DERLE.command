#!/bin/bash
# Ormanın Kalbi - iPhone sürümünü derler (Mac'te çift tıkla)
# Gerekenler: Xcode (App Store'dan ücretsiz) ve Node.js. Eksikse bu dosya kurulumu başlatır.
cd "$(dirname "$0")" || exit 1
NODE_SURUM="v22.18.0"

dur() { echo; read -r -p "Kapatmak için Enter'a bas..." _; exit "${1:-0}"; }
baslik() { echo; echo "=== $1 ==="; }

echo "╔══════════════════════════════════════╗"
echo "║   ORMANIN KALBİ - iPhone derleyici    ║"
echo "╚══════════════════════════════════════╝"

# ---- 1) Xcode ----
baslik "1/4 Xcode kontrol ediliyor"
if [ ! -d "/Applications/Xcode.app" ]; then
  echo "Xcode kurulu değil. App Store açılıyor."
  echo "Xcode'u kur, BİR KEZ açıp ek bileşenleri kurmasına izin ver, sonra bu dosyayı yeniden çalıştır."
  open "macappstore://apps.apple.com/app/xcode/id497799835"
  dur 1
fi
if ! xcodebuild -version >/dev/null 2>&1; then
  echo "Xcode seçili değil ya da lisansı onaylanmamış. Mac şifren istenecek."
  sudo xcode-select -s /Applications/Xcode.app/Contents/Developer || dur 1
  xcodebuild -version >/dev/null 2>&1 || { echo "Xcode lisansını okuyup onaylaman gerekiyor:"; sudo xcodebuild -license || dur 1; }
  sudo xcodebuild -runFirstLaunch >/dev/null 2>&1
fi
xcodebuild -version | head -1
XV=$(xcodebuild -version | head -1 | awk '{print $2}' | cut -d. -f1)
if [ "${XV:-0}" -lt 16 ]; then echo "Xcode 16 veya daha yenisi gerekiyor (sende $XV). App Store'dan güncelle."; dur 1; fi

# ---- 2) Node.js ----
baslik "2/4 Node.js kontrol ediliyor"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js kurulu değil, resmi siteden indirilip kuruluyor ($NODE_SURUM). Mac şifren istenecek."
  curl -fL -o /tmp/node.pkg "https://nodejs.org/dist/$NODE_SURUM/node-$NODE_SURUM.pkg" || { echo "İndirilemedi. https://nodejs.org adresinden LTS sürümünü elle kur."; dur 1; }
  sudo installer -pkg /tmp/node.pkg -target / || dur 1
  export PATH="/usr/local/bin:$PATH"
fi
node -v

# ---- 3) Proje ----
baslik "3/4 iPhone projesi hazırlanıyor"
npm install --no-audit --no-fund || { echo "npm install başarısız. İnternet bağlantını kontrol et."; dur 1; }
if [ ! -d "ios/App/App.xcodeproj" ]; then
  rm -rf ios
  npx cap add ios --packagemanager SPM || dur 1
  cp ayarlar/Info.plist ios/App/App/Info.plist
  rm -rf ios/App/App/Assets.xcassets && cp -R ayarlar/Assets.xcassets ios/App/App/Assets.xcassets
fi
npx cap sync ios || dur 1

# ---- 4) Seçim ----
baslik "4/4 Ne yapmak istiyorsun?"
echo "  1) Kendi iPhone'umda dene (ücretsiz, Xcode açılır)"
echo "  2) App Store için .ipa dosyası üret (Apple Developer hesabı gerekir, yıllık 99 dolar)"
read -r -p "Seçimin (1 veya 2): " SECIM

if [ "$SECIM" = "1" ]; then
  open ios/App/App.xcodeproj
  cat <<'YAZI'

Xcode açıldı. Şunları yap:
  a) Xcode > Settings > Accounts: Apple kimliğinle giriş yap.
  b) Soldan mavi "App" simgesine tıkla > TARGETS: App > "Signing & Capabilities".
     "Team" kutusundan kendi adını seç.
  c) iPhone'u kabloyla Mac'e bağla, üstteki cihaz listesinden iPhone'unu seç, ▶ düğmesine bas.
  d) iPhone'da: Ayarlar > Genel > VPN ve Cihaz Yönetimi > kendi adın > Güven.
     (iPhone'da "Geliştirici Modu" sorulursa: Ayarlar > Gizlilik ve Güvenlik > Geliştirici Modu > Aç)
Ücretsiz hesapla yüklenen uygulama 7 gün çalışır; sonra ▶ ile yeniden yükle.
YAZI
  dur 0
fi

if [ "$SECIM" = "2" ]; then
  echo
  echo "Önce Xcode > Settings > Accounts bölümünde Apple Developer hesabınla giriş yapmış olmalısın."
  echo "Team ID: https://developer.apple.com/account adresinde 'Membership details' altında, 10 harf/rakam."
  read -r -p "Team ID: " TEAM
  [ ${#TEAM} -eq 10 ] || { echo "Team ID 10 karakter olmalı."; dur 1; }
  mkdir -p CIKTI
  cat > /tmp/ExportOptions.plist <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>app-store-connect</string>
  <key>teamID</key><string>$TEAM</string>
  <key>signingStyle</key><string>automatic</string>
  <key>destination</key><string>export</string>
</dict></plist>
PLIST
  echo "Arşivleniyor (birkaç dakika sürer)..."
  xcodebuild -project ios/App/App.xcodeproj -scheme App -configuration Release \
    -destination "generic/platform=iOS" -archivePath CIKTI/OrmaninKalbi.xcarchive \
    DEVELOPMENT_TEAM="$TEAM" CODE_SIGN_STYLE=Automatic -allowProvisioningUpdates archive -quiet || { echo "Arşivleme başarısız. Xcode'da hesapla giriş yaptığından emin ol."; dur 1; }
  xcodebuild -exportArchive -archivePath CIKTI/OrmaninKalbi.xcarchive -exportPath CIKTI \
    -exportOptionsPlist /tmp/ExportOptions.plist -allowProvisioningUpdates -quiet || { echo "Dışa aktarma başarısız."; dur 1; }
  IPA=$(ls CIKTI/*.ipa 2>/dev/null | head -1)
  echo
  echo "HAZIR: $IPA"
  echo "App Store'a göndermek için Mac App Store'dan ücretsiz 'Transporter' uygulamasını kur,"
  echo "Apple hesabınla gir ve bu .ipa dosyasını içine sürükle. Sonra appstoreconnect.apple.com'dan incelemeye gönder."
  open CIKTI
  dur 0
fi
echo "Geçersiz seçim."; dur 1
